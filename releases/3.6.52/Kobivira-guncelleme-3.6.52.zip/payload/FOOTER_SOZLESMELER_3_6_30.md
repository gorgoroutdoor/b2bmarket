# Kobivira 3.6.30 — Footer ve hukuki sayfalar

3.6.29 üzerine imzalı güncellemedir. Sunucu kurulumu ve PayTR canlı modu değiştirilmez. 46 mevcut migration korunur; 047_footer_contracts içerik ekler.

## Footer

Kobivira tanıtım sitesinde Logo | Ürün ve Hizmetler | Kaynaklar | Sözleşmeler ve Politikalar | Kurumsal düzeni kullanılır. Mevcut footer kayıtları silinmez, gizlenmez veya yeniden adlandırılmaz. Logo, açıklama, e-posta, diğer sütunlar ve tüm mevcut bağlantılar korunur. Yeni sütun ve sayfa bağlantıları eklenir. Telefon ve tablette sütunlar alt alta veya ikili düzene geçer. Firma müşterilerinin ayrı kurumsal sitelerine Kobivira sözleşmeleri eklenmez.

Logo altında Instagram https://www.instagram.com/kobivira/ ve Facebook https://www.facebook.com/kobivira/ bağlantıları bulunur. Yeni sekmede açılır; noopener/noreferrer kullanılır. Ödeme satırında Visa, Mastercard, TROY ve PayTR görselleri bulunur. Görseller paketin içindedir; ziyaretçinin tarayıcısında logo sunucularına dış istek yapılmaz. Kaynaklar Footer3630Assets.json içinde kayıtlıdır.

## Sayfalar ve düzenleme

Site yönetimi → Hukuki metinler:

- Üyelik ve Yazılım Hizmet Sözleşmesi — uyelik-hizmet-sozlesmesi.html
- Mesafeli Satış / Hizmet Sözleşmesi — mesafeli-satis-sozlesmesi.html
- Ön Bilgilendirme Formu — on-bilgilendirme.html
- Hizmetin Sunulması, İptal ve İade Koşulları — teslimat-iptal-iade.html
- KVKK Aydınlatma Metni — kvkk.html (mevcut yayımlanmış metin korunur; yoksa eklenir)

İçerik değişikliği yeni hukuki sürüm oluşturur. Yayımlama, aynı footer adresindeki metni günceller. Önceki yayımlar ve kayıt onayları değiştirilmez. Sayfalar bölümünden bu sayfaların düzenleme bağlantıları hukuki sürüm editörüne gider. Önceden aynı adreste içerik varsa üzerine yeni genel metin yazılmaz. Gizlilik, çerezler, kullanım, hakkımızda ve iletişim sayfaları korunur.

Site yönetimi → Tanıtım sitesi → Menüler: Footer / Sözleşmeler ve Politikalar alanı eklenir. Bağlantı adı, adresi, sırası, sütunu ve görünürlüğü düzenlenebilir. Gizlenen/yayından kaldırılan sayfaların menü bağlantısını da yönetici buna göre güncellemelidir.

Site yönetimi → Tanıtım sitesi → Site / SEO ayarları: Dört sütun başlığı, Instagram/Facebook adresleri, sosyal bağlantılar ve ödeme logolarının görünürlüğü düzenlenebilir. Aynı alanda hizmet sağlayıcının tam ticari unvanı, VKN/TCKN, vergi dairesi, MERSİS, ticaret sicili ve KEP bilgileri vardır. Adres, telefon ve iletişim e-postası mevcut site ayarlarından alınır. Kimlik kartı hukuki sayfalarda ve iletişim sayfasında gösterilir. Boş bilgiler uydurularak doldurulmaz; canlı satış öncesinde gerçek hizmet sağlayıcı bilgilerinin yönetici tarafından tamamlanması gerekir.

## Kapsam ve yayın öncesi içerik kontrolü

Metinler yazılım aboneliğine uyarlanmıştır; fiziksel kargo, karttan otomatik yenileme, otomatik kontör veya sağlayıcı hesabı açma vaat edilmez. Ticari müşteri / tüketici ayrımı yalnız kimlik numarasına bağlanmaz. Tüketici hakları ve istisnalar koşullu anlatılır; otomatik olarak herkese iade yasağı getirilmez.

Bu sürüm footer ve kamuya açık metinlerin yönetimidir. Siparişe özel doldurulmuş ön bilgilendirme belgesi, her ödeme için yeni sözleşme onayı/sürüm anlık görüntüsü veya otomatik e-posta gönderimi eklenmez. Kamuya açık ön bilgilendirme sayfası tek başına siparişe özgü ön bilgilendirme yükümlülüğünün tamamlandığı anlamına gelmez. Mevcut kayıt onayları ve ödeme işlemleri değişmez. Yayımlanacak sözleşmeler hizmet sağlayıcı, veri işleme envanteri ve satış modeline göre hukuk danışmanıyla gözden geçirilmelidir. Teknik testler hukuki uygunluk onayı değildir.

Resmî kaynaklar: https://www.paytr.com/destek-merkezi/basvuru ; https://tuketici.ticaret.gov.tr/yayinlar/tuketici-bilgi-rehberi/mesafeli-sozlesmeler-hakkinda-bilgilendirme ; https://tuketici.ticaret.gov.tr/yayinlar/tuketici-bilgi-rehberi/abonelik-sozlesmeleri-hakkinda-bilgilendirme ; https://www.kvkk.gov.tr/Icerik/7595/2022-1358 .

## Doğrulama

287 PHP/veritabanı kontrolü ve 87 yerel HTTP kontrolü: eski sayfa/menü/ayar/yayımların korunması, beş sütun, dört paketli logo, iki sosyal bağlantı, kamuya açık sözleşme sayfaları, sürümlü yönetici yayını, eski sürüm erişimi, menü düzenleme, sütun başlığı, hizmet sağlayıcı alanları, görünürlük anahtarları ve güvensiz sosyal URL reddi dahil. Mevcut alıcı formunda 9, firma kimliğinde 3 DOM kontrolü. 155 PHP kaynak sözdizimi kontrolü. Tam tarayıcı görsel testi ve canlı sunucu kurulumu yapılmadı.
