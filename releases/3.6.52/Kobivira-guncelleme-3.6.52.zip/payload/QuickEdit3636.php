<?php
declare(strict_types=1);
function quick3636_url(string $view,int $id=0,string $anchor=''):string {
 $args=['page'=>'site_admin','site'=>1,'view'=>$view];if($id)$args['edit']=$id;return 'https://app.kobivira.com.tr/?'.http_build_query($args).($anchor!==''?'#'.rawurlencode($anchor):'');
}
function quick3636_control(string $url,string $label='Düzenle'):string {
 return '<span class="kv36-edit-control" data-kv36-control '.(cms_platform()?'':'hidden').'><a href="'.esc($url).'" target="_blank" rel="noopener noreferrer" aria-label="'.esc($label).'">'.esc($label).' ↗</a></span>';
}
function quick3636_record(array $row,string $entity,int $sid):string {
 $raw=$row['content_html'];if($sid!==1||!in_array($entity,['pages','blocks'],true)||($row['kind']??'')==='guide')return cms_fields_html($row);
 if(($row['block_key']??'')==='home-1')$raw=quick3636_hero($raw,(int)$row['id']);
 preg_match_all('~<(section|article|div)\b([^>]*)>~i',$raw,$matches,PREG_SET_ORDER|PREG_OFFSET_CAPTURE);$patches=[];
 foreach($matches as $m){$tag=strtolower($m[1][0]);$attrs=$m[2][0];$pos=$m[0][1];$classes=preg_match('/class="([^"]*)"/',$attrs,$c)?$c[1]:'';
  $card=$tag==='article'||$tag==='section'||($tag==='div'&&preg_match('/\b(?:kv32-contact|kv32-contact-card|kv33-package-card|kv32-story|guide-card|feature-card)\b/',$classes));if(!$card)continue;
  if(($row['block_key']??'')==='home-2'&&$tag==='section'&&!str_contains($attrs,'data-kv32-panel'))continue;
  $tail=substr($raw,$pos+strlen($m[0][0]));$anchor=preg_match('/\{\{field:([^}]+)\}\}/',$tail,$field)?'cms-field-'.$field[1]:'';
  $url=quick3636_url($entity,(int)$row['id'],$anchor);$open=$m[0][0];$open=preg_match('/class="/',$open)?preg_replace('/class="([^"]*)"/','class="$1 kv36-editable"',$open,1):substr($open,0,-1).' class="kv36-editable">';$patches[]=[$pos,strlen($m[0][0]),$open.quick3636_control($url)];
 }
 foreach(array_reverse($patches) as [$pos,$len,$replace])$raw=substr_replace($raw,$replace,$pos,$len);$raw=preg_replace_callback('~<details\b([^>]*)>(.*?)</details>~s',function($m)use($entity,$row){$anchor=preg_match('/\{\{field:([^}]+)\}\}/',$m[2],$field)?'cms-field-'.$field[1]:'';return '<div class="kv36-faq-wrap">'.quick3636_control(quick3636_url($entity,(int)$row['id'],$anchor)).$m[0].'</div>';},$raw)??$raw;return cms_fields_html(array_replace($row,['content_html'=>$raw]));
}
function quick3636_page_id(string $slug):int {static $map;if($map===null)$map=array_column(query('SELECT id,slug FROM cms_pages WHERE site_id=1')->fetchAll(),'id','slug');return (int)($map[$slug]??0);}
function quick3636_link_cards(string $body):string {
 return preg_replace_callback('~<a\b([^>]*)>(.*?)</a>~s',function($m){if(!preg_match('/class="([^"]*(?:guide-card|editorial-card|kv33-feature-card|kv36-related-card)[^"]*)"/',$m[1]))return $m[0];if(!preg_match('/href="([a-z0-9-]+)\.html(?:#[^"]*)?"/',$m[1],$href))return $m[0];$id=quick3636_page_id($href[1]);if(!$id)return $m[0];return '<div class="kv36-card-wrap">'.quick3636_control(quick3636_url('pages',$id)).$m[0].'</div>';},$body)??$body;
}
function quick3636_visual(string $html,string $slug):string {$id=quick3636_page_id($slug);if(!$id)return $html;return '<div class="kv36-card-wrap kv36-visual-wrap">'.quick3636_control(quick3636_url('pages',$id,'product-image')).$html.'</div>';}
function quick3636_home_visual(string $html,string $topic):string {$id=(int)query("SELECT id FROM cms_blocks WHERE site_id=1 AND block_key='home-2'")->fetchColumn();return $id?'<div class="kv36-card-wrap kv36-visual-wrap">'.quick3636_control(quick3636_url('blocks',$id,'home-image-'.$topic)).$html.'</div>':$html;}
function quick3636_hero(string $raw,int $id):string {
 foreach(['photo'=>['assets/kobivira-isletme3632.webp','Ana sayfa görseli'],'panel'=>['assets/panel-hero.png','Panel ekranı']] as $key=>$info){$mid=(int)cms_s('home3636_hero_'.$key,'0',1);$media=$mid?query('SELECT filename,alt_text FROM cms_media WHERE site_id=1 AND id=?',[$mid])->fetch():null;if($media)$raw=preg_replace_callback('~<img\b[^>]*src="'.preg_quote($info[0],'~').'"[^>]*>~',fn($m)=>preg_replace('/src="[^"]*"/','src="?page=site_media&amp;media='.esc($media['filename']).'"',$m[0],1),$raw,1);}
 $raw=str_replace('<div class="kv32-hero-visual">','<div class="kv32-hero-visual kv36-editable">'.quick3636_control(quick3636_url('blocks',$id,'hero-image-photo')),$raw);return str_replace('<div class="kv32-screen">','<div class="kv32-screen kv36-editable">'.quick3636_control(quick3636_url('blocks',$id,'hero-image-panel')),$raw);
}
function quick3636_hero_editor():void {$options=[0=>'Mevcut görsel'];foreach(query('SELECT id,name FROM cms_media WHERE site_id=1 ORDER BY id DESC') as $m)$options[$m['id']]=$m['name'];foreach(['photo'=>'Ana sayfa ana görseli','panel'=>'Hero üzerindeki panel ekranı'] as $key=>$label){echo '<div class="wide" id="hero-image-'.esc($key).'">';select_field('hero36_'.$key,$label,$options,(int)cms_s('home3636_hero_'.$key,'0',1));quick3636_upload_editor('hero_upload_'.$key,(int)cms_s('home3636_hero_'.$key,'0',1),'?page=site_asset&asset='.($key==='photo'?'kobivira-isletme3632.webp':'panel-hero.png'));echo '</div>';}}
function quick3636_save_hero():void {foreach(['photo','panel'] as $key){if(!isset($_POST['hero36_'.$key]))continue;$id=int_field('hero36_'.$key,0,PHP_INT_MAX);$uploaded=quick3636_upload('hero_upload_'.$key,'Ana sayfa '.$key);if($uploaded!==null)$id=$uploaded;if($id&&!query('SELECT 1 FROM cms_media WHERE site_id=1 AND id=?',[$id])->fetchColumn())throw new DomainException('Bu siteye ait bir görsel seçin.');$name='home3636_hero_'.$key;cms_history('settings',0,[$name=>cms_s($name,'0',1)]);cms_setting($name,(string)$id,1);}}
function quick3636_upload_editor(string $field,int $id,string $fallback=''):void {
 $m=$id?query('SELECT filename,alt_text FROM cms_media WHERE site_id=1 AND id=?',[$id])->fetch():null;$src=$m?'?page=site_media&media='.$m['filename']:$fallback;echo '<div class="wide kv36-upload-slot">';if($src!=='')echo '<img class="kv36-upload-thumb" src="'.esc($src).'" alt="Mevcut görsel" width="180" height="112">';echo '<label class="field"><span>Görsel yükle / değiştir</span><input type="file" name="'.esc($field).'" accept="image/png,image/jpeg,image/webp"></label><p class="field-hint">PNG, JPG veya WebP · en fazla 4 MB. Dosyayı seçip bu ekrandaki Kaydet düğmesine basın.</p></div>';
}
function quick3636_upload(string $field,string $label):?int {
 $file=$_FILES[$field]??null;if(!$file||($file['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)return null;if(!is_array($file)||is_array($file['error']??null)||($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||!is_string($file['tmp_name']??null)||!is_uploaded_file($file['tmp_name'])||($file['size']??0)>4194304)throw new DomainException('En fazla 4 MB PNG, JPG veya WebP seçin.');$info=@getimagesize($file['tmp_name']);$ext=[IMAGETYPE_PNG=>'png',IMAGETYPE_JPEG=>'jpg',IMAGETYPE_WEBP=>'webp'][$info[2]??0]??null;if(!$ext||$info[0]>6000||$info[1]>6000)throw new DomainException('Görsel en fazla 6000 piksel olmalıdır.');cms_media_capacity(1,(int)filesize($file['tmp_name']));$dir=APP_ROOT.'/storage/site-media';if(!is_dir($dir)&&!mkdir($dir,0700,true)&&!is_dir($dir))throw new DomainException('Görsel klasörü oluşturulamadı.');$name=bin2hex(random_bytes(16)).'.'.$ext;$path=$dir.'/'.$name;if(!move_uploaded_file($file['tmp_name'],$path))throw new DomainException('Görsel yüklenemedi.');$GLOBALS['quick3636_upload_paths'][]=$path;chmod($path,0600);query('INSERT INTO cms_media(site_id,name,filename,alt_text,created_at) VALUES (1,?,?,?,UTC_TIMESTAMP())',[$label,$name,$label]);return (int)db()->lastInsertId();
}
function quick3636_upload_cleanup():void {foreach($GLOBALS['quick3636_upload_paths']??[] as $path)if(is_file($path))@unlink($path);unset($GLOBALS['quick3636_upload_paths']);}
