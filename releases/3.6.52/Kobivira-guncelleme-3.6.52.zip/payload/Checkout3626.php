<?php
declare(strict_types=1);
function checkout3626_marked(int $cid):bool {return (bool)query('SELECT company_id FROM checkout_test_accounts WHERE company_id=?',[$cid])->fetchColumn();}
function checkout3626_state(int $cid):array {return refund356_state($cid);}
/** Called within the administrator's configuration transaction; no existing paid company can enter. */
function checkout3626_designate(int $cid):void {
 query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$cid]);$marker=query('SELECT * FROM checkout_test_accounts WHERE company_id=? FOR UPDATE',[$cid])->fetch();$state=checkout3626_state($cid);
 if($marker){if(json_decode($marker['last_state'],true,32,JSON_THROW_ON_ERROR)!==$state)throw new DomainException('Test hesabının üyeliği dışarıdan değiştirilmiş. Mevcut durum teknik olarak incelenmeli.');return;}
 if($state['has_paid_membership']||$state['paid_until']!==null||query("SELECT id FROM payment_orders WHERE company_id=? AND status='approved' LIMIT 1",[$cid])->fetchColumn())throw new DomainException('Gerçek veya geçmiş ücretli üyeliği bulunan firma test hesabı yapılamaz. Yeni oluşturduğunuz ayrı firmayı seçin.');
 if(query("SELECT id FROM gateway_payments WHERE company_id=? AND mode='live' LIMIT 1",[$cid])->fetchColumn())throw new DomainException('Canlı ödeme geçmişi bulunan firma test hesabı yapılamaz.');
 $json=json_encode($state,JSON_THROW_ON_ERROR);query('INSERT INTO checkout_test_accounts(company_id,before_state,last_state,created_at,updated_at) VALUES (?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())',[$cid,$json,$json]);
}
/** No receipts, revenue, gifts, credits or referral effects. Only the designated account's workspace subscription changes. */
function checkout3626_activate(array $o,array $g):void {
 $cid=(int)$o['company_id'];if($g['mode']!=='sandbox'||(int)$g['test_activation']!==1||$o['status']!=='awaiting_card')throw new DomainException('Test etkinleştirme izni bulunamadı.');
 $marker=query('SELECT * FROM checkout_test_accounts WHERE company_id=? FOR UPDATE',[$cid])->fetch();if(!$marker)throw new DomainException('Firma test hesabı değil.');$s=checkout3626_state($cid);
 if($s['has_paid_membership']||json_decode($marker['last_state'],true,32,JSON_THROW_ON_ERROR)!==$s)throw new DomainException('Test hesabının üyelik koşulları değişmiş.');
 if(query('SELECT status FROM companies WHERE id=?',[$cid])->fetchColumn()!=='active')throw new DomainException('Test hesabı kısıtlı.');$plan=query('SELECT * FROM plans WHERE id=? FOR UPDATE',[$o['plan_id']])->fetch();
 if(!in_array($plan['code']??'',['kobi','plus','business'],true))throw new DomainException('Test paketi geçersiz.');$count=(int)query("SELECT COUNT(*) FROM users WHERE company_id=? AND is_active=1 AND is_deleted=0 AND role<>'accountant'",[$cid])->fetchColumn();if($count>(int)$plan['user_limit'])throw new DomainException('Test paketinin kullanıcı sınırı aşılıyor.');
 $bonus=terms354_bonus($o,$s);$now=new DateTimeImmutable('now',new DateTimeZone('UTC'));$start=$now;if((int)$s['plan_id']===(int)$o['plan_id']&&$s['status']==='active'&&$s['paid_until']&&strtotime($s['paid_until'].' UTC')>time())$start=new DateTimeImmutable($s['paid_until'],new DateTimeZone('UTC'));
 $end=add_months_utc($start,(int)$o['months'])->modify('+'.$bonus.' seconds')->format('Y-m-d H:i:s');query("UPDATE subscriptions SET plan_id=?,status='active',paid_until=?,period_started_at=?,has_paid_membership=0 WHERE company_id=?",[$o['plan_id'],$end,$start>$now?$s['period_started_at']:$now->format('Y-m-d H:i:s'),$cid]);query('UPDATE membership_terms354 SET applied_bonus_seconds=? WHERE payment_order_id=?',[$bonus,$o['id']]);
 query('UPDATE checkout_test_accounts SET last_state=?,updated_at=UTC_TIMESTAMP() WHERE company_id=?',[json_encode(checkout3626_state($cid),JSON_THROW_ON_ERROR),$cid]);query("INSERT INTO audit_logs(company_id,actor_name,action,metadata,created_at) VALUES (?,'PayTR test','billing.test_activated',?,UTC_TIMESTAMP())",[$cid,json_encode(['order'=>$o['id'],'plan'=>$plan['code'],'paid_until'=>$end,'reason'=>'Yalnız ayrılmış test hesabının paketi değişti; tahsilat veya kontör etkisi yok.'],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);
}
function checkout3626_test_result(array $o,array $g):string {
 if($g['mode']!=='sandbox'||empty($g['test_activation']))return 'Test ödemesi doğrulandı. Gerçek üyelik ve kontör değişmedi.';
 db()->exec('SAVEPOINT test_membership');try{checkout3626_activate($o,$g);db()->exec('RELEASE SAVEPOINT test_membership');return 'Test ödemesi doğrulandı. Seçilen paket ve süre yalnız bu test hesabında güncellendi.';}catch(DomainException){db()->exec('ROLLBACK TO SAVEPOINT test_membership');db()->exec('RELEASE SAVEPOINT test_membership');admin_notification((int)$o['company_id'],'test-activation:'.$g['id'],'payment_test','Test paketi kontrol edilmeli','Test ödemesi doğrulandı; hesap koşulları değiştiğinden paket güncellenmedi.',(int)$o['id']);return 'Test ödemesi doğrulandı; test hesabının koşulları değiştiğinden paket güncellenmedi. Yönetici kontrolü gerekli.';}
}
function checkout3626_reset():never {
 admin351_guard();reauthenticate(base_user());$cid=int_field('test_company',1,PHP_INT_MAX);
 transaction(function()use($cid){query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$cid]);$m=query('SELECT * FROM checkout_test_accounts WHERE company_id=? FOR UPDATE',[$cid])->fetch();if(!$m)throw new DomainException('Bu firma ayrılmış test hesabı değil.');
 if(query("SELECT id FROM gateway_payments WHERE company_id=? AND callback_status IS NULL AND status IN ('created','requesting','ready','unknown') LIMIT 1",[$cid])->fetchColumn())throw new DomainException('Sonuçlanmamış ödeme var; PayTR sonucu kesinleşmeden test hesabı sıfırlanamaz.');
 if(checkout3626_state($cid)!==json_decode($m['last_state'],true,32,JSON_THROW_ON_ERROR))throw new DomainException('Üyelik test dışında değişmiş. Mevcut üyelik otomatik geri alınamaz.');$s=json_decode($m['before_state'],true,32,JSON_THROW_ON_ERROR);
 query('UPDATE subscriptions SET plan_id=?,status=?,trial_ends_at=?,paid_until=?,period_started_at=?,has_paid_membership=? WHERE company_id=?',[$s['plan_id'],$s['status'],$s['trial_ends_at'],$s['paid_until'],$s['period_started_at'],$s['has_paid_membership'],$cid]);query("UPDATE payment_orders o SET status='cancelled' WHERE o.company_id=? AND o.payment_method='card' AND o.status='awaiting_card' AND NOT EXISTS (SELECT 1 FROM gateway_payments g WHERE g.membership_order_id=o.id)",[$cid]);query('DELETE FROM checkout_test_accounts WHERE company_id=?',[$cid]);$cfg=checkout3624_config();if((int)$cfg['test_company']===$cid){$cfg['test_activation']=0;query("UPDATE settings SET value=? WHERE name='paytr_checkout3624'",[json_encode($cfg,JSON_THROW_ON_ERROR)]);}audit('billing.test_reset',['company'=>$cid]);});flash('Test öncesi üyelik geri getirildi. Test ödeme kayıtları korundu.');redirect('service_admin',['provider'=>'paytr']);
}
function checkout3626_notice():void {
 if(owner()||!current_user()||!checkout3626_marked(company_id()))return;echo '<div class="info-note" role="status">Bu firma ödeme testi için ayrılmıştır. Paket ve süre değişiklikleri test amaçlıdır; gerçek tahsilat, kontör yükleme veya canlı e-Belge işlemi yapılmaz.</div>';
}
function checkout3626_reset_view():void {
 $rows=query('SELECT c.id,c.name,c.account_number FROM checkout_test_accounts t JOIN companies c ON c.id=t.company_id ORDER BY c.name')->fetchAll();if(!$rows)return;panel('Ayrılmış test hesapları');form_start('service_admin','reset_test_membership',['provider'=>'paytr']);select_field('test_company','Test öncesi üyeliği geri getirilecek firma',array_column(array_map(fn($r)=>['id'=>$r['id'],'label'=>$r['name'].' · '.$r['account_number']],$rows),'label','id'));input('current_password','Kobivira yönetici şifreniz','','password','required');form_end('Test öncesi üyeliği geri getir');echo '</section>';
}
