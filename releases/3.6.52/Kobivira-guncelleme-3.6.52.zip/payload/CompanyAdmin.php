<?php
declare(strict_types=1);
function company_admin_navigation(array $c,string $view): void {
 echo '<nav class="desk-actions no-print" aria-label="Firma yönetimi bölümleri">';
 foreach(['membership'=>'Üyeliği düzenle','verification'=>'Firma doğrulama','credits'=>'Kontör yönetimi','security'=>'Yönetici şifresi'] as $key=>$label)echo a('companies',esc($label),['edit'=>$c['id'],'view'=>$key],'button '.($view===$key?'primary':'quiet'));
 echo (admin3641_enabled()?'':a('companies','Firma oluştur',['view'=>'new'],'button quiet')).'</nav><br>';
}
function company_admin_view(): void {
 require_owner();$view=is_string($_GET['view']??null)?$_GET['view']:'membership';
 if(!in_array($view,['membership','verification','credits','security','new'],true)){http_response_code(404);throw new DomainException('Firma yönetimi bölümü bulunamadı.');}
 // Keep the submitted form on its own screen when validation fails, including old links.
 if($_SERVER['REQUEST_METHOD']==='POST'&&($_POST['action']??'')==='create')$view='new';
 $id=isset($_GET['edit'])?filter_var($_GET['edit'],FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]):null;
 if($id===false){http_response_code(404);throw new DomainException('Firma bulunamadı.');}
 if($view==='new'){
  heading('Firma oluştur','Yeni firma ve firma yöneticisi hesabını oluşturun.',a('companies','Firma listesine dön',[],'button'));
  panel('Yeni firma');form_start('companies','create',['view'=>'new']);input('company','Firma unvanı','','text','required maxlength="160"');input('name','Firma yöneticisinin adı','','text','required maxlength="100"');input('email','Firma yöneticisinin e-postası','','email','required');input('password','İlk giriş şifresi','','password','required minlength="8" maxlength="72" autocomplete="new-password"');select_field('plan_id','Paket',array_column(query('SELECT id,name FROM plans WHERE is_active=1 ORDER BY id')->fetchAll(),'name','id'));form_end('Firmayı oluştur');echo '</section>';return;
 }
 if(!$id){if($view!=='membership'){http_response_code(404);throw new DomainException('Önce firma listesinden bir firma seçin.');}heading('Firmalar ve üyelikler','Firmaları arayın; üyeliklerini düzenleyin veya canlı inceleme başlatın.',a('companies',icon('plus').' Firma oluştur',['view'=>'new'],'button primary'));company_admin_list();return;}
 $c=query('SELECT c.*,s.plan_id,s.status subscription_status,s.trial_ends_at,s.paid_until FROM companies c JOIN subscriptions s ON s.company_id=c.id WHERE c.id=?',[$id])->fetch();
 if(!$c){http_response_code(404);throw new DomainException('Firma bulunamadı.');}
 $titles=['membership'=>'Üyeliği düzenle','verification'=>'Firma doğrulama','credits'=>'Kontör yönetimi','security'=>'Yönetici şifresi'];heading($titles[$view].' · '.$c['name'],'Firma işlemlerini üstteki bölüm düğmelerinden yönetin.',a('companies','Firma listesine dön',[],'button'));company_admin_navigation($c,$view);
 if($view==='verification'){
  $tab=is_string($_GET['verification_tab']??null)?$_GET['verification_tab']:'documents';if(!in_array($tab,['documents','history'],true)){http_response_code(404);throw new DomainException('Firma doğrulama bölümü bulunamadı.');}
  echo '<nav class="desk-actions no-print" aria-label="Firma doğrulama bölümleri">';foreach(['documents'=>'Firma evrakları','history'=>'Firma inceleme geçmişi'] as $key=>$label)echo a('companies',esc($label),['edit'=>$id,'view'=>'verification','verification_tab'=>$key],'button '.($tab===$key?'primary':'quiet'));echo '</nav><br>';
  if($tab==='history')review_history($id,true);else evidence_admin_company_view($c,false);return;
 }
 if($view==='membership'){
  panel('Üyelik bilgileri');if($c['subscription_status']==='trial')echo '<div class="info-note">Bu firma ücretsiz deneme hesabıdır. Gelişmiş panel özellikleri ücretsiz kullanım kapsamıyla açılır. Aşağıdaki paket seçimi ücretli üyelik etkinleştirildiğinde geçerlidir.</div>';form_start('companies','subscription',['edit'=>$id,'view'=>'membership']);hidden('company_id',$id);select_field('plan_id','Paket',array_column(query("SELECT id,name FROM plans WHERE code IN ('kobi','plus','business') ORDER BY FIELD(code,'kobi','plus','business')")->fetchAll(),'name','id'),$c['plan_id']);select_field('status','Üyelik durumu',['trial'=>'Deneme','active'=>'Aktif · ödeme alındı','expired'=>'Süresi dolmuş'],$c['subscription_status']);input('until','Bitiş tarihi · seçilen gün Türkiye saatiyle 23.59’a kadar',substr($c['subscription_status']==='active'?($c['paid_until']??today()):$c['trial_ends_at'],0,10),'date','required');select_field('company_status','Firma erişimi',['active'=>'Açık','suspended'=>'Askıda'],$c['status']);select_field('restriction_code','Firmaya gösterilecek erişim mesajı',array_map(fn($v)=>$v[0],restriction_catalog()),$c['restriction_code']);input('restriction_reason','Özel açıklama · yalnızca özel mesaj seçeneğinde',$c['restriction_reason'],'text','maxlength="300"');echo '<div id="restriction-preview" class="info-note wide" data-catalog="'.esc(json_encode(restriction_catalog(),JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)).'"><strong></strong><p></p></div>';form_end('Üyeliği kaydet');echo '</section>';
  if(!admin3641_enabled())company352_credits($c);delete_company_form($c,true);return;
 }
 if($view==='credits'){
  company352_credits($c);return;
 }
 panel('Firma yöneticisi şifresini yenile');form_start('companies','reset_password',['edit'=>$id,'view'=>'security']);hidden('company_id',$id);input('password','Yeni firma yöneticisi şifresi','','password','required minlength="8" maxlength="72" autocomplete="new-password"');input('current_password','Platform yöneticisinin mevcut şifresi','','password','required autocomplete="current-password"');form_end('Şifreyi yenile');echo '</section>';
}
function company_admin_list(): void {
 [$q,$filter,$where,$args]=company_filter();panel('Firma listesi');echo '<form class="filter-bar" method="get">';hidden('page','companies');input('q','Firma, yönetici veya e-posta ara',$q,'search','placeholder="Firma adından birkaç kelime"');select_field('state','Durum',[''=>'Tüm firmalar','new'=>'Son 7 gün kayıtları','trial'=>'Deneme','active'=>'Aktif ücretli paket','expired'=>'Süresi biten','suspended'=>'Askıdaki','payments'=>'Ödeme onayı bekleyen'],$filter);submit('Ara','primary');echo '</form>';
 $count=(int)query('SELECT COUNT(*) FROM companies c JOIN subscriptions s ON s.company_id=c.id'.$where,$args)->fetchColumn();$page=max(1,min(100000,(int)($_GET['p']??1)));$pages=max(1,(int)ceil($count/25));$page=min($page,$pages);$offset=($page-1)*25;
 $rs=query('SELECT c.*,p.name plan_name,s.status subscription_status,s.trial_ends_at,s.paid_until FROM companies c JOIN subscriptions s ON s.company_id=c.id JOIN plans p ON p.id=s.plan_id'.$where.' ORDER BY c.id DESC LIMIT 25 OFFSET '.$offset,$args)->fetchAll();
 table_start(['Firma','Paket','Üyelik','Bitiş','Kontör','Erişim','İşlemler']);foreach($rs as $r){$state=subscription_state(['status'=>$r['subscription_status'],'paid_until'=>$r['paid_until'],'trial_ends_at'=>$r['trial_ends_at']]);echo '<tr><td><strong>'.esc($r['name']).'</strong><small>#'.$r['id'].'</small></td><td>'.esc(($r['subscription_status']==='trial')?'Ücretsiz deneme':$r['plan_name']).'</td><td>'.esc($state).'</td><td>'.date_tr($r['subscription_status']==='active'?($r['paid_until']??$r['trial_ends_at']):$r['trial_ends_at']).'</td><td>'.$r['credits_balance'].'</td><td>'.($r['status']==='active'?'Açık':'Askıda').'</td><td><div class="desk-actions">'.a('companies','Üyeliği düzenle',['edit'=>$r['id']],'button quiet');small_action('support','request','Firmayı canlı incele',['company_id'=>$r['id']],'primary');echo '</div></td></tr>';}
 table_end(count($rs),7);echo '<div class="panel-bottom"><span>'.$count.' firma · Sayfa '.$page.' / '.$pages.'</span><span>';if($page>1)echo a('companies','Önceki',['q'=>$q,'state'=>$filter,'p'=>$page-1],'button');if($page<$pages)echo ' '.a('companies','Sonraki',['q'=>$q,'state'=>$filter,'p'=>$page+1],'button');echo '</span></div></section>';
}

function company352_credits(array $c): void {gift354_admin($c);$id=(int)$c['id'];panel('Kontör bakiyesi · '.$c['credits_balance']);form_start('billing','credit');hidden('company_id',$id);hidden('request_key',form_key());input('delta','Eklenecek / düşülecek kontör · ör. 100 veya -20','0','number','required min="-1000000" max="1000000"');input('reason','İşlem açıklaması','','text','required maxlength="300"');input('current_password','Mevcut yönetici şifreniz','','password','required autocomplete="current-password"');form_end('Kontör bakiyesini güncelle');echo '</section>';}
