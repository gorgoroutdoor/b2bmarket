(() => {
 const body=document.body;
 const preview=document.getElementById('restriction-preview'),choice=document.querySelector('[name=restriction_code]');
 if(preview&&choice){const catalog=JSON.parse(preview.dataset.catalog);const update=()=>{const item=catalog[choice.value];preview.querySelector('strong').textContent=item?.[0]||'';preview.querySelector('p').textContent=item?.[1]||'';const custom=document.querySelector('[name=restriction_reason]')?.closest('label');if(custom)custom.hidden=choice.value!=='custom';};choice.addEventListener('change',update);update();}
 document.querySelector('form:has([name=company_logo])')?.setAttribute('enctype','multipart/form-data');
 let seen=null;
 document.addEventListener('kobivira:poll-data',e=>{
  const n=e.detail.notifications;if(!n)return;const badge=document.getElementById('notification-count');if(badge){badge.textContent=n.unread?String(n.unread):'';badge.hidden=!n.unread;}
  const newest=n.items?.[0];if(!newest)return;
  const key='kobivira-notifications-seen';if(seen===null){try{seen=Number(sessionStorage.getItem(key))||0}catch{seen=0;}}
  if(newest.id<=seen)return;seen=newest.id;try{sessionStorage.setItem(key,String(seen))}catch{}
  const alert=document.getElementById('notification-live-alert');if(alert){alert.hidden=false;alert.querySelector('strong').textContent=newest.title;alert.querySelector('p').textContent=newest.body;const link=alert.querySelector('[data-notification-target]');link.href='?page='+encodeURIComponent(newest.target_page)+'&id='+encodeURIComponent(newest.target_id);}
 });
 document.querySelector('[data-dismiss-notification]')?.addEventListener('click',()=>document.getElementById('notification-live-alert').hidden=true);
})();
