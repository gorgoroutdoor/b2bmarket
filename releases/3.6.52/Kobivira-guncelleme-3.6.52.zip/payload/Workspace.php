<?php
declare(strict_types=1);
function section_links(string $page,string $key,array $sections,string $selected): void {
 echo '<nav class="desk-actions no-print" aria-label="Bölümler">';foreach($sections as $id=>$label)echo '<a class="button '.($id===$selected?'primary':'quiet').'" '.($id===$selected?'aria-current="page" ':'').'href="'.esc(url($page,[$key=>$id])).'">'.esc($label).'</a>';echo '</nav><br>';
}
function task_categories(): array {return ['general'=>'Genel','purchase'=>'Satın alma','sale'=>'Satış','customer'=>'Müşteri takibi','administrative'=>'İdari işler','other'=>'Diğer'];}
function task_states(): array {return ['open'=>'Açık','closed'=>'Sonlandırıldı','completed'=>'Tamamlandı'];}
function work_task_post(string $action): never {
 need_feature('tasks');require_write();
 $id=company_transaction(function()use($action){
  if(in_array($action,['save','add'],true)){
   $id=$action==='add'?0:int_field('id',0,PHP_INT_MAX);$t=$id?tenant_row('tasks',$id,true):null;
   if($t&&$t['status']!=='open')throw new DomainException($t['status']==='completed'?'Tamamlanan işler yeniden düzenlenemez.':'Bu iş sonlandırılmış. Düzenlemek için önce yeniden açın.');
   $category=field('category',24)?:'general';if(!isset(task_categories()[$category]))throw new DomainException('Geçerli bir iş kategorisi seçin.');
   $args=[required_field('title',200),date_field('due_date'),$category,field('description',5000)];
   if($id)query('UPDATE tasks SET title=?,due_date=?,category=?,description=?,updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?',[...$args,company_id(),$id]);
   else{query("INSERT INTO tasks(title,due_date,category,description,company_id,created_by,status,done,updated_at) VALUES (?,?,?,?,?,?,'open',0,UTC_TIMESTAMP())",[...$args,company_id(),current_user()['id']]);$id=(int)db()->lastInsertId();}
   audit($t?'task.updated':'task.created',['id'=>$id,'task_status'=>'open','category'=>$category]);return $id;
  }
  $id=int_field('id',1,PHP_INT_MAX);$t=tenant_row('tasks',$id,true);
  if($t['status']==='completed')throw new DomainException('Tamamlanan işler yeniden düzenlenemez veya yeniden açılamaz. Yeni bir takip için yeni iş oluşturun.');
  if($action==='toggle')$action=$t['status']==='closed'?'reopen':'complete';
  $status=match($action){'close'=>'closed','reopen'=>'open','complete'=>'completed',default=>throw new DomainException('İş takibi işlemi geçersiz.')};
  if(($action==='reopen'&&$t['status']!=='closed')||($action!=='reopen'&&$t['status']!=='open'))throw new DomainException('İşin durumu değişmiş. Sayfayı yenileyip tekrar deneyin.');
  query("UPDATE tasks SET status=?,done=?,closed_at=CASE WHEN ?='closed' THEN UTC_TIMESTAMP() ELSE NULL END,completed_at=CASE WHEN ?='completed' THEN UTC_TIMESTAMP() ELSE NULL END,updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?",[$status,$status==='completed'?1:0,$status,$status,company_id(),$id]);
  audit(match($action){'close'=>'task.closed','reopen'=>'task.reopened',default=>'task.completed'},['id'=>$id,'task_status'=>$status,'category'=>$t['category']]);return $id;
 });
 flash('İş takibi kaydedildi.');redirect('tasks',['id'=>$id]);
}
function work_tasks_view(): void {
 $id=(int)($_GET['id']??$_GET['focus']??$_GET['edit']??0);$t=$id?tenant_row('tasks',$id):null;$edit=isset($_GET['edit'])||isset($_GET['new'])||($_SERVER['REQUEST_METHOD']==='POST'&&in_array($_POST['action']??'',['save','add'],true));
 heading('İş takibi','İşlerin konusunu, içeriğini ve takip tarihini kaydedin.',$t||$edit?a('tasks','İş listesine dön',[],'button'):a('tasks','Yeni iş oluştur',['new'=>1],'button primary'));
 if($edit){
  if($t&&$t['status']!=='open'){echo '<div class="info-note">'.($t['status']==='completed'?'Tamamlanan işler yeniden düzenlenemez.':'Sonlandırılmış işi düzenlemek için önce yeniden açın.').'</div>';echo a('tasks','İşi görüntüle',['id'=>$id],'button');return;}
  panel($t?'İşi düzenle':'Yeni iş');form_start('tasks','save',$t?['edit'=>$id]:['new'=>1]);hidden('id',$id);input('title','Konu / iş başlığı',$t['title']??'','text','required maxlength="200"');select_field('category','İş kategorisi',task_categories(),$t['category']??'general');input('due_date','Takip tarihi',$t['due_date']??today(),'date','required');textarea('description','İşin içeriği',$t['description']??'','maxlength="5000" placeholder="Yapılacak işlemi ve takip notlarınızı yazın."');form_end('İşi kaydet');echo '</section>';return;
 }
 if($t){
  panel($t['title'],task_categories()[$t['category']].' · '.task_states()[$t['status']]);echo '<p>Takip tarihi: <strong>'.date_tr($t['due_date']).'</strong></p><p>'.nl2br(esc($t['description']?:'İçerik eklenmemiş.')).'</p>';
  if($t['status']==='completed')echo '<div class="info-note">Tamamlanan işler yeniden düzenlenemez veya yeniden açılamaz. Gerekirse yeni bir iş oluşturabilirsiniz.</div>';
  elseif($t['status']==='closed'){echo '<p>Bu iş sonlandırılmıştır. Yeniden açtığınızda düzenleyebilir ve takibe devam edebilirsiniz.</p>';small_action('tasks','reopen','İşi yeniden aç',['id'=>$id]);}
  else{echo '<div class="desk-actions">'.a('tasks','İşi düzenle',['edit'=>$id],'button');small_action('tasks','close','İşi sonlandır',['id'=>$id]);echo '</div><details><summary>İşi tamamla</summary><p>Tamamlanan işler yeniden düzenlenemez veya yeniden açılamaz. Sonlandırılan işler ise yeniden açılabilir.</p>';small_action('tasks','complete','Onaylıyorum, işi tamamla',['id'=>$id]);echo '</details>';}
  echo '</section>';return;
 }
 $rs=query("SELECT * FROM tasks WHERE company_id=? ORDER BY FIELD(status,'open','closed','completed'),due_date,id DESC LIMIT 500",[company_id()])->fetchAll();
 if(!$rs){panel('Henüz bir iş kaydınız bulunmuyor');echo '<p>Satış, satın alma veya diğer işlerinizi takip etmek için '.a('tasks','yeni bir iş oluşturun',['new'=>1]).'.</p></section>';return;}
 panel('İş listesi','Son 500 iş kaydı. Açık işler ana sayfanızdaki hatırlatmalarda da görünür.');table_start(['Konu','Kategori','Takip tarihi','Durum','']);foreach($rs as $r)echo '<tr><td>'.esc($r['title']).'</td><td>'.esc(task_categories()[$r['category']]??'Genel').'</td><td>'.date_tr($r['due_date']).'</td><td>'.esc(task_states()[$r['status']]).'</td><td>'.a('tasks','Görüntüle',['id'=>$r['id']]).($r['status']==='open'?' · '.a('tasks','Düzenle',['edit'=>$r['id']]):'').'</td></tr>';table_end(count($rs),5);echo '</section>';
}
