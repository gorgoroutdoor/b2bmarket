# 3.6.47 — Firma silme formunda görünür işlem sonucu

3.6.46 üzerine imzalı güncelleme. Yeni migration yoktur.

Firma silme, genel AJAX form göndericisinden çıkarılır; standart POST ile sunucuya gönderilir. Yönetici formu ilgili firma kimliğini ve üyelik bölümünü URL'de korur. İstek gönderilirken durum açıklaması ve “Silme işlemi sürüyor…” düğmesi görünür. Sunucu doğrulama hataları aynı firma ekranında gösterilir. JavaScript kapalıyken de standart gönderim çalışır.

Bu değişiklik kalıcı silme için gereken yetki, mevcut şifre, firma unvanı, SİL ifadesi, onay kutusu, CSRF, uygulama kilidi veya yedek temizleme kontrollerini kaldırmaz. Sunucuya ulaşan işlem tamamlanmadan başarı mesajı gösterilmez. Başarılı silme firma listesine döner. Diğer formlar mevcut AJAX akışını kullanmaya devam eder.

Önceki sürümde doğrudan HTTP silme testi başarılıydı; kullanıcının hata göstermeyen tarayıcı akışı tekrarlanamadı. Bu sürüm gönderimi sadeleştirir ve sonucu görünür kılar; kurulumdaki olası kilit, veri ilişkisi veya yedek hatasının da giderildiği iddia edilmez.

Kurulumdan sonra yönetim sayfasını Ctrl+F5 ile yenileyin. Silmek istediğiniz firmayı üyelik düzenleme ekranından açın; silme alanını doldurup bir kez gönderin. Sonuç ekranını bekleyin. Gerçek firma verileri bu geliştirme sırasında silinmedi.

E-postada DKIM/DNS ayarları ayrı bir hosting işlemidir. Bu sürüm DNS veya SMTP ayarını değiştirmez.
