<?php
declare(strict_types=1);
function email3643_pending(?array $u):bool {
 return (bool)($u&&($u['role']??'')==='company_admin'&&!empty($u['registration_email_required'])&&(!$u['registration_email_verified_at']||!contact_same('email',(string)($u['registration_email_verified_address']??''),(string)$u['email'])));
}
function email3643_enroll(int $uid,int $cid,string $address):void {
 if(setting('registration_email_verify3643','1')!=='1')return;
 query("UPDATE users SET registration_email_required=1 WHERE id=? AND company_id=? AND role='company_admin'",[$uid,$cid]);
 query("UPDATE companies SET email=?,email_verified_at=NULL WHERE id=? AND (email IS NULL OR email='')",[$address,$cid]);
}
function email3643_issue(int $uid):array {
 return transaction(function()use($uid){
  $u=query('SELECT * FROM users WHERE id=? AND is_active=1 AND is_deleted=0 FOR UPDATE',[$uid])->fetch();
  if(!email3643_pending($u))throw new DomainException('Bu hesap için bekleyen e-posta doğrulaması bulunmuyor.');
  $old=query('SELECT * FROM registration_email_checks WHERE user_id=? FOR UPDATE',[$uid])->fetch();$now=time();
  if($old&&strtotime($old['requested_at'].' UTC')>$now-60)throw new DomainException('Yeni e-posta istemeden önce bir dakika bekleyin.');
  $same=$old&&strtotime($old['window_start'].' UTC')>$now-86400;$count=$same?(int)$old['send_count']:0;
  if($count>=8)throw new DomainException('Günlük doğrulama e-postası sınırına ulaştınız. Daha sonra tekrar deneyin.');
  $token=bin2hex(random_bytes(32));$hash=hash('sha256',$token);$expires=gmdate('Y-m-d H:i:s',$now+1800);$window=$same?$old['window_start']:gmdate('Y-m-d H:i:s',$now);
  query("INSERT INTO registration_email_checks(user_id,email,token_hash,expires_at,requested_at,last_result,window_start,send_count) VALUES (?,?,?,?,UTC_TIMESTAMP(),'pending',?,?) ON DUPLICATE KEY UPDATE email=VALUES(email),token_hash=VALUES(token_hash),expires_at=VALUES(expires_at),requested_at=VALUES(requested_at),last_sent_at=NULL,last_result='pending',last_error='',window_start=VALUES(window_start),send_count=VALUES(send_count)",[$uid,$u['email'],$hash,$expires,$window,$count+1]);
  return ['user_id'=>$uid,'email'=>$u['email'],'name'=>$u['name'],'token'=>$token,'hash'=>$hash,'expires_at'=>$expires];
 });
}
function email3643_send(int $uid,?Closure $sender=null):bool {
 $r=email3643_issue($uid);$link='https://app.kobivira.com.tr/?page=verify_email&token='.$r['token'];
 $body="Merhaba ".$r['name'].",\n\nKobivira hesabınızı kullanmaya başlamak için e-posta adresinizi doğrulayın:\n\n".$link."\n\nBağlantı 30 dakika geçerlidir ve yalnız bir kez kullanılabilir. Açılan sayfada E-posta adresimi doğrula düğmesine basın. Yeni e-posta isterseniz önceki bağlantı geçersiz olur.\n\nBu hesabı siz oluşturmadıysanız bu e-postayı dikkate almayın.\n\nKobivira\nhttps://kobivira.com.tr/";
 try{if($sender)$sender($r['email'],$body);else send_channel('email',$r['email'],$body,false,'Kobivira · E-posta adresinizi doğrulayın',mail3645_verification($r['name'],$link));query("UPDATE registration_email_checks SET last_result='accepted',last_sent_at=UTC_TIMESTAMP() WHERE user_id=? AND token_hash=?",[$uid,$r['hash']]);return true;}
 catch(Throwable $e){query("UPDATE registration_email_checks SET last_result='failed',last_error=? WHERE user_id=? AND token_hash=?",[mail3644_safe_error($e),$uid,$r['hash']]);return false;}
}
function email3643_after_registration(int $cid):void {
 $u=query("SELECT * FROM users WHERE company_id=? AND role='company_admin' ORDER BY id LIMIT 1",[$cid])->fetch();if(!$u||!email3643_pending($u))return;
 try{email3643_send((int)$u['id']);}catch(Throwable){/* Mail failure must not delete a successfully registered company. */}
}
function email3643_find(string $token,bool $lock=false):?array {
 if(!preg_match('/^[a-f0-9]{64}$/D',$token))return null;
 $r=query('SELECT v.*,u.company_id,u.role,u.name,u.email current_email,u.is_active,u.is_deleted FROM registration_email_checks v JOIN users u ON u.id=v.user_id WHERE v.token_hash=?'.($lock?' FOR UPDATE':''),[hash('sha256',$token)])->fetch();
 if(!$r||!$r['is_active']||$r['is_deleted']||strtotime($r['expires_at'].' UTC')<=time()||!contact_same('email',$r['email'],$r['current_email']))return null;return $r;
}
function email3643_confirm(string $token):int {
 return transaction(function()use($token){$r=email3643_find($token,true);if(!$r)throw new DomainException('Bağlantı geçersiz, süresi dolmuş veya daha önce kullanılmış. Hesabınıza giriş yaparak yeni e-posta isteyin.');$uid=(int)$r['user_id'];
  query('UPDATE users SET registration_email_verified_at=UTC_TIMESTAMP(),registration_email_verified_address=? WHERE id=?',[$r['current_email'],$uid]);
  if($r['role']==='company_admin')query('UPDATE companies SET email_verified_at=UTC_TIMESTAMP() WHERE id=? AND LOWER(TRIM(email))=?',[$r['company_id'],strtolower(trim($r['current_email']))]);
  query('DELETE FROM registration_email_checks WHERE user_id=?',[$uid]);
  query("INSERT INTO audit_logs(company_id,user_id,actor_name,action,metadata,created_at) VALUES (?,?,'E-posta doğrulama','user.registration_email_verified',?,UTC_TIMESTAMP())",[$r['company_id'],$uid,json_encode(['user'=>$uid],JSON_THROW_ON_ERROR)]);mail3650_registration($uid,true);return $uid;
 });
}
function email3643_guard(string $page):void {
 if(!email3643_pending(base_user())||$page==='logout')return;
 if($_SERVER['REQUEST_METHOD']==='GET')redirect('verify_email');http_response_code(403);throw new DomainException('İşleme devam etmek için giriş e-posta adresinizi doğrulayın.');
}
function email3643_mask(string $email):string {[$name,$domain]=explode('@',$email,2);return mb_substr($name,0,1).'***@'.$domain;}
function email3643_public():never {
 header('Cache-Control: private, no-store');header('Referrer-Policy: no-referrer');$error='';$notice='';$done=false;
 $token=is_string($_GET['token']??null)?$_GET['token']:'';
 if($_SERVER['REQUEST_METHOD']==='POST'&&($_POST['action']??'')==='confirm'&&is_string($_POST['token']??null))$token=$_POST['token'];
 $u=base_user();$valid=$token!==''?email3643_find($token):null;
 if(!in_array($_SERVER['REQUEST_METHOD'],['GET','POST'],true)){http_response_code(405);exit;}
 if(!$u&&$token==='')redirect('login');
 if($_SERVER['REQUEST_METHOD']==='POST')try{check_csrf();$action=required_field('action',30);
  if($action==='confirm'){throttle('registration_email_confirm',16);$uid=email3643_confirm(required_field('token',64));$done=true;$token='';$valid=null;
   if($u&&(int)$u['id']===$uid){$fresh=query('SELECT * FROM users WHERE id=?',[$uid])->fetch();if(phone3644_pending($fresh)){phone3644_auto_start($fresh);redirect('verify_mobile');}flash('E-posta adresiniz doğrulandı.');$intent=$_SESSION['package_intent']??null;if(is_array($intent)&&isset($intent['plan'],$intent['period']))redirect('membership',['view'=>'plans','plan'=>$intent['plan'],'period'=>$intent['period']]);redirect('dashboard');}
  }elseif($action==='resend'){
   if(!$u||!email3643_pending($u)){http_response_code(403);throw new DomainException('Yeni bağlantı için hesabınıza giriş yapın.');}
   throttle('registration_email_resend',20);if(email3643_send((int)$u['id']))$notice='Doğrulama e-postanız gönderildi. Gelen kutunuzu ve istenmeyen e-posta klasörünü kontrol edin.';else $error='Doğrulama e-postası gönderilemedi. Biraz sonra yeniden deneyin; sorun sürerse info@kobivira.com.tr adresinden bize ulaşın.';
  }else throw new DomainException('İşlem geçersiz.');
 }catch(DomainException $e){$error=$e->getMessage();if(http_response_code()<400)http_response_code(422);}catch(Throwable){$error='Doğrulama işlemi tamamlanamadı. Lütfen yeniden deneyin.';http_response_code(500);}
 if($token!==''&&!$valid&&!$done){$error='Bağlantı geçersiz, süresi dolmuş veya daha önce kullanılmış. Hesabınıza giriş yaparak yeni e-posta isteyin.';if(http_response_code()<400)http_response_code(410);}
 if($u&&!email3643_pending($u)&&$token===''&&!$done)redirect('dashboard');
 if($u&&email3643_pending($u)&&$token===''&&$_SERVER['REQUEST_METHOD']==='GET'&&query('SELECT last_result FROM registration_email_checks WHERE user_id=?',[(int)$u['id']])->fetchColumn()==='failed')$error='Doğrulama e-postası gönderilemedi. Biraz sonra yeniden gönderin; sorun sürerse info@kobivira.com.tr adresinden bize ulaşın.';
 $mailClock=$u?query('SELECT expires_at,requested_at FROM registration_email_checks WHERE user_id=?',[(int)$u['id']])->fetch():null;$mailRetry=$mailClock?strtotime($mailClock['requested_at'].' UTC')+60:0;
 echo '<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>E-posta doğrulama · Kobivira</title><style nonce="'.esc($GLOBALS['nonce']).'">'.file_get_contents(__DIR__.'/Email3643.css').'</style><main class="mail43"><a class="mail43-brand" href="https://kobivira.com.tr/">Kobivira</a><section><span class="mail43-eyebrow">HESABINIZI TAMAMLAYIN</span><h1>'.($done?'E-posta adresiniz doğrulandı.':'E-posta adresinizi doğrulayın.').'</h1>';
 if($error!=='')echo '<p class="mail43-error" role="alert">'.esc($error).'</p>';if($notice!=='')echo '<p class="mail43-success" role="status">'.esc($notice).'</p>';
 if($done)echo '<p>Hesabınıza giriş yaparak devam edebilirsiniz.</p><a class="mail43-button" href="'.esc(url('login')).'">Hesabıma giriş yap</a>';
 elseif($valid)echo '<p><strong>'.esc(email3643_mask($valid['email'])).'</strong> adresini doğrulayarak hesabınızı kullanmaya başlayabilirsiniz.</p><form method="post" action="?page=verify_email">'.csrf_field().'<input type="hidden" name="action" value="confirm"><input type="hidden" name="token" value="'.esc($token).'"><button type="submit">E-posta adresimi doğrula</button></form>';
 elseif($u&&email3643_pending($u)){
  auth3644_clock($mailClock?strtotime($mailClock['expires_at'].' UTC'):0,$mailRetry,'Bağlantı geçerlilik süresi');echo '<p><strong>'.esc($u['email']).'</strong> adresinizi doğrulayın. E-postanızdaki bağlantıyı açıp onayladığınızda firma paneliniz açılacak.</p><p class="mail43-small">Bağlantı 30 dakika geçerlidir. Yeniden gönderim için bir dakika bekleyin. Her zaman son e-postadaki bağlantıyı kullanın.</p><form method="post" action="'.esc(url('verify_email')).'">'.csrf_field().'<input type="hidden" name="action" value="resend">'.auth3644_retry_html('Doğrulama e-postasını yeniden gönder',$mailRetry).'</form><form method="post" action="'.esc(url('logout')).'">'.csrf_field().'<input type="hidden" name="action" value="logout"><button class="mail43-quiet" type="submit">Çıkış yap</button></form>';
 }else echo '<a class="mail43-button" href="'.esc(url('login')).'">Hesabıma giriş yap</a>';
 echo '</section><p class="mail43-footer">Kobivira · İşinizin hesabı</p></main>'.auth3644_script().'</html>';exit;
}
function email3643_admin():void {
 panel('Yeni üyeliklerde e-posta doğrulaması','Yeni kayıtlarda hesap sahibinin giriş e-postası doğrulanır. Önceden kayıtlı firmaların erişimi değişmez.');
 if(setting('registration_email_verify3643','1')==='1'&&delivery_setting('email_enabled','0')!=='1')echo '<p class="alert error">Yeni üyeliklerde doğrulama zorunlu. Müşteri kaydı açmadan önce yukarıdaki SMTP bilgilerini ve e-posta gönderimini etkinleştirin.</p>';
 form_start('delivery','registration_email_test');input('test_email','Deneme e-postasının gönderileceği adres','info@kobivira.com.tr','email','required maxlength="190"');input('current_password','Mevcut yönetici şifreniz','','password','required autocomplete="current-password"');form_end('Deneme e-postası gönder');echo '<p>Deneme gönderiminden sonra gelen kutusu ve istenmeyen e-posta klasörü ayrıca kontrol edilmelidir.</p>';
 $rows=query("SELECT u.id,u.email,u.registration_email_verified_at,u.registration_email_verified_address,c.name company_name,v.last_result,v.last_error FROM users u JOIN companies c ON c.id=u.company_id LEFT JOIN registration_email_checks v ON v.user_id=u.id WHERE u.registration_email_required=1 ORDER BY u.id DESC LIMIT 50")->fetchAll();
 table_start(['Firma','Giriş e-postası','Doğrulama','Son gönderim']);foreach($rows as $r){$verified=$r['registration_email_verified_at']&&contact_same('email',(string)$r['registration_email_verified_address'],$r['email']);$status=$verified?'Doğrulama tamamlandı':(['accepted'=>'Gönderim sunucusu kabul etti','failed'=>'Gönderilemedi','pending'=>'Gönderim bekliyor'][$r['last_result']??'']??'Henüz gönderilmedi');if(!$verified&&($r['last_result']??'')==='failed'&&($r['last_error']??'')!=='')$status.=' · '.$r['last_error'];echo '<tr><td>'.esc($r['company_name']).'</td><td>'.esc($r['email']).'</td><td>'.($verified?'Doğrulandı':'Doğrulama bekliyor').'</td><td>'.esc($status).'</td></tr>';}table_end(count($rows),4);echo '<p>Son 50 yeni kayıt gösterilir.</p></section>';
}
function email3643_admin_test():never {
 $to=required_field('test_email',190);if(!filter_var($to,FILTER_VALIDATE_EMAIL))throw new DomainException('Geçerli bir deneme e-posta adresi girin.');
 send_channel('email',$to,"Kobivira e-posta gönderim denemesi başarılı.\n\nBu bir hesap doğrulama bağlantısı değildir.\nhttps://kobivira.com.tr/",false,'Kobivira · E-posta gönderim denemesi');audit('delivery.registration_email_test');flash('Deneme e-postası gönderim sunucusu tarafından kabul edildi. Alıcı gelen kutusunu kontrol edin.');redirect('delivery');
}
function email3643_account_status():void {$u=base_user();if(!$u||empty($u['registration_email_required']))return;echo '<p class="info-note">Giriş e-postası: '.esc(email3643_mask($u['email'])).' · '.(email3643_pending($u)?'Doğrulama bekliyor':'Doğrulandı').'</p>';}
function email3643_registration_hint():void {if(setting('registration_email_verify3643','1')==='1')echo '<p class="field-hint wide">Kayıttan sonra e-postanıza gönderilen bağlantıyla adresinizi doğrulayın.</p>';}
