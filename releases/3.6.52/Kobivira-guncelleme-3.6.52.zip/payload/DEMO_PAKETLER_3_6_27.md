# Kobivira 3.6.27 — Demo görünürlüğü, paket farkları ve firma kimliği

3.6.26 üzerine imzalı güncellemedir. Menü ve sayfa tasarımının mevcut yapısı korunur. Şema değişikliği yoktur; 46 migration dosyası aynıdır.

## Demoda görünürlük

Yeni firma kayıtlarının deneme hesabında Elektronik Belgeler kategorisi görünür: e-Fatura, e-Arşiv, e-İrsaliye, e-SMM, e-İhracat, Gelen e-Faturalar, Gelen e-İrsaliyeler ve bağlantı ayarları. Kullanıma açık paketlerde tanımlı türler esas alınır. Veri API erişimi ve yönetimden etkinleştirilmiş kurumsal web sitesi de uygun paketlerde bulunuyorsa önizleme sunar. Henüz müşteri kullanımına açık olmayan entegrasyonlar çalışıyor gibi gösterilmez.

Bu ekranlar tanıtım/inceleme içindir: alanlar devre dışıdır, gerçek belge/kayıt içermez, servis şifresi toplamaz, belge oluşturmaz/göndermez/indirmez ve dış servis sorgulamaz. Önizleme sayfalarına doğrudan POST yapılması sunucuda reddedilir. Dosya/kimlik/indirme parametreleri gerçek belge içeriğine eriştirmez. Ücretli servis işlem yetkisi verilmez; yalnız menü görünürlüğü eklenir. Demo hesabındaki mevcut izinli ön muhasebe işlemleri ve 5 cari kart / 5 belge sınırları korunur. Veri taşıma kampanyasının mevcut ayrı kuralları değiştirilmez.

Demodaki Kullanım kütüphanesinde ilgili e-belge rehberleri de görünür. Nasıl Yapılır bağlantıları yeni sekme/pencerede açılmaya devam eder.

Ücretli pakete geçildiğinde bu önizleme kuralı otomatik biter; menüler ve sunucu yetkileri seçilen KOBİ, Plus veya Business kapsamına döner. Mevcut ücretli firmaların görünürlüğü değiştirilmez. Ödeme testiyle paketi açılan ayrılmış test firması da seçilen paketin menüsünü görür; bütün demo menüleriyle ücretli kapsam karıştırılmaz.

## Paket kartları ve karşılaştırma

Plus kartı KOBİ'ye ek özellikleri, Business kartı Plus'a ek özellikleri öne çıkarır. Business özetinde e-İrsaliye, e-SMM, e-İhracat, proje kârlılığı, CRM ve nakit öngörüsü önceliklidir. Aynı altı temel özellik iki kartta tekrar edilmez. Özet en fazla altı maddedir; Tüm özellikleri incele bağlantısı ve tam karşılaştırma korunur. Firma panelindeki Paketler sayfası da aynı özetleri ve kapsam açıklamasını kullanır.

Business gerçekten Plus'ın tüm özelliklerini içeriyorsa “KOBİ Plus paketinin özelliklerine ek olarak” yazılır. Yönetici paket içeriklerini değiştirip bu ilişkiyi bozarsa yanlış kapsam iddiası yerine “KOBİ Plus paketine göre farklılaşan özellikler” yazılır. Paket yetkileri, fiyatlar ve kullanıcı sınırları değiştirilmez.

## TCKN / VKN ve belge türü

Firma bilgileri ekranında şahıs işletmesi seçilince T.C. kimlik numarası (11 rakam), tüzel kişi/şirket seçilince vergi kimlik numarası (10 rakam) alanı gösterilir. Tür değişince alan başlığı ve sınırları güncellenir; girilmiş numara sessizce kesilmez. Profil kaydetmede ve canlı e-belge bağlantı kontrolünde bu tür/hane ilişkisi sunucuda da kontrol edilir. Kontrol yalnız biçim/hane kontrolüdür; numaranın gerçek kişiye/firmaya ait olduğunun resmî doğrulanması değildir. Eski kayıtlar kendiliğinden dönüştürülmez veya silinmez. Bu akış mevcut Türk şahıs işletmesi/tüzel kişi türleri içindir; yabancı alıcıların kimlik istisnaları bu sürümde eklenmemiştir.

Şahıs veya tüzel kişi seçimi tek başına e-Fatura / e-Arşiv hakkını belirlemez. GİB açıklamasına göre e-Fatura kayıtlı alıcıya e-Fatura; kayıtlı olmayan alıcıya uygun durumda e-Arşiv Fatura düzenlenir. Aynı firma farklı alıcılara iki hizmeti de kullanabilir. Aynı satış için iki tür birden üretilmemelidir. Paket kartları, karşılaştırma, demo ve ilgili belge ekranlarında ayrım açıklanır. Mevcut servis kodundaki alıcı mükellefiyet kontrolü ve aynı kaynak satış için billing kaynak anahtarıyla ikinci belgeyi engelleme kuralı korunur. Bu sürüm gerçek GİB/entegratör sorgusu yapılarak doğrulanmamıştır.

Firma evrak onayı, paket yetkisi ve sağlayıcı hesabının etkinleştirilmesi farklı kontrollerdir. Yönetimde firmaya özel yeni e-belge hizmeti seçme/onay/ret ekranı bu sürümde eklenmemiştir. e-Fatura ile e-Arşiv'i hukuken zorunlu olarak birbirini dışlayan iki seçenek şeklinde kısıtlama getirilmez.

## Ödeme testi uyarısı

“Bu firma ödeme testi için ayrılmıştır...” uyarısı 3.6.26'da yönetici tarafından özellikle ayrılan test hesabına aittir. Genel demo uyarısı değildir. Testte değiştirilen paketi gerçek tahsilat gibi sunmamak için o hesapta görünür. Normal ücretli firmalarda gösterilmez. Test tamamlandığında aynı PayTR ayar sayfasındaki Test öncesi üyeliği geri getir işlemiyle test öncesi durum geri alınabilir; sonuçlanmamış ödeme veya test dışında üyelik değişimi varsa koruma uygulanır. Bu sürüm test hesabı işaretini veya PayTR modunu kendiliğinden kaldırmaz.

## Doğrulama

74 PHP/veritabanı kontrolü, 42 yerel HTTP kontrolü, 3 kimlik alanı DOM kontrolü geçti. 165 PHP kaynak dosyası sözdizimi kontrolünden geçti; kimlik alanı JavaScript'i DOM testinde çalıştırıldı. İmzalı 3.6.26 → 3.6.27 kurulumu ve mevcut firma/ödeme/üyelik verilerinin korunması denendi. Gerçek tarayıcı görsel kontrolü, PayTR ve e-belge sağlayıcısıyla dış servis işlemi bu sürüm çalışmasında yapılmadı.

Resmî kaynaklar:
- GİB e-Arşiv Fatura Uygulaması: https://cdn.gib.gov.tr/api/gibportal-file/file/getFileResources?objectKey=arsiv%2Fyardim-kaynaklar%2Finfografikler%2Fpdfs%2Fe_arsiv_fatura.pdf
- GİB gerçek kişi kimlik açıklaması: https://gib.gov.tr/mevzuat/kanun/434/ozelge/25748
