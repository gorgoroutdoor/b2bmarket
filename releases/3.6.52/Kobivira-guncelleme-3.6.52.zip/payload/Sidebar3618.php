(() => {
 const sidebar=document.getElementById('sidebar'),nav=document.getElementById('sidebar-nav'),toggle=document.getElementById('menu-toggle');
 if(!sidebar||!nav||!toggle)return;
 const key=sidebar.dataset.navKey+'-3618',groups=[...nav.querySelectorAll('details.nav-group')],media=matchMedia('(max-width: 900px)');let saved={},desktopHidden=false;
 try{saved=JSON.parse(sessionStorage.getItem(key)||'{}')||{};desktopHidden=saved.hidden===true}catch{}
 const active=nav.querySelector('[aria-current="page"]')?.closest('details');
 const selected=active||groups.find(g=>g.dataset.group===saved.open);groups.forEach(g=>g.open=g===selected);
 function save(){try{sessionStorage.setItem(key,JSON.stringify({hidden:desktopHidden,open:groups.find(g=>g.open)?.dataset.group||'',scroll:nav.scrollTop}))}catch{}}
 function update(){const mobile=media.matches,open=mobile?document.body.classList.contains('menu-open'):!desktopHidden;document.body.classList.toggle('sidebar-hidden3618',!mobile&&desktopHidden);document.body.classList.remove('sidebar-rail353');sidebar.inert=!open;sidebar.setAttribute('aria-hidden',String(!open));toggle.setAttribute('aria-expanded',String(open));toggle.setAttribute('aria-label',open?'Menüyü kapat':'Menüyü aç');toggle.title=open?'Menüyü kapat':'Menüyü aç';}
 function hide(){if(media.matches)document.body.classList.remove('menu-open');else desktopHidden=true;update();save();toggle.focus();}
 function flip(){if(media.matches)document.body.classList.toggle('menu-open');else desktopHidden=!desktopHidden;update();save();const open=media.matches?document.body.classList.contains('menu-open'):!desktopHidden;if(!open)toggle.focus();else if(media.matches)sidebar.querySelector('[data-close-menu]')?.focus();}
 toggle.addEventListener('click',flip);document.querySelectorAll('[data-toggle-sidebar]').forEach(b=>b.addEventListener('click',flip));document.querySelectorAll('[data-close-menu]').forEach(b=>b.addEventListener('click',hide));
 groups.forEach(g=>g.addEventListener('toggle',()=>{if(g.open)groups.forEach(other=>{if(other!==g)other.open=false});save()}));
 nav.addEventListener('scroll',save,{passive:true});window.addEventListener('pagehide',save);media.addEventListener('change',()=>{document.body.classList.remove('menu-open');update()});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&media.matches&&document.body.classList.contains('menu-open')){hide();return;}if(e.key!=='Tab'||!media.matches||!document.body.classList.contains('menu-open'))return;const els=[...sidebar.querySelectorAll('a,button,summary,input,select')].filter(el=>el.getClientRects().length&&!el.disabled),first=els[0],last=els.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus()}});
 update();requestAnimationFrame(()=>nav.scrollTop=Number(saved.scroll)||0);
})();
