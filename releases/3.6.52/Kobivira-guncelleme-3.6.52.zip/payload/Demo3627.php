<?php
declare(strict_types=1);
/** Visibility only: does not change has_feature(), billing or provider entitlements. */
function demo3627_account():bool {
 if(!current_user()||owner()||support_context()||isset($_GET['support'])||suspended_firm()||(base_user()['role']??'')!=='company_admin')return false;$s=subscription();return $s['status']==='trial'||($s['status']==='expired'&&empty($s['has_paid_membership']));
}
function demo3627_visible_feature(string $key):bool {
 if(!demo3627_account()||!launch3619_available($key))return false;
 if($key==='edocs')return count(array_filter(['edoc_invoice','edoc_archive','edoc_incoming','edoc_despatch','edoc_incoming_despatch','edoc_smm','edoc_export'],fn($f)=>demo3627_visible_feature($f)))>0;
 if($key==='website'&&empty(module351_config()['website']['enabled']))return false;
 foreach(['kobi','plus','business'] as $code)if(plan3616_has($code,$key))return true;return false;
}
function demo3627_preview(string $page,array $params=[]):bool {
 if(!demo3627_account())return false;
 if($page==='edoc_center'){
  if(($params['tab']??'')==='connection'||isset($params['id'])||!isset($params['kind']))return demo3627_visible_feature('edocs');
  if(!is_string($params['kind'])||!in_array($params['kind'],['invoice','archive','despatch','smm','export'],true))return false;return demo3627_visible_feature(plan3616_edoc_feature($params['kind']));
 }
 if($page==='incoming_invoices')return demo3627_visible_feature(($params['kind']??'')==='despatch'?'edoc_incoming_despatch':'edoc_incoming');
 if($page==='service_center')return demo3627_visible_feature('public_api');
 if($page==='website')return demo3627_visible_feature('website');return false;
}
function demo3627_guard(string $page):void {
 if(!demo3627_preview($page,$_GET))return;
 if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET'){http_response_code(403);throw new DomainException('Bu bölüm demoda yalnız incelenebilir. İşlem yapmak için ilgili özelliği kapsayan ücretli paketi seçin.');}
}
function demo3627_view(string $page):void {
 if(in_array($page,['edoc_center','incoming_invoices'],true)){edoc3629_preview($page);return;}

 $params=$_GET;$connection=$page==='edoc_center'&&($params['tab']??'')==='connection';$incoming=$page==='incoming_invoices';$kind=is_string($params['kind']??null)?$params['kind']:'invoice';$kind=in_array($kind,['invoice','archive','smm','despatch','export'],true)?$kind:'invoice';
 $names=['invoice'=>'e-Fatura','archive'=>'e-Arşiv','despatch'=>'e-İrsaliye','smm'=>'e-SMM','export'=>'e-İhracat'];
 $title=$connection?'Elektronik belge bağlantısı':($incoming?($kind==='despatch'?'Gelen e-İrsaliyeler':'Gelen e-Faturalar'):($names[$kind]??'Elektronik Belgeler'));if($page==='service_center')$title='Veri API erişimi';if($page==='website')$title='Web sitesi yönetimi';
 heading($title);echo '<div class="info-note"><strong>Bu bölümü inceleyebilirsiniz.</strong><p>Gerçek işlemler için ilgili özelliği kapsayan paketi satın almanız ve gerekiyorsa firmanıza ait servis bağlantısını etkinleştirmeniz gerekir. Demo hesabında bu ekran kayıt oluşturmaz veya dış servise bağlanmaz.</p>'.a('membership','Paketleri ve özelliklerini incele',['view'=>'plans'],'button').'</div>';
 if($page==='service_center'){panel('Salt okunur veri API erişimi');echo '<p>Firma kayıtlarının yetkili uygulamalar tarafından okunmasını sağlayan anahtarları yönetin. Firma ayrımı ve erişim kotaları uygulanır. Demoda anahtar oluşturulmaz ve veri servisi etkinleştirilmez.</p><fieldset disabled class="form-grid">';input('preview_key_name','Uygulama / anahtar adı');echo '<button type="button" class="button" disabled>API anahtarı oluştur</button></fieldset></section>';return;}
 if($page==='website'){panel('İçerik ve sayfa yönetimi');echo '<p>Tanımlı kurumsal sitenizin sayfalarını ve içeriklerini yönetin. Demoda içerik kaydetme veya yayınlama işlemi yapılmaz.</p><fieldset disabled class="form-grid">';input('preview_page_title','Sayfa başlığı');textarea('preview_page_content','Sayfa içeriği');echo '<button type="button" class="button" disabled>İçeriği kaydet</button></fieldset></section>';return;}
}

function package3627_features(string $code):array {return array_values(array_filter(array_keys(plan3616_selectable()),fn($f)=>launch3619_plan_has($code,$f)));}
function package3627_intro(string $code):string {
 $parent=['plus'=>'kobi','business'=>'plus'][$code]??null;if(!$parent)return 'Günlük ön muhasebe özellikleri';$name=$parent==='kobi'?'KOBİ':'KOBİ Plus';return array_diff(package3627_features($parent),package3627_features($code))?$name.' paketine göre farklılaşan özellikler':$name.' paketinin özelliklerine ek olarak';
}
function package3627_summary(string $code):array {
 $parent=['plus'=>'kobi','business'=>'plus'][$code]??null;$all=package3627_features($code);$diff=$parent?array_values(array_diff($all,package3627_features($parent))):$all;
 $priority=match($code){'business'=>['edoc_despatch','edoc_smm','edoc_export','projects','crm','forecast','edoc_incoming_despatch','bank_match'],'plus'=>['edoc_invoice','edoc_archive','edoc_incoming','orders','currency','statements'],default=>['bookkeeping','quotes','sharing','approvals','roles','audit']};$keys=array_values(array_unique(array_merge(array_values(array_intersect($priority,$diff)),$diff)));$catalog=plan3616_catalog();$out=[];foreach($keys as $k){$out[]=$catalog[$k][1];if(count($out)===6)break;}return $out;
}
function identity3627_validate(string $type,string $number):string {
 $length=match($type){'sole'=>11,'company'=>10,default=>throw new DomainException('İşletme türünü seçin.')};if(!preg_match('/^[0-9]{'.$length.'}$/D',$number)){$GLOBALS['validation_field']='tax_number';throw new DomainException($type==='sole'?'Şahıs işletmesi için 11 rakamlı T.C. kimlik numarasını girin.':'Tüzel kişi / şirket için 10 rakamlı vergi kimlik numarasını girin.');}return $number;
}
function identity3627_input(array $c):void {
 $type=posted_value('business_type',$c['business_type']);$value=posted_value('tax_number',$c['tax_number']);$sole=$type==='sole';$length=$sole?11:10;echo '<label class="field"><span data-identity3627-label>'.($sole?'T.C. kimlik numarası · şahıs işletmesi':'Vergi kimlik numarası · tüzel kişi / şirket').'</span><input name="tax_number" value="'.esc($value).'" type="text" required inputmode="numeric" minlength="'.$length.'" maxlength="'.$length.'" pattern="[0-9]{'.$length.'}" data-identity3627></label><p class="field-hint wide">Şahıs işletmesinde 11 rakamlı TCKN, tüzel kişi / şirkette 10 rakamlı VKN kullanılır.</p>';
}
function edoc3627_type_note():string {return '';}
