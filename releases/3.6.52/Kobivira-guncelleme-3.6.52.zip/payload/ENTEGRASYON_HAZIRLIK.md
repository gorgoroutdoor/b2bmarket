# Gerçek e-Dönüşüm bağlantısının tamamlanması

Bu sürümde ticari bir özel entegratör seçilmemiş, sözleşme yapılmamış, gerçek müşteri belgesi gönderilmemiştir. Mevcut gelen fatura adaptör arayüzü tek başına bir sağlayıcı bağlantısı değildir. Resmî e-Belge gönderimi yerine ön muhasebe çıktıları kullanılmaz.

GİB izin listesi: https://ebelge.gib.gov.tr/efaturaozelentegratorlerlistesi.html

## Sağlayıcıdan birlikte istenecekler

1. SaaS / bayi / iş ortaklığı koşulları; firmalar için ayrı yetkilendirme; test ortamı, güncel API dokümanı ve örnek istek / yanıtlar.
2. e-Fatura ve e-Arşiv için ayrı yetki kapsamı; gönderim, durum sorgulama, gelen belge, uygun belgede kabul / ret, iptal / itiraz akışları ve asıl belge dosyalarını alma işlemleri.
3. Belge, kontör, saklama, başlangıç, minimum kullanım ve destek maliyetleri; faturalama şekli; kampanya kontörlerinin süre ve tüketim koşulları.
4. Firma bazında bağlantı açma / kapama; işlem tekrarında mükerrer belgeyi önleyen anahtarlar; zaman aşımı sonrası sorgulama; webhook imzaları ve tekrar bildirim politikası.
5. Kimlik ve imza yöntemleri, firma kayıt evrakları, saklama / dışa aktarma kapsamı ve hizmet sonlandırıldığında belge erişimi. Şartlar seçilen sağlayıcı ve firmaya göre kesinleştirilmelidir.

## Yazılımda tamamlanacak işler

Firma bazında yetki ve gizli anahtarların güvenli yapılandırılması; sağlayıcı adaptörünün geliştirilmesi; gönderim kuyruğu; taslak ile resmî belgenin ayrılması; aynı istek için tek belge; yanıt / zaman aşımı uzlaştırması; kontör tüketiminin sağlayıcı teyidiyle kaydı; hata ekranları; asıl belgeyi indirme; kullanıcı yetkileri ve okunabilir işlem geçmişi.

Testler: başarısız / mükerrer gönderim, yanlış firma, geçersiz / iptal edilmiş erişim, zaman aşımı sonrası sonuç sorgulama, tekrarlı webhook, kontör yetersizliği, gelen belgenin muhasebeye bir kez aktarılması ve farklı firmaların belgelerinin ayrılığı. Gerçek resmî belge işlemleri ancak test ortamı ve kontrollü gerçek kullanım doğrulandıktan sonra satış kapsamına açılmalıdır.

API anahtarı, mali mühür şifresi veya müşteri parolası bu rapora ya da yazışmaya eklenmemelidir; sağlayıcı seçildikten sonra sunucunun özel yapılandırmasında tanımlanmalıdır.
