<?php
declare(strict_types=1);
function issuer_requirements(string $kind): array {
 if(!in_array($kind,['sale','quote','proforma','order'],true))return [];
 $c=query('SELECT * FROM companies WHERE id=?',[company_id()])->fetch();$missing=[];
 foreach(['name'=>'Firma unvanı','tax_number'=>'Vergi / T.C. numarası','tax_office'=>'Vergi dairesi','phone'=>'Telefon','email'=>'E-posta','address'=>'Firma adresi'] as $key=>$label)if(trim((string)($c[$key]??''))==='')$missing[]=$label;
 if($c['tax_number']!==''&&!preg_match('/^\d{10,11}$/D',$c['tax_number']))$missing[]='Vergi / T.C. numarası · 10 veya 11 rakam';
 if($c['email']!==''&&!filter_var($c['email'],FILTER_VALIDATE_EMAIL))$missing[]='Geçerli firma e-postası';
 if(!query('SELECT company_id FROM company_logos WHERE company_id=?',[company_id()])->fetchColumn())$missing[]='Firma logosu';
 if($kind==='proforma')foreach(bank_fields() as $key=>$label)if($key!=='bank_branch'&&trim((string)$c[$key])==='')$missing[]=$label;
 return array_values(array_unique($missing));
}
function require_issuer(string $kind): void {if($missing=issuer_requirements($kind)){$GLOBALS['issuer_missing']=$missing;throw new DomainException('Belge hazırlamadan önce firma bilgilerinizi tamamlayın: '.implode(', ',$missing).'.');}}
function issuer_notice(string $kind): bool {
 $missing=issuer_requirements($kind);if(!$missing)return false;
 echo '<div class="info-note no-print" role="status"><strong>Önce firma bilgilerinizi tamamlayın</strong><p>Eksik veya düzeltilmesi gereken alanlar: '.esc(implode(', ',$missing)).'. Ticaret sicil ve MERSİS numaralarını varsa ekleyin.</p>';
 if((current_user()['role']??'')==='company_admin'&&!support_context())echo '<div class="desk-actions">'.a('settings','Firma bilgilerimi tamamla',[],'button primary').($kind==='proforma'?a('settings','Banka bilgilerimi tamamla',['section'=>'bank'],'button'):'').'</div>';
 else echo '<p>Bu bilgileri tamamlaması için firma yöneticinize başvurun.</p>';
 echo '</div>';return true;
}
function bank_fields(): array {return ['bank_account_name'=>'Hesap adı','bank_name'=>'Banka adı','bank_account_holder'=>'Hesap sahibi / unvanı','bank_iban'=>'IBAN','bank_branch'=>'Şube · isteğe bağlı'];}
function document_number(int $value,int $scale=2): string {$divisor=10**$scale;$fraction=rtrim(str_pad((string)(abs($value)%$divisor),$scale,'0',STR_PAD_LEFT),'0');return ($value<0?'−':'').number_format(intdiv(abs($value),$divisor),0,',','.').($fraction!==''?','.$fraction:'');}
function valid_iban(string $value): string {
 $iban=strtoupper(preg_replace('/\s+/u','',$value)??'');if($iban==='')return '';
 if(!preg_match('/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/D',$iban)||str_starts_with($iban,'TR')&&strlen($iban)!==26)throw new DomainException('IBAN bilgisini kontrol edin. Türkiye IBAN numarası TR ile başlayan 26 karakterden oluşur.');
 $reordered=substr($iban,4).substr($iban,0,4);$remainder=0;foreach(str_split($reordered) as $ch){$digits=ctype_alpha($ch)?(string)(ord($ch)-55):$ch;foreach(str_split($digits) as $digit)$remainder=($remainder*10+(int)$digit)%97;}if($remainder!==1)throw new DomainException('IBAN kontrolü başarısız. Bankanızdaki IBAN numarasını kontrol edip yeniden girin.');return $iban;
}
function bank_profile_view(array $c): void {
 firm_manager();panel('Belgelere yazılacak banka bilgileri','Proforma oluşturmak için hesap adı, banka adı, hesap sahibi ve geçerli IBAN gereklidir.');form_start('settings','save_bank',['section'=>'bank']);foreach(bank_fields() as $key=>$label)input($key,$label,$c[$key]??'','text','maxlength="'.($key==='bank_iban'?42:160).'"'.($key==='bank_iban'?' placeholder="TR00 0000 0000 0000 0000 0000 00"':''));echo '<p class="field-hint wide">Bu bilgiler belge alıcısının ödeme yapması içindir; kasa / banka bakiyelerinizi değiştirmez. Banka şifresi veya kart bilgisi girmeyin. Yeni belgeler kayıt anındaki banka bilgilerini korur.</p>';form_end('Banka bilgilerini kaydet');echo '</section>';
}
function save_bank_profile(): never {
 firm_manager();if(suspended_firm()){http_response_code(403);throw new DomainException('Erişim askıdayken yalnız firma bilgileri ve inceleme işlemleri kullanılabilir.');}$values=[];foreach(bank_fields() as $key=>$label)$values[$key]=$key==='bank_iban'?valid_iban(field($key,42)):field($key,160);
 profile_transaction(function()use($values){if(query('SELECT status FROM companies WHERE id=?',[company_id()])->fetchColumn()!=='active'){http_response_code(403);throw new DomainException('Firma erişimi askıda. Banka bilgileri değiştirilemez.');}query('UPDATE companies SET bank_account_name=?,bank_name=?,bank_account_holder=?,bank_iban=?,bank_branch=? WHERE id=?',[...array_values($values),company_id()]);audit('company.bank_settings');});flash('Belgelere yazılacak banka bilgileri kaydedildi.');redirect('settings',['section'=>'bank']);
}
function bank_snapshot(): string {$c=query('SELECT * FROM companies WHERE id=?',[company_id()])->fetch();return json_encode(array_intersect_key($c,bank_fields()),JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);}
function document_bank(array $d): array {$b=json_decode($d['bank_snapshot']??'null',true);if(is_array($b))return array_map(fn($v)=>is_string($v)?$v:'',array_intersect_key($b,bank_fields()));$c=query('SELECT * FROM companies WHERE id=?',[company_id()])->fetch();return array_intersect_key($c,bank_fields());}
function compact_recipient(array $c,array $d): string {
 $s='<section class="document-party document-party--recipient"><div class="document-metadata"><strong>'.esc($d['record_type']==='return'?'İade kaydı':($d['record_type']==='smm'?'Serbest meslek makbuzu kaydı':kind_options($d['kind']))).'</strong><dl><div><dt>Belge no</dt><dd>'.esc(display_number($d)).'</dd></div><div><dt>Tarih</dt><dd>'.date_tr($d['issue_date']).'</dd></div><div><dt>Vade</dt><dd>'.date_tr($d['due_date']).'</dd></div></dl></div>'.recipient_html($c).'</section>';return $s;
}
function base_business_document(array $d): string {
 $c=query('SELECT * FROM companies WHERE id=?',[company_id()])->fetch();$ls=query('SELECT * FROM document_lines WHERE company_id=? AND document_id=? ORDER BY id',[company_id(),$d['id']])->fetchAll();$discount=(int)$d['discount_total'];$gross=(int)$d['subtotal']+$discount;
 $s='<article class="panel printable-document business-document"><div class="document-parties"><section class="document-party document-party--issuer">'.printed_company($c).'</section>'.compact_recipient(document_recipient($d),$d).'</div><div class="table-wrap document-lines-print"><table><colgroup><col class="col-description"><col class="col-qty"><col class="col-price">'.($discount?'<col class="col-discount">':'').'<col class="col-vat"><col class="col-total"></colgroup><thead><tr><th>Açıklama</th><th>Miktar</th><th>Birim fiyat</th>'.($discount?'<th>İndirim</th>':'').'<th>KDV</th><th>Toplam</th></tr></thead><tbody>';
 foreach($ls as $l)$s.='<tr><td>'.nl2br(esc($l['label'])).'</td><td class="numeric">'.esc(document_number((int)$l['quantity'],3)).'</td><td class="numeric">'.money($l['price']).'</td>'.($discount?'<td class="numeric">%'.document_number((int)$l['discount_rate']).'</td>':'').'<td class="numeric">'.(!empty($l['vat_total_only'])?money($l['tax']):'%'.document_number((int)$l['vat'])).'</td><td class="numeric">'.money($l['total']).'</td></tr>';
 $s.='</tbody></table></div><div class="document-settlement"><div class="document-notes">';$b=document_bank($d);
 if($b&&($b['bank_iban']??'')!==''&&in_array($d['kind'],['sale','quote','proforma','order'],true)){$s.='<section class="document-bank"><h3>Ödeme için banka bilgileri</h3>';foreach(bank_fields() as $key=>$label)if(($b[$key]??'')!=='')$s.='<div><strong>'.esc(str_replace(' · isteğe bağlı','',$label)).':</strong> <span'.($key==='bank_iban'?' class="document-iban"':'').'>'.esc($key==='bank_iban'?implode(' ',str_split($b[$key],4)):$b[$key]).'</span></div>';$s.='</section>';}
 if($d['description']!=='')$s.='<p class="document-description">'.nl2br(esc($d['description'])).'</p>';
 $s.='</div><dl class="document-totals"><div><dt>Ara toplam</dt><dd>'.money($gross).'</dd></div>'.($discount?'<div><dt>İndirim toplamı</dt><dd>−'.money($discount).'</dd></div>':'').'<div><dt>KDV</dt><dd>'.money($d['tax']).'</dd></div><div class="document-total"><dt>Genel toplam</dt><dd>'.money($d['total']).'</dd></div></dl></div><p class="document-footnote">Kobivira Ön muhasebe çıktısıdır. Resmî e-Belge numarası yerine geçmez.</p></article>';return $s;
}
function next_step_flow(): string {
 $s=task_summary();$html='<section class="panel action-panel" id="next-step-flow"><span class="eyebrow">SIRADAKİ ADIM</span><h2>Firmanızın iş akışı</h2>';
 if($s){$html.='<div class="next-step-tasks"><h3>Takip edilecek işler</h3>';if(!$s['count'])$html.='<p>Şu anda açık bir işiniz bulunmuyor. '.a('tasks','Yeni iş oluştur',['new'=>1]).'.</p>';else{$html.='<p class="field-hint">'.$s['count'].' açık iş · '.$s['overdue'].' gecikmiş</p><div class="action-list">';foreach($s['items'] as $r)$html.=a('tasks',icon('clock').'<span><strong>'.esc($r['title']).'</strong><small>'.date_tr($r['due_date']).($r['due_date']<today()?' · Gecikti':($r['due_date']===today()?' · Bugün':'')).'</small></span>'.icon('arrow'),['id'=>$r['id']]);$html.='</div><p>'.a('tasks','Tüm işleri gör',[],'button quiet').'</p>';}$html.='</div>';}
 if(has_feature('automation')&&(current_user()['role']??'')==='company_admin'&&!support_context()){$n=(int)query("SELECT COUNT(*) FROM automation_events WHERE company_id=? AND status='unread'",[company_id()])->fetchColumn();if($n)$html.='<p>'.a('automation',$n.' yeni takip bildiriminiz var',[],'button').'</p>';}
 $html.='<div class="action-list">';foreach([['newdocument','sales','Teklif hazırlayın','Bir sonraki satışın ilk adımı','sale',['kind'=>'quote']],['payments','finance','Tahsilat kaydedin','Hesaplarınız güncel kalsın','wallet',['view'=>'new']],['cashflow','finance','Vadelerinizi görün','Alacak ve borçlar bir arada','clock',[]]] as [$page,$scope,$title,$hint,$icon,$params])if(employee_allowed($page,$params)&&(!support_context()||support_allowed($scope)))$html.=a($page,icon($icon).'<span><strong>'.esc($title).'</strong><small>'.esc($hint).'</small></span>'.icon('arrow'),$params);
 return $html.'</div><div class="action-note">'.icon('check').'<span>Verileriniz firmanıza özel çalışma alanında tutulur.</span></div></section>';
}
