# 3.6.18 — Sade firma menüsü ve kalıcı firma adresleri

Bu imzalı güncelleme **3.6.17 üzerine** yönetimdeki Sürüm güncellemeleri bölümünden yüklenir. Henüz canlı hostinge uygulanmamıştır. Yeni imza anahtarı gerekmez.

## Firma arayüzü

Firma panelinin sol menüsü Kobivira logosundaki lacivert (#09244d) ve turkuaz (#00d9c1) ile düzenlendi. Alt menüler aynı sol alanda açılır; yana açılan ayrı pencere üretilmez. Ana içerik, mevcut modüller, kategori bağlantıları ve paket/rol filtreleri korunur. Örnek görsellerde bulunan fakat Kobivira'da uygulanmamış depo veya pazaryeri işlevleri eklenmedi.

Hamburger masaüstünde artık sadece açık kategoriyi kapatmaz: sol menüyü tamamen gizler ve içerik alanını genişletir; tekrar basılınca geri getirir. Menüyü gizle düğmesi, mobil aç/kapat, Escape, arka alana tıklama ve erişilebilirlik durumları aynı işlevi kullanır. Masaüstü tercihi oturum sekmesi içinde korunur. Salt okunur izleme ekranında da menü düğmesi çalışır; kayıt yazma yetkisi değişmez.

## Hesap numarası ve adres

041 geçişi mevcut firmalara benzersiz sekiz haneli hesap numarası atar. Yeni firmalara da oluşturulurken numara atanır. Bu numara üst alanda ve tarayıcı sekmesi başlığında gösterilir. Numara bir parola değildir; kullanıcı oturumu ve tüm mevcut yetki kontrolleri korunur.

Örnek adres: `https://app.kobivira.com.tr/12345678/`. Firma içindeki ekranlar `/12345678/?page=...` biçimindeki adresleri kullanır. Eski `?page=...` bağlantıları girişten sonra doğru firma adresine yönlenir. Başka firmanın numarası yazılarak ekran veya form işlemi yapılamaz. Giriş, yasal metinler ve token ile korunan dış paylaşım uçları ortak kök adreste kalır. Platform yöneticisinin menüsü firma adresine taşınmaz.

Temiz adresler için uygulamanın mevcut ana index.php dosyasının yanında, ilgili hesap numarası klasörü ve sabit küçük bir index.php girişi oluşturulur. Bu giriş sadece ana uygulamayı yükler; şifre/veritabanı bilgisi içermez. Ana index.php ve .htaccess üzerine yazılmaz. Mevcut dosya/dolu klasör ve sembolik bağlantı çakışmasında üzerine yazılmaz.

**Hosting koşulu:** PHP kullanıcısı uygulamanın web giriş klasöründe bu klasörleri oluşturabilmelidir ve index.php dizin girişi olarak çalışmalıdır. Bu izin yoksa hesap numarası yine görünür; ölü bağlantı üretmek yerine eski panel adresi çalışır ve firma adresinin etkinleşmediğine dair açık uyarı gösterilir. Uyarı varsa hosting izinleri kontrol edilmeden adres özelliği tamamlandı sayılmaz. Bu koşul canlı sunucuda güncelleme sonrası doğrulanmalıdır.

Mevcut yedekleme veritabanındaki hesap numaralarını kapsar. Web giriş klasöründeki bu küçük yönlendirme dosyaları özel uygulama klasörünün dışındadır; hosting yedeğiyle korunmalı veya güncel uygulama tarafından tekrar oluşturulmalıdır.

## Üyelik açıklamaları

Firma panelindeki eski, genel “elektronik belge bağlantısı geliştirme aşamasında / henüz bağlı değil” açıklamaları güncellendi. Paket bakiyesi ile e-belge servis bakiyesinin farklı olduğu belirtilir. Bu metin düzeltmesi canlı servisi kendiliğinden açmaz ve başarısız işlemi başarılı yapmaz.

## Kontroller ve sınırlar

- İzole PHP/MariaDB ortamında gerçek 3.6.17 → 3.6.18 imzalı kurulum; önceki 40 geçişin ve firma/paket/fiyat/belgelerin korunması; yeni hesap numaraları ve 41. geçişin tekrarlanabilmesi kontrol edildi.
- 304 PHP/veritabanı/erişim kontrolü, 12 gerçek HTTP isteği akışı ve 14 menü etkileşimi kontrolü başarılı. HTTP testleri giriş, firma adresi, eski bağlantılar, farklı firmaya erişim reddi, CSRF ve yönetici adresini kapsar. Menü etkileşimleri DOM olay benzetimiyle denetlendi; gerçek tarayıcıda yerleşim testi olarak sunulmaz.
- 153 PHP kaynak dosyası ve tarayıcı betiklerinin sözdizimi kontrol edildi. Yerel dosyanın bulut tarayıcıda açılması güvenlik politikası nedeniyle engellendi; yeni görünümün canlı tarayıcı kontrolü kurulum sonrasında yapılmalıdır.
- EDM, PayTR veya başka dış kanala canlı gönderim yapılmadı. Kanal durumu ayrı KANAL_ENTEGRASYON_DURUMU_3_6_18.md dosyasındadır. İrsaliye/ihracat ve ödeme doğrulamaları bu tasarım sürümüyle tamamlanmış sayılmaz.
