# Kobivira 3.6.3 — EDM sorgu sınırı düzeltmesi

22 Ekim 2026. Yalnız 3.6.2 üzerine imzalı güncelleme.

## Sorun

3.6.2, bütün EDM test işlemlerinde firma ve IP başına ortak 30 deneme/15 dakika sayacı kullanıyordu. Bağlantı, alıcı, gelen belge ve durum sorguları ile gönderim/kabul/ret aynı kotayı dolduruyor, normal test akışında “Çok fazla deneme. 15 dakika sonra tekrar deneyin.” mesajına neden olabiliyordu. Bu mesaj Kobivira yerel korumasıdır; EDM’nin faturayı reddettiği veya hesabı kapattığı anlamına gelmez.

## Düzeltme

Durum sorgusu 120, bağlantı kontrolü 12, alıcı sorgusu 60, gelen belge sorgusu 20, XML yükleme 30; gönderim/kabul/ret ortak yazma grubu 20 deneme/15 dakika ile ayrı sınırlandırılır. Sayaçlar firma ve IP ayrımını korur. Eski EDM ortak sayacı yeni alanları kilitlemez. Kullanıcı giriş ve yönetici şifresi deneme sayaçları sıfırlanmaz veya değiştirilmez.

Aynı test belgesi için 30 saniyelik yenileme aralığı atomik SQL ile uygulanır. Erken tıklamada EDM’ye yeni giriş veya sorgu yapılmaz; son kaydedilen durum gösterilir ve kullanıcı bilgilendirilir. Erken tıklama aralığı uzatmaz. Sorgu zamanı ile gönderim sonucu karıştırılmaz; eski durum gösteriliyorsa mesajda açıkça belirtilir. Yeni aralık farklı belgeleri ve firmaları engellemez.

Gönderim denemesi, kabul ve ret kaydı korumaları değişmedi. Durum sorgusu hiçbir belgeyi yeniden göndermez. Otomatik finansal işlem tekrarı yoktur. EDM oturum yenileme düzeltmesi korunur. Yeni servis veya ürün eklenmez.

## Kontroller

Eski ortak sınır doluyken yeni sorgu gruplarının çalışması, giriş deneme engelinin korunması, sorgu/yazma kotalarının ayrılığı, firma ayrımı, ilk/tekrar/zamanı dolan sorgu davranışı ve erken HTTP sorgusunda uzak servise bağlanmadan önceki sonucun gösterilmesi test edildi. Önceki SOAP, oturum, firma, CSRF, XML yükleme kontrolleri tekrar çalıştırıldı. İmzalı gerçek yerel 3.6.2 → 3.6.3 kurulumunda şifreli hesaplar, test belgeleri, abonelikler, kontörler ve site içerikleri korunması kontrol edildi. PHP/JavaScript sözdizimi ve önceki 33 migration bütünlüğü kontrol edildi. Yeni migration yoktur.

Bu sürüm için gerçek EDM’ye fatura gönderimi yapılmadı; doğrulamalar yerel MariaDB/HTTP ve sahte SOAP taşıyıcısıyla yapıldı. Kullanıcının mevcut test belgesi ve uzak servis sonucu değiştirilmedi. Canlı sunucuya kurulum yapılmadı. Önceki sürümlerin raporları tarihsel kayıt olarak korunur.

## Kullanım

1. Yönetici → Sistem → Sürüm güncellemeleri üzerinden bu 3.6.3 paketini yükleyin.
2. KVT2026000000001 kaydını yeniden açın; mevcut gönderim UUID’si korunur.
3. “Durumu sorgula” düğmesine basın. Aynı belge için en az 30 saniye aralık bırakın.
4. XML’i tekrar yüklemeyin ve faturayı tekrar göndermeyin. Nihai gönderim durumu ve gelen tarafta aynı UUID ayrı ayrı kontrol edilmelidir.

Yalnız Edm361.php, sürüm açıklaması ve bu sürümün test/rapor dosyaları değişir. Tasarım, paket kapsamı ve ödeme işlemleri değiştirilmez. Kullanıcı sırları veya imzalama özel anahtarı pakette bulunmaz.
