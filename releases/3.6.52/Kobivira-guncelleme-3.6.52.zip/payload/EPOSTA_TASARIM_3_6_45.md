# 3.6.45 — Doğrulama e-postası

3.6.44 üzerine imzalı güncellemedir. Yeni migration yoktur.

Üyelik doğrulama e-postası lacivert/turkuaz Kobivira renklerinde, beyaz kart ve belirgin “E-posta adresimi doğrula” düğmesiyle HTML olarak gönderilir. Dar ekranlara uyumlu tablo düzeni ve satır içi stiller kullanılır. İsim güvenli biçimde kaçırılır; resim yüklenmesine bağımlı değildir. HTML desteklemeyen istemciler için düz metin alternatifi korunur. Açık bağlantı, süre ve hesap sahibinin yapmadığı kayıtlar için açıklama vardır.

Mevcut tek kullanımlık token, 30 dakika, yeniden gönderim sınırı ve onay sayfasındaki POST güvenliği korunur. E-postayı açmak veya düğmeye tıklamak hesabı tek başına doğrulamaz; açılan sayfada onay gerekir. SMS, PayTR ve paket ayarları değiştirilmez. Diğer bildirimler mevcut düz metin biçiminde kalır.

Gönderen adresini değiştirmek için hostingde örneğin bildirim@kobivira.com.tr posta kutusunu oluşturun. Yönetim → Destek ve İletişim → E-posta / SMS gönderimleri bölümünde SMTP kullanıcısını ve gönderen e-postayı bu adresle, SMTP şifresini yeni posta kutusunun şifresiyle değiştirin. mail.kobivira.com.tr, 465, TLS / SSL aynı kalabilir. Mevcut platform yöneticisi şifresiyle kaydedip deneme e-postası gönderin. Yeni adres bu sürüm tarafından oluşturulmaz veya kendiliğinden etkinleştirilmez. info@ destek adresi olarak kalır.

Gerçek doğrulama e-postasının teslimi önceki sürümde kullanıcı tarafından paylaşılan gelen iletiyle gözlendi. Bu yeni HTML şablonunun farklı gerçek posta istemcilerindeki görünümü kurulumdan sonra kontrol edilmelidir. Bu çalışma sırasında gerçek e-posta gönderilmedi.
