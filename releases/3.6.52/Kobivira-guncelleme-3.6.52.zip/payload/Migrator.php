<?php
declare(strict_types=1);
final class Migrator {
    public function __construct(private PDO $db) {}
    public function run(string $dir): void {
        $this->db->exec("CREATE TABLE IF NOT EXISTS schema_migrations (id VARCHAR(100) PRIMARY KEY,checksum CHAR(64) NOT NULL,status VARCHAR(16) NOT NULL,applied_at DATETIME NULL,error TEXT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $dirty=$this->db->query("SELECT id FROM schema_migrations WHERE status <> 'applied'")->fetchColumn();
        if ($dirty !== false) { throw new RuntimeException('Tamamlanmamış migration: ' . $dirty . '. Önce yedekten kurtarma gerekir.'); }
        $files=glob($dir . '/*.php') ?: []; sort($files, SORT_STRING);
        foreach ($files as $file) {
            $id=basename($file); $hash=hash_file('sha256',$file);
            $q=$this->db->prepare('SELECT checksum FROM schema_migrations WHERE id=?'); $q->execute([$id]); $old=$q->fetchColumn();
            if ($old !== false) { if (!hash_equals($old,$hash)) { throw new RuntimeException('Uygulanmış migration değiştirilemez: ' . $id); } continue; }
            $q=$this->db->prepare("INSERT INTO schema_migrations(id,checksum,status) VALUES (?,?,'started')"); $q->execute([$id,$hash]);
            try {
                $migration=require $file;
                if (!is_callable($migration)) { throw new RuntimeException('Migration callable olmalıdır.'); }
                $migration($this->db);
                $q=$this->db->prepare("UPDATE schema_migrations SET status='applied',applied_at=UTC_TIMESTAMP(),error=NULL WHERE id=?"); $q->execute([$id]);
            } catch(Throwable $e) {
                $q=$this->db->prepare("UPDATE schema_migrations SET status='failed',error=? WHERE id=?"); $q->execute([mb_substr($e->getMessage(),0,2000),$id]); throw $e;
            }
        }
    }
}
