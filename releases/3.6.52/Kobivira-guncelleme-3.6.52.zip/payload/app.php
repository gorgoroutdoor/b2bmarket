<?php
declare(strict_types=1);
foreach(['pdo_mysql','mbstring','zip','sodium','zlib','tokenizer','ctype'] as $ext){if(!extension_loaded($ext)){http_response_code(503);exit('Eksik PHP eklentisi: '.htmlspecialchars($ext));}}
if(PHP_INT_SIZE<8){http_response_code(503);exit('64 bit PHP gereklidir.');}
require __DIR__.'/Modules.php';
if(($_GET['page']??null)==='paytr_callback')paytr3623_callback();
if(($_GET['page']??null)==='payment_return')checkout3624_return();
ini_set('session.use_strict_mode','1');ini_set('session.use_only_cookies','1');session_name('kobi_finans');
$isHttps=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off');
if(!$isHttps&&!in_array($_SERVER['REMOTE_ADDR']??'',['127.0.0.1','::1'],true)){http_response_code(426);exit('Güvenli bağlantı için bu adresi https:// ile açın.');}
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$isHttps,'httponly'=>true,'samesite'=>'Lax']);
session_save_path(APP_ROOT.'/storage/sessions');if(!session_start()){http_response_code(503);exit('Oturum başlatılamadı. Çalışma klasörünün yazma izinlerini kontrol edin.');}
if(isset($_SESSION['user_id'])&&(time()-($_SESSION['seen']??0)>1800||time()-($_SESSION['started']??0)>43200))$_SESSION=[];
$_SESSION['seen']=time();$_SESSION['csrf']??=bin2hex(random_bytes(32));
$nonce=base64_encode(random_bytes(18));$GLOBALS['nonce']=$nonce;
$paytrFrame=(in_array($_GET['page']??null,['paytr_test','billing'],true))?' https://www.paytr.com':'';
header("Content-Security-Policy: default-src 'none'; style-src 'nonce-$nonce'; script-src 'nonce-$nonce'; img-src 'self' data:; connect-src 'self'; frame-src 'self'$paytrFrame; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
if(($_GET['page']??'')==='register'&&($_GET['embedded']??'')==='1'&&$_SERVER['REQUEST_METHOD']==='GET')header("Content-Security-Policy: default-src 'none'; style-src 'nonce-$nonce'; script-src 'nonce-$nonce'; img-src 'self' data:; connect-src 'self'; frame-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors https://kobivira.com.tr https://www.kobivira.com.tr");
header('X-Content-Type-Options: nosniff');header('Referrer-Policy: same-origin');header('Cache-Control: no-store');header('Permissions-Policy: camera=(),microphone=(),geolocation=()');
$page=is_string($_GET['page']??null)?$_GET['page']:'dashboard';if($page==='register'&&($_GET['campaign']??'')==='migration'&&is_file(APP_ROOT.'/config/installed.lock')&&migration_config()['enabled'])$_SESSION['migration_intent']=time();if(in_array($page,['verify_mobile','forgot_password'],true)&&is_file(APP_ROOT.'/config/installed.lock'))phone3644_page();if($page==='verify_email'&&is_file(APP_ROOT.'/config/installed.lock'))email3643_public();pricing_capture_intent();if(($_GET['kv_action']??'')==='lead'&&is_file(APP_ROOT.'/config/installed.lock'))lead352_public();if(($_GET['kv_action']??'')==='popup'&&is_file(APP_ROOT.'/config/installed.lock'))promotion353_public_claim();if($page==='site_asset')cms_asset();if($page==='public_site')cms_public();if($page==='sales_lead')lead352_public();if($page==='site_media')cms_media();if($page==='marketing_data')marketing_data();if($page==='brand_asset')brand_asset();if($page==='showcase')public_site();if($page==='site_edit_context')studio3634_edit_context();$error=null;$GLOBALS['authorized']=false;
if($_SERVER['REQUEST_METHOD']==='POST'&&in_array($page,['document','newdocument'],true)&&!isset($_GET['id'])&&is_string($_POST['id']??null)&&ctype_digit($_POST['id'])&&(int)$_POST['id']>0)$_GET['id']=$_POST['id'];
try {
    if(!is_file(APP_ROOT.'/config/installed.lock')){$page='install';$GLOBALS['authorized']=true;if($_SERVER['REQUEST_METHOD']==='POST'){check_csrf();install_app();}}
    else {
        if($page==='legal')legal_public();if($page==='reconciliation_reply')ledger_public_reply();if($page==='customer_portal')customer_portal();if($page==='public_data')public_data();
        if($page==='web_preview'){try{cp_preview_scope();}catch(DomainException $e){header('Cache-Control: private, no-store, max-age=0');header('Location: https://kobivira.com.tr/',true,303);exit;}}
        company3618_scope($page);
        if(!in_array($page,['login','register'],true)&&!current_user())redirect('login');
        if(current_user()&&$page==='register'&&($_GET['embedded']??'')==='1'&&$_SERVER['REQUEST_METHOD']==='GET'){product3633_registration(null);exit;}if(current_user()&&in_array($page,['login','register','install'],true)){$intent=pricing_intent();if($intent&&current_user()['role']==='company_admin')redirect('membership',['view'=>'plans','plan'=>$intent['plan'],'period'=>$intent['period']]);redirect('dashboard');}
        if(is_file(APP_ROOT.'/storage/maintenance.json')&&!in_array($page,['login','updates','logout'],true)){
            if(owner())redirect('updates');http_response_code(503);throw new DomainException('Kısa bir bakım yapılıyor. Lütfen daha sonra tekrar deneyin.');
        }
        authorize_page($page);$GLOBALS['authorized']=true;if($_SERVER['REQUEST_METHOD']==='GET'&&!demo3627_preview($page,$_GET))background_company_cycle();
        if($_SERVER['REQUEST_METHOD']==='POST'){check_csrf();dispatch_post($page);}
        if($page==='edm_test')edm366_download();if(in_array($page,['edoc_center','incoming_invoices'],true)&&empty($_GET['legacy'])&&!demo3627_preview($page,$_GET))firm3615_download();
        if(ledger_route($page))ledger_download($page);if($page==='migration')migration_download();if($page==='web_preview')cms_public(true);if($page==='bank_match'&&isset($_GET['template']))bank_template();if($page==='data_import'&&isset($_GET['template']))import_template((string)$_GET['template']);if($page==='contact_lookup')contact_lookup();if($page==='verification_download')evidence_download();if($page==='print_document')print_document();if($page==='invoice_download')invoice_download();
        if($page==='support_follow')desk_follow_response();
        if($page==='export'){export_csv();exit;}
        if($page==='support_poll'){http_response_code(405);json_response(['ok'=>false]);}
    }
} catch(DomainException $e){$error=$e->getMessage();if(http_response_code()<400)http_response_code(422);}
catch(Throwable $e){error_log((string)$e);http_response_code(500);$error=$e instanceof PDOException&&$e->getCode()==='23000'?'Bu e-posta veya kayıt kodu zaten kullanılıyor. Bilgileri kontrol edin.':'İşlem tamamlanamadı. Lütfen tekrar deneyin; sorun sürerse yöneticiye başvurun.';}
if(form353_ajax())form353_response($error===null,$error??'Kaydedildi.', $error===null?url($page,$_GET):null,$error===null?200:max(400,http_response_code()));
ob_start();
try {render($page,$error);echo ob_get_clean();}
catch(DomainException $e){ob_end_clean();if(http_response_code()<400)http_response_code(422);$GLOBALS['authorized']=false;render($page,$e->getMessage());}
catch(Throwable $e){ob_end_clean();error_log((string)$e);http_response_code(500);echo '<p>Sayfa görüntülenemedi. Yönetici hata günlüğünü kontrol edebilir.</p>';}

