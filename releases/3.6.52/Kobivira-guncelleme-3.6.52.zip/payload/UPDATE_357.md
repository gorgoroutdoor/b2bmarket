# Kobivira 3.5.7

3.5.6 üzerine imzalı güncelleme. Tanıtım sitesinde mobil hamburger menüsüne Giriş yap bağlantısı ekler. Adres sistemin public_app_url ayarından alınır. Mevcut masaüstü giriş bağlantısı ve tasarım korunur; ek bağlantı yalnız 800 piksel ve altında menü içinde gösterilir. Migration, fiyat, kota, firma verisi ve entegrasyon değişikliği yoktur.
