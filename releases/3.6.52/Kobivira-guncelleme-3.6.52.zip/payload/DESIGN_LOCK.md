# Kobivira tasarım sabiti

Kullanıcı kararı — 19 Ekim 2026: mevcut tasarım bir yıl boyunca sabit tutulacaktır. Kullanıcı açıkça istemedikçe renkler, yazı tipi, menü biçimi, temel ekran yerleşimi ve bileşen stilleri yeniden tasarlanmaz. Yeni işlevler mevcut bileşenlerle eklenir.

3.1.0 sürümünün style.css dosyası, 3.0.0 kurulumundaki style.css ile bayt düzeyinde aynıdır. Marka metninin Kobivira olması, istenen üyelik/ödeme bilgileri, onay pencereleri, alan açıklamaları ve kategori kapanma davranışı işlev kapsamındadır.

Bu karar gelecekteki güncellemelere de taşınmalıdır. Otomatik periyodik bir iş veya bir yıl sonraki otomatik değişiklik izni anlamına gelmez.

3.1.1: kullanıcının açık talebiyle belge satırının taşması giderildi; mobil satırlar etiketlenip istiflendi; pencereler ortalanıp küçültüldü; destek izinleri kaydırılabilir oldu. Bu düzeltmeler patch.css içinde izole edilmiştir. style.css hâlâ önceki sürümle aynıdır. Destek sırası ve izleme işlevleri mevcut bileşenleri kullanır.

3.1.2: kullanıcı 19 Ekim 2026 tarihinde logoya uygun tema renklerini açıkça talep etti. Bu istisna yalnızca lacivert / turkuaz renk uygulamasını ve istenen işlev alanlarını kapsar. Temel yerleşim, yazı tipleri, menü yapısı ve boyutlar korunur. Renkler brand.css içindedir; eski style.css değişmemiştir.

3.1.3: temel style.css ve brand.css değişmedi. Destek sayaçları, yazışmalar ve izin alanları aynı bileşenlerle eklendi. Logo / Genel bakış tüm kategorileri kapatır.

3.1.4: Temel stil ve marka renkleri aynıdır. Firma evrakları, mesajlar ve iş hatırlatmaları mevcut panel bileşenlerini kullanır. PDF / yazdır ayrı sekmede açılır.

3.1.5: Mevcut yerleşim ve marka stilleri korunur. Ayrı kullanıcı düzenleme sayfası, sade destek konuşması, müşteri araması ve okunabilir geçmiş mevcut bileşenlerle eklenir.

3.6.19: Kullanıcının 23 Ekim 2026 tarihli açık talebiyle firma ve yönetici menülerinde ortak lacivert/turkuaz palet, daraltılmış ikon şeridi, sade başlıklar, bağlamsal yardım ve tablo satırı vurgusu uygulandı. Mevcut kategori sırası ve iş ekranlarının yerleşimi korundu.
