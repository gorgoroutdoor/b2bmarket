# Kobivira 3.5.4 — 3.5.3 üzerine güncelleme

Bu paket yeni kurulum değildir. Tek imzalı ZIP, mevcut yönetim panelindeki **Sistem → Sürüm güncellemeleri** bölümünden yüklenir. ZIP açılmaz; cPanel'den dosya veya SQL yüklemek gerekmez. Güncelleyici mevcut güvenilen anahtarla imzayı ve tüm dosya özetlerini doğrular, veritabanını yedekler ve yeni migration'ı uygular.

## Kapsam ve korunan ayarlar

- Tasarım, logo, renkler ve eski CSS dosyaları korunur. Yalnız ortak erişim kartı ve kütüphane paket etiketleri için ek stiller bulunur.
- Kullanıcı kotaları, paket fiyatları, KDV, yıllık indirimler ve dönemsel kampanya ayarları değiştirilmez; admin yönetiminde kalır.
- Eski 27 migration dosyası ve önceki sürüm açıklamaları değiştirilmez. Yeni migration: `028_policy354.php`.
- Üç paket devam eder: KOBİ, KOBİ Plus, KOBİ Business.
- Gerçek e-Belge, POS, otomatik banka / pazaryeri bağlantıları veya yeni SMS entegrasyonu yapılmaz. Mevcut bağlantı ayarları korunur. Bu sürüm bir entegratör aktivasyonu değildir.

## 1. Kritik işleyiş düzeltmeleri

- Paket düşürüldüğünde firmaya ait eski belge ve PDF görüntüleme açık kalır. Önceki siparişler liste üzerinden de görülebilir. Üst pakete ait oluşturma, düzenleme, kesinleştirme ve dönüşüm işlemleri ayrı denetlenir; başka firmanın kayıtlarına erişilemez.
- KOBİ ve deneme hesapları ücretli e-Belge / müşteri POS işlemlerini başlatamaz. Gelen e-Fatura işleminde paket kontrolü özel adaptör oluşturulmadan ve çağrılmadan önce yapılır. Geçmiş kutu kayıtları salt okunur görüntülenebilir.
- Firma adına kartla tahsilat yetkisi ile Kobivira'nın kendi üyelik tahsilatı ayarları ayrıdır.
- CLI zamanlayıcısı web uygulamasıyla aynı modül tanımlarını yükler. Deneme tekrarındaki eksik fonksiyon giderilir; veri taşıma kampanyası normal 5 belge kotasıyla karıştırılmaz.
- Üç otomasyon türünde de ilk 500'den sonraki kayıtlar sonraki çalıştırmalarda işlenir. Günlük tekillik ve firma ayrımı korunur. 100'den fazla kuralda da sıra ilerler. Oluşturulan tekrar belgeleri taslaktır; otomatik finansal kesinleştirme yapılmaz.
- Gerçek tarayıcı kontrolünde bulunan `action` ve `method` adlı form alanlarının JavaScript form özelliklerini gölgelemesi düzeltildi. Genel formlar ve geri arama popup'ı gönderim adresini HTML özniteliğinden okur. Hata halinde girilen değerler korunur.

## 2. Paket kapsamı

| İşlev | KOBİ | KOBİ Plus | KOBİ Business |
|---|---|---|---|
| Satış / alış / gider, cari, kasa / banka, tahsilat / ödeme, temel rapor | Dahil | Dahil | Dahil |
| Standart teklif / proforma ve PDF | Dahil | Dahil | Dahil |
| Temel CSV dışa aktarım | Dahil | Dahil | Dahil |
| Sipariş ve belgeler arası dönüşüm | — | Dahil | Dahil |
| Cari PDF / Excel ekstre, yaşlandırma, iade, döviz, çek | — | Dahil | Dahil |
| İş takibi, tekrarlar, çalışan giderleri | — | Dahil | Dahil |
| CRM, proje, nakit öngörüsü, mutabakat, gelişmiş onay / otomasyon | — | — | Dahil |
| e-Fatura / e-Arşiv ve kartla tahsilat hazırlık yetkisi | — | Ücretli üyelikte | Ücretli üyelikte |
| e-SMM / e-İrsaliye / e-İhracat hazırlık yetkisi | — | Yönetici ek yetkisi varsa | Ücretli üyelikte |
| Salt okunur veri API | — | Yönetici ek yetkisi varsa | Ücretli üyelikte |
| Web / reklam modüllerinin görünürlüğü | Yönetici seçimine bağlı | Yönetici seçimine bağlı | Yönetici seçimine bağlı |

Hazırlık yetkisi, gerçek dış servis işleminin çalıştığı anlamına gelmez. Bağlantı ve varsa kullanım bedeli ayrıca gerekir. Reklam alanı bağlantı hazırlığıdır; çalışan kampanya yönetimi olarak sunulmaz. Kullanıcı sayıları ve aktarım alanı admin değerlerinden okunur.

## 3. Kütüphane ve erişim kartları

- Müşterilere açık tüm rehberlerde belirgin tam paket adları yer alır; eski genel paket etiketleri kaldırılır.
- Standart teklif / proforma, yaşlandırma ve on adet günlük ön muhasebe / aktarım rehberindeki eski seviyeler güncellenir.
- Temel çalışan onayı ile Business'ın gelişmiş onay kuralları açıkça ayrılır.
- Uygulama, admin karşılaştırması ve tanıtım sitesi aynı işlev kataloğundan kapsam alır. Paket tanıtım kartlarının metinleri yenilenir; önceki kart içerikleri CMS geçmişine kaydedilir. Fiyat ve indirimler değiştirilmez.
- Uygulanmış üst paket özellikleri menüde görülebilir; tıklanınca aynı mobil uyumlu erişim kartı açılır. Yönetici tarafından kapatılan web / reklam modülleri gizli kalır.
- Paket eksikliği, rol yetkisi, süre bitişi, demo kotası, kapalı modül ve bağlantısı olmayan servis aynı hata gibi sunulmaz. Rol yetkisi olmayan çalışanı paket satın almaya yönlendirme yapılmaz.

## 4. Yıllık Plus: bir kez 1.000 hediye kontör

- Yalnız **tek ödeme talebinde 12 ay KOBİ Plus** satın alımı ve yönetici ödeme onayı uygundur.
- Firma hesabı ve kampanya için tekil hediye kaydı tutulur. Bildirim ve ayrı kontör hareketi oluşur; bu hediye mevcut aylık paket kontörü hesabına karışmaz.
- Aylık / üç aylık ödeme, yalnız paket atama, deneme, henüz onaylanmamış havale, ret ve iptal hediye oluşturmaz.
- Yenileme, tekrar onay ve sonraki tekrar satın alım ikinci hediye vermez. Geri alınmış hediye de yeniden verilmez.
- Önceden onaylanmış geçmiş ödemelere otomatik geriye dönük hediye verilmez. Güncelleme anındaki bekleyen yıllık Plus talepleri uygunluğunu korur.
- Admin, firma kontör yönetiminde ödeme iptali / iadesi değerlendirmesi için gerekçeyle hediyeyi geri alabilir. Bakiye yetersizse negatif bakiye yaratılmaz; ayrı iade değerlendirmesi gerekir. Bu işlem bankadan para iadesi yapmaz.
- Kontör tanımlanması resmî belge gönderimi açmaz. Kullanım paket yetkisi ve etkin sağlayıcı gerektirir. Bu sürüm kontör süresini tüketen bir sona erme tarihi koymaz; sağlayıcıya özel kullanım koşulları bağlantı aşamasında ayrıca belirlenmelidir.

## 5. Paket değişikliği ve fiyat yönetimi

- Aynı pakette yenileme kalan ücretli sürenin sonuna eklenir.
- Farklı pakete geçiş ödeme onayında başlar. Kalan ücretli saniye, talep anında sabitlenen **eski net aylık liste fiyatı / yeni net aylık liste fiyatı** oranıyla ek süreye çevrilir. Yeni satın alınan dönemin sonuna eklenir. Deneme günleri taşınmaz.
- Örnek: 30 gün kalan ve liste fiyatı 400 TL olan paketten 1.200 TL'lik pakete geçişte yaklaşık 10 gün ek süre oluşur. Gerçek hesap onay anındaki kalan saniyeyi kullanır.
- Bu bir nakit iade veya ödeme indirimi değildir. Kampanyalar satın alma tutarına normal şekilde uygulanır; süre oranının liste fiyatları talep kaydında sabitlenir.
- Firma satın almadan önce koşulları onaylar; firma ve admin ödeme kaydında sabitlenen oranı ve onayda eklenen süreyi görür.
- Bekleyen talep oluşturulduktan sonra üyelik başka bir işlemle değiştirilirse eski talep otomatik onaylanmaz; güncel üyeliğe göre yeni talep gerekir. Kalan süre hesabında fiyat bulunmaması veya 10 yılı aşan sonuç yönetici incelemesine bırakılır.

## Doğrulama ve sınırlar

İşlev, gerçek HTTP, gerçek Chromium masaüstü / mobil, gerçek CLI ve önceki sürüm güncelleyicisi testleri yerel ve geçici MySQL kurulumunda yapılır. Finansal belgeler ve ödeme onayları test verileridir; gerçek banka / entegratör işlemi yapılmaz. Canlı hosting'e bu çalışma sırasında dosya yüklenmez.

Son yerel turda 522 işlev / HTTP / MySQL / CLI kontrolü ve gerçek Chromium ile 26 masaüstü / mobil tarayıcı kontrolü geçti. 117 PHP dosyası ve 19 JavaScript kaynağı sözdizimi kontrolünden geçti. Bu testler bütün hosting yapılandırmaları için güvenlik sertifikası veya gerçek sağlayıcı kabul testi değildir.
