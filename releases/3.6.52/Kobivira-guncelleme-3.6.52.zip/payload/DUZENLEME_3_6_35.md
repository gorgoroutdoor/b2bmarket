# Kobivira 3.6.35

3.6.34 üzerine imzalı tam güncelleme.

Hero altındaki logo şeridinden **Hareketi durdur** düğmesi kaldırıldı.

Yeni metin:

**VERİ TAŞIMA**

**Mevcut kayıtlarınızı Kobivira’ya taşıyın.**

Cari, ürün ve fatura kayıtlarınızı desteklenen dosyalarla aktarın.

Bağlantı: **Veri taşıma rehberi →**

Bu alan, listelenen programlardan desteklenen dosyalar aracılığıyla veri aktarımını tanıtır. Canlı entegrasyon bağlantısı anlamına gelmez.

Başlık ve açıklama **Veri taşıma tanıtımı → Satış kartı metinleri → Hero altındaki logo şeridi** alanlarından değiştirilebilir. Mevcut program logoları ve rehber bağlantıları korunur. Hareket, fareyle üzerine gelindiğinde ve klavye odağında durur; azaltılmış hareket tercihi desteklenir.

Veritabanı migration değişikliği yoktur. Değişen PHP dosyalarının söz dizimi ve imzalı paketin bütünlüğü kontrol edildi. Canlı siteye yükleme yapılmadı.
