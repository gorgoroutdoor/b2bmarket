# Kobivira 3.5.1 test raporu

Yeni değişikliklerde 224 kontrol başarılıdır. Ayrıca 3.5.0 muhasebe / aktarım regresyonundan 108 kontrol 3.5.1 koduyla çalıştırılmıştır. PHP 8.3.6 ve MariaDB 10.11.14 kullanıldı.

## Paket, form ve doğrudan erişim HTTP testleri · 174 kontrol

- Login kobi-policy@example.invalid
- Dashboard kobi-policy@example.invalid
- No fourth package kobi
- kobi can create sale
- kobi can post sale
- kobi can create purchase
- kobi can post purchase
- kobi can create expense
- kobi can post expense
- kobi quote entitlement enforced in POST
- kobi proforma form entitlement
- kobi direct URL aging
- kobi direct URL reconciliations
- kobi direct URL projects
- kobi direct URL advanced_reports
- kobi direct URL forecast
- kobi direct URL crm
- kobi default closed digital module website
- kobi default closed digital module digital_ads&channel=meta
- kobi default closed digital module digital_ads&channel=google
- kobi sees exactly three package comparison
- kobi can create contact
- kobi can create product service
- kobi can record receipt
- Login plus-policy@example.invalid
- Dashboard plus-policy@example.invalid
- No fourth package plus
- plus can create sale
- plus can post sale
- plus can create purchase
- plus can post purchase
- plus can create expense
- plus can post expense
- plus quote entitlement enforced in POST
- plus proforma form entitlement
- plus direct URL aging
- plus direct URL reconciliations
- plus direct URL projects
- plus direct URL advanced_reports
- plus direct URL forecast
- plus direct URL crm
- plus default closed digital module website
- plus default closed digital module digital_ads&channel=meta
- plus default closed digital module digital_ads&channel=google
- plus sees exactly three package comparison
- plus can create contact
- plus can create product service
- plus can record receipt
- Login business-policy@example.invalid
- Dashboard business-policy@example.invalid
- No fourth package business
- business can create sale
- business can post sale
- business can create purchase
- business can post purchase
- business can create expense
- business can post expense
- business quote entitlement enforced in POST
- business proforma form entitlement
- business direct URL aging
- business direct URL reconciliations
- business direct URL projects
- business direct URL advanced_reports
- business direct URL forecast
- business direct URL crm
- business default closed digital module website
- business default closed digital module digital_ads&channel=meta
- business default closed digital module digital_ads&channel=google
- business sees exactly three package comparison
- business can create contact
- business can create product service
- business can record receipt
- Login admin-policy@example.invalid
- Dashboard admin-policy@example.invalid
- Admin module_admin renders
- Admin launch_admin renders
- Admin legal_admin renders
- Admin plans renders
- Admin companies renders
- Admin saves independent selected package module access
- Login plus-policy@example.invalid
- Dashboard plus-policy@example.invalid
- Login business-policy@example.invalid
- Dashboard business-policy@example.invalid
- Selected Plus sees website
- Unselected Business cannot see website
- Selected Business sees Meta preparation
- Unselected Plus cannot see Meta
- Disabled Google remains inaccessible
- Admin creates corporate website for selected Plus company
- Selected Plus can open actual corporate content panel
- plus saves quote
- plus finalizes quote
- plus prints quote
- plus saves proforma
- plus finalizes proforma
- plus prints proforma
- plus saves order
- plus finalizes order
- plus prints order
- business saves quote
- business finalizes quote
- business prints quote
- business saves proforma
- business finalizes proforma
- business prints proforma
- business saves order
- business finalizes order
- business prints order
- Registration includes checkbox and popup
- Login screen has no registration consent checkbox
- Admin publishes terms
- Sanitized public legal terms
- Admin publishes privacy
- Sanitized public legal privacy
- Admin publishes kvkk
- Sanitized public legal kvkk
- Registration rejects missing consent
- Registration rejects forged legal version
- Registration succeeds with all published versions accepted
- Marketing homepage includes mega menu and premium migration card
- Public packages remove fourth package
- Published marketing link rehber-teklif
- Published marketing link rehber-veri-tasima
- Published marketing link hakkimizda
- Published marketing link rehber-ongoru
- Published marketing link rehber-iade
- Published marketing link rehber-web-sitesi
- Published marketing link rehber-hesaplar
- Published marketing link rehber-baslangic
- Published marketing link rehber-raporlar
- Published marketing link rehber-siparis
- Published marketing link rehber-cari-ekstre
- Published marketing link rehber-onay-kurallari
- Published marketing link kullanim
- Published marketing link rehber-calisan-gideri
- Published marketing link rehber-alis-faturasi
- Published marketing link yazi-ekip-yetkileri
- Published marketing link rehber-urunler
- Published marketing link yazi-tekliften-tahsilata
- Published marketing link referans
- Published marketing link rehber-gelen-efatura
- Published marketing link cerezler
- Published marketing link rehber-musteriler
- Published marketing link paketler
- Published marketing link yazi-cari-bakiye-ve-nakit
- Published marketing link rehber-satis-faturasi
- Published marketing link guvenlik
- Published marketing link iletisim
- Published marketing link rehber-smm
- Published marketing link rehber-is-takibi
- Published marketing link sss
- Published marketing link baglantilar
- Published marketing link rehber-mutabakat
- Published marketing link blog
- Published marketing link ozellikler
- Published marketing link rehber-yaslandirma
- Published marketing link rehber-proje
- Published marketing link gizlilik
- Published marketing link kutuphane
- Published marketing link rehber-ebelge-turleri
- Published marketing link rehber-giderler
- Published marketing link rehber-elektronik-belge
- Published marketing link rehber-guvenlik
- Published marketing link rehber-proforma
- Published marketing link rehber-crm
- Published marketing link deneyim
- Published marketing link rehber-kullanicilar
- Published marketing link rehber-genel-bakis
- Published marketing link rehber-tahsilat
- Login kobi-policy@example.invalid
- Dashboard kobi-policy@example.invalid
- Expired paid package cannot create new invoice
- Expired paid package can still view its records

## Yetki / menü / hukuki sürüm ve HTML denetimleri · 21 kontrol

- Registered company exists after legal consent
- Three accepted legal versions persist
- Publishing a later revision does not change previous consent
- Consent hashes match actual accepted immutable content
- HTML editor removes active HTML and dangerous links
- Safe formatted HTML links retained
- Retired plan disabled while history retained
- Comparison matrix is feature plus three plans
- Forged retired plan administration rejected
- kobi hides unavailable quote menu
- kobi hides unavailable aging menu
- kobi hides disabled Google module
- kobi keeps usable finance menus
- plus hides unavailable quote menu
- plus hides unavailable aging menu
- plus hides disabled Google module
- plus keeps usable finance menus
- business hides unavailable quote menu
- business hides unavailable aging menu
- business hides disabled Google module
- business keeps usable finance menus

## İstatistik kartı algoritması ve CSS kontrolleri · 8 kontrol

- Metric text fits modeled 136px content width without dropping currency
- Metric text fits modeled 170px content width without dropping currency
- Metric text fits modeled 200px content width without dropping currency
- Metric text fits modeled 240px content width without dropping currency
- Metric text fits modeled 320px content width without dropping currency
- Metric text fits modeled 400px content width without dropping currency
- Metric nowrap, equal-height cards, 48/32px spacing and reduced-motion rules present
- Registration popup/editor JavaScript parses

## Hukuki metin açılır pencere etkileşimleri · 4 kontrol

- Registration links open native modal without navigation
- Closing legal modal returns focus to source link
- Stale request cannot replace a newly opened legal document
- Separate-tab link preserves selected document and version

## Firma silme ve kabul kayıtlarının yedekten temizlenmesi · 3 kontrol

- Company deletion clears new accounting and import tables
- Company deletion removes private uploaded files
- Application backup sanitized for new tenant tables

## Tasarım / önceki migration bütünlüğü · 3 kontrol

- All 23 old migration files unchanged
- Existing application CSS and brand pack unchanged
- Only targeted marketing CSS / JS and feature metadata changed in asset pack

## 3.5.0 güncelleyicisiyle kurulum · 11 kontrol

- Existing installation public key verifies package signature
- Modified payload rejected before installation
- Actual 3.5.0 updater installs and activates 3.5.1
- All installed payload file hashes match
- Upgrade applies two new migrations while preserving all 23 old checksums
- Existing company and subscription retained
- New release history appears without altering previous notes
- Migration guide installed by old updater
- Update completion recorded
- Legacy Business Plus subscription migrated to Business
- Legacy subscription dates and company data preserved

## Kanıt sınırları

108 PHP uzantılı dosya sözdizimi kontrolünden geçti. İstatistik sığdırma testleri gerçek font / cihaz renderı değil, genişlik ve metin ölçüsü modelidir. Hukuki açılır pencere etkileşimi DOM benzetimiyle sınandı. Chromium kurulumu indirilen arşiv geçersiz olduğundan tamamlanamadı; masaüstü / mobil görsel QA yapılmış sayılmaz. Gerçek sağlayıcı / reklam hesapları bağlanmadı, canlı hostingde işlem yapılmadı. Dosya imzası mevcut açık anahtarla doğrulandı ve imza kontrolü korundu. Yeni modül ve hukuki kayıt tabloları firma erişimi / silme davranışında denetlendi.
