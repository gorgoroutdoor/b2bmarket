<?php
declare(strict_types=1);
function retention3649_install():void {$path=APP_ROOT.'/KobiviraCron.php';$source=(string)file_get_contents(__DIR__.'/Cron3649.php');if(is_link($path)||(is_file($path)&&!hash_equals(hash('sha256',$source),hash_file('sha256',$path))))throw new DomainException('Sabit zamanlayıcı dosyası zaten var ve farklı. Üzerine yazılmadı.');if(!is_file($path))atomic_write($path,$source);chmod($path,0600);}
function retention3649_queue():void {atomic_write(APP_ROOT.'/storage/retention3649.pending',gmdate('c'));}
function retention3649_plan():array {
 $rows=query("SELECT id,version,previous_version,status,backup_file FROM system_updates ORDER BY id DESC")->fetchAll();$keep=[];$protected=[APP_VERSION=>true];$candidates=[];$n=0;
 foreach($rows as $r){$file=(string)($r['backup_file']??'');if(!preg_match('/^backup-[A-Za-z0-9-]+\.jsonl\.gz$/D',$file))continue;$path=APP_ROOT.'/storage/backups/'.$file;if(!is_file($path)||is_link($path))continue;
  if($r['status']!=='applied'||$n<10){$keep[$file]=true;if($r['status']==='applied')$n++;foreach(['version','previous_version'] as $key)if(preg_match('/^\d+\.\d+\.\d+$/D',$r[$key]))$protected[$r[$key]]=true;}
  else $candidates[$file]=$path;
 }
 foreach($keep as $file=>$v)unset($candidates[$file]);$releases=[];foreach(glob(APP_ROOT.'/releases/*',GLOB_ONLYDIR)?:[] as $path){$v=basename($path);if(preg_match('/^\d+\.\d+\.\d+$/D',$v)&&!isset($protected[$v])&&!is_link($path))$releases[$v]=$path;}
 return ['keep'=>$keep,'protected'=>$protected,'backups'=>$candidates,'releases'=>$releases];
}
function retention3649_stable_ready():bool {$path=APP_ROOT.'/KobiviraCron.php';return is_file($path)&&!is_link($path)&&hash_equals(hash_file('sha256',__DIR__.'/Cron3649.php'),hash_file('sha256',$path));}
function retention3649_step():array {
 $out=['backups'=>[],'releases'=>[],'pending'=>false];if(is_file(APP_ROOT.'/storage/maintenance.json')||!is_file(APP_ROOT.'/storage/retention3649.pending'))return $out;
 $pointer=json_decode((string)file_get_contents(APP_ROOT.'/storage/current.json'),true);if(($pointer['version']??'')!==APP_VERSION)return $out;
 $gate=$GLOBALS['gate']??null;$own=false;if(!is_resource($gate)){$gate=fopen(APP_ROOT.'/storage/request.lock','c');$own=true;}if(!$gate||!flock($gate,LOCK_EX|LOCK_NB)){if($own&&is_resource($gate))fclose($gate);$out['pending']=true;return $out;}
 try{$plan=retention3649_plan();$end=microtime(true)+6;foreach($plan['backups'] as $file=>$path){if(microtime(true)>$end)break;if(is_link($path))continue;if(!unlink($path))throw new DomainException('Eski güncelleme yedeği temizlenemedi.');$out['backups'][]=$file;}
  if(setting('retention3649_stable_cron','0')==='1'&&retention3649_stable_ready())foreach($plan['releases'] as $v=>$path){if(microtime(true)>$end)break;Updater::remove_tree($path);$out['releases'][]=$v;}
  $after=retention3649_plan();$out['pending']=(bool)$after['backups']||(setting('retention3649_stable_cron','0')==='1'&&retention3649_stable_ready()&&(bool)$after['releases']);
  atomic_write(APP_ROOT.'/storage/retention3649.last.json',json_encode($out+['at'=>gmdate('c')],JSON_THROW_ON_ERROR));if(!$out['pending'])@unlink(APP_ROOT.'/storage/retention3649.pending');return $out;
 }finally{if($own){flock($gate,LOCK_UN);fclose($gate);}else flock($gate,LOCK_SH);}
}
function retention3649_post(string $action):never {
 require_owner();if((base_user()['role']??'')!=='platform_admin'||support_context())throw new DomainException('Platform yöneticisi gerekir.');
 if($action==='stable_cron_confirm'){reauthenticate(base_user());if(!isset($_POST['cron_updated'])||!retention3649_stable_ready())throw new DomainException('Önce cron komutunu sabit dosyaya taşıyıp onaylayın.');query("INSERT INTO settings(name,value) VALUES ('retention3649_stable_cron','1') ON DUPLICATE KEY UPDATE value='1'");audit('system.retention_enabled');}
 elseif($action!=='retention_continue')throw new DomainException('Temizlik işlemi geçersiz.');retention3649_queue();$r=retention3649_step();flash('Güncelleme saklama politikası uygulandı.'.($r['pending']?' Temizlenecek eski dosyalar için devam edebilirsiniz.':''));redirect('updates');
}
function retention3649_bytes(string $path,float $end):array {$sum=0;$complete=true;if(is_link($path))return [0,true];if(is_file($path))return [(int)filesize($path),true];if(!is_dir($path))return [0,true];$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path,FilesystemIterator::SKIP_DOTS));foreach($it as $f){if(microtime(true)>$end){$complete=false;break;}if(!$f->isLink()&&$f->isFile())$sum+=$f->getSize();}return [$sum,$complete];}
function retention3649_view():void {
 if((base_user()['role']??'')!=='platform_admin'||support_context())return;
 if(is_file(APP_ROOT.'/storage/retention3649.pending'))try{retention3649_step();}catch(Throwable $e){echo '<p class="alert error">Eski dosya temizliği tamamlanamadı. Sunucu hata günlüğünü kontrol edin.</p>';error_log('Retention: '.$e->getMessage());}
 $p=retention3649_plan();panel('Güncelleme yedekleri ve disk kullanımı','Son 10 başarılı güncellemenin mevcut yedeği ve geri dönüş için gereken sürümler korunur. Şifreli tam sistem yedeklerinin saklama ayarı ayrıdır.');echo '<p>Sabit zamanlayıcı komutu:</p><pre>'.esc('/usr/local/bin/php '.escapeshellarg(APP_ROOT.'/KobiviraCron.php').' --run').'</pre><p class="field-hint">Güncellemelerde bu komutun sürüm numarası değişmez. Diğer zamanlayıcı komutlarını da eski releases yollarından taşımalısınız. İş takibi için aynı sabit dosyada --tasks kullanılabilir.</p>';
 if(setting('retention3649_stable_cron','0')!=='1'){form_start('updates','stable_cron_confirm');echo '<label class="wide"><input type="checkbox" name="cron_updated" value="1" required> cPanel cron görevlerimi yukarıdaki sabit dosyaya taşıdım; eski sürüm yollarını kullanan başka görev veya komut kalmadı. Geri dönüş için korunmayan eski sürümlerin temizlenmesini onaylıyorum.</label>';input('current_password','Mevcut yönetici şifreniz','','password','required');form_end('Onayla ve eski sürümleri temizle');}else echo '<p>Sabit cron geçişi onaylandı. Eski sürüm temizliği açık.</p>';
 $paths=glob(APP_ROOT.'/releases/*',GLOB_ONLYDIR)?:[];usort($paths,fn($a,$b)=>version_compare(basename($b),basename($a)));$end=microtime(true)+2;table_start(['Sürüm','Boyut','Durum']);foreach($paths as $path){$v=basename($path);if(!preg_match('/^\d+\.\d+\.\d+$/D',$v))continue;[$bytes,$full]=retention3649_bytes($path,$end);echo '<tr><td>'.esc($v).'</td><td>'.($full?'':($bytes?'En az ':'Ölçüm tamamlanmadı · ')).number_format($bytes/1048576,2,',','.').' MB</td><td>'.($v===APP_VERSION?'Çalışan sürüm · korunur':(isset($p['protected'][$v])?'Geri dönüş için korunur':'Eski sürüm · cron geçişi sonrası temizlenebilir')).'</td></tr>';}table_end(count($paths),3);
 echo '<p>Korunan kayıtlı güncelleme yedeği: '.count($p['keep']).' · Temizlenecek eski kayıtlı yedek: '.count($p['backups']).'</p>';if(is_file(APP_ROOT.'/storage/retention3649.pending')){form_start('updates','retention_continue');form_end('Eski dosya temizliğini sürdür');}echo '<p class="field-hint">Başarısız veya yarım kalan güncellemelerin kurtarma dosyaları ayrıca korunur. Firma kayıtları, yüklenen evraklar, e-posta kutuları ve tanınmayan dosyalar bu işlemle silinmez.</p></section>';
}
function retention3649_register():void {if(PHP_SAPI!=='cli')return;register_shutdown_function(static function(){if(!is_file(APP_ROOT.'/storage/retention3649.pending'))return;try{retention3649_step();}catch(Throwable $e){error_log('Retention: '.$e->getMessage());}});}
