# EDM 3.6.6 – PDF ve XML indirme

EDM test belge detayına PDF ve XML indirme bağlantıları eklendi. Dosyalar yerel yüklemenin kopyası yerine EDM test servisinden GetInvoice ile alınır. UUID, fatura numarası, gönderen/alıcı VKN/TCKN ve senaryo eşleşmeden dosya indirilmez. XML içindeki belge kimliği ayrıca kontrol edilir. PDF biçim imzası, base64, içerik boyutu ve tekil sonuç kontrol edilir.

Firma/paket/destek oturumu yetkileri ve yerel belge sahipliği servis bağlantısından önce kontrol edilir. Test adresi ve sabit Kobivira uygulama adı korunur. Dosyalar ek olarak, önbelleğe alınmadan indirilir. Yeni fatura, kabul/ret, yerel kontör veya muhasebe kaydı oluşturulmaz.

Giden e-Arşiv detayında yanıltıcı gelen kayıt ve kabul/ret yönlendirmesi kaldırıldı. Eski belirsiz ret denemesi tekrar açılmaz.

Gerçek EDM test hesabıyla KVA2026000000001 / 8fe6ebe2-e43f-4ecc-85f2-4e2c158e6081 için XML (186826 bayt) ve PDF (71889 bayt) indirmesi doğrulandı. Bu, kullanıcının kurulu sitesindeki indirme yolunun henüz test edildiği anlamına gelmez.

Paket 3.6.5 üzerine kurulur. Kurulumdan sonra EDM test alanında aynı faturanın OUT kaydını açın. EDM’den PDF indir ve EDM’den XML indir bağlantılarını ayrı ayrı deneyin. PDF’de KVA2026000000001, alıcı 22222222222 ve toplam 240 TL bilgilerini kontrol edin. e-Arşiv iptali ve diğer belge türleri bu sürümün kapsamında değildir.
