<?php
declare(strict_types=1);
function support_scopes(): array {return ['sales'=>'Satışlar · teklif ve fatura tutarları dahil','purchases'=>'Alışlar · alış faturaları','expenses'=>'Gider kayıtları','contacts'=>'Müşteri ve tedarikçi kartları','products'=>'Ürün / hizmet, fiyat ve maliyetler','finance'=>'Para · kasa, banka, tahsilat, ödeme ve cari ekstre','reports'=>'Raporlar · tüm finansal özetler','settings'=>'Firma bilgileri','tasks'=>'İş takibi'];}
function base_owner(): bool {return in_array(base_user()['role']??'',['platform_admin','support_agent'],true);}
function restriction_message(string $reason=''): string {return 'Firmanızın erişimi kısıtlanmıştır. '.($reason!==''?$reason.' ':'').'Erişimi yeniden açmak için Kobivira temsilcisiyle '.setting('support_email','info@kobivira.com.tr').(setting('support_phone')?' veya '.setting('support_phone'):'').' üzerinden iletişime geçiniz.';}
function support_context(bool $fresh=false,bool $lock=false): ?array {
    if(!empty($GLOBALS['follow_context']))return $GLOBALS['follow_context'];
    if(!isset($_GET['support']))return null;
    if(!$fresh&&array_key_exists('support_context',$GLOBALS))return $GLOBALS['support_context'];
    $GLOBALS['support_context']=null;$GLOBALS['support_invalid']=true;$token=$_GET['support'];$u=base_user();
    if(!is_string($token)||!preg_match('/^[a-f0-9]{64}$/D',$token)||!$u||!in_array($u['role'],['platform_admin','support_agent'],true)||!isset($_SESSION['support_tickets'][$token]))return null;
    $id=(int)$_SESSION['support_tickets'][$token];
    $r=query("SELECT r.*,c.status company_status,c.name company_name,u.is_active approver_active,u.session_version current_approver_version FROM support_requests r JOIN companies c ON c.id=r.company_id LEFT JOIN users u ON u.company_id=r.company_id AND u.id=r.approved_by WHERE r.id=? AND r.actor_id=?".($lock?' FOR UPDATE':''),[$id,$u['id']])->fetch();
    if(!$r||$r['status']!=='active'||strtotime($r['expires_at'].' UTC')<=time()||$r['company_status']!=='active'||!paid_support((int)$r['company_id'])||!(int)$r['approver_active']||(int)$r['current_approver_version']!==(int)$r['approver_version'])return null;
    $helper=query("SELECT * FROM users WHERE company_id=? AND id=? AND role='support' AND is_active=0",[$r['company_id'],$r['helper_user_id']])->fetch();if(!$helper)return null;
    $r['permissions']=json_decode($r['permissions'],true,16,JSON_THROW_ON_ERROR);$r['helper']=$helper;$GLOBALS['support_invalid']=false;return $GLOBALS['support_context']=$r;
}
function support_allowed(string $scope,bool $write=false): bool {if($write&&!empty($GLOBALS['follow_mode']))return false;$r=support_context();return $r&&isset($r['permissions'][$scope])&&(!$write||$r['permissions'][$scope]==='write');}
function route_scopes(): array {
    $page=$_GET['page']??'dashboard';
    if(in_array($page,['support_workspace','support_poll','support_end'],true))return [];
    if(in_array($page,['documents','newdocument','document','print_document','contact_lookup'],true)){
        $kind=$_SERVER['REQUEST_METHOD']==='POST'?($_POST['kind']??$_GET['kind']??'sale'):($_GET['kind']??'sale');
        $id=(int)($_POST['id']??$_GET['id']??0);
        if($id&&$page!=='contact_lookup'){$r=query('SELECT kind FROM documents WHERE company_id=? AND id=?',[support_context()['company_id']??0,$id])->fetch();if(!$r)return ['forbidden'];$kind=$r['kind'];}
        return [match($kind){'quote','proforma','order','sale'=>'sales','purchase'=>'purchases','expense'=>'expenses',default=>'forbidden'}];
    }
    return match($page){'edoc_center'=>['sales','purchases'],'quantity'=>['products'],'cheques','currency_report'=>['finance'],'staff_money'=>['expenses'],'incoming_invoices'=>['purchases'],'contacts','quick_contact'=>['contacts'],'contact'=>['contacts','finance'],'products'=>['products'],'accounts','payments','cashflow','reminders'=>['finance'],'reports'=>(($_GET['view']??'')==='cash'?['reports','finance']:['reports']),'settings'=>['settings'],'tasks'=>['tasks'],default=>['forbidden']};
}
function support_route_allowed(bool $write=false): bool {if(!support_context())return false;foreach(route_scopes() as $scope)if(!support_allowed($scope,$write))return false;return true;}
function support_guard(bool $write=false): void {
    if(!isset($_GET['support']))return;
    if(!support_context()||!support_route_allowed($write)){http_response_code(403);throw new DomainException('Canlı destek bağlantısı sona ermiş veya bu bölüm için firma izni verilmemiş. Firma yeniden onay verirse bağlantı kurulabilir.');}
}
function support_audit(array $r,string $action,array $metadata=[]): void {query('INSERT INTO audit_logs(company_id,user_id,actor_user_id,support_request_id,action,metadata,created_at) VALUES (?,?,?,?,?,?,UTC_TIMESTAMP())',[$r['company_id'],base_user()['id'],base_user()['id'],$r['id'],$action,json_encode($metadata,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);}
function seal_code(string $code): string {$nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);return base64_encode($nonce.sodium_crypto_secretbox($code,$nonce,hex2bin(config()['app_key'])));}
function open_code(string $cipher): string {$v=base64_decode($cipher,true);if($v===false)return '';$r=sodium_crypto_secretbox_open(substr($v,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),substr($v,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),hex2bin(config()['app_key']));return $r===false?'':$r;}
function support_request_row(int $id,bool $lock=false): array {$r=query('SELECT * FROM support_requests WHERE id=?'.($lock?' FOR UPDATE':''),[$id])->fetch();if(!$r){http_response_code(404);throw new DomainException('Destek talebi bulunamadı.');}return $r;}
function support_post(string $action): void {
    $u=base_user();if(!$u)throw new DomainException('Oturum açın.');
    if(isset($_GET['support'])&&$action!=='end'){http_response_code(403);throw new DomainException('Destek oturumunda bu işlem açılamaz.');}
    if($action==='request'){
        if(!base_owner()){http_response_code(403);throw new DomainException('Platform yetkisi gerekir.');}throttle('support_request_'.$u['id'],30);$cid=int_field('company_id',1,PHP_INT_MAX);
        $queue=(int)($_POST['queue_id']??0);if($u['role']==='support_agent'&&!$queue){http_response_code(403);throw new DomainException('Temsilci yalnızca kendisine atanmış destek talebinden bağlantı başlatabilir.');}
        $id=transaction(function()use($cid,$u,$queue){$c=query('SELECT * FROM companies WHERE id=? FOR UPDATE',[$cid])->fetch();if(!$c||$c['status']!=='active')throw new DomainException('Erişimi açık bir firma seçin.');
            if(query("SELECT id FROM support_requests WHERE company_id=? AND actor_id<>? AND status IN ('requested','awaiting','active') AND expires_at>UTC_TIMESTAMP() FOR UPDATE",[$cid,$u['id']])->fetchColumn())throw new DomainException('Firma başka bir temsilciyle bağlantı aşamasında.');
            if($queue){$q=query('SELECT * FROM support_queue WHERE id=? AND company_id=? FOR UPDATE',[$queue,$cid])->fetch();if(!$q||$q['status']!=='scheduled'||(int)$q['assigned_to']!==(int)$u['id'])throw new DomainException('Önce bu talebi kendi adınıza planlayın.');$ag=query('SELECT availability FROM support_agents WHERE user_id=? FOR UPDATE',[$u['id']])->fetchColumn();if($ag!=='available')throw new DomainException('Bağlantı başlatmak için destek durumunuzu Müsait yapın.');if(query("SELECT id FROM support_requests WHERE actor_id=? AND status IN ('requested','awaiting','active') AND expires_at>UTC_TIMESTAMP() FOR UPDATE",[$u['id']])->fetchColumn())throw new DomainException('Önce diğer canlı bağlantınızı sonlandırın.');query("UPDATE support_queue SET status='connecting',updated_at=UTC_TIMESTAMP() WHERE id=?",[$queue]);}
            require_paid_support($cid);
            if(!query("SELECT id FROM users WHERE company_id=? AND role='company_admin' AND is_active=1",[$cid])->fetchColumn())throw new DomainException('Firma yöneticisi bulunamadı.');
            query("UPDATE support_requests SET status='cancelled',code_hash=NULL,code_cipher=NULL,monitor_state=NULL,ended_at=UTC_TIMESTAMP() WHERE company_id=? AND actor_id=? AND status IN ('requested','awaiting','active')",[$cid,$u['id']]);
            $code=(string)random_int(10000000,99999999);query("INSERT INTO support_requests(company_id,actor_id,status,code_hash,code_cipher,created_at,expires_at) VALUES (?,?,'requested',?,?,UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 10 MINUTE))",[$cid,$u['id'],hash_hmac('sha256',$code,config()['app_key']),seal_code($code)]);$id=(int)db()->lastInsertId();if($queue)query('UPDATE support_requests SET queue_id=? WHERE id=?',[$queue,$id]);support_audit(['company_id'=>$cid,'id'=>$id],'support.requested');return $id;
        });redirect('support',['id'=>$id]);
    }
    $id=int_field('id',1,PHP_INT_MAX);$raw=support_request_row($id);
    if(base_owner()){if((int)$raw['actor_id']!==(int)$u['id']){http_response_code(403);throw new DomainException('Bu bağlantı başka bir yöneticiye ait.');}}
    elseif($u['role']!=='company_admin'||(int)$u['company_id']!==(int)$raw['company_id']){http_response_code(403);throw new DomainException('Firma yöneticisinin onayı gerekir.');}
    if($action==='enter'){
        if(!base_owner())throw new DomainException('Platform yetkisi gerekir.');
        $token=bin2hex(random_bytes(32));$_SESSION['support_tickets'][$token]=$id;$_GET['support']=$token;
        if(!support_context(true)){unset($_SESSION['support_tickets'][$token]);unset($_GET['support']);throw new DomainException('Firma onayı yok, izin geri alınmış veya bağlantının süresi dolmuş.');}
        redirect('support_workspace',['support'=>$token]);
    }
    $message=transaction(function()use($action,$id,$u,$raw){
        query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$raw['company_id']]);$r=support_request_row($id,true);
        if(in_array($action,['end','cancel'],true)){
            if(!in_array($r['status'],['requested','awaiting','active'],true))return 'Bağlantı zaten kapalı.';
            query("UPDATE support_requests SET status='revoked',code_hash=NULL,code_cipher=NULL,monitor_state=NULL,ended_at=UTC_TIMESTAMP() WHERE id=?",[$id]);support_audit($r,'support.revoked');return 'Canlı destek bağlantısı sonlandırıldı.';
        }
        if(strtotime($r['expires_at'].' UTC')<=time())throw new DomainException('Talebin süresi doldu. Yeni bağlantı isteği oluşturun.');
        if($action==='connect'){
            if(!base_owner()||$r['status']!=='requested')throw new DomainException('Yeni bir bağlantı talebi oluşturun.');
            if((int)$r['code_tries']>=5)throw new DomainException('Kod deneme sınırı doldu. Yeni bağlantı talebi oluşturun.');
            $code=required_field('connection_code',20);$ok=hash_equals((string)$r['code_hash'],hash_hmac('sha256',$code,config()['app_key']));
            query('UPDATE support_requests SET code_tries=code_tries+1 WHERE id=?',[$id]);
            if(!$ok){if((int)$r['code_tries']>=4){query("UPDATE support_requests SET status='denied',code_hash=NULL,code_cipher=NULL,monitor_state=NULL,ended_at=UTC_TIMESTAMP() WHERE id=?",[$id]);support_audit($r,'support.code_locked');}return 'Kod eşleşmedi. Kodu firma yöneticisinden alın ve tekrar deneyin.';}
            query("UPDATE support_requests SET status='awaiting',code_hash=NULL,code_cipher=NULL WHERE id=?",[$id]);support_audit($r,'support.code_verified');return 'Kod doğrulandı. Firma yöneticisinin açık onayı bekleniyor.';
        }
        if(base_owner()){http_response_code(403);throw new DomainException('Yönetici kendi bağlantısını onaylayamaz.');}
        if($action==='deny'&&in_array($r['status'],['requested','awaiting'],true)){
            query("UPDATE support_requests SET status='denied',code_hash=NULL,code_cipher=NULL,monitor_state=NULL,ended_at=UTC_TIMESTAMP() WHERE id=?",[$id]);support_audit($r,'support.denied');return 'Bağlantı talebini reddettiniz. Yöneticiye bağlanamadığı bildirildi.';
        }
        if($action==='approve'&&$r['status']==='awaiting'){require_paid_support((int)$r['company_id']);
            $reads=$_POST['allow_read']??[];$writes=$_POST['allow_write']??[];if(!is_array($reads)||!is_array($writes))throw new DomainException('İzinleri seçin.');$allowed=[];
            foreach(support_scopes() as $key=>$label){if($key==='tasks'&&!has_feature('tasks'))continue;if(in_array($key,$reads,true))$allowed[$key]=in_array($key,$writes,true)?'write':'read';}
            if(!$allowed)throw new DomainException('En az bir bölüm için görüntüleme izni seçin.');
            query("INSERT INTO users(company_id,name,email,password_hash,role,is_active,created_at) VALUES (?,?,?,?,'support',0,UTC_TIMESTAMP())",[$r['company_id'],'Kobivira Destek #'.$r['actor_id'],'support-'.bin2hex(random_bytes(16)).'@internal.invalid',password_hash(bin2hex(random_bytes(32)),PASSWORD_DEFAULT)]);$helper=(int)db()->lastInsertId();
            query("UPDATE support_requests SET status='active',permissions=?,approved_by=?,approver_version=?,helper_user_id=?,approved_at=UTC_TIMESTAMP(),expires_at=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 20 MINUTE) WHERE id=?",[json_encode($allowed,JSON_THROW_ON_ERROR),$u['id'],$u['session_version'],$helper,$id]);support_audit($r,'support.approved',['permissions'=>$allowed]);return 'İzin verdiğiniz bölümler için 20 dakikalık destek bağlantısı açıldı. İstediğiniz an sonlandırabilirsiniz.';
        }
        throw new DomainException('Talebin durumu değişti. Ekranı yenileyin.');
    });
    desk_sync();
    flash($message);if(base_owner()){unset($_GET['support']);redirect('support',['id'=>$id]);}redirect('support_center');
}
function support_poll(): never {
    check_csrf();desk_sync();$u=base_user();if(!$u){http_response_code(401);json_response(['ok'=>false]);}
    if(base_owner()){
        if(isset($_GET['support'])){$c=support_context(true);if($c)desk_monitor_record($c);json_response(['ok'=>true,'active'=>(bool)$c,'id'=>$c['id']??null]);}
        query('UPDATE support_agents SET last_seen=UTC_TIMESTAMP() WHERE user_id=?',[$u['id']]);
        $queueCount=(int)query("SELECT COUNT(*) FROM support_queue WHERE status IN ('waiting','scheduled','connecting')")->fetchColumn();
        $queueRevision=hash('sha256',json_encode(query("SELECT COUNT(*) n,MAX(id) latest_id,COALESCE(SUM(CRC32(CONCAT(id,':',status,':',COALESCE(assigned_to,0),':',COALESCE(scheduled_at,''),':',updated_at))),0) fingerprint FROM support_queue WHERE status IN ('waiting','scheduled','connecting')")->fetch(),JSON_THROW_ON_ERROR));
        $id=(int)($_POST['request_id']??0);$r=$id?query('SELECT id,status,expires_at FROM support_requests WHERE id=? AND actor_id=?',[$id,$u['id']])->fetch():null;
        if($r&&strtotime($r['expires_at'].' UTC')<=time())$r['status']='expired';json_response(['ok'=>true,'request'=>$r?:null,'queue_count'=>$queueCount,'queue_revision'=>$queueRevision,'notifications'=>notification_summary()]);
    }
    if($u['company_status']!=='active'){if($u['role']==='company_admin')json_response(['ok'=>true,'request'=>null,'queue'=>null,'monitor'=>null]);http_response_code(403);json_response(['ok'=>false]);}
    $page=is_string($_POST['current_page']??null)?$_POST['current_page']:'dashboard';$allowed=['dashboard','documents','document','newdocument','contacts','contact','products','accounts','payments','cashflow','reports','settings','users','membership','recurring','reminders','tasks','approvals','search'];
    if(in_array($page,$allowed,true)){
        $params=[];foreach(['id','kind','view','from','to'] as $key){$v=$_POST['location_'.$key]??null;if(is_string($v)&&preg_match('/^[a-z0-9_-]{1,30}$/D',$v))$params[$key]=$v;}
        query('INSERT INTO company_presence(user_id,company_id,page,params,last_seen) VALUES (?,?,?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE page=VALUES(page),params=VALUES(params),last_seen=UTC_TIMESTAMP()',[$u['id'],$u['company_id'],$page,json_encode($params,JSON_THROW_ON_ERROR)]);
    }
    if(!paid_support((int)$u['company_id']))json_response(['ok'=>true,'request'=>null,'queue'=>null,'monitor'=>null]);
    if($u['role']!=='company_admin')json_response(['ok'=>true,'request'=>null]);
    $r=query("SELECT r.id,r.actor_id,r.status,r.code_cipher,r.permissions,r.expires_at,r.approved_by,u.name actor_name FROM support_requests r JOIN users u ON u.id=r.actor_id WHERE r.company_id=? AND r.status IN ('requested','awaiting','active') AND r.expires_at>UTC_TIMESTAMP() ORDER BY r.id DESC LIMIT 1",[$u['company_id']])->fetch();
    if($r){$r['code']=$r['status']==='requested'?open_code((string)$r['code_cipher']):'';unset($r['code_cipher']);}json_response(['ok'=>true,'request'=>$r?:null,'queue'=>desk_queue_data((int)$u['company_id']),'monitor'=>$r&&$r['status']==='active'&&(int)$r['approved_by']===(int)$u['id']?desk_monitor_data($r):null]);
}
function json_response(array $data): never {if(($_GET['page']??'')==='support_poll'&&($data['ok']??false))$data+=workflow_poll();if(($_GET['page']??'')==='support_poll'&&($data['ok']??false)){if((base_user()['role']??'')==='company_admin'&&!support_context())$data['company_notices']=firm_notice_summary();if(!owner()&&!suspended_firm())$data['task_reminder']=task_summary();}header('Content-Type: application/json; charset=UTF-8');echo json_encode($data,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);exit;}
