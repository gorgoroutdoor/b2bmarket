# 3.6.8 — e-Arşiv iptal testi

EDM teknik dokümanı v4.2.1 bölüm 5.14 ve Request-Response bölüm 1.10 esas alınmıştır. CancelInvoice yalnız EDM test endpoint'ine gider. Bu sürümde yalnız gönderimi tamamlanmış, firmaya ait giden EARSIVFATURA için iptal açılır. Başarılı e-Fatura iptali bu düğmeyle yapılmaz.

EDM test alanı → KVA2026000000001 → OUT → İncele → Durumu sorgula. SEND - SUCCEED görünüyorsa iptal onayını işaretleyip Test e-Arşiv faturasını iptal et düğmesine bir kez basın. Sonra durumu sorgulayın. RETURN_CODE=0 tek başına tamamlanmış iptal veya tamamlanmış GİB raporu olarak gösterilmez. Son durumun ekranını kontrol edin. GİB iptal raporu ayrı olarak doğrulanmalıdır.

İptal girişimi dış çağrıdan önce kaydedilir; zaman aşımı/hata halinde düğme açılmaz ve istek kendiliğinden tekrar edilmez. Ön doğrulama başarısız olsa bile bu konservatif kilit korunur; UUID ile teknik inceleme gerekir. Belge XML'i, tarafları ve numarası EDM'den yeniden doğrulanır, güncel SEND - SUCCEED kontrol edilir. Mevcut firma yetkisi, CSRF, hız limiti ve belge kilidi kullanılır. Sadece test kayıtları etkilenir; muhasebe, tahsilat veya yerel kontör hareketi oluşmaz.

3.6.7 üzerine imzalı güncelleme olarak hazırlanmıştır. 3.6.7 tam yedekleme özelliğini içerir. Mevcut 33 migration değiştirilmemiş, nullable cancel_attempted_at sütunu için 034 eklenmiştir. Hosting cron kurulumu yine gereklidir; güncelleme tek başına günlük yedeği çalıştırmaz.

Ticari ret testi: KVT2026000000004 (360 TRY), UUID b85054a7-1359-408a-ab10-a062eca7c7d5. Kullanıcının paylaştığı ekranlarda IN REJECT - SUCCEED ve OUT REJECTED - SUCCEED doğrulandı. KVT2026000000003 ayrı bir açık incelemedir. Bu paket e-SMM/e-İrsaliye/ihracat entegrasyonunu tamamlamaz; canlıya hazır olunduğu anlamına gelmez.
