# Kobivira 3.6.33

3.6.32 üzerine imzalı tam güncelleme paketi.

## Değişenler

- Özellikler dizininde 50 özelliğin kendi tanıtım sayfası bulunur. Kütüphane rehberleri ayrı kalır; ürün sayfasından ilgili rehbere geçilir.
- Her ürün sayfasında konu açıklaması, ilgili görsel, üyelik formu, üç fayda, kullanım akışı, paket kapsamı, ilgili özellikler ve sık sorulanlar bulunur. Kasa ve Banka sayfasındaki kullanım akışı mevcut hesap ve tahsilat ekranlarına göre yazılmıştır.
- Lacivert ve turkuaz tasarım, masaüstünde yan yana anlatım ve form; mobilde tek sütun. Rakip sitenin görselleri veya tasarımı kopyalanmaz.
- Özellikler menüsü ve dizininde ikon, başlık ve kısa açıklama yer alır. Mobil menü içinde tek kaydırma alanı kullanılır.
- Ana sayfa özellik gezgininde satış, cari, para, elektronik belge, ürün ve rapor için farklı yerleşik anlatım görselleri kullanılır. İnsan fotoğraflı ana hero ve gerçek panel görseli korunur.
- Ana sayfa ve yeni ürün sayfalarında sık sorulan sorular aynı grupta yalnız bir yanıt açık kalacak şekilde çalışır.
- Hero altında soldan sağa hareket eden program/logolar şeridi bulunur. Durdurma düğmesi, fare ve klavye odağında duraklama, azaltılmış hareket tercihi desteği vardır.

## Yönetimden düzenleme

1. **Tanıtım sitesi → Sayfalar**: Özellikler kategorisindeki ilgili sayfayı açın. Başlık, kısa açıklama ve sayfa metin alanlarını düzenleyin. Başlık ve kısa açıklama menü/dizine de yansır. Sayfa içindeki büyük başlığı ilgili metin alanından düzenleyebilirsiniz. Adresler bağlantıların bozulmaması için sabittir.
2. **Tanıtım sitesi → Görseller**: Özellikte kullanacağınız resmi yükleyin. İlgili sayfanın düzenleme ekranındaki **Özellik sayfası görseli** seçicisinden resmi seçin. Seçim yapılmazsa konuya ait yerleşik anlatım görseli kullanılır.
3. **Veri taşıma tanıtımı → Program logoları**: Program adı, yüklenen logo, sıra, rehber bağlantısı ve görünürlüğü düzenleyin. Üstteki yeni şerit ile mevcut alttaki tanıtım aynı kayıtları kullanır. Logo yüklenmemişse program adı gösterilir. Bu liste veri taşıma kaynaklarını tanıtır; canlı entegrasyon anlaşması anlamına gelmez.
4. **Tanıtım sitesi → Ana sayfa blokları**: Mevcut düzenlenebilir hero ve kategori açıklamaları korunmuştur. Yeni şerit home-1 sonunda, kategori görselleri home-2 içinde dinamik alanlarla oluşturulur.

Paket kapsamı mevcut paket/özellik ayarlarından hesaplanır. Bu sürüm paket izinlerini, fiyatları, üyelikleri, ödemeleri veya e-Belge sağlayıcı yapılandırmasını değiştirmez. Firma panelinin menüsü değiştirilmez.

## Üyelik formu

Form doğrudan app.kobivira.com.tr üzerindeki mevcut kayıt işlemini kullanır. CSRF, zorunlu hukuki metin sürümleri/onayı, üyelik açıklığı ve deneme hesabı oluşturma kuralları korunur. Form gönderimi üst pencerede normal üyelik akışına devam eder. Önceden giriş yapmış ziyaretçiye hesabına geçiş bağlantısı gösterilir.

Yalnız kompakt kayıt ekranı resmi kobivira.com.tr ve www.kobivira.com.tr sayfalarında çerçevelenebilir. Diğer uygulama ekranlarında çerçeveleme kapalıdır. Sunucu/hosting ayrıca X-Frame-Options veya ikinci bir CSP başlığı ekliyorsa kayıt formu engellenebilir; bu durumda form altındaki doğrudan kayıt bağlantısı çalışır. Kurulumdan sonra gerçek alan adında kontrol edin.

## Kurulum

Yönetim panelindeki mevcut sürüm güncelleme ekranından ZIP paketini yükleyin. Kaynak sürüm 3.6.32 olmalıdır. Güncelleme sonrası tanıtım sitesini Ctrl+F5 ile yenileyin. Özellikler → Kasa ve Banka Hesapları sayfasını, formu ve yönetim düzenleme ekranını kontrol edin.

Önceki sayfa/blok içerikleri cms_history kayıtlarına alınır. Kullanıcıya ait diğer ana sayfa blokları ve başka firmaların kurumsal siteleri değiştirilmez. Mevcut 48 migration aynıdır; yeni 049 migration ürün sayfalarını ve iki ana sayfa alanını düzenler.

## Doğrulama sınırı

Yerel PHP/MySQL ortamında imzalı 3.6.32 → 3.6.33 güncellemesi, verilerin korunması, 50 ürün sayfası, kayıt/onay kontrolleri ve yönetimden içerik kaydetme test edildi. Tarayıcıda masaüstü, mobil, farklı kategori görselleri, soru açılımı ve hareket düğmesi kontrol edildi. Bu doğrulama canlı hosting dağıtımı veya gerçek e-Belge/ödeme işlemi değildir.
