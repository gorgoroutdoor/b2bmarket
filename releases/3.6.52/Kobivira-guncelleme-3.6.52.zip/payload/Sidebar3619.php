(() => {
 const sidebar=document.getElementById('sidebar'),nav=document.getElementById('sidebar-nav'),toggle=document.getElementById('menu-toggle');
 if(!sidebar||!nav||!toggle)return;
 const rail=document.getElementById('menu-rail3619');
 const key=sidebar.dataset.navKey+'-3619',groups=[...nav.querySelectorAll('details.nav-group')],media=matchMedia('(max-width: 900px)');let saved={},desktopHidden=false;
 try{saved=JSON.parse(sessionStorage.getItem(key)||'{}')||{};desktopHidden=saved.hidden===true}catch{}
 const active=nav.querySelector('[aria-current="page"]')?.closest('details');
 const selected=active||groups.find(g=>g.dataset.group===saved.open);groups.forEach(g=>g.open=g===selected);
 function save(){try{sessionStorage.setItem(key,JSON.stringify({hidden:desktopHidden,open:groups.find(g=>g.open)?.dataset.group||'',scroll:nav.scrollTop}))}catch{}}
 function update(){const mobile=media.matches,open=mobile?document.body.classList.contains('menu-open'):!desktopHidden;document.body.classList.toggle('sidebar-hidden3618',!mobile&&desktopHidden);document.body.classList.remove('sidebar-rail353');sidebar.inert=!open;sidebar.setAttribute('aria-hidden',String(!open));toggle.setAttribute('aria-expanded',String(open));toggle.setAttribute('aria-label',open?'Menüyü daralt':'Menüyü genişlet');toggle.title=open?'Menüyü daralt':'Menüyü genişlet';if(rail){const active=!mobile&&desktopHidden;rail.inert=!active;rail.setAttribute('aria-hidden',String(!active));}document.querySelectorAll('.rail-group3619').forEach(g=>{g.classList.remove('open');g.querySelector('button').setAttribute('aria-expanded','false')});}
 function hide(){if(media.matches)document.body.classList.remove('menu-open');else desktopHidden=true;update();save();toggle.focus();}
 function flip(){if(media.matches)document.body.classList.toggle('menu-open');else desktopHidden=!desktopHidden;update();save();const open=media.matches?document.body.classList.contains('menu-open'):!desktopHidden;if(!open)toggle.focus();else if(media.matches)sidebar.querySelector('[data-close-menu]')?.focus();}
 toggle.addEventListener('click',flip);document.querySelectorAll('[data-toggle-sidebar]').forEach(b=>b.addEventListener('click',flip));document.querySelectorAll('[data-close-menu]').forEach(b=>b.addEventListener('click',hide));
 groups.forEach(g=>g.addEventListener('toggle',()=>{if(g.open)groups.forEach(other=>{if(other!==g)other.open=false});save()}));
 nav.addEventListener('scroll',save,{passive:true});window.addEventListener('pagehide',save);media.addEventListener('change',()=>{document.body.classList.remove('menu-open');update()});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&media.matches&&document.body.classList.contains('menu-open')){hide();return;}if(e.key!=='Tab'||!media.matches||!document.body.classList.contains('menu-open'))return;const els=[...sidebar.querySelectorAll('a,button,summary,input,select')].filter(el=>el.getClientRects().length&&!el.disabled),first=els[0],last=els.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus()}});
 if(rail){
 const items=[...rail.querySelectorAll('.rail-group3619')];
 const place=g=>{const panel=g.querySelector('.rail-flyout3619'),r=g.getBoundingClientRect();panel.style.top=Math.max(8,Math.min(r.top,window.innerHeight-panel.scrollHeight-8))+'px';};
 items.forEach(g=>{const b=g.querySelector('button');g.addEventListener('mouseenter',()=>place(g));g.addEventListener('focusin',()=>place(g));b.addEventListener('click',()=>{const was=g.classList.contains('open');items.forEach(x=>{x.classList.remove('open');x.querySelector('button').setAttribute('aria-expanded','false')});if(!was){g.classList.add('open');b.setAttribute('aria-expanded','true');place(g)}});});
 document.addEventListener('click',e=>{if(!rail.contains(e.target))items.forEach(g=>{g.classList.remove('open');g.querySelector('button').setAttribute('aria-expanded','false')})});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')items.forEach(g=>{if(g.classList.contains('open')){g.classList.remove('open');g.querySelector('button').setAttribute('aria-expanded','false');g.querySelector('button').focus()}})});
 }
 const search=document.querySelector('[data-guide-search]');if(search)search.addEventListener('input',()=>{const q=search.value.toLocaleLowerCase('tr').trim();let count=0;document.querySelectorAll('[data-guide-entry]').forEach(el=>{el.hidden=!el.textContent.toLocaleLowerCase('tr').includes(q);if(!el.hidden)count++});document.querySelectorAll('.guide-category3619').forEach(el=>el.hidden=![...el.querySelectorAll('[data-guide-entry]')].some(e=>!e.hidden));document.querySelector('[data-guide-empty]').hidden=count>0});
 document.querySelectorAll('.support-menu3619').forEach(menu=>{document.addEventListener('click',e=>{if(!menu.contains(e.target))menu.open=false});menu.addEventListener('keydown',e=>{if(e.key==='Escape'){menu.open=false;menu.querySelector('summary').focus()}})});
 update();requestAnimationFrame(()=>nav.scrollTop=Number(saved.scroll)||0);
})();
