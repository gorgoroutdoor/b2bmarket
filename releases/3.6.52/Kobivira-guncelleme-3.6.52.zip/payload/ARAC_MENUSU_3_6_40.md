# Kobivira 3.6.40 — Araçlar menüsü

3.6.39 üzerine yönetimdeki **Sistem → Sürüm güncellemeleri** alanından ZIP olarak yüklenir. Menüleri tek tek düzenlemek gerekmez.

## Düzeltilenler

- Araçlar açılır listesindeki fazladan **Giriş yap** bağlantısı kaldırıldı. Mobil giriş bağlantısı yalnız ana site menüsüne ekleniyor; masaüstündeki mevcut ana giriş bağlantısı korunuyor.
- Araçlar başlığına ve dokuz hesaplama bağlantısına, mevcut site ikon sistemiyle uyumlu ikonlar eklendi.
- Özellikler ve Araçlar aynı etkileşim kodunu kullanıyor. Masaüstünde fare üzerine geldiğinde açılır; fare ayrıldıktan kısa süre sonra kapanır. Başlığa tıklanıp odak orada kalsa da menü açık takılı kalmaz.
- Sayfa kaydırma, dışarı tıklama, Escape ve pencere boyutu değişimi açık menüyü kapatır. Bir menü açıldığında diğeri kapanır.
- Uzun Özellikler listesinin kendi içinde kaydırılması menüyü kapatmaz. Mobilde dokunarak açma/kapama korunur.

Hesaplama formülleri, makale metinleri, footer bağlantıları ve önceki özellik sayfaları değiştirilmedi. Yeni veritabanı göçü yoktur.

## Doğrulama

İzole veritabanında imzalı 3.6.39 → 3.6.40 güncellemesi uygulandı. 477 PHP/veritabanı, 248 HTTP, 30 menü etkileşimi, 649 aritmetik ve 59 hesaplayıcı DOM kontrolü başarılıdır. 179 PHP dosyasının sözdizimi doğrulandı. Önceki göçlerin sağlama değerleri korunmuştur.

Etkileşim kontrolleri masaüstü fare hareketi, odak başlıkta kaldığında kapanma, sayfa ve panel içi kaydırma, dış tıklama, Escape, tek menü açık kalması ve mobil dokunma senaryolarını kapsar. Yerel ön izlemeye bu oturumdaki bulut tarayıcısından erişilemediği için görsel tarayıcı kontrolü tamamlanamamıştır; DOM kontrolleri görsel tarayıcı testi olarak sunulmaz.
