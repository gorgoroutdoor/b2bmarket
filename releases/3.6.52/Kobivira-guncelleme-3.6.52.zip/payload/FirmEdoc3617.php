<?php
declare(strict_types=1);
/** Customer navigation follows the owned document, including after a POST. */
function firm3617_route(array $r):array {
 return [$r['direction']==='IN'?'incoming_invoices':'edoc_center',['id'=>(int)$r['id'],'kind'=>$r['kind']]];
}
function firm3617_context(array $r):void {
 if($r['mode']!=='live')throw new DomainException('Belge firma kullanım alanında bulunamadı.');
 if(($_GET['page']??'')==='incoming_invoices'&&$r['direction']!=='IN')throw new DomainException('Bu belge gelen belge kutusuna ait değil.');
 if(isset($_GET['kind'])&&(!is_string($_GET['kind'])||$_GET['kind']!==$r['kind']))throw new DomainException('Belge türü ile açılan bölüm eşleşmiyor.');
 $GLOBALS['edoc3616_incoming']=$r['direction']==='IN';
 firm3615_guard($r['kind']);
}
function firm3617_record_feature(string $page,array $params):?string {
 if(!in_array($page,['edoc_center','incoming_invoices'],true)||empty($params['id']))return null;
 $id=filter_var($params['id'],FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
 if(!$id)throw new DomainException('Belge kimliği geçersiz.');
 $r=query('SELECT kind,direction FROM edoc_documents WHERE company_id=? AND id=?',[company_id(),$id])->fetch();
 if(!$r)throw new DomainException('Elektronik belge bu firmada bulunamadı.');
 if($page==='incoming_invoices'&&$r['direction']!=='IN')throw new DomainException('Bu belge gelen belge kutusuna ait değil.');
 if(isset($params['kind'])&&$params['kind']!==$r['kind'])throw new DomainException('Belge türü ile açılan bölüm eşleşmiyor.');
 return $r['direction']==='IN'?($r['kind']==='despatch'?'edoc_incoming_despatch':'edoc_incoming'):plan3616_edoc_feature($r['kind']);
}
function firm3617_kind_links(bool $create=false):void {
 echo '<nav class="desk-actions" aria-label="Elektronik belge türleri">';
 foreach(edoc_kinds() as $kind=>$label)if(edoc3616_allowed($kind))echo a('edoc_center',esc($label),['kind'=>$kind]+($create?['new'=>1]:[]),'button quiet');
 echo '</nav>';
}
function firm3617_list_tabs(string $kind,string $selected):void {
 echo '<nav class="desk-actions" aria-label="Belge listeleri">';
 foreach(['all'=>'Tüm belgeler','drafts'=>'Taslaklar','sent'=>'Giden belgeler'] as $view=>$label)echo a('edoc_center',$label,['view'=>$view]+($kind!==''?['kind'=>$kind]:[]),$view===$selected?'button primary':'button quiet');
 echo '</nav>';
}
function firm3617_source_options(int $cid,string $kind,int $selected=0):array {
 $smm=$kind==='smm';$out=[];
 foreach(query("SELECT id,number FROM documents WHERE company_id=? AND kind='sale' AND status='posted' AND return_of_id IS NULL AND record_type ".($smm?'=':'<>')." 'smm' ORDER BY id DESC LIMIT 500",[$cid]) as $r)$out[$r['id']]=$r['number'];
 if($selected>0&&!isset($out[$selected])){$r=query("SELECT id,number FROM documents WHERE company_id=? AND id=? AND kind='sale' AND status='posted' AND return_of_id IS NULL AND record_type ".($smm?'=':'<>')." 'smm'",[$cid,$selected])->fetch();if($r)$out[$r['id']]=$r['number'];}
 return $out;
}

function firm3617_small_action(string $page,string $action,string $label,array $params):void {
 form_start($page,$action,$params,'inline-form');foreach($params as $key=>$value)hidden($key,$value);submit($label,'quiet');echo '</form>';
}
