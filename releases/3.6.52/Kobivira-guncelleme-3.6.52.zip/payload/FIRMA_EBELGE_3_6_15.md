# Kobivira 3.6.15 — Firma elektronik belge akışı

Bu sürüm 3.6.14 üzerine imzalı yönetim güncellemesi olarak kurulur. Mevcut test kayıtları korunur; normal firma belgeleri ayrı tablolarda tutulur. Kurulum, canlı kullanımı kendiliğinden açmaz.

## İlk firma testi

1. Yönetimden sürüm ZIP dosyasını yükleyin ve sürümün 3.6.15 olduğunu doğrulayın.
2. Test yaptığınız firmanın hesabıyla **Satışlar → Elektronik belgeler → Bağlantı ayarları** alanını açın.
3. Ortamı **Test** seçin. Bu firmaya yönetimden önceden açılmış test hesabı varsa, **Yönetimce bu firmaya açılan test hesabını kullan** seçeneğini kullanabilirsiniz. Firma VKN'si değişmez. Başka firmaya ait test hesabı kullanılamaz.
4. Düzenleyen adresinin il, ilçe, posta kodu ve ülke bilgilerini tamamlayın. Bağlantıyı kaydedin; **Firma bağlantısını doğrula** işlemini yapın, ardından bağlantıyı etkinleştirin. Hesap değişirse yeniden doğrulama gerekir.
5. Kaydedilip kesinleştirilmiş bir satışın ayrıntısından **Elektronik belge hazırla** seçin. Ya da elektronik belgelerde yeni belge açıp kaynak satışı seçin. Taslak muhasebe kaydı gönderilemez.
6. Alıcı kimliğini/adresini, belge türünü ve gerekli alanları kontrol edin. Test e-Fatura için EDM test alıcısı; e-Arşiv için EDM'nin bildirdiği 22222222222 TCKN kullanılmalıdır. e-SMM'nin kaynağı serbest meslek kaydı olmalıdır.
7. Oluşan belgeyi inceleyin; gönderim onayını verip kuyruğa bir kez alın. Sonuç belirsizse yeniden gönderim yapılmaz, yalnız durum sorgulanır. Test hesabı ortak kullanıldığından eş zamanlı portal/servis oturumları işlemleri etkileyebilir.
8. Gelen belgeler bölümünden tarih aralığıyla eşitleme isteyin. Kabul/ret yalnız servisin güncel durumu izin verdiğinde görünür. Gelen irsaliyeler ayrı türde listelenir. Test belgeleri muhasebeye işlenemez.

## Değişiklikler

- Gerçek firma satışlarından e-Fatura, e-Arşiv, tek satırlı e-SMM, e-İrsaliye ve mal ihracı faturası için UBL hazırlama; inceleme, onaylı kuyruk, PDF/XML indirme.
- Firma başına şifreli ve doğrulanan hesap; tek VKN, ortam ve firma erişimi kontrolü. Normal panelde yönetim test belgeleri kullanılmaz. Tarihsel demo kayıtları ayrı, salt okunur görünümde korunur.
- Kobi Plus için standart e-Fatura/e-Arşiv ve gelen fatura; ileri belge türlerinde Business/ilgili yetki kontrolü. Paket yetkisi gönderim anında da yeniden denetlenir.
- Durumların ve gelen belgelerin arka planda takibi. Daha önce tanımlanan 3.6.12 BackupCli367.php --run komutu güncel modülleri yüklediğinde bu işçi de çalışır; ikinci bir zamanlayıcı gerekmez. Sunucuda mevcut zamanlayıcının gerçekten çalıştığı firma testi sırasında doğrulanmalıdır.
- Gönderim/yanıt denemesi ağ çağrısından önce kalıcı kaydedilir. Sayfa yenileme veya belirsiz ağ yanıtı aynı belgeyi otomatik tekrar göndermez. Kaynak satış gönderimden sonra korumaya alınır.
- Canlıya geçiş yönetimde ana izin ve belge türü izinleriyle açılır; varsayılan kapalıdır. Gerçek firma hesabı ve doğru VKN gerekir. Her istek APPLICATION_NAME=Kobivira gönderir.
- EDM bakiyesi gösterilir; yerel Kobivira kontörü EDM kontörü sayılmaz, otomatik düşülmez. EDM müşteri/kontör satın alma API'si yoktur; mevcut gelir paylaşımı modelindeki manuel kayıt ve satın alma süreci devam eder.

## Sınırlar ve tamamlanmamış doğrulamalar

İlk akış TRY içindir. Döviz, KDV tevkifatı ve ek vergiler desteklenmiş sayılmaz; güvenli biçimde engellenir. e-SMM tek satırla sınırlandırılmıştır. İrsaliye kesinleşmiş satıştan hazırlanır; bağımsız sevkiyat/ek stok hareketi oluşturmaz. İhracat yalnız 301 mal ihracı senaryosudur; GTİP, teslim şekli, taşıma türü ve yabancı alıcı bilgileri gerekir. Diğer e-belgeler (e-Reçete/e-Bilet dahil) kapsam dışıdır.

EDM'nin isteği kabul etmesi belgenin nihai başarılı olması anlamına gelmez. PDF/XML açılması da GİB raporunun veya gümrük kabulünün tamamlandığını kanıtlamaz. e-Arşiv ve e-SMM raporları ayrıca izlenir; iptal raporu da ayrıdır. İrsaliye kabul/ret/kısmi kabul ve ihracat nihai sonucu henüz uçtan uca tamamlanmamıştır. Canlı firma testi ve PayTR entegrasyonu tamamlanmamıştır. Bu sürüm tek başına satışa hazır olunduğuna dair onay değildir.

## Yapılan doğrulama

- İzole MySQL üzerinde 39 geçişin iki kez çalışması; 56 akış/yetki/idempotans/veri bütünlüğü kontrolü başarılı.
- 147 PHP dosyasında sözdizimi kontrolü başarılı.
- Yeni normal üreticiden oluşturulan beş test belge türünün EDM test ortamında PDF ve XML içerikleri alınarak UUID, numara, taraf ve senaryo eşleşmesi denetlendi.
- e-Fatura FI62026000000001: SEND - WAIT_APPLICATION_RESPONSE; ticari yanıt bekliyor.
- e-Arşiv FA72026000000001: SEND - SUCCEED. GİB raporu ayrıca doğrulanmalıdır.
- e-SMM FS72026000000001: SEND - SUCCEED. GİB raporu ayrıca doğrulanmalıdır.
- e-İrsaliye FD72026000000001: SEND - PROCESSING; nihai sonuç bekliyor.
- İhracat FX62026000000001: SEND - FAILED; Sorgu yanıtında ayrıntılı hata kodu bulunmadı; EDM teknik yanıtı gerekli. Başarılı olarak gösterilmez.
- Önceki yönetim test belgeleri ve bu teknik test numaraları birbirinden ayrıdır; eski başarısız/bekleyen belgelere yeni gönderim yapılmadı.

Kabul ölçütü: güncelleme sonrası gerçek firma panelinde bağlantı → kesinleşmiş satış → belge hazırlama → tek gönderim → otomatik durum → PDF/XML → karşı tarafta gelen belge görülmesi zinciri tamamlanmalıdır. İleri türler için yanıt/nihai durum ve canlı hesap doğrulamaları da ayrıca tamamlanmalıdır.
