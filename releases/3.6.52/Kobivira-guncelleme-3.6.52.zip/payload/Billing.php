<?php
declare(strict_types=1);
require_once __DIR__.'/Pricing.php';
function subscription_end(array $s): string {return $s['status']==='trial'?$s['trial_ends_at']:($s['paid_until']??$s['trial_ends_at']);}
function subscription_state(array $s): string {return (($s['status']==='trial'&&strtotime($s['trial_ends_at'].' UTC')>time())?'Deneme':(($s['status']==='active'&&$s['paid_until']&&strtotime($s['paid_until'].' UTC')>time())?'Aktif':'Süresi dolmuş'));}
function subscription_days(array $s): int {if(subscription_state($s)==='Süresi dolmuş')return 0;$tz=new DateTimeZone('Europe/Istanbul');$end=(new DateTimeImmutable(subscription_end($s),new DateTimeZone('UTC')))->setTimezone($tz)->setTime(0,0);$now=(new DateTimeImmutable('now',$tz))->setTime(0,0);return max(0,(int)$now->diff($end)->format('%r%a'));}
function add_months_utc(DateTimeImmutable $start,int $months): DateTimeImmutable {$start=$start->setTimezone(new DateTimeZone('Europe/Istanbul'));$t=$start->modify('first day of this month')->modify('+'.$months.' months');return $t->setDate((int)$t->format('Y'),(int)$t->format('m'),min((int)$start->format('d'),(int)$t->format('t')))->setTimezone(new DateTimeZone('UTC'));}
function credit_change(int $cid,int $delta,string $reason,string $reference,int $actor): void {
    if(query('SELECT id FROM credit_ledger WHERE company_id=? AND reference=?',[$cid,$reference])->fetchColumn())return;
    $old=(int)query('SELECT credits_balance FROM companies WHERE id=? FOR UPDATE',[$cid])->fetchColumn();$new=$old+$delta;if($new<0||$new>1000000000)throw new DomainException('Kontör bakiyesi sıfırdan küçük veya sınırdan büyük olamaz.');
    query('UPDATE companies SET credits_balance=? WHERE id=?',[$new,$cid]);query('INSERT INTO credit_ledger(company_id,delta,balance_after,reason,reference,actor_id,created_at) VALUES (?,?,?,?,?,?,UTC_TIMESTAMP())',[$cid,$delta,$new,$reason,$reference,$actor]);mail3650_credit($cid,$delta,$reference);
}
function billing_post(string $action): void {
    if(in_array($action,['card_start','card_cancel'],true))checkout3624_post($action);if($action==='card_resolve')checkout3624_resolve();
    if(in_array($action,['refund_request','refund_decide'],true))refund356_post($action);
    if(support_context()||isset($_GET['support'])){http_response_code(403);throw new DomainException('Canlı destek oturumu üyelik / ödeme işlemlerine erişemez.');}
    if(owner()){
        if(!in_array($action,['approve','reject','credit','revoke_gift'],true))throw new DomainException('İşlem tanınmadı.');reauthenticate(current_user());
        if($action==='revoke_gift'){transaction(function(){$cid=int_field('company_id',1,PHP_INT_MAX);if(!query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$cid])->fetchColumn())throw new DomainException('Firma bulunamadı.');gift354_revoke($cid,required_field('reason',500));});flash('Hediye kontör geri alındı. İade değerlendirmesini ödeme kaydıyla ayrıca sonuçlandırın.');redirect('companies',['edit'=>$_POST['company_id'],'view'=>'credits']);}
        if($action==='credit'){
            transaction(function(){$cid=int_field('company_id',1,PHP_INT_MAX);if(!query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$cid])->fetchColumn())throw new DomainException('Firma bulunamadı.');credit_change($cid,int_field('delta',-1000000,1000000),required_field('reason',300),'manual:'.request_key(),(int)current_user()['id']);audit('credits.adjusted',['company'=>$cid]);});flash('Kontör bakiyesi güncellendi.');redirect('companies',['edit'=>$_POST['company_id'],'view'=>'credits']);
        }
        $id=int_field('id',1,PHP_INT_MAX);$message=transaction(function()use($id,$action){
            $unlocked=query('SELECT company_id FROM payment_orders WHERE id=?',[$id])->fetch();if(!$unlocked)throw new DomainException('Ödeme talebi bulunamadı.');
            $company=query('SELECT * FROM companies WHERE id=? FOR UPDATE',[$unlocked['company_id']])->fetch();$r=query('SELECT * FROM payment_orders WHERE id=? FOR UPDATE',[$id])->fetch();
            if($action==='approve'&&checkout3626_marked((int)$r['company_id']))throw new DomainException('Ayrılmış test hesabı gerçek havale onayı alamaz. Önce test öncesi üyeliği geri getirin.');if($r['payment_method']==='card')throw new DomainException('Kart ödemesi havale onayıyla sonuçlandırılamaz.');
            if(in_array($r['status'],['approved','rejected','cancelled'],true))throw new DomainException('Bu ödeme talebi zaten sonuçlandırılmış.');
            if($action==='reject'){company_notice((int)$r['company_id'],'payment:'.$id.':rejected','Ödeme / paket talebiniz reddedildi',$r['reference'].' · '.required_field('admin_note',500),'billing',$id);query("UPDATE payment_orders SET status='rejected',admin_note=? WHERE id=?",[required_field('admin_note',500),$id]);audit('billing.rejected',['company'=>$r['company_id'],'order'=>$id]);return 'Ödeme bildirimi reddedildi; üyelik etkinleştirilmedi.';}
            if($r['status']!=='reported')throw new DomainException('Firma önce havale bildirimini göndermelidir.');
            if($company['status']!=='active')throw new DomainException('Firma askıda. Önce firma erişimini yeniden açın.');
            $plan=query('SELECT * FROM plans WHERE id=? FOR UPDATE',[$r['plan_id']])->fetch();if(($plan['code']??'')==='business_plus')throw new DomainException('Business Plus test aşamasındadır; satış onayı verilemez.');$s=query('SELECT * FROM subscriptions WHERE company_id=? FOR UPDATE',[$r['company_id']])->fetch();
            $count=(int)query('SELECT COUNT(*) FROM users WHERE company_id=? AND is_active=1 AND role<>\'accountant\'',[$r['company_id']])->fetchColumn();if($count>(int)$plan['user_limit'])throw new DomainException('Yeni paket kullanıcı sayısını karşılamıyor. Önce fazla kullanıcıları kapatın.');
            $refundBefore=refund356_state((int)$r['company_id']);$bonus=terms354_bonus($r,$s);$now=new DateTimeImmutable('now',new DateTimeZone('UTC'));$start=$now;
            if((int)$s['plan_id']===(int)$r['plan_id']&&$s['status']==='active'&&$s['paid_until']&&strtotime($s['paid_until'].' UTC')>time())$start=new DateTimeImmutable($s['paid_until'],new DateTimeZone('UTC'));
            $end=add_months_utc($start,(int)$r['months'])->modify('+'.$bonus.' seconds')->format('Y-m-d H:i:s');query('UPDATE membership_terms354 SET applied_bonus_seconds=? WHERE payment_order_id=?',[$bonus,$id]);
            commerce_receipt(required_field('bank_reference',100),'membership',$id);query("UPDATE payment_orders SET status='approved',bank_reference=?,admin_note=?,approved_by=?,approved_at=UTC_TIMESTAMP() WHERE id=?",[required_field('bank_reference',100),field('admin_note',500),current_user()['id'],$id]);
            $periodStart=$start>$now?$s['period_started_at']:$now->format('Y-m-d H:i:s');query("UPDATE subscriptions SET plan_id=?,status='active',has_paid_membership=1,paid_until=?,period_started_at=? WHERE company_id=?",[$r['plan_id'],$end,$periodStart,$r['company_id']]);
            referral_on_payment($r);referral_apply_bank((int)$r['company_id']);$credits=(int)$plan['credits_per_period']*(int)$r['months'];if($credits)credit_change((int)$r['company_id'],$credits,'Paket dönemi kontörü','payment:'.$id,(int)current_user()['id']);
            gift354_award($r);refund356_snapshot($id,(int)$r['company_id'],$refundBefore);company_notice((int)$r['company_id'],'payment:'.$id.':approved','Ödemeniz onaylandı',$r['reference'].' · Paketiniz etkinleştirildi. '.field('admin_note',500),'billing',$id);billing_notice($r,'approved');mail3650_payment($id,'activated');audit('billing.approved',['company'=>$r['company_id'],'order'=>$id,'total'=>$r['total'],'paid_until'=>$end]);return 'Ödeme onaylandı. Paket ve kullanım süresi etkinleştirildi.';
        });$cid=(int)query('SELECT company_id FROM payment_orders WHERE id=?',[$id])->fetchColumn();deliver_notices($cid);flash($message);redirect('billing',['id'=>$id]);
    }
    require_manager();
    // Renewal requests and support consent remain available when the business records are read-only.
    $result=transaction(function()use($action){
        if(query('SELECT status FROM companies WHERE id=? FOR UPDATE',[company_id()])->fetchColumn()!=='active')throw new DomainException(restriction_message());
        if($action==='create'){
            $plan=query('SELECT * FROM plans WHERE id=? AND is_active=1 FOR UPDATE',[int_field('plan_id',1,1000)])->fetch();
            if(!$plan)throw new DomainException('Bu paket şu anda satın alınamıyor.');
            $months=int_field('months',1,12);$quote=pricing_quote($plan,$months);$method=choice('payment_method',array_keys(checkout3624_options()));
            $key=request_key();$old=query('SELECT id FROM payment_orders WHERE company_id=? AND request_key=?',[company_id(),$key])->fetchColumn();if($old)return (int)$old;
            $pending=query("SELECT * FROM payment_orders WHERE company_id=? AND status IN ('awaiting_transfer','reported','awaiting_card','card_review') ORDER BY id DESC LIMIT 1",[company_id()])->fetch();if($pending){if((int)$pending['plan_id']!==(int)$plan['id']||(int)$pending['months']!==$months||$pending['payment_method']!==$method){$GLOBALS['validation_action']=['label'=>'Ödeme talebini aç','url'=>url('billing',['id'=>(int)$pending['id']])];throw new DomainException('Sonuçlanmamış bir ödeme talebiniz var. Mevcut talebinizi açarak devam edin.');}return (int)$pending['id'];}
            $users=(int)query('SELECT COUNT(*) FROM users WHERE company_id=? AND is_active=1 AND role<>\'accountant\'',[company_id()])->fetchColumn();if($users>(int)$plan['user_limit'])throw new DomainException('Bu pakette kullanıcı sınırı daha düşük. Önce fazla kullanıcıları kapatın.');
            if(($_POST['accept_terms354']??'')!=='1'){$GLOBALS['validation_field']='accept_terms354';throw new DomainException('Paket değişikliği ve kalan kullanım süresi koşullarını onaylayın.');}$net=$quote['net'];$tax=$quote['tax'];
            $ref='KV-'.date('Ymd').'-'.strtoupper(bin2hex(random_bytes(5)));query('INSERT INTO payment_orders(company_id,plan_id,reference,request_key,months,net,tax,total,vat_rate,payment_method,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP())',[company_id(),$plan['id'],$ref,$key,$months,$net,$tax,$net+$tax,$plan['vat_rate'],$method,$method==='card'?'awaiting_card':'awaiting_transfer']);$id=(int)db()->lastInsertId();query('INSERT INTO payment_pricing(payment_order_id,months,monthly_net,base_net,discount_basis_points,discount_amount,discount_source,created_at) VALUES (?,?,?,?,?,?,?,UTC_TIMESTAMP())',[$id,$months,$quote['monthly_net'],$quote['base_net'],$quote['discount_basis_points'],$quote['discount_amount'],$quote['discount_source']]);terms354_create($id,$plan,$months);unset($_SESSION['package_intent']);audit('billing.created',['id'=>$id]);billing_notice(query('SELECT * FROM payment_orders WHERE id=?',[$id])->fetch(),'created');return $id;
        }
        $id=int_field('id',1,PHP_INT_MAX);$r=query('SELECT * FROM payment_orders WHERE company_id=? AND id=? FOR UPDATE',[company_id(),$id])->fetch();if(!$r)throw new DomainException('Ödeme talebi bulunamadı.');
        if($r['payment_method']!=='transfer')throw new DomainException('Bu işlem yalnız Havale/EFT ödemeleri içindir.');
        if($action==='report'){
            if($r['status']!=='awaiting_transfer')throw new DomainException('Bu talep için bildirim zaten gönderilmiş veya talep kapanmış.');
            $day=date_field('transfer_date');if($day>today())throw new DomainException('İleri tarihli havale bildirimi gönderilemez.');
            query("UPDATE payment_orders SET status='reported',sender=?,transfer_date=?,transfer_note=?,reported_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?",[required_field('sender',160),$day,required_field('transfer_note',500),company_id(),$id]);audit('billing.reported',['id'=>$id]);billing_notice($r,'reported');mail3650_payment($id,'transfer');return $id;
        }
        if($action==='cancel'&&$r['status']==='awaiting_transfer'){query("UPDATE payment_orders SET status='cancelled' WHERE company_id=? AND id=?",[company_id(),$id]);audit('billing.cancelled',['id'=>$id]);return $id;}
        throw new DomainException('Bu işlem bu ödeme talebi için kullanılamaz.');
    });flash($action==='report'?'Havale bildiriminiz alındı. Kobivira ödemeyi doğruladığında paketiniz etkinleşir.':'Ödeme talebi güncellendi.');redirect('billing',['id'=>$result]);
}
function payment_state(string $s): string {return ['awaiting_card'=>'Kart ödemesi bekleniyor','card_failed'=>'Kart ödemesi tamamlanamadı','card_test_success'=>'Test ödemesi doğrulandı','card_review'=>'Ödeme alındı · etkinleştirme kontrol ediliyor','awaiting_transfer'=>'Havale bekleniyor','reported'=>'Yönetici onayı bekleniyor','approved'=>'Ödeme onaylandı','rejected'=>'Bildirim reddedildi','cancelled'=>'İptal edildi'][$s]??$s;}

function email_contact_field(): string {$v=required_field('support_email',190);if(!filter_var($v,FILTER_VALIDATE_EMAIL))throw new DomainException('İletişim e-postası hatalı.');return $v;}
