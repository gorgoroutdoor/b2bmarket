# Kobivira 3.6.0 — Yerel doğrulama raporu

Tarih: 22.10.2026. Kontroller izole PHP 8.3 / MySQL uyumlu MariaDB ve gerçek Chromium ortamında yapıldı. Canlı hosting veya firma verisi üzerinde işlem yapılmadı.

## Tamamlanan kontroller

- 32 migration ile temiz test veritabanına rehberler işlendi.
- 77 rehber sayfası oturum açmadan HTTP üzerinden açıldı; mevcut makale / kategori / paket etiket yapısı kontrol edildi.
- Önceki genel rehber adresleri korundu; 59 alt menü ve Genel Bakış için rehber eşleştirmesi doğrulandı.
- 474 numaralı adım, 156 soru / yanıt, iç bağlantılar ve sayfa içi adım bağlantıları incelendi.
- Kütüphanede arama, kategori filtresi, KOBİ paket filtresi, kütüphaneye dönüş ve doğrudan adım bağlantıları tarayıcıda denendi.
- 320, 390, 768 ve 1440 piksel genişliklerde teklif, revizyon, firma bilgileri, veri taşıma ve tüm kategoriler rehberlerinin içerik alanı yatay taşmadı.
- Mevcut masaüstü ve mobil görünüm ekran görüntüleri iç kontrolde incelendi; kullanıcıya özel ekran görüntüsü pakete konulmadı.
- Yönetici CMS’den rehber içeriğini düzenledi; değişiklik genel sayfada göründü. Rehber taslak yapıldığında genel sayfa 404 döndü, dizinden bağlantısı kalktı, sayaç azaldı. Tekrar yayına alma doğrulandı.
- Firma hesabının genel kütüphane içeriklerini düzenleyemediği; yöneticiye özel rehberlerin 404 kaldığı doğrulandı.
- Teklif / proforma / sipariş ve diğer rehber paket etiketleri mevcut erişim kurallarıyla karşılaştırıldı. Meta / Google için bağımsız modül ayarı ve kapalı modül davranışı denendi.
- Revizyon için 51, ticari belge iptalini geri alma için 15 önceki işlev kontrolü yeni sürüm modülleriyle tekrar geçti.
- 115 PHP dosyası ve 21 JavaScript kaynağının sözdizimi kontrol edildi; JSON dosyaları ayrıştırıldı.
- 11 CSS dosyası, site Assets.json, PublicSite.json, panel Views.php ve belge / paylaşım işlem dosyaları önceki sürümle aynı. Önceki 31 migration ve tüm eski sürüm açıklamaları aynı kaldı.

## Paket kabulü

3.5.9 kaynağındaki gerçek Updater ile imzalı 3.6.0 ZIP’i izole kurulumda yüklendi ve yedekten geri dönüldü. Sonuçlar:

- Mevcut güvenilen açık anahtar yeni imzayı doğruladı. Başlangıç sürümü 3.5.9 ve hedef 3.6.0 doğrulandı.
- Guide360.json içeriği değiştirilmiş ZIP reddedildi. Kurulan tüm dosyaların SHA-256 özetleri imzalı manifest ile eşleşti.
- Yeni sürüm kuruldu, maintenance durumu temizlendi, yalnız 032 migration eklendi.
- Özelleştirilmiş fiyatlar, kullanıcı kotaları, üyelik, 88 kontörlü test bakiyesi, tüm sistem ayarları ve ana sayfa blokları değişmedi.
- Diğer tanıtım / hukuki sayfalar ve başka firmanın aynı adresli site içeriği değişmedi.
- Mevcut rehber kimliği / adresi korundu; önceki özel HTML, metin alanları ve metadata CMS geçmişinde tam olarak saklandı. Özel SEO alt yazısı korundu.
- Yönetici tarafından taslağa alınmış rehber taslak kaldı. Yönetim kategorisine alınmış rehbere dokunulmadı.
- Aynı rehber adresini kullanan farklı türde özel sayfa senaryosunda migration tüm içerik değişikliklerini geri aldı; özel sayfa ezilmedi.
- Sonradan CMS’de yapılan düzenleme migration tekrarında korunmaya devam etti.
- Yeni yedek, genişletilmiş rehber içeriğini geri getirdi.
- Güncelleyicinin gerçek recover akışı 3.5.9 sürümüne, önceki 31 migration geçmişine ve özel eski rehber metin alanlarına döndü; yeni dizin kaldırıldı, firma içeriği ve kontör korundu.

Bu sonuçlar yerel doğrulamadır; canlı hosting sonucunun yerine geçmez.

## Sınırlar

- Bu güncelleme kapsamı kütüphanedir; tüm muhasebe fonksiyonlarının yeni bir tam denetimi değildir.
- Gerçek e-Belge, banka, kartlı tahsilat, SMS, OCR ve reklam sağlayıcıları bu çalışmada bağlanmadı veya canlı test edilmedi.
- Rehberlerde mevcut hazırlık ekranları, yerel kayıtlar ve gerçek servis sonuçları ayrılır.
- Yönetici tarafından özel olarak yeniden adlandırılmış / yayından kaldırılmış rehberler ve özel firma izinleri canlı ortamda farklı görünebilir.
