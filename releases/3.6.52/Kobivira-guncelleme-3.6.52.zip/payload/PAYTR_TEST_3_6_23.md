# Kobivira 3.6.23 — PayTR test ödemesi

Bu paket 3.6.22 üzerine yönetimdeki sürüm güncelleme ekranından yüklenir. Firma panelinin tasarımı ve mevcut paket erişimleri değiştirilmez. Yönetimde PayTR test ekranı eklenir. Önceki sürümlerde kaydedilen PayTR mağaza bilgileri korunur.

## Kurulumdan sonra ilk test

1. Kobivira yönetim panelinde **Sistem → PayTR ödeme ayarları** bölümünü açın. Mağaza numarası, mağaza anahtarı ve mağaza salt değeri kayıtlı olmalıdır. Şifre alanlarını boş bırakmak kayıtlı değerleri korur. Buradaki yönetici şifresi Kobivira yönetim giriş şifrenizdir.
2. PayTR Mağaza Paneli → **Destek & Kurulum → Ayarlar → Bildirim URL** alanına `https://app.kobivira.com.tr/?page=paytr_callback` yazıp kaydedin. Callback için kullanıcı girişi gerekmez. Adresi tarayıcıda açınca `METHOD` görülmesi normaldir; yalnız POST kabul eder. Hosting/WAF bu yola PayTR'nin POST isteklerini ulaştırmalıdır.
3. Kobivira'daki aynı PayTR ayar sayfasından **PayTR test ödemesini aç** düğmesine basın. Doğrudan yönetici adresi: `https://app.kobivira.com.tr/?page=paytr_test`.
4. Firma, paket, dönem ve test ödeyenin ad, e-posta, telefon, adres bilgilerini girin. Test onayını işaretleyin ve Kobivira yönetici şifrenizi girin. **PayTR test ödeme ekranını aç** düğmesine bir kez basın. Tutar girilmez; kayıtlı paket fiyatı, indirim ve KDV sunucuda hesaplanır. Mağaza canlıda olsa bile bu ekrandan gönderilen istekte `test_mode=1` sabittir.
5. Açılan PayTR test ekranındaki test kartı ve doğrulama adımlarını tamamlayın. Dönüşte **Sonucu yenile** düğmesine basın. Beklenen sonuç **Test başarılı** ve doğrulanan bildirim tarihidir. Sadece başarılı dönüş adresine gelmek yeterli değildir.
6. PayTR panelindeki işlem referansını Kobivira'daki `KVT…` referansıyla karşılaştırın. Ardından farklı bir yeni test açarak PayTR'nin sunduğu başarısız ödeme senaryosunu deneyin. Kobivira'da **Test ödeme başarısız** ve bildirim tarihi görünmelidir. İki sonucu da doğrulamadan gerçek ödeme başarısı kabul etmeyin.

## Sonuçları okumak

- **Ödeme / bildirim bekleniyor:** Ekran açılmıştır; doğrulanmış sonuç henüz yoktur. Ödemeyi tamamladıysanız PayTR bildirim URL ve işlem kaydını kontrol edin. Sonucu yenilemek ödeme isteğini tekrarlamaz veya sağlayıcıya durum sorgusu göndermez; veritabanındaki son bildirimi gösterir.
- **PayTR yanıtı bekleniyor:** Token isteği başlamış, henüz sonuç kaydedilmemiştir. Sunucu işlemi kesilmiş olabilir. Bu referansla yeniden istek gönderilmez; PayTR işlem kaydını kontrol edin.
- **Ödeme ekranı açılmadı:** PayTR isteği reddetmiştir. Mağaza bilgileri, iFrame API yetkisi ve PayTR panelindeki IP/domain ayarlarını kontrol edin.
- **Sonuç belirsiz:** Bağlantı, TLS, zaman aşımı veya yanıt doğrulama sorunu olmuştur. Otomatik tekrar yapılmaz. PayTR kaydını kontrol edin; sonradan gelen geçerli bildirim işlenir.
- **Test başarılı / Test ödeme başarısız:** İmzalı sonuç bildirimi doğrulanmıştır.
- Çelişen geçerli sonuçlar gelirse ilk sonuç korunur ve yönetimde inceleme uyarısı görünür.

## Teknik kapsam ve sınırlar

- Token isteği sunucudan sabit PayTR HTTPS adresine yapılır. cURL, geçerli CA sertifikaları ve sunucudan PayTR'ye dış bağlantı gerekir. Sertifika doğrulaması açıktır; yönlendirme izlenmez. Bu geliştirme ortamında gerçek PayTR ağına istek yapılmamıştır; sağlayıcı cevabı kontrollü taklitle denenmiştir.
- PayTR istek ve bildirim imzaları HMAC-SHA256 ile doğrulanır. Anahtar/salt şifreli tutulur. Test oluşturulurken alınan şifreli anahtar kopyası, ayarlar sonradan değiştirilse de o testin bildirimini doğrular. Anahtarlar, kart bilgileri ve ham servis cevapları loga yazılmaz; kart bilgileri Kobivira'ya gönderilmez.
- Tek form anahtarından tek test ve tek token isteği çıkar. Tekrarlanan doğru bildirimlere yalnız `OK` döner. Bakımda `503` döner, PayTR'nin tekrar bildirmesi beklenir.
- Her test kendi firma, paket, dönem ve tutarını saklar. Test tablosu gerçek ödeme siparişlerinden ayrıdır. Başarılı ve başarısız testlerin hiçbiri abonelik süresi, paket, gerçek kontör veya hediye kontör değiştirmez. PayTR otomatik gerçek üyelik etkinleştirmesi bu sürümün kapsamına dahil değildir.
- Firma faturası üzerinden müşteriden kartla tahsilat bağlantısı, otomatik yenileme ve iade API'si bu sürümde eklenmemiştir. Mevcut havale/onay akışı korunur.
- Test ekranı yalnız platform yöneticisine açıktır; firma, çalışan, muhasebeci ve destek temsilcisi kullanamaz.
- Eski 42 migration dosyası değiştirilmemiştir. 043 yalnız test tablosunu ekler. Firma kalıcı silme akışına bu tablonun temizliği eklenmiştir.

## Doğrulama

Yerel izole MariaDB/PHP testlerinde imzalı 3.6.22 → 3.6.23 güncellemesi, veri korunması, fiyat hesabı, iki bağımsız HMAC referansı, tekrar/yanlış imza/yanlış tutar/anahtar değişimi/başarısız ödeme, oturum ve yetki kontrolleri çalıştırıldı. 50 PHP/veritabanı kontrolü ve 19 gerçek yerel HTTP kontrolü geçti. 159 PHP dosyası sözdizimi kontrolünden geçti. Bunlar PayTR'nin gerçek hesabınızda ödemeyi onayladığını veya canlıya geçişi onayladığını göstermez. Sunucudaki yukarıdaki testler tamamlanmalıdır.

Resmî kaynaklar: https://dev.paytr.com/iframe-api/iframe-api-1-adim ve https://dev.paytr.com/iframe-api/iframe-api-2-adim
