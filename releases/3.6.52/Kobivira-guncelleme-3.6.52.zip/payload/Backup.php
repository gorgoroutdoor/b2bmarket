<?php
declare(strict_types=1);
/** Yalnızca uygulamaya ayrılmış veritabanı. Küçük kurulumlar için web yedeği. */
final class Backup {
    private const MAX_ROWS = 100000;
    private const MAX_BYTES = 67108864; // sıkıştırılmamış 64 MiB
    public function __construct(private PDO $db) {}
    private function tables(): array {
        $tables=$this->db->query("SHOW FULL TABLES WHERE Table_type='BASE TABLE'")->fetchAll(PDO::FETCH_COLUMN);
        foreach($tables as $t) { if(!preg_match('/^[a-zA-Z0-9_]+$/D',$t)) throw new RuntimeException('Tablo adı desteklenmiyor.'); }
        return $tables;
    }
    public function create(): array {
        $filename='backup-' . gmdate('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.jsonl.gz';
        $path=APP_ROOT . '/storage/backups/' . $filename;
        $f=gzopen($path,'wb6'); if(!$f) throw new RuntimeException('Yedek açılamadı.'); chmod($path,0600);
        $rows=0; $bytes=0; $large=PHP_SAPI==='cli'; $deadline=$large?INF:microtime(true)+20;
        $write=function(array $r) use ($f,&$bytes,$deadline,$large) {
            $line=json_encode($r,JSON_THROW_ON_ERROR|JSON_INVALID_UTF8_SUBSTITUTE) . "\n";
            $bytes+=strlen($line);
            if((!$large&&$bytes>self::MAX_BYTES) || microtime(true)>$deadline) throw new RuntimeException('Web yedek sınırı aşıldı. Büyük veritabanı için CLI güncelleme aracını kullanın.');
            if(gzwrite($f,$line)!==strlen($line)) throw new RuntimeException('Yedek yazılamadı.');
        };
        try {
            $this->db->exec('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ'); $this->db->beginTransaction();
            $write(['format'=>1]);
            foreach($this->tables() as $t) {
                $create=$this->db->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1];
                $write(['table'=>$t,'create'=>$create]);
                // Buffer kapalı: büyük tek bir tablonun belleği doldurmasını engeller.
                $this->db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY,false);
                $q=$this->db->query("SELECT * FROM `$t`",PDO::FETCH_ASSOC);
                while($row=$q->fetch()) {
                    if(++$rows>self::MAX_ROWS&&!$large) throw new RuntimeException('Web yedeği 100.000 satır sınırını aştı.');
                    $encoded=[]; foreach($row as $k=>$v) $encoded[$k]=$v===null?null:base64_encode((string)$v);
                    $write(['row'=>$encoded]);
                }
                $q->closeCursor(); $this->db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY,true);
            }
            $write(['end'=>true,'rows'=>$rows]); $this->db->commit(); gzclose($f);
            return ['file'=>$filename,'sha256'=>hash_file('sha256',$path)];
        } catch(Throwable $e) { if(isset($q)) $q->closeCursor(); $this->db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY,true); if($this->db->inTransaction()) $this->db->rollBack(); gzclose($f); @unlink($path); throw $e; }
    }
    /** Build and validate a complete staging copy before atomically replacing live tables. */
    public function restore(array $snapshot): void {
        $name=$snapshot['file']??'';$sha=$snapshot['sha256']??'';
        if(!is_string($name)||!preg_match('/^backup-[a-zA-Z0-9-]+\.jsonl\.gz$/D',$name)||!is_string($sha)||!preg_match('/^[a-f0-9]{64}$/D',$sha))throw new RuntimeException('Yedek bilgisi geçersiz.');
        $path=APP_ROOT.'/storage/backups/'.$name;
        if(!is_file($path)||!hash_equals($sha,hash_file('sha256',$path)))throw new RuntimeException('Yedek doğrulanamadı.');
        $definitions=[];$table=null;$rows=0;$ended=false;$first=true;
        // Validate every record, not just the final marker. No DDL before this pass succeeds.
        foreach($this->records($path) as $r){
            if($first){$first=false;if($r!==['format'=>1])throw new RuntimeException('Yedek biçimi desteklenmiyor.');continue;}
            if($ended)throw new RuntimeException('Yedek sonundan sonra veri var.');
            if(isset($r['table'])){
                $table=$r['table'];
                if(!is_string($table)||!preg_match('/^[a-zA-Z0-9_]{1,64}$/D',$table)||isset($definitions[$table])||!is_string($r['create']??null)||!preg_match('/^CREATE TABLE `'.preg_quote($table,'/').'`\s*\(/',$r['create'])||!preg_match('/ENGINE=InnoDB\b/i',$r['create']))throw new RuntimeException('Yedek tablo tanımı geçersiz.');
                $definitions[$table]=$r['create'];
            }elseif(isset($r['row'])){
                if($table===null||!is_array($r['row'])||!$r['row'])throw new RuntimeException('Yedek satırı geçersiz.');
                foreach($r['row'] as $key=>$v)if(!is_string($key)||!preg_match('/^[a-zA-Z0-9_]+$/D',$key)||($v!==null&&(!is_string($v)||base64_decode($v,true)===false)))throw new RuntimeException('Yedek satır verisi geçersiz.');
                $rows++;
            }elseif(($r['end']??false)===true){if(($r['rows']??null)!==$rows)throw new RuntimeException('Yedek satır sayısı uyuşmuyor.');$ended=true;}
            else throw new RuntimeException('Bilinmeyen yedek kaydı.');
        }
        if(!$ended||!$definitions)throw new RuntimeException('Yedek eksik.');
        $prefix='kv_stage_'.bin2hex(random_bytes(6)).'_';$map=[];$created=[];$switched=false;$old=[];
        foreach(array_keys($definitions) as $i=>$t)$map[$t]=$prefix.$i;
        $fk=(int)$this->db->query('SELECT @@FOREIGN_KEY_CHECKS')->fetchColumn();
        $this->db->exec('SET FOREIGN_KEY_CHECKS=0');
        try{
            foreach($definitions as $t=>$ddl){
                $stage=$map[$t];$ddl=preg_replace('/^CREATE TABLE `[^`]+`/','CREATE TABLE `'.$stage.'`',$ddl,1);
                $ddl=preg_replace_callback('/\bREFERENCES `([^`]+)`/',function($m)use($map){if(!isset($map[$m[1]]))throw new RuntimeException('Yedek dışındaki tabloya bağımlılık var.');return 'REFERENCES `'.$map[$m[1]].'`';},$ddl);
                $n=0;$ddl=preg_replace_callback('/\bCONSTRAINT `[^`]+`/',function()use(&$n,$stage){return 'CONSTRAINT `'.$stage.'_fk'.(++$n).'`';},$ddl);
                $this->db->exec($ddl);$created[]=$stage;
            }
            $this->db->beginTransaction();$insert=null;$columns=[];
            foreach($this->records($path) as $r){
                if(isset($r['table'])){
                    $stage=$map[$r['table']];$columns=$this->db->query("SHOW COLUMNS FROM `$stage`")->fetchAll(PDO::FETCH_COLUMN);
                    $insert=$this->db->prepare("INSERT INTO `$stage` (".implode(',',array_map(fn($c)=>'`'.$c.'`',$columns)).') VALUES ('.implode(',',array_fill(0,count($columns),'?')).')');
                }elseif(isset($r['row'])){
                    if(array_keys($r['row'])!==$columns)throw new RuntimeException('Yedek sütunları tabloyla uyuşmuyor.');
                    $values=[];foreach($r['row'] as $v)$values[]=$v===null?null:base64_decode($v,true);$insert->execute($values);
                }
            }
            $this->db->commit();
            // FOREIGN_KEY_CHECKS=1 does not retroactively check imported rows; explicitly check them.
            foreach($map as $stage){
                $q=$this->db->prepare('SELECT CONSTRAINT_NAME,COLUMN_NAME,REFERENCED_TABLE_NAME,REFERENCED_COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND REFERENCED_TABLE_NAME IS NOT NULL ORDER BY CONSTRAINT_NAME,ORDINAL_POSITION');$q->execute([$stage]);$groups=[];
                foreach($q as $r)$groups[$r['CONSTRAINT_NAME']][]=$r;
                foreach($groups as $keys){$parent=$keys[0]['REFERENCED_TABLE_NAME'];if(!in_array($parent,$map,true))throw new RuntimeException('Geri yükleme bağımlılığı geçersiz.');$on=[];$nonnull=[];
                    foreach($keys as $key){$c=$key['COLUMN_NAME'];$r=$key['REFERENCED_COLUMN_NAME'];$on[]="c.`$c`=p.`$r`";$nonnull[]="c.`$c` IS NOT NULL";}
                    $firstColumn=$keys[0]['REFERENCED_COLUMN_NAME'];
                    if($this->db->query("SELECT 1 FROM `$stage` c LEFT JOIN `$parent` p ON ".implode(' AND ',$on).' WHERE '.implode(' AND ',$nonnull)." AND p.`$firstColumn` IS NULL LIMIT 1")->fetchColumn())throw new RuntimeException('Yedekte ilişkisi eksik kayıt var.');
                }
            }
            $renames=[];$retired='kv_retired_'.bin2hex(random_bytes(6)).'_';
            foreach($this->tables() as $i=>$t){if(in_array($t,$created,true))continue;$old[]=$retired.$i;$renames[]="`$t` TO `".$retired.$i.'`';}
            foreach($map as $t=>$stage)$renames[]="`$stage` TO `$t`";
            $this->db->exec('RENAME TABLE '.implode(',',$renames));$switched=true;
            // Failure to clean retired copies must not invalidate a completed atomic restore.
            foreach($old as $t){try{$this->db->exec("DROP TABLE `$t`");}catch(Throwable $e){error_log('Kobivira restore cleanup: '.$e->getMessage());}}
        }catch(Throwable $e){
            if($this->db->inTransaction())$this->db->rollBack();
            if(!$switched)foreach($created as $t){try{$this->db->exec("DROP TABLE IF EXISTS `$t`");}catch(Throwable $ignored){error_log('Kobivira restore staging cleanup failed.');}}
            throw $e;
        }finally{$this->db->exec('SET FOREIGN_KEY_CHECKS='.$fk);}
    }
    private function records(string $path): Generator {
        $f=gzopen($path,'rb');if(!$f)throw new RuntimeException('Yedek okunamadı.');
        try{while(($line=gzgets($f))!==false){$r=json_decode($line,true,512,JSON_THROW_ON_ERROR);if(!is_array($r))throw new RuntimeException('Yedek kaydı geçersiz.');yield $r;}}finally{gzclose($f);}
    }
}
