<?php
declare(strict_types=1);
function cms_e(mixed $v): string{return esc($v);}
function cms_q(string $sql,array $args=[]): PDOStatement {return query($sql,$args);}
function cms_json(mixed $v): string{return json_encode($v,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);}
function cms_post(string $key,int $max=2000): string {return field($key,$max);}
function cms_platform(): bool {return (base_user()['role']??'')==='platform_admin'&&!support_context();}
function cms_entitled(int $cid): bool {return module351_allowed('website',$cid,true);}
function cms_scope(bool $write=false): array {
 if(cms_platform()){$id=max(1,(int)($_GET['site']??1));$s=query('SELECT * FROM cms_sites WHERE id=?',[$id])->fetch();}
 else{firm_manager();if($write&&!cms_entitled(company_id())){http_response_code(403);throw new DomainException('Web sitesi yönetimi için etkin web sitesi modülü ve aktif üyelik gerekir.');}$s=query('SELECT * FROM cms_sites WHERE company_id=?',[company_id()])->fetch();}
 if(!$s){http_response_code(404);throw new DomainException('Web sitesi henüz tanımlanmadı. Kobivira ile iletişime geçin.');}return $s;
}
function cms_sid(): int{return (int)cms_scope()['id'];}
function cms_s(string $name,string $default='',?int $sid=null): string {$v=query('SELECT value FROM cms_settings WHERE site_id=? AND name=?',[$sid??cms_sid(),$name])->fetchColumn();return $v===false?$default:(string)$v;}
function cms_setting(string $k,string $v,int $sid): void {query('INSERT INTO cms_settings(site_id,name,value) VALUES (?,?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',[$sid,$k,$v]);}
function cms_go(string $view='dashboard',array $args=[]): never {redirect(cms_platform()?'site_admin':'website',['view'=>$view]+(cms_platform()?['site'=>max(1,(int)($_GET['site']??1))]:[])+$args);}
function cms_user(): ?array{return base_user();}
function cms_tx(callable $fn): mixed{if(cms_platform())return transaction($fn);return company_transaction(function()use($fn){if(!cms_entitled(company_id())){http_response_code(403);throw new DomainException('Etkin web sitesi modülü ve aktif üyelik gerekir.');}return $fn();});}
function cms_history(string $entity,int $id,array $old,string $action='save'): void {query('INSERT INTO cms_history(site_id,entity,entity_id,action,snapshot,actor_id,created_at) VALUES (?,?,?,?,?,?,UTC_TIMESTAMP())',[cms_sid(),$entity,$id,$action,cms_json($old),base_user()['id']]);}
function cms_slug(string $s): string {if(!preg_match('/^[a-z0-9][a-z0-9-]{0,100}$/D',$s)||in_array($s,['admin','assets','media','index'],true))throw new DomainException('Adres yalnız küçük harf, rakam ve tire içermeli.');return $s;}
function cms_amount(string $s): ?int {if($s==='')return null;$s=str_replace([' ','₺','TL'],'',$s);if(str_contains($s,','))$s=str_replace(',','.',str_replace('.','',$s));if(!preg_match('/^(\d{1,9})(?:\.(\d{1,2}))?$/D',$s,$m))throw new DomainException('Fiyatı 999.000,00 biçiminde girin.');return (int)$m[1]*100+(int)str_pad($m[2]??'',2,'0',STR_PAD_RIGHT);}
function cms_fields_html(array $r): string {$html=$r['content_html'];foreach(json_decode($r['fields'],true,32,JSON_THROW_ON_ERROR) as $k=>$f)$html=str_replace('{{field:'.$k.'}}',esc($f['value']),$html);return $html;}
function cms_asset_pack(bool $includeGuideImages=true): array {static $base,$all;$base??=json_decode(file_get_contents(__DIR__.'/Assets.json'),true,16,JSON_THROW_ON_ERROR);if(!$includeGuideImages)return $base;if($all!==null)return $all;$all=$base;foreach(glob(dirname(__DIR__).'/Guide3642Assets[0-9]*.json')?:[] as $f)$all+=json_decode(file_get_contents($f),true,16,JSON_THROW_ON_ERROR);return $all;}
function cms_asset(): never {$n=is_string($_GET['asset']??null)?$_GET['asset']:'';$a=str_starts_with($n,'guide3642-')?guide3642_asset($n):(cms_asset_pack(false)[$n]??null);if(!$a){http_response_code(404);exit;}header('Content-Type: '.$a['type']);header('Cache-Control: public,max-age=86400');echo base64_decode($a['data'],true);exit;}
function cms_media_scope(): array {
 $host=strtolower(preg_replace('/:\d+$/','',$_SERVER['HTTP_HOST']??''));
 if($host==='app.kobivira.com.tr'&&current_user())return ['site_id'=>(int)cms_scope()['id'],'private'=>true];
 return ['site_id'=>(int)cms_public_scope()['id'],'private'=>false];
}
function cms_media(): never {
 $n=is_string($_GET['media']??null)?$_GET['media']:'';
 if(!preg_match('/^[a-f0-9]{32}\.(png|jpg|webp)$/D',$n)){http_response_code(404);exit;}
 try{$scope=cms_media_scope();}catch(DomainException $e){http_response_code(404);exit;}
 if(!$scope['private']&&in_array($n,cp_demo_state((int)$scope['site_id'])['media']??[],true)){http_response_code(404);exit;}
 $r=query('SELECT * FROM cms_media WHERE site_id=? AND filename=?',[$scope['site_id'],$n])->fetch();
 if(!$r){http_response_code(404);exit;}$p=APP_ROOT.'/storage/site-media/'.$n;$i=@getimagesize($p);
 if(!$i){http_response_code(404);exit;}
 header('Content-Type: '.$i['mime']);header('Cache-Control: '.($scope['private']?'private,no-store':'public,max-age=86400'));readfile($p);exit;
}
function cms_record(string $entity,int $id,bool $lock=false): array {if(!in_array($entity,['pages','blocks','plans','features','nav'],true))throw new LogicException('İçerik türü geçersiz.');$r=query('SELECT * FROM cms_'.$entity.' WHERE site_id=? AND id=?'.($lock?' FOR UPDATE':''),[cms_sid(),$id])->fetch();if(!$r){http_response_code(404);throw new DomainException('İçerik bulunamadı veya bu siteye ait değil.');}return $r;}
function cms_view_allowed(string $view): void {if(!cms_platform()&&!in_array($view,['dashboard','pages','blocks','nav','media','settings','history','corporate','catalog'],true)){http_response_code(403);throw new DomainException('Bu bölüm yalnız Kobivira yöneticisine açıktır.');}}
function cms_seed_site(PDO $db,int $sid,array $seed): void {
 foreach($seed['settings'] as $k=>$v){$q=$db->prepare('INSERT INTO cms_settings(site_id,name,value) VALUES (?,?,?)');$q->execute([$sid,$k,is_string($v)?$v:json_encode($v,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);}
 foreach(['pages','blocks','plans','features','nav'] as $key)foreach($seed[$key]??[] as $r){$r=['site_id'=>$sid]+$r;$q=$db->prepare('INSERT INTO cms_'.$key.' ('.implode(',',array_keys($r)).') VALUES ('.implode(',',array_fill(0,count($r),'?')).')');$q->execute(array_values($r));}
}
