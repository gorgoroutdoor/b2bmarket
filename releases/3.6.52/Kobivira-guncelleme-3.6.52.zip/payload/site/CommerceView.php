<?php
declare(strict_types=1);
function commerce_campaign(): string {
 $c=commerce_config();if(empty($c['enabled'])||time()<commerce_time($c['starts'])||time()>=commerce_time($c['ends']))return '';$offers=[];foreach(['kobi'=>'KOBİ','plus'=>'KOBİ Plus','business'=>'KOBİ Business'] as $code=>$name)if(($c['rates'][$code]['campaign']??0)>0)$offers[]=$name.' %'.$c['rates'][$code]['campaign'].' indirimli';if(!$offers)return '';
 $end=(new DateTimeImmutable('@'.commerce_time($c['ends'])))->setTimezone(new DateTimeZone('Europe/Istanbul'));return '<aside class="kv-campaign kv36-editable" data-campaign-end="'.esc($end->format(DATE_ATOM)).'" aria-label="Paket kampanyası">'.quick3636_control('https://app.kobivira.com.tr/?page=plans#campaign-settings').'<div class="wrap"><div><strong>'.esc($c['title']).'</strong><span>'.esc(implode(' · ',$offers)).' · '.$end->format('d.m.Y H:i').' tarihine kadar (Türkiye saati)</span></div><div class="kv-countdown" role="timer" aria-live="off"><span data-countdown>Bitiş: '.$end->format('d.m.Y').'</span></div><a href="paketler.html">Kampanyayı incele ↗</a></div></aside>';
}
function commerce_stats(): string {
 return '<section class="kv-impact wrap"><div><span class="eyebrow">İŞİNİZİN HAREKETİNİ GÖRÜN</span><h2>Her kayıt, daha net bir iş tablosu.</h2><p>Firmalar, belgeler ve KDV dahil işlem hacmi tek bir çalışma düzeninde. İşinizin bugününü görün, yarınını planlayın.</p></div><div class="kv-impact-grid"><article><strong data-kv-metric="companies">—</strong><span>Sistemi kullanan firma</span></article><article><strong data-kv-metric="documents">—</strong><span>Kesinleşmiş alış / satış kaydı</span></article><article><strong data-kv-metric="gross">—</strong><span>KDV dahil toplam kayıt hacmi</span></article></div><p class="kv-metric-note" data-kv-metric-note>Toplu istatistikler yayın koşulları oluştuğunda gösterilir. İşlem hacmi ön muhasebeye kaydedilen alış ve satış belgeleridir; sistemden geçen ödeme veya resmî e-Fatura hacmi değildir.</p></section>';
}
function commerce_credit_prices(): string {
 $x='<section class="wrap kv-credit-section" id="kontor-fiyatlari"><div class="section-title"><span class="eyebrow">İHTİYACINIZ KADAR</span><h2>Kontör paketleri</h2><p>Kontör satın alma talebinizi firma panelinden iletin. Havale onaylandığında bakiyeniz otomatik güncellenir.</p></div><div class="kv-credit-grid">';foreach(query('SELECT * FROM credit_packs ORDER BY sort_order,id') as $p){$x.='<article class="kv36-editable">'.quick3636_control('https://app.kobivira.com.tr/?page=credits#credit-pack-'.(int)$p['id']).'<h3>'.number_format((int)$p['quantity'],0,',','.').' kontör</h3>';if(!empty($p['is_active'])&&$p['net_price']!==null){$q=credits_pack_quote($p);$x.='<strong>'.money($q['total']).'</strong><small>KDV dahil</small><a href="https://app.kobivira.com.tr/?page=credits">Kontör satın al ↗</a>';}else $x.='<span>Bilgi alın</span><small>Satışa kapalı</small>';$x.='</article>';}
 return $x.'</div><p>5.000 üzeri ihtiyaçlarınız için <a href="iletisim.html">bizimle iletişime geçin →</a></p></section>';
}
function commerce_faq(): string {
 $rows=json_decode(setting('commerce_faq','[]'),true,32,JSON_THROW_ON_ERROR);$x='<section class="wrap kv-faq" id="sikca-sorulan-sorular"><div><span class="eyebrow">AKLINIZDA SORU KALMASIN</span><h2>Sıkça sorulan sorular</h2><p>Aradığınız yanıtı bulamadınız mı? <a href="iletisim.html">Bize ulaşın →</a></p></div><div>';foreach($rows as $i=>$r)$x.='<div class="kv36-faq-wrap">'.quick3636_control('https://app.kobivira.com.tr/?page=plans#commerce-faq-'.$i).'<details><summary>'.esc($r['q']).'<span aria-hidden="true">+</span></summary><p>'.nl2br(esc($r['a'])).'</p></details></div>';return $x.'</div></section>';
}
function commerce_home(string $body): string {
 $body=preg_replace('~</section>~','</section>'.commerce_stats(),$body,1);
 if(!str_contains($body,'{{customer_reviews}}'))$body.='{{customer_reviews}}';return $body.commerce_credit_prices().commerce_faq();
}
