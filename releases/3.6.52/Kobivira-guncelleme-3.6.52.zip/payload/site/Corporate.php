<?php
declare(strict_types=1);
require_once __DIR__.'/CorporatePro.php';
require_once __DIR__.'/CorporateEditor.php';

// Firma sitesi verileri muhasebe ürünlerinden ve Kobivira tanıtım sitesinden ayrıdır.
function corporate_scope(bool $write=false): array {
    $s=cms_scope($write);
    if(!(int)$s['company_id'])throw new DomainException('Bu bölüm yalnız firma web siteleri içindir.');
    return $s;
}
function corporate_data(int $sid): array {
    return json_decode(cp_setting('corporate_content','{}',$sid),true,32,JSON_THROW_ON_ERROR)+[
        'revision'=>0,'enabled'=>false,'headline'=>'','intro'=>'','about'=>'','cover'=>'','products'=>[], 'accent'=>'teal','faq'=>[]
    ];
}
function corporate_image(string $filename,int $sid,string $alt='',bool $thumbnail=false): string {
    if($filename===''||!query('SELECT id FROM cms_media WHERE site_id=? AND filename=?',[$sid,$filename])->fetchColumn())return '';
    return '<img style="max-width:100%;'.($thumbnail?'max-height:220px;object-fit:contain':'').'" loading="lazy" src="/?page=site_media&amp;site='.$sid.'&amp;media='.esc($filename).'" alt="'.esc($alt).'">';
}
function corporate_file(string $field,int $sid): ?string {
    $f=$_FILES[$field]??[];
    if(($f['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)return null;
    if(($f['error']??1)!==UPLOAD_ERR_OK||!is_uploaded_file($f['tmp_name'])||filesize($f['tmp_name'])>4194304)throw new DomainException('En fazla 4 MB PNG, JPG veya WebP görsel yükleyin.');
    $i=@getimagesize($f['tmp_name']);$ext=[IMAGETYPE_PNG=>'png',IMAGETYPE_JPEG=>'jpg',IMAGETYPE_WEBP=>'webp'][$i[2]??0]??null;
    if(!$ext||$i[0]>6000||$i[1]>6000)throw new DomainException('Görsel en fazla 6000 × 6000 piksel olmalıdır.');
    $dir=APP_ROOT.'/storage/site-media';if(!is_dir($dir)&&!mkdir($dir,0700,true))throw new RuntimeException('Görsel klasörü oluşturulamadı.');
    cms_media_capacity($sid,(int)filesize($f['tmp_name']));
    $name=bin2hex(random_bytes(16)).'.'.$ext;$dest=$dir.'/'.$name;
    if(!move_uploaded_file($f['tmp_name'],$dest))throw new DomainException('Görsel yüklenemedi.');
    chmod($dest,0600);$GLOBALS['corporate_uploads'][]=$dest;
    query('INSERT INTO cms_media(site_id,name,filename,alt_text,created_at) VALUES (?,?,?,?,UTC_TIMESTAMP())',[$sid,['logo'=>'Firma logosu','cover'=>'Ana sayfa görseli','product_image'=>'Ürün görseli'][$field]??'Görsel',$name,'']);
    return $name;
}
function corporate_save(string $action): never {
    if(in_array($action,['demo_start','demo_stop'],true))cp_demo_action($action);
    cp_assert_context();
    if($action==='pro_message_delete')cp_message_delete();
    if(in_array($action,['pro_save','pro_delete','pro_settings'],true))cp_save($action);
    $s=corporate_scope(true);$sid=(int)$s['id'];
    if(!in_array($action,['corporate_save','product_save','product_delete'],true))throw new DomainException('Site işlemi geçersiz.');
    $GLOBALS['corporate_uploads']=[];
    try{cms_tx(function()use($sid,$action){
        // Site kilidi ilk kayıtta da iki tarayıcının birbirinin değişikliğini ezmesini önler.
        query('SELECT id FROM cms_sites WHERE id=? FOR UPDATE',[$sid]);cp_assert_context();
        $d=corporate_data($sid);
        if((int)cms_post('revision',12)!==(int)$d['revision'])throw new DomainException('Site başka bir işlemde değişti. Sayfayı yenileyip tekrar deneyin.');
        cms_history('settings',0,['corporate_content'=>$d,'logo_url'=>cp_setting('logo_url','',$sid)]);
        if($action==='corporate_save'){
            foreach(['headline'=>180,'intro'=>2000,'about'=>12000] as $key=>$max)$d[$key]=cp_clean(cms_post($key,$max));
            foreach(['company_name'=>180,'contact_email'=>200,'phone'=>80,'address'=>2000,'site_title'=>180,'meta_description'=>500,'footer_text'=>2000] as $key=>$max){
                $v=cms_post($key,$max);
                if($key==='contact_email'&&$v!==''&&!filter_var($v,FILTER_VALIDATE_EMAIL))throw new DomainException('Geçerli iletişim e-postası yazın.');
                cms_history('settings',0,[$key=>cp_setting($key,'',$sid)]);cp_store($key,$v,$sid);
            }
            $robots=choice('robots',['noindex,nofollow','index,follow']);cp_store('robots',$robots,$sid);
            if(isset($_POST['remove_logo']))cp_store('logo_url','',$sid);
            if(($logo=corporate_file('logo',$sid))!==null)cp_store('logo_url','?page=site_media&media='.$logo,$sid);
            if(isset($_POST['remove_cover']))$d['cover']='';
            if(($cover=corporate_file('cover',$sid))!==null)$d['cover']=$cover;
            $d['enabled']=isset($_POST['enabled']);
            $d['accent']=choice('accent',['teal','blue','copper']);$d['faq']=[];
            for($i=0;$i<4;$i++){$q=cms_post('question_'.$i,200);$a=cms_post('answer_'.$i,2000);if(($q==='')!==($a===''))throw new DomainException('Sık sorulan sorunun hem soru hem cevap alanını doldurun.');if($q!=='')$d['faq'][]=['question'=>$q,'answer'=>$a];}
        }else{
            $id=cms_post('product_id',32);$products=$d['products'];
            if($id!==''&&!isset($products[$id]))throw new DomainException('Ürün bu siteye ait değil.');
            if($action==='product_delete'){
                if($id===''||!isset($_POST['confirm_delete']))throw new DomainException('Ürünü kaldırmak için onay verin.');
                unset($products[$id]);
            }else{
                if($id===''&&count($products)>=200)throw new DomainException('Web sitesine en fazla 200 ürün / hizmet eklenebilir.');
                $old=$products[$id]??[];$id=$id?:bin2hex(random_bytes(12));
                $p=['name'=>required_field('product_name',180),'description'=>cp_clean(cms_post('product_description',6000)),'category'=>cms_post('product_category',100),'kind'=>choice('product_kind',['product','service','project']),'visible'=>isset($_POST['visible']),'image'=>$old['image']??''];
                if(isset($_POST['remove_product_image']))$p['image']='';
                if(($image=corporate_file('product_image',$sid))!==null)$p['image']=$image;
                $products[$id]=$p;
            }
            $d['products']=$products;
        }
        $d['revision']++;cp_store('corporate_content',cms_json($d),$sid);
    });}catch(Throwable $e){foreach($GLOBALS['corporate_uploads'] as $path)if(is_file($path))unlink($path);throw $e;}
    audit('site.corporate_saved',['site'=>$sid,'action'=>$action]);flash('Web sitesi değişiklikleri kaydedildi.');cms_go($action==='corporate_save'?'corporate':'catalog');
}
function corporate_file_field(string $name,string $label): void {
    echo '<label class="field"><span>'.esc($label).'</span><input type="file" name="'.esc($name).'" accept="image/png,image/jpeg,image/webp"><small>Bilgisayarınızdan seçin · PNG, JPG veya WebP · en fazla 4 MB</small></label>';
}
function corporate_view_content(string $view): void {
    $s=corporate_scope();$sid=(int)$s['id'];$d=corporate_data($sid);
    if($view==='corporate'&&!cms_platform()){
        echo cp_toolbar();$section=is_string($_GET['section']??null)?$_GET['section']:'profile';
        if($section==='catalog'){corporate_view('catalog');return;}
        if($section!=='profile'){cp_editor($section);return;}
    }
    if($view==='corporate'){
        panel('Firma siteniz','Logonuzu ve görsellerinizi yükleyin, metinlerinizi yazın. Kaydettiğiniz içerik ön izlemede görünür.');
        cp_form('corporate','corporate_save',[],true);hidden('revision',$d['revision']);
        foreach(['company_name'=>'Firma / marka adı','phone'=>'Telefon','contact_email'=>'İletişim e-postası','site_title'=>'Google’da görünecek site başlığı'] as $k=>$label)input($k,$label,cp_setting($k,'',$sid),'text','maxlength="180"');
        $logo=cp_setting('logo_url','',$sid);if(preg_match('/media=([a-f0-9]{32}\.(?:png|jpg|webp))$/D',$logo,$m))echo '<div class="wide corporate-admin-preview">'.corporate_image($m[1],$sid,'Mevcut logo',true).'</div>';
        corporate_file_field('logo','Firma logosu yükle');cms_check_field('remove_logo','Mevcut logoyu kaldır',false);
        input('headline','Ana sayfa başlığı',$d['headline'],'text','maxlength="180" placeholder="Firmanızı anlatan kısa bir başlık"');textarea('intro','Ana sayfa tanıtım yazısı',$d['intro'],'maxlength="2000"');
        if($d['cover'])echo '<div class="wide corporate-admin-preview">'.corporate_image($d['cover'],$sid,'Mevcut ana sayfa görseli',true).'</div>';
        corporate_file_field('cover','Ana sayfa görseli yükle');cms_check_field('remove_cover','Ana sayfa görselini kaldır',false);
        textarea('about','Hakkımızda',$d['about'],'maxlength="12000"');textarea('address','Adres',cp_setting('address','',$sid),'maxlength="2000"');textarea('footer_text','Site altında görünecek kısa açıklama',cp_setting('footer_text','',$sid),'maxlength="2000"');textarea('meta_description','Google’da görünecek kısa açıklama',cp_setting('meta_description','',$sid),'maxlength="500"');
        select_field('robots','Arama motorlarında görünürlük',['noindex,nofollow'=>'Arama motorlarına kapalı','index,follow'=>'Arama motorlarına açık'],cp_setting('robots','noindex,nofollow',$sid));
        select_field('accent','Firma sitenizin vurgu rengi',['teal'=>'Turkuaz','blue'=>'Mavi','copper'=>'Bakır'],$d['accent']);
        if(cms_platform()){
        echo '<div class="wide"><h3>Sık sorulan sorular</h3><p>Yalnız doldurduğunuz sorular ana sayfada gösterilir.</p></div>';
        for($i=0;$i<4;$i++){input('question_'.$i,'Soru '.($i+1),$d['faq'][$i]['question']??'','text','maxlength="200"');textarea('answer_'.$i,'Cevap '.($i+1),$d['faq'][$i]['answer']??'','maxlength="2000"');}
        }else{
            for($i=0;$i<4;$i++){hidden('question_'.$i,$d['faq'][$i]['question']??'');hidden('answer_'.$i,$d['faq'][$i]['answer']??'');}
            echo '<p class="field-hint wide">Sık sorulan soruları '.cms_link('corporate','İçerikler → Sorular',['section'=>'faq']).' bölümünden düzenleyebilirsiniz.</p>';
        }
        cms_check_field('enabled','Kurumsal temayı kullan',$d['enabled']);
        echo '<p class="field-hint wide">Kurumsal tema ana sayfa, hakkımızda, ürünler ve iletişim sayfalarında kullanılır. Önceki sayfa ve blok kayıtlarınız korunur; bu seçeneği kapatarak eski görünüme dönebilirsiniz. Alan adı ve genel yayın izni Kobivira yöneticisi tarafından yönetilir.</p>';
        cms_close('Site bilgilerimi kaydet');echo '</section>';return;
    }
    $id=is_string($_GET['product']??null)?$_GET['product']:'';
    if(isset($_GET['new'])||$id!==''){
        if($id!==''&&!isset($d['products'][$id]))throw new DomainException('Ürün bulunamadı.');$p=$d['products'][$id]??[];
        panel($id?'Ürün / hizmeti düzenle':'Ürün / hizmet ekle','Bu katalog web siteniz içindir; muhasebe stok ve fiyat kayıtlarınızı değiştirmez.');cp_form('catalog','product_save',$id?['product'=>$id]:['new'=>1],true);hidden('revision',$d['revision']);hidden('product_id',$id);
        input('product_name','Ürün / hizmet adı',$p['name']??'','text','required maxlength="180"');input('product_category','Kategori',$p['category']??'','text','maxlength="100"');textarea('product_description','Açıklama',$p['description']??'','maxlength="6000"');
        select_field('product_kind','Sitede hangi bölümde görünsün?',['product'=>'Ürünler','service'=>'Hizmetler','project'=>'Projeler / galeri'],$p['kind']??'product');
        if(!empty($p['image']))echo '<div class="wide corporate-admin-preview">'.corporate_image($p['image'],$sid,$p['name'],true).'</div>';
        corporate_file_field('product_image','Ürün / hizmet fotoğrafı yükle');cms_check_field('remove_product_image','Mevcut fotoğrafı kaldır',false);cms_check_field('visible','Web sitesinde göster',$p['visible']??true);cms_close('Ürün / hizmeti kaydet');echo '</section>';
        if($id){panel('Ürünü web sitesinden kaldır');cp_form('catalog','product_delete');hidden('revision',$d['revision']);hidden('product_id',$id);cms_check_field('confirm_delete','Bu ürünü web sitesi kataloğundan kaldırmayı onaylıyorum',false);cms_close('Ürünü kaldır');echo '</section>';}return;
    }
    echo cms_link('catalog','Ürün / hizmet ekle',['new'=>1],'button primary').'<br><br>';panel('Web sitesi ürün ve hizmetleri','Fotoğraflı ürün ve hizmetlerinizi buradan yönetin.');
    table_start(['Ürün / hizmet','Kategori','Durum','İşlem']);foreach($d['products'] as $id=>$p)echo '<tr><td>'.esc($p['name']).'</td><td>'.esc($p['category']).'</td><td>'.($p['visible']?'Görünür':'Gizli').'</td><td>'.cms_link('catalog','Düzenle',['product'=>$id]).'</td></tr>';table_end(count($d['products']),4);echo '</section>';
}
function corporate_public(array $site,string $slug,bool $preview): ?string {
    if(!(int)$site['company_id']||!in_array($slug,['ana-sayfa','hakkimizda','urunler','iletisim'],true))return null;
    $sid=(int)$site['id'];$d=corporate_data($sid);if(!$d['enabled'])return null;
    $link=fn($page)=>esc($preview?url('web_preview',['slug'=>$page]+['site'=>$sid]):cms_site_url($page));
    $brand=cp_setting('company_name',$site['name'],$sid);$intro=nl2br(esc($d['intro']));$about=nl2br(esc($d['about']));
    $contact='<div class="corporate-contact">';
    $email=cp_setting('contact_email','',$sid);if(filter_var($email,FILTER_VALIDATE_EMAIL))$contact.='<p><span>E-posta</span><a href="mailto:'.esc($email).'">'.esc($email).'</a></p>';
    $phone=cp_setting('phone','',$sid);if($phone!=='')$contact.='<p><span>Telefon</span><a href="tel:'.esc(preg_replace('/[^+0-9]/','',$phone)).'">'.esc($phone).'</a></p>';
    $address=cp_setting('address','',$sid);if($address!=='')$contact.='<p><span>Adres</span>'.nl2br(esc($address)).'</p>';$contact.='</div>';
    if($slug==='ana-sayfa')$body='<section class="corporate-hero"><div><span class="eyebrow">'.esc($brand).'</span><h1>'.esc($d['headline']?:$brand).'</h1><div class="corporate-copy">'.$intro.'</div><div class="corporate-actions"><a class="btn" href="'.$link('urunler').'">Ürün ve hizmetler</a><a class="corporate-secondary" href="'.$link('iletisim').'">İletişime geçin ↗</a></div></div>'.corporate_image($d['cover'],$sid,$brand).'</section>';
    else $body='<section class="corporate-title"><span class="eyebrow">'.esc($brand).'</span><h1>'.esc(['hakkimizda'=>'Hakkımızda','urunler'=>'Ürün ve hizmetler','iletisim'=>'İletişim'][$slug]).'</h1></section>';
    if(in_array($slug,['ana-sayfa','hakkimizda'],true)&&$d['about']!=='')$body.='<section class="corporate-section"><span class="eyebrow">BİZİ TANIYIN</span><h2>'.esc($brand).'</h2><div class="corporate-copy">'.$about.'</div></section>';
    if(in_array($slug,['ana-sayfa','urunler'],true)){
        foreach(['service'=>'Hizmetlerimiz','product'=>'Ürünlerimiz','project'=>'Projeler / galeri'] as $kind=>$label){
            $cards='';$count=0;foreach($d['products'] as $p){if(!$p['visible']||($p['kind']??'product')!==$kind)continue;if($slug==='ana-sayfa'&&$count>=6)break;$count++;$cards.='<article class="corporate-card">'.corporate_image($p['image'],$sid,$p['name']).'<div><span class="eyebrow">'.esc($p['category']).'</span><h3>'.esc($p['name']).'</h3><p>'.nl2br(esc($p['description'])).'</p><a href="'.$link('iletisim').'">Bilgi alın ↗</a></div></article>';}
            if($cards!=='')$body.='<section class="corporate-section"><div class="corporate-section-head"><h2>'.$label.'</h2><a href="'.$link('urunler').'">Tümünü inceleyin ↗</a></div><div class="corporate-grid">'.$cards.'</div></section>';
        }
    }
    if($slug==='ana-sayfa'&&$d['faq']){$body.='<section class="corporate-section"><h2>Sık sorulan sorular</h2><div class="corporate-faq">';foreach($d['faq'] as $f)$body.='<details><summary>'.esc($f['question']).'</summary><p>'.nl2br(esc($f['answer'])).'</p></details>';$body.='</div></section>';}
    if($slug==='iletisim')$body.='<section class="corporate-section">'.$contact.'</section>';
    elseif($slug==='ana-sayfa')$body.='<section class="corporate-cta"><h2>Birlikte çalışalım.</h2><a class="btn" href="'.$link('iletisim').'">Bize ulaşın ↗</a></section>';
    return '<div class="corporate-site corporate-accent-'.esc(in_array($d['accent'],['teal','blue','copper'],true)?$d['accent']:'teal').'">'.$body.'</div>';
}
