<?php
declare(strict_types=1);

// Demo is a separate, editable site draft. Public requests never read this draft.
function cp_demo_context(): bool {
 return !cms_platform()&&in_array($_GET['page']??'',['website','web_preview'],true);
}
function cp_demo_state(int $sid): array {
 return json_decode(cms_s('corporate_demo','{}',$sid),true,64,JSON_THROW_ON_ERROR);
}
function cp_demo_active(int $sid): bool {return cp_demo_context()&&!empty(cp_demo_state($sid)['active']);}
function cp_demo_revision(int $sid): int {return (int)(cp_demo_state($sid)['revision']??0);}
function cp_form(string $view,string $action,array $args=[],bool $upload=false): void {
 cms_form($view,$action,$args,$upload);$sid=cms_sid();hidden('editor_mode',cp_demo_active($sid)?'demo':'live');hidden('editor_revision',(string)cp_demo_revision($sid));
}
function cp_assert_context(): void {
 $sid=cms_sid();$d=cp_demo_state($sid);if(!$d)return;
 if(cms_post('editor_mode',8)!==(cp_demo_active($sid)?'demo':'live')||cms_post('editor_revision',12)!==(string)cp_demo_revision($sid))throw new DomainException('Çalışma kopyası değişti. Sayfayı yenileyip tekrar kaydedin.');
}
function cp_preview_scope(): array {
 $u=current_user();if(!$u){http_response_code(401);throw new DomainException('Ön izleme için hesabınıza giriş yapın.');}
 if(support_context()||!in_array($u['role']??'',['company_admin','platform_admin'],true)){http_response_code(403);throw new DomainException('Bu ön izlemeye erişim yetkiniz yok.');}
 if(!isset($_GET['site'])||!is_string($_GET['site'])||!ctype_digit($_GET['site'])||(int)$_GET['site']<1){http_response_code(400);throw new DomainException('Ön izleme bağlantısında site seçimi eksik. Web sitem bölümündeki Ön izleme düğmesini kullanın.');}
 $s=cms_scope();
 if(!cms_platform()&&(!cms_entitled(company_id())||(isset($_GET['site'])&&(string)$_GET['site']!==(string)$s['id']))){http_response_code(403);throw new DomainException('Yalnız kendi firmanızın ön izlemesini açabilirsiniz.');}
 header('Cache-Control: private, no-store, max-age=0');header('X-Robots-Tag: noindex, nofollow, noarchive');header('Referrer-Policy: no-referrer');
 return $s;
}
function cp_setting(string $key,string $default='',?int $sid=null): string {
 $sid=$sid??cms_sid();
 if(cp_demo_active($sid)){$d=cp_demo_state($sid);if(array_key_exists($key,$d['values']??[]))return (string)$d['values'][$key];}
 return cms_s($key,$default,$sid);
}
function cp_store(string $key,string $value,int $sid): void {
 if(cp_demo_active($sid)){$d=cp_demo_state($sid);$d['values'][$key]=$value;foreach($GLOBALS['corporate_uploads']??[] as $path)$d['media'][]=basename($path);$d['media']=array_values(array_unique($d['media']??[]));cms_setting('corporate_demo',cms_json($d),$sid);return;}
 cms_setting($key,$value,$sid);
}
function cp_demo_action(string $action): never {
 firm_manager();$site=corporate_scope(true);$sid=(int)$site['id'];$GLOBALS['corporate_uploads']=[];
 try{cms_tx(function()use($sid,$action){
  query('SELECT id FROM cms_sites WHERE id=? FOR UPDATE',[$sid]);$d=cp_demo_state($sid);
  if((string)($d['revision']??0)!==cms_post('demo_revision',12))throw new DomainException('Demo durumu değişti. Sayfayı yenileyin.');
  if($action==='demo_start'&&empty($d['values'])){
   $seed=json_decode(file_get_contents(__DIR__.'/CorporateDemo.json'),true,64,JSON_THROW_ON_ERROR);$map=[];
   $dir=APP_ROOT.'/storage/site-media';if(!is_dir($dir)&&!mkdir($dir,0700,true))throw new RuntimeException('Görsel klasörü açılamadı.');
   foreach($seed['images'] as $key=>$image){
    $bytes=base64_decode($image,true);$info=$bytes!==false?getimagesizefromstring($bytes):false;
    if(!$info||$info[2]!==IMAGETYPE_PNG||strlen($bytes)>4194304)throw new RuntimeException('Demo görseli geçersiz.');
    cms_media_capacity($sid,strlen($bytes));
    $filename=bin2hex(random_bytes(16)).'.png';$path=$dir.'/'.$filename;
    if(file_put_contents($path,$bytes)!==strlen($bytes))throw new RuntimeException('Demo görseli kaydedilemedi.');
    chmod($path,0600);$GLOBALS['corporate_uploads'][]=$path;
    query('INSERT INTO cms_media(site_id,name,filename,alt_text,created_at) VALUES (?,?,?,?,UTC_TIMESTAMP())',[$sid,'Demo · '.$key,$filename,'Örnek görsel']);$map['@'.$key]=$filename;
   }
   $replace=function($v)use(&$replace,$map){if(is_array($v))return array_map($replace,$v);return is_string($v)?strtr($v,$map):$v;};
   $values=$replace($seed['values']);$d['media']=array_values($map);$d['values']=[];foreach($values as $key=>$value)$d['values'][$key]=is_array($value)?cms_json($value):(string)$value;
   cms_history('settings',0,['demo_created'=>true,'live_values_changed'=>false]);
  }
  $d['active']=$action==='demo_start';$d['revision']=(int)($d['revision']??0)+1;cms_setting('corporate_demo',cms_json($d),$sid);
 });}catch(Throwable $e){foreach($GLOBALS['corporate_uploads'] as $path)if(is_file($path))unlink($path);throw $e;}
 audit('site.demo_mode',['site'=>$sid,'enabled'=>$action==='demo_start']);flash($action==='demo_start'?'Dolu demo açıldı. Değişiklikler yalnız demo kopyasında saklanır.':'Gerçek sitenize döndünüz. Demo düzenlemeleriniz ayrı saklanır.');cms_go('corporate');
}
function cp_clean(string $value): string {
 if(!preg_match('/<\/?(?:p|h[23]|strong|b|em|i|u|ul|ol|li|a|blockquote|br)(?:\s|>|\/)/i',$value))return $value;
 if(!class_exists('DOMDocument'))throw new DomainException('HTML düzenleme için sunucuda PHP DOM eklentisi etkin olmalıdır.');
 $doc=new DOMDocument();$old=libxml_use_internal_errors(true);
 try{$doc->loadHTML('<?xml encoding="UTF-8"><div>'.$value.'</div>',LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);$body=$doc->getElementsByTagName('body')->item(0);if(!$body)return '';return cp_clean_nodes($body);}
 finally{libxml_clear_errors();libxml_use_internal_errors($old);}
}
function cp_clean_nodes(DOMNode $parent): string {
 $out='';foreach($parent->childNodes as $node){
  if($node instanceof DOMText){$out.=esc($node->nodeValue);continue;}
  if(!($node instanceof DOMElement))continue;$tag=strtolower($node->tagName);
  if(in_array($tag,['script','style','iframe','object','embed','svg','math','form','input','button','textarea','template'],true))continue;
  $content=cp_clean_nodes($node);if(!in_array($tag,['p','h2','h3','strong','b','em','i','u','ul','ol','li','a','blockquote','br'],true)){$out.=$content;continue;}
  $attrs='';if($tag==='a'){$href=trim($node->getAttribute('href'));if(!cp_https($href)||$href===''){$out.=$content;continue;}$attrs=' href="'.esc($href).'" rel="noopener noreferrer"';}
  $out.='<'.$tag.$attrs.'>'.($tag==='br'?'':$content.'</'.$tag.'>');
 }return $out;
}
function cp_rich_html(string $value): string {
 return preg_match('/<\/?(?:p|h[23]|strong|b|em|i|u|ul|ol|li|a|blockquote|br)(?:\s|>|\/)/i',$value)?cp_clean($value):nl2br(esc($value));
}
function corporate_view(string $view): void {
 if(cms_platform()){corporate_view_content($view);return;}
 $pack=cms_asset_pack();$css=base64_decode($pack['corporate-editor.css']['data']??'',true);$js=base64_decode($pack['corporate-editor.js']['data']??'',true);$nonce=esc($GLOBALS['nonce']??'');
 echo '<style nonce="'.$nonce.'">'.$css.'</style><div class="cp-manage">';corporate_view_content($view);echo '</div><script nonce="'.$nonce.'">'.$js.'</script>';
}
