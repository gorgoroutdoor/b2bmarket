<?php
declare(strict_types=1);

function cp_definitions(): array {
 return [
  'slides'=>['Giriş görselleri',6,['title'=>'Başlık','text'=>'Tanıtım yazısı','button'=>'Buton yazısı']],
  'features'=>['Öne çıkan özellikler',6,['title'=>'Başlık','text'=>'Açıklama']],
  'team'=>['Ekibimiz',20,['title'=>'Ad soyad','subtitle'=>'Görev / unvan','text'=>'Kısa tanıtım']],
  'stats'=>['Firma rakamları',4,['title'=>'Gösterge adı','value'=>'Gerçek sayı','subtitle'=>'Birim / ek açıklama']],
  'pricing'=>['Fiyat / hizmet paketleri',12,['title'=>'Paket adı','value'=>'Fiyat metni','subtitle'=>'Dönem / birim','text'=>'Özellikler · her satıra bir madde','button'=>'Buton yazısı']],
  'faq'=>['Sık sorulan sorular',30,['title'=>'Soru','text'=>'Cevap']],
  'clients'=>['Referans logoları',30,['title'=>'Firma / marka adı']],
  'testimonials'=>['Müşteri yorumları',20,['title'=>'Müşterinin adı','subtitle'=>'Firma / görev','text'=>'Müşterinin kendi sözleri']],
  'blog'=>['Yazılar / haberler',60,['title'=>'Yazı başlığı','subtitle'=>'Kategori','text'=>'Kısa açıklama','body'=>'Yazının tamamı']],
 ];
}
function cp_data(int $sid): array {
 $v=json_decode(cp_setting('corporate_pro','{}',$sid),true,32,JSON_THROW_ON_ERROR);
 return $v+['revision'=>0,'template'=>'pro','about_image'=>'','mission'=>'','vision'=>'','history'=>'','video_url'=>'','video_title'=>'','social_instagram'=>'','social_facebook'=>'','social_linkedin'=>'','groups'=>[]];
}
function cp_credit(): string {
 return '<p class="cp-credit">Bu sitenin <a href="https://www.kobivira.com.tr">Ön Muhasebe Yazılımı</a>, <a href="https://kobivira.com.tr">Kobivira.com.tr</a> tarafından sağlanmaktadır.</p>';
}
function cp_https(string $value): bool {
 return $value===''||(filter_var($value,FILTER_VALIDATE_URL)&&strtolower((string)parse_url($value,PHP_URL_SCHEME))==='https'&&!parse_url($value,PHP_URL_USER)&&!parse_url($value,PHP_URL_PASS));
}
function cp_save(string $action): never {
 firm_manager();$site=corporate_scope(true);$sid=(int)$site['id'];$defs=cp_definitions();$group=cms_post('group',30);
 if($action!=='pro_settings'&&!isset($defs[$group]))throw new DomainException('Tema bölümü bulunamadı.');
 $GLOBALS['corporate_uploads']=[];
 try{cms_tx(function()use($sid,$group,$defs,$action){
  query('SELECT id FROM cms_sites WHERE id=? FOR UPDATE',[$sid]);cp_assert_context();$d=cp_data($sid);
  if((string)$d['revision']!==cms_post('revision',12))throw new DomainException('Tema başka bir işlemde değişti. Sayfayı yenileyin.');
  cms_history('settings',0,['corporate_pro'=>$d]);
  if($action==='pro_settings'){
   $d['template']=choice('template',['pro','classic']);
   foreach(['mission'=>4000,'vision'=>4000,'history'=>4000,'video_title'=>180,'video_url'=>1000,'social_instagram'=>1000,'social_facebook'=>1000,'social_linkedin'=>1000] as $key=>$max){$value=cms_post($key,$max);if(($key==='video_url'||str_starts_with($key,'social_'))&&!cp_https($value))throw new DomainException('Bağlantılar https:// ile başlamalıdır.');$d[$key]=in_array($key,['mission','vision','history'],true)?cp_clean($value):$value;}
   if(isset($_POST['remove_image']))$d['about_image']='';if(($file=corporate_file('theme_image',$sid))!==null)$d['about_image']=$file;
  }else{
   $id=cms_post('item_id',32);$items=$d['groups'][$group]??[];
   if($id!==''&&!isset($items[$id]))throw new DomainException('Kayıt bu firma sitesine ait değil.');
   if($action==='pro_delete'){
    if($id===''||!isset($_POST['confirm_delete']))throw new DomainException('Silmek için onay verin.');unset($items[$id]);
   }elseif($action==='pro_save'){
    if($id===''&&count($items)>=$defs[$group][1])throw new DomainException('Bu bölüm için kayıt sınırına ulaşıldı.');
    $item=$id?$items[$id]:['image'=>''];
    foreach($defs[$group][2] as $key=>$label)$item[$key]=$key==='title'?required_field('item_'.$key,180):(in_array($key,['text','body'])?cp_clean(cms_post('item_'.$key,12000)):cms_post('item_'.$key,180));
    if($group==='stats'&&!preg_match('/^\d{1,12}$/D',$item['value']))throw new DomainException('Gösterge için gerçek bir tam sayı girin.');
    $item['visible']=isset($_POST['visible']);$item['sort']=max(0,min(9999,(int)cms_post('sort',5)));
    if(in_array($group,['clients','testimonials'],true)){$item['consent']=isset($_POST['consent']);$item['verified']=isset($_POST['verified']);if($item['visible']&&empty($item['demo'])&&(!$item['consent']||!$item['verified']))throw new DomainException('Yayın için gerçek müşteri / referans doğrulaması ve yayın izni gerekir.');}
    if(isset($_POST['remove_image']))$item['image']='';if(($file=corporate_file('theme_image',$sid))!==null)$item['image']=$file;
    $id=$id?:bin2hex(random_bytes(12));$items[$id]=$item;
   }else throw new DomainException('Tema işlemi geçersiz.');
   $d['groups'][$group]=$items;
  }
  $d['revision']++;cp_store('corporate_pro',cms_json($d),$sid);
 });}catch(Throwable $e){foreach($GLOBALS['corporate_uploads'] as $path)if(is_file($path))unlink($path);throw $e;}
 audit('site.theme_saved',['site'=>$sid,'section'=>$group]);flash('Tema içeriği kaydedildi.');cms_go('corporate',['section'=>$action==='pro_settings'?'appearance':$group]);
}
function cp_toolbar(): string {
 $section=is_string($_GET['section']??null)?$_GET['section']:'profile';
 $groups=[
  'Firma'=>['profile'=>'Logo ve iletişim','appearance'=>'Hakkımızda ve tema'],
  'Ana sayfa'=>['slides'=>'Giriş görselleri','features'=>'Öne çıkanlar','stats'=>'Firma rakamları'],
  'Katalog'=>['catalog'=>'Ürün, hizmet ve projeler','pricing'=>'Hizmet paketleri'],
  'İçerikler'=>['team'=>'Ekibimiz','faq'=>'Sorular','blog'=>'Yazılar','clients'=>'Referanslar','testimonials'=>'Yorumlar'],
  'Mesajlar'=>['inbox'=>'Gelen mesajlar'],
 ];
 $active='Firma';foreach($groups as $name=>$items)if(isset($items[$section]))$active=$name;
 $html='<nav class="cp-editor-tabs" aria-label="Site düzenleme grupları">';
 foreach($groups as $name=>$items)$html.=cms_link('corporate',$name,['section'=>array_key_first($items)],'button '.($active===$name?'primary':'quiet'));
 $html.='</nav><nav class="cp-editor-subtabs" aria-label="'.$active.' bölümleri">';
 foreach($groups[$active] as $key=>$name)$html.=cms_link('corporate',$name,['section'=>$key],'button '.($key===$section?'primary':'quiet'));
 $html.='</nav><div class="cp-demo-tools">';
 $sid=(int)corporate_scope()['id'];$demo=cp_demo_active($sid);
 $html.='<div><strong>'.($demo?'Demo çalışma kopyası':'Firma web siteniz').'</strong><p>'.($demo?'Örnek içerikleri düzenliyorsunuz. Gerçek siteniz ve yayındaki bilgileriniz değişmez.':'Bölüm seçin, içeriği düzenleyin ve ön izlemede kontrol edin.').'</p></div>';
 ob_start();cms_form('corporate',$demo?'demo_stop':'demo_start');hidden('demo_revision',(string)cp_demo_revision($sid));cms_close($demo?'Gerçek siteme dön':'Dolu demoyu aç');$html.=ob_get_clean();
 return $html.'</div>';
}
function cp_editor(string $section): void {
 firm_manager();$s=corporate_scope();$sid=(int)$s['id'];$d=cp_data($sid);$defs=cp_definitions();
 if($section==='inbox'){
  panel('Web sitenizden gelen mesajlar','Ziyaretçilerinizin iletişim formundan gönderdiği mesajlar.');
  $items=json_decode(cp_setting('corporate_inbox','{}',$sid),true,32,JSON_THROW_ON_ERROR);
  foreach(array_reverse($items,true) as $id=>$item){echo '<details class="help-message"><summary>'.esc($item['name']).' · '.esc($item['subject']).' · '.esc($item['created_at']).'</summary><p>'.nl2br(esc($item['message'])).'</p><p>E-posta: '.esc($item['email']).'<br>Telefon: '.esc($item['phone']).'</p>';cp_form('corporate','pro_message_delete',['section'=>'inbox']);hidden('message_id',$id);cms_check_field('confirm_delete','Bu mesajı silmeyi onaylıyorum',false);cms_close('Mesajı sil');echo '</details>';}
  if(!$items)echo '<p>Henüz mesaj yok.</p>';echo '</section>';return;
 }
 if($section==='appearance'){
  panel('Tema ve kurumsal tanıtım','Firma bilgileri ve hakkımızda metni Logo / firma bilgileri bölümündedir.');cp_form('corporate','pro_settings',['section'=>'appearance'],true);hidden('revision',$d['revision']);
  select_field('template','Firma sitesinin görünümü',['pro'=>'Gelişmiş kurumsal tema','classic'=>'Önceki sade kurumsal görünüm'],$d['template']);
  foreach(['history'=>'Firma geçmişi','mission'=>'Misyonumuz','vision'=>'Vizyonumuz'] as $k=>$label)textarea($k,$label,$d[$k],'maxlength="4000"');
  if($d['about_image'])echo '<div class="wide">'.corporate_image($d['about_image'],$sid,'Hakkımızda görseli',true).'</div>';
  corporate_file_field('theme_image','Hakkımızda fotoğrafı');cms_check_field('remove_image','Mevcut fotoğrafı kaldır',false);
  input('video_title','Tanıtım videosu başlığı',$d['video_title'],'text','maxlength="180"');input('video_url','Tanıtım videosu bağlantısı · https://',$d['video_url'],'url','maxlength="1000"');
  foreach(['social_instagram'=>'Instagram','social_facebook'=>'Facebook','social_linkedin'=>'LinkedIn'] as $k=>$label)input($k,$label.' bağlantısı',$d[$k],'url','maxlength="1000"');
  cms_close('Tema ayarlarını kaydet');echo '</section>';return;
 }
 if(!isset($defs[$section]))throw new DomainException('Tema bölümü bulunamadı.');
 $id=is_string($_GET['item']??null)?$_GET['item']:'';$items=$d['groups'][$section]??[];
 if($id!==''||isset($_GET['new'])){
  if($id!==''&&!isset($items[$id]))throw new DomainException('Kayıt bulunamadı.');$item=$items[$id]??[];
  panel($defs[$section][0].($id?' · Düzenle':' · Yeni kayıt'));cp_form('corporate','pro_save',['section'=>$section]+($id?['item'=>$id]:['new'=>1]),true);hidden('group',$section);hidden('item_id',$id);hidden('revision',$d['revision']);
  foreach($defs[$section][2] as $key=>$label){if(in_array($key,['text','body']))textarea('item_'.$key,$label,$item[$key]??'','maxlength="12000"');else input('item_'.$key,$label,$item[$key]??'','text',($key==='title'?'required ':'').'maxlength="180"');}
  if(!in_array($section,['stats','faq','pricing'])){
   if(!empty($item['image']))echo '<div class="wide">'.corporate_image($item['image'],$sid,$item['title'],true).'</div>';
   corporate_file_field('theme_image','Fotoğraf / logo yükle');cms_check_field('remove_image','Mevcut görseli kaldır',false);
  }
  input('sort','Görünüm sırası',$item['sort']??100,'number','min="0" max="9999"');cms_check_field('visible','Sitede göster',$item['visible']??true);
  if(in_array($section,['clients','testimonials'])){cms_check_field('verified','Bu müşteri / referansın gerçekliğini doğruluyorum',!empty($item['verified']));cms_check_field('consent','Bu içerik / logo için yayın izni aldım',!empty($item['consent']));}
  if($section==='stats')echo '<p class="field-hint wide">Yalnız firmanızın doğrulanabilir gerçek sayılarını girin. Varsayılan kullanım veya müşteri sayısı eklenmez.</p>';
  cms_close('Kaydı sakla');echo '</section>';
  if($id){panel('Kaydı kaldır');cp_form('corporate','pro_delete',['section'=>$section]);hidden('group',$section);hidden('item_id',$id);hidden('revision',$d['revision']);cms_check_field('confirm_delete','Bu kaydı kaldırmayı onaylıyorum',false);cms_close('Kaydı kaldır');echo '</section>';}return;
 }
 echo cms_link('corporate','Yeni kayıt ekle',['section'=>$section,'new'=>1],'button primary').'<br><br>';panel($defs[$section][0]);table_start(['Başlık','Durum','Sıra','İşlem']);
 foreach($items as $id=>$item)echo '<tr><td>'.esc($item['title']).'</td><td>'.($item['visible']?'Görünür':'Gizli').'</td><td>'.(int)$item['sort'].'</td><td>'.cms_link('corporate','Düzenle',['section'=>$section,'item'=>$id]).'</td></tr>';table_end(count($items),4);echo '</section>';
}
function cp_items(array $theme,string $group): array {
 $items=array_filter($theme['groups'][$group]??[],fn($v)=>!empty($v['visible'])&&(!in_array($group,['clients','testimonials'])||(!empty($v['verified'])&&!empty($v['consent']))||(!empty($theme['demo'])&&!empty($v['demo']))));
 uasort($items,fn($a,$b)=>(($a['sort']??100)<=>($b['sort']??100)));return $items;
}
function cp_page_link(string $slug,bool $preview,int $sid,string $anchor=''): string {
 return esc(($preview?url('web_preview',['slug'=>$slug]+['site'=>$sid]):cms_site_url($slug)).($anchor!==''?'#'.$anchor:''));
}
function cp_logo(int $sid,string $brand,bool $preview): string {
 $url=cp_setting('logo_url','',$sid);if($url==='')return '<strong>'.esc($brand).'</strong>';
 if(str_starts_with($url,'?page=site_media&media='))$url=cp_preview_logo($url,$sid,$preview);
 return '<img src="'.esc($url).'" alt="'.esc($brand).'">';
}
function cp_preview_logo(string $url,int $sid,bool $preview): string {return $preview?$url.'&site='.$sid:$url;}
function cp_section(string $id,string $eyebrow,string $title,string $content): string {
 return '<section class="cp-section" id="'.$id.'"><div class="cp-container"><div class="cp-section-title"><span>'.esc($eyebrow).'</span><h2>'.esc($title).'</h2><i></i></div>'.$content.'</div></section>';
}
function cp_document(array $site,array $page,string $slug,bool $preview): string {
 $sid=(int)$site['id'];$d=corporate_data($sid);$t=cp_data($sid);$brand=cp_setting('company_name',$site['name'],$sid);$home=cp_page_link('ana-sayfa',$preview,$sid);$contact=cp_page_link('iletisim',$preview,$sid);
 $link=fn($anchor)=>cp_page_link('ana-sayfa',$preview,$sid,$anchor);$logo=cp_logo($sid,$brand,$preview);
 $email=cp_setting('contact_email','',$sid);$phone=cp_setting('phone','',$sid);$address=cp_setting('address','',$sid);
 $social='';foreach(['social_instagram'=>'Instagram','social_facebook'=>'Facebook','social_linkedin'=>'LinkedIn'] as $key=>$label)if($t[$key]!==''&&cp_https($t[$key]))$social.='<a href="'.esc($t[$key]).'" target="_blank" rel="noopener">'.$label.'</a>';
 $top='<div class="cp-top"><div class="cp-container"><span>'.esc($address).'</span><span>'.esc($phone).'</span><div>'.$social.'</div></div></div>';
 $nav='<a href="'.$home.'">Ana sayfa</a><a href="'.cp_page_link('hakkimizda',$preview,$sid).'">Hakkımızda</a><a href="'.cp_page_link('urunler',$preview,$sid).'">Ürün ve hizmetler</a>';
 if(array_filter($d['products'],fn($p)=>!empty($p['visible'])&&($p['kind']??'')==='project'))$nav.='<a href="'.$link('projects').'">Projeler</a>';
 if(cp_items($t,'team'))$nav.='<a href="'.$link('team').'">Ekibimiz</a>';
 if(cp_items($t,'blog'))$nav.='<a href="'.$link('blog').'">Yazılar</a>';
 $nav.='<a href="'.$contact.'">İletişim</a>';
 if(!empty($t['demo']))$top='<div class="cp-demo-banner">DEMO · Firma, kişiler, rakamlar ve yorumlar örnektir. Canlı siteniz değişmez.</div>'.$top;
 $header=$top.'<header class="cp-header"><div class="cp-container"><a class="cp-logo" href="'.$home.'">'.$logo.'</a><button class="cp-menu-button" aria-controls="cp-menu" aria-expanded="false" aria-label="Menüyü aç">☰</button><nav id="cp-menu">'.$nav.'</nav><a class="cp-button cp-header-cta" href="'.$contact.'">Teklif alın <span>↗</span></a></div></header>';
 $body='';
 if($slug==='ana-sayfa'){
  $slides=cp_items($t,'slides');if(!$slides)$slides=[['title'=>$d['headline']?:$brand,'text'=>$d['intro'],'button'=>'Bize ulaşın','image'=>$d['cover']]];
  $body.='<section class="cp-slider" aria-label="Firma tanıtımı">';$i=0;foreach($slides as $slide){$body.='<article class="cp-slide" '.($i++?'hidden':'').'>'.corporate_image($slide['image']??'',$sid,$slide['title']).'<div class="cp-slide-shade"></div><div class="cp-container"><div class="cp-slide-copy"><span>'.esc($brand).'</span><h1>'.esc($slide['title']).'</h1><p>'.cp_rich_html($slide['text']).'</p><a class="cp-button" href="'.$contact.'">'.esc($slide['button']?:'Bize ulaşın').' <span>→</span></a></div></div></article>';}
  if(count($slides)>1)$body.='<div class="cp-slider-controls"><button data-slide="-1" aria-label="Önceki görsel">←</button><span aria-live="polite">1 / '.count($slides).'</span><button data-slide="1" aria-label="Sonraki görsel">→</button></div>';$body.='</section>';
  $features='';foreach(cp_items($t,'features') as $i=>$f)$features.='<article class="cp-feature">'.(!empty($f['image'])?corporate_image($f['image'],$sid,$f['title']):'<span class="cp-feature-mark">◇</span>').'<h3>'.esc($f['title']).'</h3><p>'.cp_rich_html($f['text']).'</p><a href="'.$contact.'">Bilgi alın →</a></article>';
  if($features)$body.=cp_section('features','ÖNE ÇIKANLAR','İşinize değer katan çözümler','<div class="cp-grid cp-grid-3">'.$features.'</div>');
 }else $body.='<section class="cp-page-title"><div class="cp-container"><h1>'.esc($page['title']).'</h1><a href="'.$home.'">Ana sayfa</a><span> / '.esc($page['title']).'</span></div></section>';
 if(in_array($slug,['ana-sayfa','hakkimizda'])){
  $tabs='';foreach(['history'=>'Geçmişimiz','mission'=>'Misyonumuz','vision'=>'Vizyonumuz'] as $key=>$label)if($t[$key]!=='')$tabs.='<details><summary>'.$label.'</summary><p>'.cp_rich_html($t[$key]).'</p></details>';
  if($d['about']!==''||$tabs||$t['about_image']!=='')$body.='<section class="cp-section" id="about"><div class="cp-container cp-about">'.($t['about_image']!==''?'<div class="cp-about-image">'.corporate_image($t['about_image'],$sid,$brand).'</div>':'').'<div><div class="cp-section-title cp-left"><span>BİZİ TANIYIN</span><h2>'.esc($brand).'</h2><i></i></div><p class="cp-lead">'.cp_rich_html($d['about']).'</p><div class="cp-about-details">'.$tabs.'</div></div></div></section>';
 }
 if(in_array($slug,['ana-sayfa','urunler']))foreach(['service'=>['services','HİZMETLERİMİZ','Size nasıl yardımcı olabiliriz?'],'product'=>['products','ÜRÜNLERİMİZ','İhtiyacınıza uygun ürünler'],'project'=>['projects','ÇALIŞMALARIMIZ','Projeler ve galeri']] as $kind=>$labels){
  $cards='';$categories=[];$count=0;foreach($d['products'] as $p){if(empty($p['visible'])||($p['kind']??'product')!==$kind)continue;if($slug==='ana-sayfa'&&$count>=9)break;$count++;$category=$p['category']??'';if($category!=='')$categories[$category]=true;
   $cards.='<article class="cp-card" data-category="'.esc($category).'">'.corporate_image($p['image']??'',$sid,$p['name']).'<div><small>'.esc($category).'</small><h3>'.esc($p['name']).'</h3><p>'.cp_rich_html($p['description']).'</p><a href="'.$contact.'">Bilgi alın <span>→</span></a></div></article>';
  }
  if($cards){$filter='';if($kind==='project'&&$categories){$filter='<div class="cp-filters" aria-label="Proje kategorileri"><button type="button" data-filter="" aria-pressed="true">Tümü</button>';foreach($categories as $cat=>$ignored)$filter.='<button type="button" data-filter="'.esc($cat).'" aria-pressed="false">'.esc($cat).'</button>';$filter.='</div>';}$body.=cp_section($labels[0],$labels[1],$labels[2],$filter.'<div class="cp-grid cp-grid-3">'.$cards.'</div>');}
 }
 if($slug==='ana-sayfa'){
  $cards='';foreach(cp_items($t,'team') as $v)$cards.='<article class="cp-team">'.corporate_image($v['image'],$sid,$v['title']).'<div><h3>'.esc($v['title']).'</h3><span>'.esc($v['subtitle']).'</span><p>'.cp_rich_html($v['text']).'</p></div></article>';
  if($cards)$body.=cp_section('team','EKİBİMİZ','İşinin arkasında duran insanlar','<div class="cp-grid cp-grid-4">'.$cards.'</div>');
  $stats='';foreach(cp_items($t,'stats') as $v)$stats.='<div><strong>'.esc($v['value']).'</strong><span>'.esc($v['title']).'</span><small>'.esc($v['subtitle']).'</small></div>';
  if($stats)$body.='<section class="cp-stats"><div class="cp-container">'.$stats.'</div></section>';
  $prices='';foreach(cp_items($t,'pricing') as $v){$list='';foreach(explode("\n",$v['text']) as $line)if(trim($line)!=='')$list.='<li>✓ '.esc($line).'</li>';$prices.='<article class="cp-price"><h3>'.esc($v['title']).'</h3><strong>'.esc($v['value']).'</strong><span>'.esc($v['subtitle']).'</span><ul>'.$list.'</ul><a class="cp-button" href="'.$contact.'">'.esc($v['button']?:'Bilgi alın').'</a></article>';}
  if($prices)$body.=cp_section('pricing','PAKETLER','İhtiyacınıza uygun seçenekler','<div class="cp-grid cp-grid-3">'.$prices.'</div>');
  if($t['video_url']!==''&&cp_https($t['video_url']))$body.='<section class="cp-video"><div class="cp-container"><a href="'.esc($t['video_url']).'" target="_blank" rel="noopener" class="cp-play" aria-label="Tanıtım videosunu aç">▶</a><h2>'.esc($t['video_title']?:'Bizi yakından tanıyın').'</h2></div></section>';
  if(!empty($t['demo'])&&$t['video_url']==='')$body.='<section class="cp-video"><div class="cp-container"><h2>Üretim yolculuğumuzu keşfedin</h2><p>Demo video alanı · Kendi tanıtım videonuzu buradan sunabilirsiniz.</p></div></section>';
  $faq='';foreach(cp_items($t,'faq') as $v)$faq.='<details><summary>'.esc($v['title']).'</summary><p>'.cp_rich_html($v['text']).'</p></details>';
  if($faq==='')foreach($d['faq'] as $v)$faq.='<details><summary>'.esc($v['question']).'</summary><p>'.nl2br(esc($v['answer'])).'</p></details>';
  if($faq)$body.=cp_section('faq','MERAK EDİLENLER','Sık sorulan sorular','<div class="cp-faq">'.$faq.'</div>');
  $clients='';foreach(cp_items($t,'clients') as $v)$clients.='<div class="cp-client">'.corporate_image($v['image'],$sid,$v['title']).'<span>'.esc($v['title']).'</span></div>';
  if($clients)$body.=cp_section('clients','BİRLİKTE ÇALIŞTIKLARIMIZ','Referanslarımız','<div class="cp-clients">'.$clients.'</div>');
  $quotes='';foreach(cp_items($t,'testimonials') as $v)$quotes.='<figure class="cp-quote"><span aria-hidden="true">“</span><blockquote>'.cp_rich_html($v['text']).'</blockquote><figcaption>'.corporate_image($v['image'],$sid,$v['title']).'<div><strong>'.esc($v['title']).'</strong><small>'.esc($v['subtitle']).'</small></div></figcaption></figure>';
  if($quotes)$body.=cp_section('testimonials','MÜŞTERİ DENEYİMİ','Birlikte çalıştıklarımızın sözleri','<div class="cp-grid cp-grid-3">'.$quotes.'</div>');
  $blog='';foreach(cp_items($t,'blog') as $v)$blog.='<article class="cp-card">'.corporate_image($v['image'],$sid,$v['title']).'<div><small>'.esc($v['subtitle']).'</small><h3>'.esc($v['title']).'</h3><p>'.cp_rich_html($v['text']).'</p>'.($v['body']!==''?'<details class="cp-readmore"><summary>Devamını oku →</summary><p>'.cp_rich_html($v['body']).'</p></details>':'').'</div></article>';
  if($blog)$body.=cp_section('blog','BİZDEN HABERLER','Yazılar ve duyurular','<div class="cp-grid cp-grid-3">'.$blog.'</div>');
 }
 if(in_array($slug,['ana-sayfa','iletisim'])){
  $contactcards='';if($address!=='')$contactcards.='<div><span>Adresimiz</span><p>'.nl2br(esc($address)).'</p></div>';
  if($phone!=='')$contactcards.='<div><span>Bizi arayın</span><a href="tel:'.esc(preg_replace('/[^+0-9]/','',$phone)).'">'.esc($phone).'</a></div>';
  if(filter_var($email,FILTER_VALIDATE_EMAIL))$contactcards.='<div><span>Bize yazın</span><a href="mailto:'.esc($email).'">'.esc($email).'</a></div>';
  $form='<form class="cp-contact-form" method="post" action="'.cp_page_link('iletisim',false,$sid).'">'.csrf_field().'<input type="hidden" name="action" value="cp_contact"><label>Adınız soyadınız<input name="contact_name" required maxlength="100" autocomplete="name"></label><label>E-posta<input name="contact_email" type="email" required maxlength="190" autocomplete="email"></label><label>Telefon<input name="contact_phone" maxlength="50" autocomplete="tel"></label><label>Konu<input name="contact_subject" required maxlength="180"></label><label class="cp-form-wide">Mesajınız<textarea name="contact_message" required maxlength="5000" rows="5"></textarea></label><label class="cp-honeypot" aria-hidden="true">Web adresi<input name="contact_website" tabindex="-1" autocomplete="off"></label><label class="cp-form-wide cp-consent"><input type="checkbox" name="contact_consent" value="1" required> Mesajımın yanıtlanması amacıyla iletişim bilgilerimin kullanılmasını kabul ediyorum.</label><div><button class="cp-button" type="submit">Mesajı gönder →</button></div></form>';
  if($preview)$form='<fieldset class="cp-preview-form" disabled>'.$form.'</fieldset><p class="cp-contact-note">Ön izlemede mesaj gönderimi kapalıdır.</p>';
  if(!$preview&&!empty($_SESSION['cp_sent_'.$sid])){unset($_SESSION['cp_sent_'.$sid]);$form='<p class="cp-success" role="status">Mesajınız firmaya iletildi.</p>'.$form;}
  $body.=cp_section('contact','İLETİŞİM','Birlikte çalışalım','<div class="cp-contact">'.$contactcards.'</div>'.$form);
 }elseif(!in_array($slug,['ana-sayfa','hakkimizda','urunler']))$body.='<section class="cp-section"><div class="cp-container cp-custom">'.cms_fields_html($page).'</div></section>';
 $footer='<footer class="cp-footer"><div class="cp-container cp-footer-grid"><div><a class="cp-logo" href="'.$home.'">'.$logo.'</a><p>'.nl2br(esc(cp_setting('footer_text','',$sid))).'</p><div class="cp-social">'.$social.'</div></div><div><h3>Kurumsal</h3>'.$nav.'</div><div><h3>İletişim</h3><p>'.nl2br(esc($address)).'</p><p>'.esc($phone).'</p><a href="mailto:'.esc($email).'">'.esc($email).'</a></div></div><div class="cp-container cp-bottom"><span>© '.date('Y').' '.esc($brand).'</span>'.cp_credit().'<a href="#top">Yukarı ↑</a></div></footer>';
 $asset=fn($file)=>esc('/?page=site_asset&asset='.$file.'&v='.APP_VERSION);$title=$slug==='ana-sayfa'?cp_setting('site_title',$brand,$sid):$page['title'];
 return '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.esc($title).' | '.esc($brand).'</title><meta name="description" content="'.esc(cp_setting('meta_description','',$sid)).'"><meta name="robots" content="'.esc(cp_setting('robots','noindex,nofollow',$sid)).'"><link rel="stylesheet" href="'.$asset('corporate-pro.css').'"><script defer src="'.$asset('corporate-pro.js').'"></script></head><body id="top" class="cp-site cp-accent-'.esc(in_array($d['accent'],['teal','blue','copper'])?$d['accent']:'teal').'"><a class="cp-skip" href="#content">İçeriğe geç</a>'.($preview?'<div class="cp-preview">Ön izleme — Bu sayfa herkese açık değildir.</div>':'').$header.'<main id="content">'.$body.'</main>'.$footer.'</body></html>';
}
function cp_contact(array $site,bool $preview): never {
 $host=strtolower(preg_replace('/:\d+$/','',$_SERVER['HTTP_HOST']??''));
 if($preview||!(int)$site['company_id']||$host==='app.kobivira.com.tr'||!corporate_data((int)$site['id'])['enabled']||cp_data((int)$site['id'])['template']!=='pro')throw new DomainException('Bu sayfadan mesaj gönderilemez.');
 check_csrf();$sid=(int)$site['id'];throttle('site_contact_'.$sid,5);
 if(cms_post('contact_website',500)!=='')throw new DomainException('Mesaj gönderilemedi.');
 $email=required_field('contact_email',190);if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new DomainException('Geçerli e-posta yazın.');
 if(!isset($_POST['contact_consent']))throw new DomainException('İletişim iznini onaylayın.');
 $message=['name'=>required_field('contact_name',100),'email'=>$email,'phone'=>cms_post('contact_phone',50),'subject'=>required_field('contact_subject',180),'message'=>required_field('contact_message',5000),'created_at'=>gmdate('Y-m-d H:i:s').' UTC'];
 transaction(function()use($sid,$site,$message){$fresh=query("SELECT * FROM cms_sites WHERE id=? AND company_id=? FOR UPDATE",[$sid,$site['company_id']])->fetch();if(!$fresh||$fresh['status']!=='published'||!$fresh['verified_at']||$fresh['domain']!==strtolower(preg_replace('/:\d+$/','',$_SERVER['HTTP_HOST']??''))||!cms_entitled((int)$fresh['company_id']))throw new DomainException('Firma şu anda mesaj alamıyor.');$items=json_decode(cp_setting('corporate_inbox','{}',$sid),true,32,JSON_THROW_ON_ERROR);if(count($items)>=200)throw new DomainException('Firma şu anda yeni mesaj alamıyor. Telefon veya e-posta ile ulaşabilirsiniz.');$items[bin2hex(random_bytes(12))]=$message;cp_store('corporate_inbox',cms_json($items),$sid);});
 $_SESSION['cp_sent_'.$sid]=true;header('Location: '.cms_site_url('iletisim'),true,303);exit;
}
function cp_message_delete(): never {
 firm_manager();$site=corporate_scope(true);$sid=(int)$site['id'];$id=cms_post('message_id',32);
 if(!isset($_POST['confirm_delete']))throw new DomainException('Silme onayı gerekir.');
 cms_tx(function()use($sid,$id){query('SELECT id FROM cms_sites WHERE id=? FOR UPDATE',[$sid]);cp_assert_context();$items=json_decode(cp_setting('corporate_inbox','{}',$sid),true,32,JSON_THROW_ON_ERROR);if(!isset($items[$id]))throw new DomainException('Mesaj bulunamadı.');unset($items[$id]);cp_store('corporate_inbox',cms_json($items),$sid);});
 audit('site.message_deleted',['site'=>$sid]);flash('Mesaj silindi.');cms_go('corporate',['section'=>'inbox']);
}
