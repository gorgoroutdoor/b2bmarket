# Kobivira 3.6.37

3.6.36 üzerine imzalı tam güncelleme.

Mobil footer’daki kategori grupları arasındaki boşluklar, başlık altları, bağlantı satırları, sosyal medya ve ödeme bölümü çevresindeki aralıklar daraltıldı. İki sütunlu, sürekli açık yapı ve mevcut yazı boyutları korundu.

Tarayıcıda mobil görünüm ve yatay taşma kontrol edildi. PHP kodu, yönetim işlemleri ve veritabanı migration dosyaları değişmedi. Canlı siteye yükleme yapılmadı.

Güncelleme sonrası mobil tarayıcıda sayfayı yeniden yükleyin. Gerekirse site önbelleğini temizleyin.
