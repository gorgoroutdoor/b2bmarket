<?php
declare(strict_types=1);
final class Updater {
    public function __construct(private PDO $db) {}
    public function unpack(string $path): array {
        if(!is_file($path)||filesize($path)>16777216) throw new DomainException('Paket en fazla 16 MiB olmalıdır.');
        $zip=new ZipArchive(); if($zip->open($path)!==true) throw new DomainException('ZIP açılamadı.');
        $stage=null;
        try {
            if($zip->numFiles>400) throw new DomainException('Paket çok fazla dosya içeriyor.');
            $seen=[]; $size=0;
            for($i=0;$i<$zip->numFiles;$i++) {
                $s=$zip->statIndex($i); $n=$s['name'];
                if(isset($seen[$n])||!preg_match('#^(manifest\.json|manifest\.sig|payload/[A-Za-z0-9_/-]+\.(php|css|json|md))$#D',$n)||str_contains($n,'..')||str_contains($n,'//')) throw new DomainException('Yasak veya tekrarlı ZIP yolu.');
                $seen[$n]=true; $size+=$s['size'];
                if($size>33554432||$s['size']>8388608) throw new DomainException('Açılmış paket boyutu sınırı aşıldı.');
                $opsys=0; $attr=0; $zip->getExternalAttributesIndex($i,$opsys,$attr);
                if(($attr>>16 & 0170000)===0120000) throw new DomainException('Sembolik bağlantı kabul edilmez.');
            }
            $raw=$zip->getFromName('manifest.json'); $signature=$zip->getFromName('manifest.sig');
            if($raw===false||$signature===false||strlen($raw)>131072) throw new DomainException('Paket bildirimi eksik.');
            $sig=base64_decode(trim($signature),true); $pub=hex2bin(trim((string)file_get_contents(APP_ROOT . '/config/update-public.key')));
            if($sig===false||strlen($sig)!==SODIUM_CRYPTO_SIGN_BYTES||$pub===false||strlen($pub)!==SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES||!sodium_crypto_sign_verify_detached($sig,$raw,$pub)) throw new DomainException('Güncelleme imzası doğrulanamadı.');
            $m=json_decode($raw,true,32,JSON_THROW_ON_ERROR);
            $v=$m['version']??'';
            if(($m['product']??'')!=='kobi-finans'||($m['format']??0)!==1||!is_string($v)||!preg_match('/^\d+\.\d+\.\d+$/D',$v)||version_compare($v,APP_VERSION,'<=')||($m['from_version']??'')!==APP_VERSION) throw new DomainException('Paket bu kurulu sürümle uyumlu değil.');
            if(!is_int($m['min_php']??null)||PHP_VERSION_ID<$m['min_php']) throw new DomainException('PHP sürümü yetersiz.');
            if(!is_array($m['files']??null)||!$m['files']) throw new DomainException('Paket dosya listesi yok.');
            foreach(['app.php','Core.php','Migrator.php','Backup.php','Updater.php','Installer.php','Controllers.php','Views.php','style.css','migrations/001_core.php'] as $required) if(!isset($m['files'][$required])) throw new DomainException('Tam sürüm paketi eksik: ' . $required);
            if(count($seen)!==count($m['files'])+2) throw new DomainException('Listelenmemiş paket dosyası var.');
            $target=APP_ROOT . '/releases/' . $v;
            if(file_exists($target)) throw new DomainException('Bu sürüm klasörü zaten var. Yeni bir sürüm numarası kullanın.');
            $stage=APP_ROOT . '/storage/staging/' . bin2hex(random_bytes(12));
            if(!mkdir($stage,0700)) throw new RuntimeException('Geçici klasör oluşturulamadı.');
            foreach($m['files'] as $file=>$hash) {
                if(!is_string($file)||!is_string($hash)||!preg_match('/^[a-f0-9]{64}$/D',$hash)||!isset($seen['payload/' . $file])) throw new DomainException('Dosya bildirimi geçersiz.');
                $bytes=$zip->getFromName('payload/' . $file);
                if($bytes===false||!hash_equals($hash,hash('sha256',$bytes))) throw new DomainException('Dosya özeti uyuşmuyor: ' . $file);
                if(str_ends_with($file,'.php')) token_get_all($bytes,TOKEN_PARSE);
                $dest=$stage . '/' . $file;
                if(!is_dir(dirname($dest))&&!mkdir(dirname($dest),0700,true)) throw new RuntimeException('Dosya klasörü oluşturulamadı.');
                atomic_write($dest,$bytes);
            }
            foreach($this->db->query('SELECT id,checksum,status FROM schema_migrations') as $migration) {
                $f=$stage . '/migrations/' . $migration['id'];
                if($migration['status']!=='applied'||!is_file($f)||!hash_equals($migration['checksum'],hash_file('sha256',$f))) throw new DomainException('Migration geçmişi eksik, değiştirilmiş veya tamamlanmamış.');
            }
            return ['manifest'=>$m,'stage'=>$stage,'target'=>$target];
        } catch(Throwable $e) { if($stage!==null) self::remove_tree($stage); throw $e; }
        finally { $zip->close(); }
    }
    public function install(string $path,int $actor): void {
        if(is_file(APP_ROOT . '/storage/maintenance.json')) throw new DomainException('Önce yarım kalan güncellemeyi yedekten geri alın.');
        $p=$this->unpack($path); $m=$p['manifest']; $backup=null; $state=null; $id=null;
        try {
            // request.lock exclusive tutuluyor: uygulama üzerinden eşzamanlı yazılamaz.
            atomic_write(APP_ROOT . '/storage/maintenance.json',json_encode(['phase'=>'backup','previous'=>APP_VERSION,'version'=>$m['version']],JSON_THROW_ON_ERROR));
            $backup=(new Backup($this->db))->create();
            $state=['phase'=>'migrating','previous'=>APP_VERSION,'version'=>$m['version'],'backup'=>$backup,'actor'=>$actor];
            atomic_write(APP_ROOT . '/storage/maintenance.json',json_encode($state,JSON_THROW_ON_ERROR));
            $q=$this->db->prepare("INSERT INTO system_updates(version,previous_version,status,backup_file,actor_id,created_at) VALUES (?,?,'running',?,?,UTC_TIMESTAMP())");
            $q->execute([$m['version'],APP_VERSION,$backup['file'],$actor]); $id=(int)$this->db->lastInsertId();
            if(!rename($p['stage'],$p['target'])) throw new RuntimeException('Yeni sürüm klasörü taşınamadı.');
            (new Migrator($this->db))->run($p['target'] . '/migrations');
            sync_release_catalog($this->db,$p['target'].'/release_history.json');
            $q=$this->db->prepare("UPDATE system_updates SET status='applied',completed_at=UTC_TIMESTAMP() WHERE id=?"); $q->execute([$id]);
            atomic_write(APP_ROOT . '/storage/current.json',json_encode(['version'=>$m['version']],JSON_THROW_ON_ERROR));
            if(!unlink(APP_ROOT . '/storage/maintenance.json')) throw new RuntimeException('Bakım kaydı kaldırılamadı.');
            retention3649_queue();
        } catch(Throwable $e) {
            if($state!==null) {
                $state['phase']='failed'; $state['error']='Güncelleme tamamlanamadı. Hata günlüğünü kontrol edin ve yedekten geri alın.';
                atomic_write(APP_ROOT . '/storage/maintenance.json',json_encode($state,JSON_THROW_ON_ERROR));
                try { if($id) { $q=$this->db->prepare("UPDATE system_updates SET status='failed',error=? WHERE id=?"); $q->execute([mb_substr($e->getMessage(),0,2000),$id]); } } catch(Throwable $ignored) { error_log((string)$ignored); }
            } else { @unlink(APP_ROOT . '/storage/maintenance.json'); }
            error_log((string)$e); throw new DomainException($state===null?'Yedek alınamadı; güncelleme başlamadı.':'Güncelleme durdu. Bakım modu açık; aşağıdaki yedekten geri dönün.');
        } finally { if(is_dir($p['stage'])) self::remove_tree($p['stage']); }
    }
    public function recover(int $actor): void {
        $path=APP_ROOT . '/storage/maintenance.json';
        if(!is_file($path)) throw new DomainException('Kurtarılacak güncelleme yok.');
        $s=json_decode((string)file_get_contents($path),true,32,JSON_THROW_ON_ERROR);
        if(empty($s['backup'])) throw new DomainException('Yedek oluşturma yarım kalmış. CLI kurtarma rehberine bakın.');
        $previous=$s['previous']??'';
        if(!preg_match('/^\d+\.\d+\.\d+$/D',$previous)||!is_file(APP_ROOT . '/releases/' . $previous . '/app.php')) throw new RuntimeException('Önceki sürüm bulunamadı.');
        (new Backup($this->db))->restore($s['backup']);
        atomic_write(APP_ROOT . '/storage/current.json',json_encode(['version'=>$previous],JSON_THROW_ON_ERROR));
        $q=$this->db->prepare("INSERT INTO system_updates(version,previous_version,status,backup_file,actor_id,created_at,completed_at) VALUES (?,?,'restored',?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())");
        $q->execute([$s['version'],$previous,$s['backup']['file'],$actor]);
        // Başarısız sürüm klasörü korunur; yeniden denemede yeni patch numarası kullanılır.
        if(!unlink($path)) throw new RuntimeException('Bakım modu kaldırılamadı.');
    }
    public static function remove_tree(string $dir): void {
        if(!is_dir($dir)) return;
        $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
        foreach($it as $f) { if($f->isDir()&&!$f->isLink()) rmdir($f->getPathname()); else unlink($f->getPathname()); }
        rmdir($dir);
    }
}
