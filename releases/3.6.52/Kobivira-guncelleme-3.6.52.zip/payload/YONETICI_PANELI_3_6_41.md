# Kobivira 3.6.41 — Yönetici paneli düzeni

3.6.40 üzerine mevcut yönetimdeki **Sistem → Sürüm güncellemeleri** alanından ZIP yüklenir. Kurulumdan sonra yönetim ana sayfasını yenileyin.

## Menü yapısı

1. **Genel Bakış:** Yönetim özeti, bekleyen işlemler, favoriler.
2. **Firmalar:** Firma listesi, yeni firma, doğrulama talepleri, firma web siteleri.
3. **Paketler ve Ödemeler:** Paket fiyatları, paket özellikleri, ek modüller, ödeme kayıtları, bekleyen havaleler, firma kontörleri, kontör paketleri ve talepleri.
4. **Site ve İçerikler:** Ana sayfa, özellik sayfaları, hesaplama araçları, diğer bilgi sayfaları, blog, kullanım kütüphanesi, görseller, site menüleri ve footer, site ve SEO ayarları, hukuki metinler, içerik geçmişi.
5. **Pazarlama:** Kampanyalar, tanıtım pencereleri ve başvurular, veri taşıma tanıtımı, tavsiye ve referanslar, müşteri yorumları.
6. **Destek ve İletişim:** Destek talepleri, canlı destek sırası, bildirimler, e-posta ve SMS gönderimleri.
7. **Entegrasyonlar:** PayTR, e-Belge sağlayıcı ayarları, yönetimde e-Belge doğrulama alanı, diğer servisler.
8. **Sistem:** Genel ayarlar, yedekleme, güncellemeler, işlem geçmişi, yönetici menü düzeni.

## Kullanım

- Üstteki **Yönetimde ara** alanına örneğin “kontör”, “footer” veya “PayTR” yazın. Sonuçlar ilgili yönetim bölümünü doğrudan açar.
- Her yönetim sayfasının üstünde konum yolu ve **Favoriye ekle** bulunur. Favoriler ana sayfada da gösterilir.
- **Sistem → Yönetici menü düzeni** veya üstteki **Menüyü düzenle** bağlantısı kategori adı, ikon ve sıralamayı değiştirir. Bir bölümün kategori seçimini değiştirerek başka kategoriye taşıyabilirsiniz. Yeni kategori eklenebilir; yalnız boş kategori silinebilir.
- Düzen ve favoriler giriş yapan platform yöneticisine özel kaydedilir. Varsayılan menüye dön düğmesi yalnız bu tercihleri sıfırlar. Bölümleri taşımak yetki vermez veya firma paket özelliklerini değiştirmez.
- Ana sayfada bekleyen firma doğrulamaları, havale bildirimleri, yeni destek mesajları ve canlı destek sırası sayıları ilgili bölümlere bağlanır.
- Site içerikleri tek uzun sekme listesi yerine ayrı bağlantılardan açılır. Özellik sayfaları ve araçlar yalnız kendi içeriklerini listeler. Blog ve kütüphane ayrı türlerle açılır; yeni kayıt formu doğru içerik türünü seçer. Listeler sayfa başına en fazla 50 kayıt gösterir.
- Paket fiyatları ve özellik seçimleri ayrı ekranlardadır. Fiyat kaydında mevcut özellik seçimi korunur. Özellik değişikliği yönetici şifresi ve mevcut kayıt sürümü doğrulamasıyla yapılır.
- Firma ayrıntısında üyelik, doğrulama, kontör ve güvenlik işlemleri seçilen firma bağlamında devam eder. PayTR ayarları ayrı açılır.

Firma panelinin menü yapısı, ücretli paket yetkileri, fiyatlar, firma kayıtları, ödeme ve belge işleyişi bu güncellemeyle değiştirilmez. Yeni veritabanı göçü yoktur; tercihler mevcut settings tablosunda yönetici kimliğiyle saklanır. Güncelleme canlı ödeme veya e-Belge gönderimi yapmaz.

## Doğrulama

İmzalı 3.6.40 → 3.6.41 güncellemesi izole veritabanına uygulanarak denetlendi. PHP sözdizimi, önceki veri ve göçlerin korunması, yeni yönetim bağlantıları, kategori taşıma ve sıralama, arama, favoriler, eşzamanlı değişiklik koruması, CSRF ve firma hesabının erişim reddi kontrol edildi. Önceki araç hesaplama ve menü etkileşim kontrolleri de çalıştırıldı. Sayısal sonuçlar Admin3641TestResults.json dosyasındadır.

Yerel ön izleme bu oturumdaki bulut tarayıcısından açılamadığı için masaüstü ve mobil görsel tarayıcı kontrolü tamamlanamadı. HTTP ve DOM kontrolleri görsel tarayıcı testi yerine sunulmaz.
