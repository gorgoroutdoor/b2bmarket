<?php
declare(strict_types=1);

function visual3638_defaults():array {
 static $data;return $data??=json_decode(file_get_contents(__DIR__.'/FeatureVisual3638.json'),true,32,JSON_THROW_ON_ERROR);
}
function visual3638_data(string $slug):?array {
 $base=visual3638_defaults()[$slug]??null;if(!$base)return null;
 $saved=json_decode(cms_s('visual3638_'.$slug,'',1),true);
 if(is_array($saved))foreach(visual3638_flat($base) as $key=>$value){if(isset($saved[$key])&&is_string($saved[$key]))$base=visual3638_assign($base,$key,$saved[$key]);}
 return $base;
}
function visual3638_flat(array $data):array {
 $out=['title'=>$data['title'],'lead'=>$data['lead']];
 foreach($data['headers'] as $i=>$v)$out['headers.'.$i]=$v;
 foreach($data['rows'] as $i=>$row)foreach($row as $j=>$v)$out['rows.'.$i.'.'.$j]=$v;
 foreach($data['cards'] as $i=>$card){$out['cards.'.$i.'.title']=$card['title'];$out['cards.'.$i.'.caption']=$card['caption'];foreach($card['rows'] as $j=>$row)foreach($row as $k=>$v)$out['cards.'.$i.'.rows.'.$j.'.'.$k]=$v;}
 return $out;
}
function visual3638_assign(array $data,string $path,string $value):array {
 $parts=explode('.',$path);$ref=&$data;foreach($parts as $p)$ref=&$ref[$p];$ref=$value;return $data;
}
function visual3638_render(string $slug):string {
 $d=visual3638_data($slug);if(!$d)return '';
 $kind=product3633_item($slug)['visual']??'satis';
 $out='<figure class="kv38-visual" data-feature-visual="'.esc($slug).'" aria-label="'.esc($d['title'].' · örnek verilerle temsili görünüm').'"><div class="kv38-layout"><div class="kv38-main kv38-card"><header class="kv38-heading"><span class="kv38-symbol" aria-hidden="true">'.product3633_icon($kind).'</span><div><strong>'.esc($d['title']).'</strong><p>'.esc($d['lead']).'</p></div></header><div class="kv38-table-wrap"><table class="kv38-table"><caption class="sr-only">'.esc($d['title']).' örnek kayıtları</caption><thead><tr>';
 foreach($d['headers'] as $h)$out.='<th scope="col">'.esc($h).'</th>';$out.='</tr></thead><tbody>';
 foreach($d['rows'] as $row){$out.='<tr>';foreach($row as $i=>$value)$out.='<'.($i===0?'th scope="row"':'td').'>'.esc($value).'</'.($i===0?'th':'td').'>';$out.='</tr>';}$out.='</tbody></table></div></div><div class="kv38-side">';
 foreach($d['cards'] as $i=>$card){$out.='<section class="kv38-card kv38-summary"><strong class="kv38-card-title">'.esc($card['title']).'</strong><p class="kv38-caption">'.esc($card['caption']).'</p><dl>';foreach($card['rows'] as [$label,$value])$out.='<div><dt>'.esc($label).'</dt><dd>'.esc($value).'</dd></div>';$out.='</dl></section>';}
 return $out.'</div></div><figcaption>Örnek verilerle temsili görünüm</figcaption></figure>';
}
function visual3638_output(string $slug,string $title):string {
 if(cms_s('visual3638_mode_'.$slug,'code',1)==='image'){$image=product3633_uploaded($slug,$title);if($image!=='')return $image;}
 return visual3638_render($slug);
}
function visual3638_editor(array $row):void {
 $slug=$row['slug']??'';$d=visual3638_data($slug);if(!$d)return;
 select_field('visual3638_mode','Tanıtım alanı',['code'=>'Kodlu tasarım · resim yüklemek gerekmez','image'=>'Yüklediğim görseli kullan'],cms_s('visual3638_mode_'.$slug,'code',1));
 echo '<p class="field-hint wide">Bu alan temsili örnek veriler gösterir. Firma kayıtlarını değiştirmez. Boş bıraktığınız metinler boş görünür.</p><details class="wide kv38-editor"><summary>Tanıtım alanındaki metinleri ve örnek kayıtları düzenle</summary><div class="form-grid">';
 $flat=visual3638_flat($d);$labels=['title'=>'Görsel başlığı','lead'=>'Kısa açıklama'];
 foreach($flat as $key=>$value){$parts=explode('.',$key);$label=$labels[$key]??'';
  if($parts[0]==='headers')$label='Tablo · '.((int)$parts[1]+1).'. sütun başlığı';
  elseif($parts[0]==='rows')$label='Tablo · '.((int)$parts[1]+1).'. kayıt · '.$d['headers'][(int)$parts[2]];
  elseif($parts[0]==='cards'){$label=((int)$parts[1]+1).'. özet kartı · ';$label.=count($parts)===3?($parts[2]==='title'?'başlık':'alt başlık'):((int)$parts[3]+1).'. satır · '.($parts[4]==='0'?'açıklama':'değer');}
  input('visual3638_text['.str_replace('.','_',$key).']',$label,$value,'text','maxlength="140"');
 }
 echo '</div></details><label class="wide"><input type="checkbox" name="visual3638_reset" value="1"> Bu sayfanın örnek metinlerini varsayılana döndür</label>';
}
function visual3638_save(array $row):void {
 if(!cms_platform()||cms_sid()!==1||!isset($_POST['visual3638_mode']))return;
 $slug=$row['slug']??'';$base=visual3638_defaults()[$slug]??null;if(!$base)return;
 $mode=$_POST['visual3638_mode'];if(!is_string($mode)||!in_array($mode,['code','image'],true))throw new DomainException('Geçerli bir tanıtım alanı seçin.');
 $posted=$_POST['visual3638_text']??null;if(!is_array($posted))throw new DomainException('Tanıtım alanı metinleri eksik.');$saved=[];
 foreach(visual3638_flat($base) as $key=>$value){$text=$posted[str_replace('.','_',$key)]??null;if(!is_string($text)||!mb_check_encoding($text,'UTF-8')||mb_strlen($text)>140||preg_match('/[\x00-\x1f\x7f]/u',$text))throw new DomainException('Tanıtım alanlarında en fazla 140 karakterlik düz metin kullanın.');$saved[$key]=trim($text);}
 $key='visual3638_'.$slug;$modeKey='visual3638_mode_'.$slug;
 cms_history('settings',0,[$key=>cms_s($key,'',1),$modeKey=>cms_s($modeKey,'code',1)]);
 cms_setting($key,($_POST['visual3638_reset']??'')==='1'?'':json_encode($saved,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),1);
 cms_setting($modeKey,$mode,1);
}
