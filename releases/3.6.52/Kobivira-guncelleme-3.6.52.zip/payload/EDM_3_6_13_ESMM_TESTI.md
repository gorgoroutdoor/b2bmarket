# Kobivira 3.6.13 — EDM e-SMM test alanı

3.6.12 üzerinden imzalı güncellemedir. Mevcut firma, belge, kontör, abonelik ve yedek kayıtlarını korur. Mevcut 36 migrasyon değişmez; 037 yalnız ayrı e-SMM test tablosunu ekler. Tasarım/CSS değişmez.

## Panelden test

1. Yönetim → EDM test alanını açın, e-SMM test alanını aç bağlantısını seçin.
2. Mevcut EDM test hesabına bağlı firmayı seçip e-SMM testini aç düğmesine basın.
3. e-SMM bağlantısını kontrol et düğmesiyle oturum ve test kontör bakiyesini sorgulayın.
4. Örnek e-SMM hazırla: KSM + yıl + dokuz haneli sıra ve yeni UUID ile yalnız yerel sentetik XML oluşturur. Hazır örnek sadece 3230512384 test hesabı içindir. Brüt 1.000 TL, stopaj 200 TL, KDV 200 TL ve net tahsilat 1.000 TL'dir; ticari işlem değildir.
5. Açılan makbuzda test gönderim onayını işaretleyin, Test makbuzunu EDM’ye gönder düğmesine bir kez basın.
6. PACKAGE - PROCESSING veya SEND - PROCESSING nihai başarı değildir. En az 30 saniye sonra Makbuz durumunu sorgula ile kontrol edin.
7. EDM’den makbuz PDF indir / XML indir ile gerçek servis içeriklerini indirin. Sonucun SEND - SUCCEED olmasını doğrulayın. GİB rapor durumu ayrıca takip edilmelidir.

XML yükleme ESMM / SATIS ve TRY senaryosuyla sınırlıdır. Diğer vergi senaryoları bu sürümde doğrulanmış sayılmaz. Servis şema ve belge kurallarını ayrıca uygular. e-SMM için e-Fatura ticari kabul/ret işlemi sunulmaz.

## Güvenilirlik

Test adresi sabittir: https://test.edmbilisim.com.tr/EFaturaEDM21ea/ESmmEDM.svc . Canlı endpoint seçimi yoktur. Her istekte APPLICATION_NAME=Kobivira gönderilir. Önce e-Fatura GetCompany ile aynı kullanıcı/VKN bağı doğrulanır; sonra ayrı e-SMM oturumu açılır.

Gönderimden önce deneme kaydı kalıcı olarak işaretlenir. Zaman aşımı, teknik ret veya belirsiz sonuçta aynı kaydı tekrar gönderen buton açılmaz. Yeni belge oluşturmadan önce eski belgenin UUID durumu incelenmelidir. Firma başına GET_LOCK ve belge kilidi eşzamanlı işlemleri sınırlar.

UBL ve kullanıcı bilgileri şifreli saklanır. UUID, numara, taraf ve profil yerelde ve uzak indirmelerde doğrulanır. XML DTD/entity kabul edilmez; PDF imzası kontrol edilir. Başka firmanın belgesi veya hesabı kullanılamaz. Destek/takip oturumları engellenir. Firma kullanıcısı için ücretli paket ve advanced_edocs yetkisi gerekir.

Testler ayrı tablodadır; normal muhasebe, stok ve yerel kontör bakiyesi değişmez. Firma silme akışı yeni tabloyu temizler. Tam yedek tüm veritabanını kapsadığı için yeni tablo da kapsamdadır. Kurulmuş cron görevi güncel sürüm işaretçisini kullanmayı sürdürür.

## Kapsam sınırı

Bu sürüm admin/firma EDM test alanını genişletir. Normal firma panelindeki yerel SMM kayıtlarını otomatik resmî e-SMM'ye dönüştürmez. e-İhracat, normal firma panelinin uçtan uca e-belge bağlantısı, otomatik durum eşitleme, canlı doğrulama ve PayTR ayrıca tamamlanmalıdır. e-Reçete ve e-Bilet eklenmemiştir.

## Gerçek test sonucu

Test makbuzu KVS2026900000002, UUID 9440f516-8aa9-4b32-b9ab-87bc8d5c01cb: SEND - SUCCEED, EDM kaynaklı XML ve PDF doğrulandı. Bu belge teknik kontrol için test servisine gönderildi; normal paneldeki yerel test listesine otomatik eklenmez. Panel örnekleri bu teknik kontrolden ayrı KSM serisini kullanır. Önceki KVS2026900000001 denemesi 2005 teknik hata verdi; aynı UUID yeniden gönderilmedi.
