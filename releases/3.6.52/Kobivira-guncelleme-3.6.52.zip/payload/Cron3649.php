<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit;}
$cronRoot=__DIR__;$cronPointer=json_decode((string)file_get_contents($cronRoot.'/storage/current.json'),true,16,JSON_THROW_ON_ERROR);$cronVersion=$cronPointer['version']??'';
if(!is_string($cronVersion)||!preg_match('/^\d+\.\d+\.\d+$/D',$cronVersion)){fwrite(STDERR,"Sürüm işaretçisi doğrulanamadı.\n");exit(1);}
$cronMode=$argv[1]??'--run';if(!in_array($cronMode,['--run','--tasks'],true)){fwrite(STDERR,"Yalnız --run veya --tasks kullanılabilir.\n");exit(1);}
$cronTarget=$cronRoot.'/releases/'.$cronVersion.'/'.($cronMode==='--tasks'?'SchedulerCli.php':'BackupCli367.php');
if(is_link($cronRoot.'/releases/'.$cronVersion)||is_link($cronTarget)||!is_file($cronTarget)){fwrite(STDERR,"Çalışan sürümün zamanlayıcısı bulunamadı.\n");exit(1);}
$_SERVER['SCRIPT_FILENAME']=$cronTarget;$argv[0]=$cronTarget;if($cronMode==='--tasks')$argv=[$cronTarget];$GLOBALS['argv']=$argv;require $cronTarget;
