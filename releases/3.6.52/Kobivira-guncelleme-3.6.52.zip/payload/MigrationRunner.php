(() => {
 const run=document.getElementById('migration-run'),pause=document.getElementById('migration-pause'),state=document.getElementById('migration-run-state');let paused=false;
 if(!run)return;pause.onclick=()=>{paused=true;pause.disabled=true;state.textContent='Mevcut adım bitince duraklatılacak…';};
 run.onclick=async()=>{const action=__ACTION__;const form=[...document.querySelectorAll('form')].find(f=>f.querySelector('input[name="action"]')?.value===action);if(!form)return;run.disabled=true;pause.hidden=false;paused=false;let steps=0;
 try{do{state.textContent='İşleniyor · tamamlanan adım: '+steps;const data=new FormData(form);data.set('json','1');const r=await fetch(form.action,{method:'POST',body:data,credentials:'same-origin',cache:'no-store'});if(!r.ok||!(r.headers.get('content-type')||'').includes('application/json'))throw new Error('İşlem duraklatıldı. Ayrıntıyı görmek ve kaldığınız adımdan devam etmek için sayfayı yenileyin.');const result=await r.json();steps++;if(!['scanning','processing'].includes(result.status)){location.href=result.url;return;}}while(!paused);location.reload();}catch(e){state.textContent=e.message;run.disabled=false;pause.hidden=true;}};
})();
