<?php
declare(strict_types=1);
function esc(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function atomic_write(string $path,string $bytes): void {
    $tmp=$path.'.'.bin2hex(random_bytes(6)).'.tmp';
    if(file_put_contents($tmp,$bytes,LOCK_EX)!==strlen($bytes)) throw new RuntimeException('Dosya yazılamadı.');
    chmod($tmp,0600); if(!rename($tmp,$path)){@unlink($tmp);throw new RuntimeException('Dosya etkinleştirilemedi.');}
}
function config(): array { static $c;return $c??=require APP_ROOT.'/config/app.php'; }
function connect_db(array $c): PDO {
    if(!preg_match('/^[a-zA-Z0-9_.-]+$/D',$c['host']??'')||!preg_match('/^[a-zA-Z0-9_]+$/D',$c['name']??'')) throw new DomainException('Veritabanı adı veya sunucusu geçersiz.');
    $port=(int)($c['port']??3306);if($port<1||$port>65535)throw new DomainException('Port geçersiz.');
    $p=new PDO("mysql:host={$c['host']};port=$port;dbname={$c['name']};charset=utf8mb4",$c['user'],$c['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false,PDO::MYSQL_ATTR_MULTI_STATEMENTS=>false]);
    $p->exec("SET time_zone='+00:00'");$p->exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'");return $p;
}
function db(): PDO { static $p;return $p??=connect_db(config()['database']); }
function query(string $sql,array $args=[]): PDOStatement {$q=db()->prepare($sql);$q->execute($args);return $q;}
function setting(string $key,string $default=''): string {$v=query('SELECT value FROM settings WHERE name=?',[$key])->fetchColumn();return $v===false?$default:(string)$v;}
function url(string $page,array $params=[]): string {if(isset($_GET['support'])&&is_string($_GET['support'])&&!array_key_exists('support',$params))$params['support']=$_GET['support'];return company3618_prefix($page).'?'.http_build_query(['page'=>$page]+$params);}
function redirect(string $page,array $params=[]): never {if(function_exists('form353_ajax')&&form353_ajax()){if($page==='login')form353_response(false,'Oturumunuz sona ermiş olabilir. Bilgileriniz bu formda korunuyor. Yeni sekmede giriş yapıp tekrar deneyin.',null,401);form353_response(true,'Kaydedildi.',url($page,$params));}header('Location: '.url($page,$params),true,303);exit;}
function flash(string $text): void {$_SESSION['flash']=$text;}
function csrf_field(): string {return '<input type="hidden" name="csrf" value="'.esc($_SESSION['csrf']).'">';}
function check_csrf(): void {if(!is_string($_POST['csrf']??null)||!hash_equals($_SESSION['csrf'],$_POST['csrf'])){http_response_code(419);throw new DomainException('Formun süresi doldu. Sayfayı yenileyin.');}}
function field(string $key,int $max=190): string {$v=trim(is_string($_POST[$key]??null)?$_POST[$key]:'');if(mb_strlen($v)>$max){$GLOBALS['validation_field']=$key;throw new DomainException('Alan çok uzun: '.$key);}return $v;}
function required_field(string $key,int $max=190): string {$v=field($key,$max);if($v===''){$GLOBALS['validation_field']=$key;throw new DomainException('Zorunlu alan eksik: '.$key);}return $v;}
function email_field(): string {$v=mb_strtolower(required_field('email'));if(!filter_var($v,FILTER_VALIDATE_EMAIL))throw new DomainException('Geçerli bir e-posta girin.');return $v;}
function password_field(string $key='password'): string {$v=$_POST[$key]??'';if(!is_string($v)||mb_strlen($v,'UTF-8')<8||strlen($v)>72)throw new DomainException('Şifre en az 8 karakter olmalıdır ve 72 baytı aşmamalıdır.');return $v;}
function int_field(string $key,int $min,int $max): int {$v=filter_var($_POST[$key]??null,FILTER_VALIDATE_INT);if($v===false||$v<$min||$v>$max){$GLOBALS['validation_field']=$key;throw new DomainException('Geçersiz sayı: '.$key);}return $v;}
function choice(string $key,array $values): string {$v=required_field($key,40);if(!in_array($v,$values,true)){$GLOBALS['validation_field']=$key;throw new DomainException('Geçersiz seçim: '.$key);}return $v;}
function scaled(string $value,int $scale=2,int $max=99999999999): int {
    $v=preg_replace('/[\s\x{00A0}]+/u','',trim($value));
    $v=preg_replace('/(?:TL|TRY|₺)$/iu','',$v);
    if(str_contains($v,',')){
        if(!preg_match('/^(\d+|\d{1,3}(?:\.\d{3})+),(\d{1,'.$scale.'})$/D',$v,$m))throw new DomainException('Tutarı 7.500,00 veya 7500 biçiminde yazın.');
        $v=str_replace('.','',$m[1]).'.'.$m[2];
    } elseif($scale===2&&preg_match('/^\d{1,3}(?:\.\d{3})+$/D',$v))$v=str_replace('.','',$v);
    if(!preg_match('/^(\d{1,12})(?:\.(\d{1,'.$scale.'}))?$/D',$v,$m))throw new DomainException('Geçerli bir sayı girin. Örnek: 7.500,00');
    $n=(int)$m[1]*(10**$scale)+(int)str_pad($m[2]??'',$scale,'0');
    if($n>$max)throw new DomainException('Tutar izin verilen sınırı aşıyor.');return $n;
}
function number_tr(int $n): string {return ($n<0?'-':'').number_format(intdiv(abs($n),100),0,',','.').','.str_pad((string)(abs($n)%100),2,'0',STR_PAD_LEFT);}
function amount(string $key,int $max=99999999999): int {return scaled(required_field($key,30),2,$max);}
function decimal(int $n,int $scale=2): string {return ($n<0?'-':'').intdiv(abs($n),10**$scale).'.'.str_pad((string)(abs($n)%(10**$scale)),$scale,'0',STR_PAD_LEFT);}
function money(mixed $n): string {$n=(int)$n;return ($n<0?'−':'').number_format(intdiv(abs($n),100),0,',','.').','.str_pad((string)(abs($n)%100),2,'0',STR_PAD_LEFT).' '.esc(($GLOBALS['print_currency']??'TRY')==='TRY'?'₺':$GLOBALS['print_currency']);}
function today(): string {return (new DateTimeImmutable('now',new DateTimeZone('Europe/Istanbul')))->format('Y-m-d');}
function date_value(string $v): string {$d=DateTimeImmutable::createFromFormat('!Y-m-d',$v);if(!$d||$d->format('Y-m-d')!==$v||$v<'2000-01-01'||$v>'2100-12-31')throw new DomainException('Geçerli bir tarih girin.');return $v;}
function date_field(string $key): string {return date_value(required_field($key,10));}
function next_month(string $v,?int $anchor=null): string {$d=new DateTimeImmutable($v);$t=$d->modify('first day of next month');return $t->setDate((int)$t->format('Y'),(int)$t->format('m'),min($anchor??(int)$d->format('d'),(int)$t->format('t')))->format('Y-m-d');}
function base_user(): ?array {
    if(PHP_SAPI==='cli'&&isset($GLOBALS['scheduler_user']))return $GLOBALS['scheduler_user'];
    static $loaded=false,$u=null;
    if(!$loaded){$loaded=true;if(isset($_SESSION['user_id'])){$u=query('SELECT u.*,c.status company_status,c.restriction_reason,c.restriction_code FROM users u LEFT JOIN companies c ON c.id=u.company_id WHERE u.id=? AND u.is_active=1 AND u.is_deleted=0',[$_SESSION['user_id']])->fetch()?:null;if($u&&(int)$u['session_version']!==($_SESSION['sv']??0))$u=null;}}
    return $u;
}
function current_user(): ?array {
    $u=base_user();if(!$u)return null;
    if($u['company_id']&&$u['company_status']!=='active'&&$u['role']!=='company_admin'){
        unset($_SESSION['user_id'],$_SESSION['sv']);flash(restriction_message(company_restriction($u)));return null;
    }
    if(!empty($GLOBALS['follow_context']))return $GLOBALS['follow_context']['helper'];
    if(isset($_GET['support'])){$c=support_context();if($c)return $c['helper'];}
    return $u;
}
function owner(): bool {return in_array(current_user()['role']??'',['platform_admin','support_agent'],true);}
function require_owner(): void {if(!owner()){http_response_code(403);throw new DomainException('Platform yöneticisi yetkisi gerekir.');}}
function company_id(): int {$id=(int)(current_user()['company_id']??0);if(!$id){http_response_code(403);throw new DomainException('Firma hesabı gerekir.');}return $id;}
function subscription(): array {static $cache=[];$cid=company_id();return $cache[$cid]??=query('SELECT s.*,p.name plan_name,p.code plan_code,p.user_limit,p.monthly_price FROM subscriptions s JOIN plans p ON p.id=s.plan_id WHERE s.company_id=?',[company_id()])->fetch();}
function can_write(bool $fresh=false): bool {if(query('SELECT status FROM companies WHERE id=?',[company_id()])->fetchColumn()!=='active')return false;$s=$fresh?query('SELECT * FROM subscriptions WHERE company_id=?',[company_id()])->fetch():subscription();return ($s['status']==='trial'&&strtotime($s['trial_ends_at'].' UTC')>time())||($s['status']==='active'&&$s['paid_until']&&strtotime($s['paid_until'].' UTC')>time());}
function require_write(): void {if(!empty($GLOBALS['follow_mode'])){http_response_code(403);throw new DomainException('Canlı izleme salt okunurdur.');}if(!can_write(true))throw new DomainException('Abonelik süresi doldu. Kayıtlarınız okunabilir; yeni işlem için üyeliğinizi etkinleştirin.');}
function has_feature(string $feature): bool {return feature_allowed($feature);}
function need_feature(string $f): void {if(!has_feature($f)){http_response_code(403);$GLOBALS['upgrade_required']=true;$GLOBALS['upgrade_feature']=$f;throw new DomainException('Bu işlem hesabınızda kullanılamıyor.');}}
function require_manager(): void {if(!in_array(current_user()['role'],['company_admin','platform_admin'],true)&&!(support_context()&&support_route_allowed(true))){http_response_code(403);throw new DomainException('Firma yöneticisi yetkisi gerekir.');}}
function can_approve(): bool {return current_user()['role']==='company_admin'||(support_context()&&support_route_allowed(true));}
function tenant_row(string $table,int $id,bool $lock=false): array {
    if(!in_array($table,['contacts','products','documents','accounts','users','tasks','recurring'],true))throw new LogicException('Tablo geçersiz.');
    $r=query("SELECT * FROM $table WHERE company_id=? AND id=?".($lock?' FOR UPDATE':''),[company_id(),$id])->fetch();
    if(!$r){http_response_code(404);throw new DomainException('Kayıt bulunamadı.');}return $r;
}
function transaction(callable $fn): mixed {db()->beginTransaction();try{$r=$fn();db()->commit();return $r;}catch(Throwable $e){if(db()->inTransaction())db()->rollBack();throw $e;}}
function company_transaction(callable $fn): mixed {return transaction(function()use($fn){if(query('SELECT status FROM companies WHERE id=? FOR UPDATE',[company_id()])->fetchColumn()!=='active')throw new DomainException('Firma erişimi kapatıldı.');require_write();if(!support_context()){$actor=query('SELECT is_active,session_version FROM users WHERE id=? AND company_id=?',[base_user()['id'],company_id()])->fetch();if(!$actor||!$actor['is_active']||(int)$actor['session_version']!==($_SESSION['sv']??0)){http_response_code(403);throw new DomainException('Kullanıcı erişimi değişmiş. Yeniden giriş yapın.');}}if(isset($_GET['support'])){support_context(true,true);support_guard(true);}return $fn();});}
function audit(string $action,array $metadata=[]): void {$u=current_user();if(function_exists('audit_capture'))$metadata=audit_capture($action,$metadata,isset($u['company_id'])?(int)$u['company_id']:null);$ctx=support_context();query('INSERT INTO audit_logs(company_id,user_id,actor_user_id,support_request_id,actor_name,action,metadata,created_at) VALUES (?,?,?,?,?,?,?,UTC_TIMESTAMP())',[$u['company_id']??null,$u['id']??null,base_user()['id']??null,$ctx['id']??null,base_user()['name']??$u['name']??'',$action,json_encode($metadata,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);}
function throttle_key(string $scope): string {return hash_hmac('sha256',$scope.'|'.($_SERVER['REMOTE_ADDR']??''),config()['app_key']);}
function throttle(string $scope,int $limit=8): void {
    $k=throttle_key($scope);query('DELETE FROM login_attempts WHERE last_attempt<DATE_SUB(UTC_TIMESTAMP(),INTERVAL 1 DAY)');
    $r=query('SELECT attempts,last_attempt FROM login_attempts WHERE bucket=?',[$k])->fetch();
    if($r&&(int)$r['attempts']>=$limit&&strtotime($r['last_attempt'].' UTC')>time()-900){http_response_code(429);throw new DomainException('Çok fazla deneme. 15 dakika sonra tekrar deneyin.');}
    query('INSERT INTO login_attempts(bucket,attempts,last_attempt) VALUES (?,1,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE attempts=IF(last_attempt<DATE_SUB(UTC_TIMESTAMP(),INTERVAL 15 MINUTE),1,attempts+1),last_attempt=UTC_TIMESTAMP()',[$k]);
}
function reauthenticate(array $u): void {throttle('reauth');if(!password_verify($_POST['current_password']??'',$u['password_hash'])){$GLOBALS['validation_field']='current_password';throw new DomainException(empty($_POST['current_password'])?'Mevcut yönetici şifrenizi girin.':'Mevcut şifreniz hatalı.');}query('DELETE FROM login_attempts WHERE bucket=?',[throttle_key('reauth')]);}
function login(array $u): never {$intent=function_exists('pricing_intent')?pricing_intent():null;session_regenerate_id(true);$_SESSION=['user_id'=>(int)$u['id'],'sv'=>(int)$u['session_version'],'csrf'=>bin2hex(random_bytes(32)),'started'=>time(),'seen'=>time()];if(email3643_pending($u)){if($intent)$_SESSION['package_intent']=$intent;redirect('verify_email');}if(phone3644_pending($u)){if($intent)$_SESSION['package_intent']=$intent;phone3644_auto_start($u);redirect('verify_mobile');}if($intent&&$u['company_id']&&$u['role']==='company_admin'){$_SESSION['package_intent']=$intent;redirect('membership',['view'=>'plans','plan'=>$intent['plan'],'period'=>$intent['period']]);}redirect('dashboard');}
function create_company(string $name,string $email,string $pass,string $person,int $plan,string $referral=''): int {
    return transaction(function()use($name,$email,$pass,$person,$plan,$referral){
        if(!query('SELECT id FROM plans WHERE id=? AND (is_active=1 OR code=\'kobi\') AND code IN (\'kobi\',\'plus\',\'business\') FOR UPDATE',[$plan])->fetchColumn())throw new DomainException('Paket seçilemedi.');
        query('INSERT INTO companies(name,created_at) VALUES (?,UTC_TIMESTAMP())',[$name]);$cid=(int)db()->lastInsertId();company3618_number($cid);
        query('INSERT INTO users(company_id,name,email,password_hash,role,created_at) VALUES (?,?,?,?,\'company_admin\',UTC_TIMESTAMP())',[$cid,$person,$email,password_hash($pass,PASSWORD_DEFAULT)]);
        $newOwner=(int)db()->lastInsertId();if(isset($GLOBALS['registration_consent'])){email3643_enroll($newOwner,$cid,$email);phone3644_enroll($newOwner,$cid);}
        $campaign=!empty($_SESSION['migration_intent'])&&time()-(int)$_SESSION['migration_intent']<3600&&migration_config()['enabled'];$days=max(1,min(14,(int)setting('trial_days','14')));$now=new DateTimeImmutable('now',new DateTimeZone('UTC'));$end=$now->modify($campaign?'+3 months':'+'.$days.' days')->format('Y-m-d H:i:s');
        query("INSERT INTO subscriptions(company_id,plan_id,status,trial_ends_at,created_at) VALUES (?,?,'trial',?,UTC_TIMESTAMP())",[$cid,$plan,$end]);
        query("INSERT INTO accounts(company_id,name,kind,created_at) VALUES (?,'Ana kasa','cash',UTC_TIMESTAMP())",[$cid]);if(isset($GLOBALS['registration_consent']))legal_record_consent($cid,$GLOBALS['registration_consent']);referral_attach($cid,$referral);if($campaign){query('INSERT INTO migration_campaigns(company_id,expires_at,created_at) VALUES (?,?,UTC_TIMESTAMP())',[$cid,$end]);unset($_SESSION['migration_intent']);}return $cid;
    });
}
function doc_kinds(): array {return ['quote'=>'Teklif','proforma'=>'Proforma','order'=>'Sipariş','sale'=>'Satış faturası','purchase'=>'Alış faturası','expense'=>'Gider'];}
function status_label(string $s): string {return ['draft'=>'Taslak','rejected'=>'Reddedildi','pending'=>'Onay bekliyor','posted'=>'Kesinleşti','approved'=>'Onaylandı','superseded'=>'Revize edildi · kapalı','cancelled'=>'İptal'][$s]??$s;}
function outstanding(array $d): int {return max(0,(int)$d['total']+ledger_return_sum((int)$d['id'])-(int)($d['staff_settled']??0)-(int)query('SELECT COALESCE(SUM(amount),0) FROM payments WHERE company_id=? AND document_id=? AND reversed_at IS NULL',[company_id(),$d['id']])->fetchColumn());}
