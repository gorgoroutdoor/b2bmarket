<?php
declare(strict_types=1);
/** Account numbers are public identifiers. Every request still uses the authenticated tenant. */
function company3618_number(int $cid,?PDO $pdo=null):string {
 if($cid<1)return '';$pdo??=db();static $cache=[];if(isset($cache[$cid]))return $cache[$cid];
 $q=$pdo->prepare('SELECT account_number FROM companies WHERE id=?');$q->execute([$cid]);$existing=$q->fetchColumn();
 if($existing===false)throw new DomainException('Firma hesabı bulunamadı.');if(is_string($existing)&&preg_match('/^[1-9][0-9]{7}$/D',$existing))return $cache[$cid]=$existing;
 for($attempt=0;$attempt<20;$attempt++){$number=(string)random_int(10000000,99999999);try{$q=$pdo->prepare('UPDATE companies SET account_number=? WHERE id=? AND account_number IS NULL');$q->execute([$number,$cid]);if($q->rowCount()===1)return $cache[$cid]=$number;$q=$pdo->prepare('SELECT account_number FROM companies WHERE id=?');$q->execute([$cid]);$value=$q->fetchColumn();if(is_string($value)&&preg_match('/^[1-9][0-9]{7}$/D',$value))return $cache[$cid]=$value;}catch(PDOException $e){if($e->getCode()!=='23000')throw $e;}}
 throw new DomainException('Firma hesap numarası oluşturulamadı.');
}
function company3618_public_pages():array {return ['verify_mobile','forgot_password','verify_email','payment_return','paytr_callback','login','register','install','legal','public_site','site_asset','site_media','marketing_data','brand_asset','showcase','customer_portal','public_data','reconciliation_reply','sales_lead','web_preview'];}
function company3618_webroot():?string {
 $documentRoot=$_SERVER['DOCUMENT_ROOT']??null;if(!is_string($documentRoot)||$documentRoot===''||!str_starts_with($documentRoot,'/'))return null;$root=realpath($documentRoot);if(!$root||!is_file($root.'/index.php')||is_link($root.'/index.php'))return null;
 $private=realpath(APP_ROOT);if($private&&($root===$private||str_starts_with($root,$private.DIRECTORY_SEPARATOR)))return null;
 return $root;
}
function company3618_route_source():string {return "<?php\ndeclare(strict_types=1);\n// Kobivira managed company entry; no credentials are stored here.\nrequire dirname(__DIR__).'/index.php';\n";}
function company3618_ensure_route(string $number):bool {
 if(!preg_match('/^[1-9][0-9]{7}$/D',$number))throw new DomainException('Firma hesap numarası geçersiz.');$root=company3618_webroot();if(!$root)return false;$directory=$root.'/'.$number;$file=$directory.'/index.php';$source=company3618_route_source();
 if(is_link($directory)||is_link($file))return false;
 if(is_file($file))return hash_equals($source,(string)file_get_contents($file));
 if(file_exists($directory)&&!is_dir($directory))return false;if(is_dir($directory)&&array_diff(scandir($directory)?:[],['.','..']))return false;
 if(!is_dir($directory)&&!@mkdir($directory,0755)&&!is_dir($directory))return false;
 if(realpath($directory)!==$directory||!is_writable($directory))return false;
 // Exclusive creation never overwrites an existing customer or hosting file.
 $h=@fopen($file,'x');if(!$h)return is_file($file)&&hash_equals($source,(string)file_get_contents($file));$ok=fwrite($h,$source)===strlen($source);fclose($h);if(!$ok){@unlink($file);return false;}@chmod($file,0644);return true;
}
function company3618_current_number():string {
 if(!is_file(APP_ROOT.'/config/installed.lock'))return '';$u=current_user();$cid=(int)($u['company_id']??0);return $cid?company3618_number($cid):'';
}
function company3618_prefix(string $page):string {
 if(in_array($page,company3618_public_pages(),true))return '/';$number=company3618_current_number();if($number==='')return '/';
 static $ready=[];if(!array_key_exists($number,$ready))$ready[$number]=company3618_ensure_route($number);
 if(!$ready[$number]){$GLOBALS['company3618_route_issue']=true;return '/';}return '/'.$number.'/';
}
function company3618_requested_number(string $uri):?string {
 $path=parse_url($uri,PHP_URL_PATH);if(!is_string($path))throw new DomainException('Firma adresi geçersiz.');
 if(preg_match('~^/([1-9][0-9]{7})(?:/(?:index\.php)?)?$~D',$path,$m))return $m[1];
 if($path==='/'||$path==='/index.php')return null;
 http_response_code(404);throw new DomainException('Firma adresi bulunamadı.');
}
function company3618_scope(string $page):void {
 if(in_array($page,company3618_public_pages(),true))return;$requested=company3618_requested_number($_SERVER['REQUEST_URI']??'/');$u=current_user();if(!$u)return;$number=company3618_current_number();
 if($requested!==null&&$number===''&&owner()&&($_SERVER['REQUEST_METHOD']??'GET')==='GET')redirect($page,array_diff_key($_GET,['page'=>true]));
 if($requested!==null&&$number!==$requested){http_response_code(403);throw new DomainException('Bu firma adresine erişiminiz yok.');}
 if($number!==''&&$requested===null&&($_SERVER['REQUEST_METHOD']??'GET')==='GET'&&company3618_prefix($page)!=='/')redirect($page,array_diff_key($_GET,['page'=>true]));
}
function company3618_header():string {$number=company3618_current_number();if($number==='')return '';return '<div class="company-account3618"><span>Firma hesap no</span><strong>'.esc($number).'</strong></div>';}
function company3618_route_notice():void {if(empty($GLOBALS['company3618_route_issue'])||owner())return;echo '<div class="info-note">Firma hesap numaranız tanımlı. Hesap adresinin açılması için sunucunun uygulama giriş klasörüne yazma izni gerekir. Mevcut panel adresiniz kullanılmaya devam ediyor; yöneticiniz hosting izinlerini kontrol etmelidir.</div>';}
