<?php
declare(strict_types=1);
function guide3642_asset(string $name):?array {static $index;$index??=json_decode(file_get_contents(__DIR__.'/Guide3642AssetIndex.json'),true,16,JSON_THROW_ON_ERROR);$file=$index[$name]??null;if(!is_string($file)||!preg_match('/^Guide3642Assets[0-9]+\.json$/D',$file))return null;$data=json_decode(file_get_contents(__DIR__.'/'.$file),true,16,JSON_THROW_ON_ERROR);return $data[$name]??null;}
function guide3642_catalog():array {static $v;return $v??=json_decode(file_get_contents(__DIR__.'/Guide3642Catalog.json'),true,32,JSON_THROW_ON_ERROR);}
function guide3642_config(string $slug):array {
 $defaults=['hidden'=>false,'media'=>[0,0],'captions'=>['','']];$v=json_decode(cms_s('guide3642_'.$slug,'',1),true);if(!is_array($v))return $defaults;return array_replace($defaults,array_intersect_key($v,$defaults));
}
function guide3642_gallery(array $p):string {
 $slug=$p['slug'];$row=guide3642_catalog()[$slug]??null;if(!$row)return '';$cfg=guide3642_config($slug);if($cfg['hidden'])return '';
 $out='<section class="guide42-gallery" aria-labelledby="guide42-heading"><header><span class="eyebrow">GERÇEK PANEL EKRANLARI</span><h2 id="guide42-heading">Panelde nereden başlamalısınız?</h2><p>'.esc($row['path']).'</p></header>';
 foreach($row['shots'] as $i=>$shot){$src='?page=site_asset&asset=guide3642-'.$shot['file'].'.jpg';$caption=$shot['caption'];$markers=$shot['markers'];$width=$shot['width'];$height=$shot['height'];$media=(int)($cfg['media'][$i]??0);
  if($media){$m=query('SELECT filename,alt_text FROM cms_media WHERE site_id=1 AND id=?',[$media])->fetch();if($m){$src='?page=site_media&media='.$m['filename'];$markers=[];$width=0;$height=0;}}
  if(($cfg['captions'][$i]??'')!=='')$caption=$cfg['captions'][$i];
  if($i>0)$out.='<details class="guide42-more"><summary>Form alanlarını görüntüleyin</summary>';
  $out.='<figure class="guide42-figure"><div class="guide42-image"><a href="'.esc($src).'" target="_blank" rel="noopener noreferrer" aria-label="'.esc($caption).' · tam boy görüntüle"><img src="'.esc($src).'" alt="'.esc($caption).'"'.($width?' width="'.$width.'" height="'.$height.'"':'').' loading="lazy" decoding="async">';
  foreach($markers as $j=>$m)$out.='<span class="guide42-marker" aria-hidden="true" style="left:'.$m['x'].'%;top:'.$m['y'].'%;width:'.$m['w'].'%;height:'.$m['h'].'%"><b>'.($j+1).'</b></span>';
  $out.='</a></div><figcaption><strong>'.esc($caption).'</strong><a href="'.esc($src).'" target="_blank" rel="noopener noreferrer">Tam boy görüntüle ↗</a></figcaption>';
  if($markers){$out.='<ol class="guide42-key">';foreach($markers as $j=>$m)$out.='<li><b>'.($j+1).'</b><span>'.esc($m['text']).'</span></li>';$out.='</ol>';}
  $out.='</figure>';if($i>0)$out.='</details>';
 }
 return $out.'<p class="guide42-caption">Görüntüler Kobivira’nın gerçek firma panelinden alınmıştır. Menü ve işlem alanları paket kapsamınıza ve yetkilerinize göre görünür.</p></section>';
}
function guide3642_banner():string {
 return '<section class="wrap guide42-banner-wrap"><aside class="guide42-banner" aria-labelledby="guide42-banner-title"><div><h2 id="guide42-banner-title">İşinizin hesabını Kobivira ile kolaylaştırın.</h2><p>14 günlük ücretsiz deneme. Kontör ve ücretli servisler dahil değildir.</p></div><a class="btn" href="https://app.kobivira.com.tr/?page=register">Ücretsiz deneyin ↗</a></aside></section>';
}
function guide3642_navigation_copy(string $body):string {
 $body=strtr($body,['Alışlar → Alış faturaları'=>'Alışlar ve Giderler → Alış faturaları','Para →'=>'Kasa ve Banka →']);
 $body=preg_replace('/(?:Alışlar ve )?Giderler → Gelen e-Faturalar/u','Elektronik Belgeler → Gelen e-Faturalar',$body)??$body;
 $body=preg_replace('/(?:Alışlar ve )?Giderler → Gider kayıtları/u','Alışlar ve Giderler → Gider kayıtları',$body)??$body;
 $body=preg_replace('/(?:Firma ve )?Ayarlar → Ürün miktar hareketleri/u','Ürün ve Hizmetler → Ürün miktar hareketleri',$body)??$body;
 $body=preg_replace('/(?:Firma ve )?Ayarlar → Kullanıcılar/u','Firma ve Ayarlar → Şirket çalışanları',$body)??$body;
 return preg_replace('/(?<!Firma ve )Ayarlar →/u','Firma ve Ayarlar →',$body)??$body;
}
function guide3642_layout(array $p,string $body):string {
 if(($p['kind']??'')!=='guide'||guide352_private($p))return $body;$body=guide3642_navigation_copy($body);$gallery=guide3642_gallery($p);
 if($gallery!==''){$count=0;$body=preg_replace_callback('~(<article\b[^>]*class="[^"]*\barticle\b[^"]*"[^>]*>.*?<p\b[^>]*class="[^"]*\blead\b[^"]*"[^>]*>.*?</p>)~s',fn($m)=>$m[1].$gallery,$body,1,$count)??$body;if(!$count)$body=preg_replace_callback('~(<article\b[^>]*class="[^"]*\barticle\b[^"]*"[^>]*>.*?</h1>)~s',fn($m)=>$m[1].$gallery,$body,1)??$body;}
 return $body.guide3642_banner();
}
function guide3642_editor(array $r):void {
 if(!cms_platform()||cms_sid()!==1||($r['kind']??'')!=='guide'||!isset(guide3642_catalog()[$r['slug']??'']))return;$slug=$r['slug'];$cfg=guide3642_config($slug);$row=guide3642_catalog()[$slug];
 echo '<details class="wide" id="guide-screenshots"><summary>Gerçek panel ekran görüntüleri</summary><p>Bu rehberin görüntüleri hazır eklenmiştir. Değiştirmek isterseniz site görsellerinden seçim yapın veya doğrudan yeni görsel yükleyin.</p>';hidden('guide3642_present',1);echo '<label><input type="checkbox" name="guide3642_hidden" value="1" '.($cfg['hidden']?'checked':'').'> Bu rehberde ekran görüntülerini gizle</label>';
 $options=[0=>'Hazır gerçek panel görüntüsünü kullan'];foreach(query('SELECT id,name FROM cms_media WHERE site_id=1 ORDER BY id DESC') as $m)$options[(int)$m['id']]=$m['name'];
 foreach($row['shots'] as $i=>$s){echo '<div class="wide"><h3>'.($i+1).'. görüntü</h3>';select_field('guide3642_media_'.$i,'Görsel',$options,(int)($cfg['media'][$i]??0));input('guide3642_caption_'.$i,'Görsel açıklaması',$cfg['captions'][$i]??'','text','maxlength="200" placeholder="'.esc($s['caption']).'"');$id=(int)($cfg['media'][$i]??0);quick3636_upload_editor('guide3642_upload_'.$i,$id,'?page=site_asset&asset=guide3642-'.$s['file'].'.jpg');echo '</div>';}
 echo '<p>Yeni bir görsel seçtiğinizde hazır numaralı işaretler kaldırılır; böylece yanlış düğme işaretlenmez. Hazır görüntüye döndüğünüzde işaretler geri gelir.</p></details>';
}
function guide3642_save(array $r):void {
 if(!isset($_POST['guide3642_present']))return;if(!cms_platform()||cms_sid()!==1||($r['kind']??'')!=='guide'||!isset(guide3642_catalog()[$r['slug']??'']))throw new DomainException('Bu rehberin görüntüleri düzenlenemez.');$slug=$r['slug'];$row=guide3642_catalog()[$slug];$cfg=['hidden'=>isset($_POST['guide3642_hidden']),'media'=>[],'captions'=>[]];
 foreach($row['shots'] as $i=>$s){$id=int_field('guide3642_media_'.$i,0,PHP_INT_MAX);$uploaded=quick3636_upload('guide3642_upload_'.$i,'Rehber görseli · '.$r['title']);if($uploaded!==null)$id=$uploaded;if($id&&!query('SELECT 1 FROM cms_media WHERE site_id=1 AND id=?',[$id])->fetchColumn())throw new DomainException('Bu siteye ait bir rehber görseli seçin.');$cfg['media'][]=$id;$cfg['captions'][]=cms_post('guide3642_caption_'.$i,200);}
 $key='guide3642_'.$slug;cms_history('settings',0,[$key=>cms_s($key,'',1)]);cms_setting($key,json_encode($cfg,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),1);
}
