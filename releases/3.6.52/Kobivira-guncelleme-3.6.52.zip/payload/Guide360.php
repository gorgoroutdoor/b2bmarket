<?php
declare(strict_types=1);
/** Only public company help content; the platform administration has no public guides. */
function guide360_catalog(): array {
 static $catalog;return $catalog??=json_decode(file_get_contents(__DIR__.'/Guide360.json'),true,64,JSON_THROW_ON_ERROR);
}
function guide360_features(): array {
 $out=[];foreach(guide360_catalog()['guides'] as $r)if($r['feature']!=='')$out[$r['slug']]=$r['feature'];return $out;
}
function guide360_visible_links(string $body): string {
 $published=array_fill_keys(query("SELECT slug FROM cms_pages WHERE site_id=1 AND kind='guide' AND status='published' AND category<>'Yönetim' AND slug NOT IN ('rehber-yonetim','rehber-surumler')")->fetchAll(PDO::FETCH_COLUMN),true);
 foreach(array_keys($published) as $slug)if(!launch3619_guide_visible($slug,guide3616_catalog()[$slug]??['feature'=>'']))unset($published[$slug]);
 // Guide directory / related lists must respect later CMS unpublishing or deletion.
 return preg_replace_callback('~<li\b[^>]*>(?:(?!<li\b).)*?</li>~s',function($m)use($published){if(preg_match('~href="(rehber-[a-z0-9-]+)\.html(?:#[a-z0-9-]+)?"~',$m[0],$a)&&!isset($published[$a[1]]))return '';return $m[0];},$body);
}
function guide360_library(string $body): string {
 $n=0;foreach(guide3616_catalog() as $slug=>$g)if(launch3619_guide_visible($slug,$g))$n++;
 $body=preg_replace_callback('~(<p\b[^>]*id="results-count"[^>]*>).*?(</p>)~s',fn($m)=>$m[1].$n.' rehber'.$m[2],$body);
 $body=preg_replace('~(<select[^>]*id="plan-filter"[^>]*>).*?(</select>)~s','$1<option value="">Tüm paketler</option><option value="1">KOBİ</option><option value="2">KOBİ Plus</option><option value="3">KOBİ Business</option>$2',$body);
 if(!str_contains($body,'href="rehber-menu.html"'))$body=str_replace('<div class="library-tools">','<p><a href="rehber-menu.html">Tüm kategoriler ve adım adım işlem rehberleri →</a></p><div class="library-tools">',$body);
 return $body;
}
