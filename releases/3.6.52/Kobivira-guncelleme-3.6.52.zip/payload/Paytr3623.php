<?php
declare(strict_types=1);
/** Admin-only sandbox. Deliberately cannot write subscriptions, credits or payment_orders. */
final class Paytr3623 {
 public const ORIGIN='https://app.kobivira.com.tr';
 public static function credentials(array $v):array {
  foreach(['merchant_id','merchant_key','merchant_salt'] as $k)if(!is_string($v[$k]??null)||$v[$k]===''||strlen($v[$k])>500)throw new DomainException('PayTR mağaza bilgileri eksik. PayTR ödeme ayarlarını kaydedin.');
  if(!preg_match('/^[0-9]{1,20}$/D',$v['merchant_id']))throw new DomainException('PayTR mağaza numarası yalnız rakam olmalı.');
  return array_intersect_key($v,array_flip(['merchant_id','merchant_key','merchant_salt']));
 }
 public static function tokenHash(array $p,array $c):string {
  $s='';foreach(['merchant_id','user_ip','merchant_oid','email','payment_amount','user_basket','no_installment','max_installment','currency','test_mode'] as $k)$s.=$p[$k];
  return base64_encode(hash_hmac('sha256',$s.$c['merchant_salt'],$c['merchant_key'],true));
 }
 public static function callbackHash(string $oid,string $status,string $amount,array $c):string {return base64_encode(hash_hmac('sha256',$oid.$c['merchant_salt'].$status.$amount,$c['merchant_key'],true));}
 public static function payload(array $r,array $c,array $buyer,string $ip):array {
  if(!filter_var($ip,FILTER_VALIDATE_IP)||strlen($ip)>39)throw new DomainException('Sunucu müşteri IP adresini belirleyemedi. Hosting ayarlarını kontrol edin.');
  if(!filter_var($buyer['email'],FILTER_VALIDATE_EMAIL)||strlen($buyer['email'])>100||preg_match('/[^\x20-\x7e]/',$buyer['email']))throw new DomainException('Geçerli, Türkçe karakter içermeyen e-posta yazın.');
  foreach(['user_name'=>60,'user_address'=>400,'user_phone'=>20] as $key=>$max)if(trim($buyer[$key]??'')===''||mb_strlen($buyer[$key])>$max)throw new DomainException('Ödeyen bilgisi eksik veya çok uzun: '.$key);
  $basket=base64_encode(json_encode([[$r['plan_name'].' · '.$r['months'].' ay',number_format((int)$r['amount']/100,2,'.',''),1]],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE));
  $back=self::ORIGIN.'/?page=paytr_test&id='.(int)$r['id'];
  $p=['merchant_id'=>$c['merchant_id'],'user_ip'=>$ip,'merchant_oid'=>$r['merchant_oid'],'email'=>$buyer['email'],'payment_amount'=>(string)$r['amount'],'user_basket'=>$basket,'no_installment'=>'1','max_installment'=>'0','currency'=>'TL','test_mode'=>'1','debug_on'=>'0','timeout_limit'=>'30','lang'=>'tr','user_name'=>$buyer['user_name'],'user_address'=>$buyer['user_address'],'user_phone'=>$buyer['user_phone'],'merchant_ok_url'=>$back.'&returned=success','merchant_fail_url'=>$back.'&returned=failed'];
  $p['paytr_token']=self::tokenHash($p,$c);return $p;
 }
 public static function request(array $p):array {
  if(!function_exists('curl_init'))throw new DomainException('Hosting PHP cURL eklentisi gerekli. Hosting desteğinden etkinleştirmesini isteyin.');
  $ch=curl_init('https://www.paytr.com/odeme/api/get-token');$body='';$tooLarge=false;
  curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($p),CURLOPT_RETURNTRANSFER=>false,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>25,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded'],CURLOPT_WRITEFUNCTION=>static function($ch,$part)use(&$body,&$tooLarge){if(strlen($body)+strlen($part)>16384){$tooLarge=true;return 0;}$body.=$part;return strlen($part);}]);
  $ok=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
  if($ok===false||$tooLarge||$code!==200)throw new RuntimeException('PayTR yanıtı doğrulanamadı.');
  $v=json_decode($body,true,16,JSON_THROW_ON_ERROR);if(!is_array($v))throw new RuntimeException('PayTR yanıtı geçersiz.');return $v;
 }
}
function paytr3623_prepare(int $cid,int $pid,int $months,string $key,int $actor,array $buyer,string $ip):array {
 if(!preg_match('/^[a-f0-9]{32}$/D',$key))throw new DomainException('Form anahtarı geçersiz. Sayfayı yenileyin.');
 return transaction(function()use($cid,$pid,$months,$key,$actor,$buyer,$ip){
  // Serialize creation per administrator, so double submits and limits also hold concurrently.
  if(!query('SELECT id FROM users WHERE id=? FOR UPDATE',[$actor])->fetchColumn())throw new DomainException('Yönetici bulunamadı.');
  $old=query('SELECT * FROM paytr_test_attempts WHERE actor_id=? AND request_key=?',[$actor,$key])->fetch();if($old)return $old;
  if((int)query('SELECT COUNT(*) FROM paytr_test_attempts WHERE actor_id=? AND created_at>DATE_SUB(UTC_TIMESTAMP(),INTERVAL 1 HOUR)',[$actor])->fetchColumn()>=10)throw new DomainException('Bir saatte en fazla 10 yeni test açabilirsiniz. Mevcut testin sonucunu kontrol edin.');
  if(!query("SELECT id FROM companies WHERE id=? AND status='active'",[$cid])->fetchColumn())throw new DomainException('Aktif firma seçin.');
  $plan=query('SELECT * FROM plans WHERE id=?',[$pid])->fetch();if(!$plan)throw new DomainException('Paket bulunamadı.');$quote=pricing_quote($plan,$months);
  if($quote['total']<=0||$quote['total']>999999999)throw new DomainException('Test tutarı geçersiz.');
  $c=Paytr3623::credentials(profile_values(service_profile(0,'paytr')));
  $r=['id'=>0,'merchant_oid'=>'KVT'.strtoupper(bin2hex(random_bytes(16))),'plan_name'=>$plan['name'],'months'=>$months,'amount'=>$quote['total']];
  Paytr3623::payload($r,$c,$buyer,$ip); // Validate before persisting anything.
  query("INSERT INTO paytr_test_attempts(company_id,plan_id,plan_name,months,amount,merchant_oid,request_key,actor_id,credential_cipher,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())",[$cid,$pid,$plan['name'],$months,$quote['total'],$r['merchant_oid'],$key,$actor,seal_code(json_encode($c,JSON_THROW_ON_ERROR))]);
  return query('SELECT * FROM paytr_test_attempts WHERE id=?',[(int)db()->lastInsertId()])->fetch();
 });
}
function paytr3623_start(array $r,array $buyer,string $ip,?callable $transport=null):void {
 $c=Paytr3623::credentials(json_decode(open_code($r['credential_cipher']),true,16,JSON_THROW_ON_ERROR));$p=Paytr3623::payload($r,$c,$buyer,$ip);
 // Exactly one token request per attempt, even on retry or concurrent form posts.
 query("UPDATE paytr_test_attempts SET status='requesting',updated_at=UTC_TIMESTAMP() WHERE id=? AND status='created'",[$r['id']]);
 if(!query('SELECT ROW_COUNT()')->fetchColumn())return;
 try{$v=$transport?$transport($p):Paytr3623::request($p);
  if(($v['status']??'')==='success'&&is_string($v['token']??null)&&preg_match('/^[A-Za-z0-9_-]{10,200}$/D',$v['token'])){
   query("UPDATE paytr_test_attempts SET token_cipher=?,status='ready',detail='Ödeme ekranı açıldı; imzalı bildirim bekleniyor.',updated_at=UTC_TIMESTAMP() WHERE id=? AND status='requesting'",[seal_code($v['token']),$r['id']]);
  }elseif(($v['status']??'')==='failed'){
   // Never store provider text that could echo request secrets or personal details.
   query("UPDATE paytr_test_attempts SET status='api_error',detail='PayTR ödeme ekranı isteğini reddetti. Mağaza bilgileri, mağaza yetkisi ve sunucu IP ayarlarını PayTR panelinden kontrol edin.',updated_at=UTC_TIMESTAMP() WHERE id=? AND status='requesting'",[$r['id']]);
  }else throw new RuntimeException('Beklenmeyen yanıt.');
 }catch(Throwable $e){query("UPDATE paytr_test_attempts SET status='unknown',detail='Sonuç alınamadı. Bu referansla tekrar istek gönderilmez. PayTR işlem kaydını kontrol edin; bildirim gelirse sonuç güncellenir.',updated_at=UTC_TIMESTAMP() WHERE id=? AND status='requesting'",[$r['id']]);}
}
/** Only authenticated callback fields affect the result. Unsigned test_mode/return URLs never grant anything. */
function paytr3623_receive(array $p):void {
 foreach(['merchant_oid','status','total_amount','hash'] as $k)if(!is_string($p[$k]??null))throw new DomainException('Geçersiz bildirim.');
 if(!preg_match('/^KVT[A-F0-9]{32}$/D',$p['merchant_oid'])||!in_array($p['status'],['success','failed'],true)||!preg_match('/^[0-9]{1,12}$/D',$p['total_amount'])||strlen($p['hash'])!==44)throw new DomainException('Geçersiz bildirim.');
 transaction(function()use($p){
  $r=query('SELECT * FROM paytr_test_attempts WHERE merchant_oid=? FOR UPDATE',[$p['merchant_oid']])->fetch();if(!$r)throw new DomainException('Bilinmeyen bildirim.');
  $c=Paytr3623::credentials(json_decode(open_code($r['credential_cipher']),true,16,JSON_THROW_ON_ERROR));
  if(!hash_equals(Paytr3623::callbackHash($p['merchant_oid'],$p['status'],$p['total_amount'],$c),$p['hash']))throw new DomainException('Geçersiz imza.');
  if($p['status']==='success'&&(int)$p['total_amount']!==(int)$r['amount'])throw new DomainException('Tutar uyuşmazlığı.');
  if($r['callback_status']!==null){$conflict=$r['callback_status']!==$p['status']||(int)$r['callback_amount']!==(int)$p['total_amount'];query('UPDATE paytr_test_attempts SET callback_count=callback_count+1,callback_conflict=GREATEST(callback_conflict,?),updated_at=UTC_TIMESTAMP() WHERE id=?',[(int)$conflict,$r['id']]);return;}
  query("UPDATE paytr_test_attempts SET status=?,callback_status=?,callback_amount=?,callback_count=1,callback_at=UTC_TIMESTAMP(),detail=?,token_cipher=NULL,updated_at=UTC_TIMESTAMP() WHERE id=?",[$p['status']==='success'?'success':'failed',$p['status'],(int)$p['total_amount'],$p['status']==='success'?'PayTR imzalı başarı bildirimi doğrulandı. Test tamamlandı; gerçek üyelik ve kontör değişmedi.':'PayTR imzalı başarısız ödeme bildirimi doğrulandı. Üyelik ve kontör değişmedi.',$r['id']]);
 });
}
function paytr3623_callback():never {
 header('Content-Type: text/plain; charset=utf-8');header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');
 if(($_SERVER['REQUEST_METHOD']??'')!=='POST'){header('Allow: POST');http_response_code(405);exit('METHOD');}
 if((int)($_SERVER['CONTENT_LENGTH']??0)>16384||count($_POST)>30){http_response_code(413);exit('SIZE');}
 if(!is_file(APP_ROOT.'/config/installed.lock')||is_file(APP_ROOT.'/storage/maintenance.json')){http_response_code(503);header('Retry-After: 60');exit('RETRY');}
 try{if(is_string($_POST['merchant_oid']??null)&&str_starts_with($_POST['merchant_oid'],'KVP'))checkout3624_receive($_POST);else paytr3623_receive($_POST);echo 'OK';}catch(DomainException $e){http_response_code(400);echo 'INVALID';}catch(Throwable $e){http_response_code(503);echo 'RETRY';}exit;
}
function paytr3623_post(string $action):never {
 admin351_guard();if($action!=='start')throw new DomainException('Geçersiz işlem.');reauthenticate(base_user());
 if(!isset($_POST['confirm_test']))throw new DomainException('Test ödeme onayını işaretleyin.');
 if(!function_exists('curl_init'))throw new DomainException('Hosting PHP cURL eklentisi gerekli.');
 $buyer=['email'=>required_field('email',100),'user_name'=>required_field('user_name',60),'user_address'=>required_field('user_address',400),'user_phone'=>required_field('user_phone',20)];
 $r=paytr3623_prepare(int_field('company_id',1,PHP_INT_MAX),int_field('plan_id',1,PHP_INT_MAX),int_field('months',1,12),request_key(),(int)base_user()['id'],$buyer,(string)($_SERVER['REMOTE_ADDR']??''));
 paytr3623_start($r,$buyer,(string)($_SERVER['REMOTE_ADDR']??''));redirect('paytr_test',['id'=>$r['id']]);
}
function paytr3623_labels():array {return ['created'=>'Oluşturuldu','requesting'=>'PayTR yanıtı bekleniyor','ready'=>'Ödeme / bildirim bekleniyor','api_error'=>'Ödeme ekranı açılmadı','unknown'=>'Sonuç belirsiz · PayTR kontrolü gerekli','success'=>'Test başarılı','failed'=>'Test ödeme başarısız'];}
function paytr3623_view():void {
 admin351_guard();heading('PayTR test ödemesi','Yalnız yönetim alanı. Test ödemesi üyelik süresi veya kontör yüklemez.');
 echo '<p>'.a('service_admin','PayTR ödeme ayarları',['provider'=>'paytr'],'button quiet').'</p>';
 panel('1. Bildirim adresini kaydedin');echo '<p>PayTR Mağaza Paneli → Destek &amp; Kurulum → Ayarlar → Bildirim URL alanına aşağıdaki adresi girin:</p><p><code>'.esc(Paytr3623::ORIGIN.'/?page=paytr_callback').'</code></p><p>Bu adres tarayıcıda açıldığında METHOD yazması normaldir; sonuç bildirimini PayTR POST ile gönderir.</p></section>';
 if(isset($_GET['id'])){
  if(!is_string($_GET['id'])||!ctype_digit($_GET['id']))throw new DomainException('Test kaydı geçersiz.');
  $r=query('SELECT t.*,c.name company_name FROM paytr_test_attempts t JOIN companies c ON c.id=t.company_id WHERE t.id=?',[(int)$_GET['id']])->fetch();if(!$r)throw new DomainException('Test kaydı bulunamadı.');
  panel('2. Ödeme sonucu · '.$r['merchant_oid']);echo '<p>'.esc($r['company_name'].' · '.$r['plan_name'].' · '.$r['months'].' ay').' · '.money($r['amount']).'</p><p><strong>'.esc(paytr3623_labels()[$r['status']]??$r['status']).'</strong></p><p>'.esc($r['detail']).'</p>';
  if(isset($_GET['returned']))echo '<p>Ödeme sayfasından döndünüz. Kesin sonuç yukarıdaki imzalı bildirim durumudur.</p>';
  if($r['callback_conflict'])echo '<p>Bu referansa farklı sonuçlar bildirildi. İlk doğrulanan sonuç korundu; PayTR kaydını kontrol edin.</p>';
  if($r['callback_at'])echo '<p>Doğrulanan bildirim: '.esc(desk_time($r['callback_at'])).' · Bildirim sayısı: '.(int)$r['callback_count'].'</p>';
  if($r['status']==='ready'&&$r['token_cipher']&&strtotime($r['created_at'].' UTC')>time()-1800){$token=open_code($r['token_cipher']);if(preg_match('/^[A-Za-z0-9_-]{10,200}$/D',$token))echo '<p>PayTR ekranındaki test kartını ve test doğrulama adımlarını kullanın.</p><iframe class="paytr3623-frame" src="https://www.paytr.com/odeme/guvenli/'.esc($token).'" title="PayTR test ödeme ekranı" referrerpolicy="no-referrer"></iframe>';}
  elseif($r['status']==='ready')echo '<p>Ödeme ekranının süresi doldu. Önce PayTR işlem kaydını kontrol edin; mevcut bildirim gelirse bu kayıt güncellenir.</p>';
  echo '<p>'.a('paytr_test','Sonucu yenile',['id'=>$r['id']],'button').'</p></section>';
 }
 panel('Yeni test ödemesi','Tutar seçilen paketin kayıtlı fiyatı ve KDV üzerinden sunucuda hesaplanır. PayTR isteği daima test_mode=1 ile gider.');
 form_start('paytr_test','start');hidden('request_key',form_key());
 select_field('company_id','Testin ilişkilendirileceği firma',array_column(query("SELECT id,CONCAT(name,' · ',account_number) label FROM companies WHERE status='active' ORDER BY name LIMIT 2000")->fetchAll(),'label','id'));
 $plans=[];foreach(query('SELECT * FROM plans WHERE is_active=1')->fetchAll() as $p)if(pricing_can_sell($p))$plans[$p['id']]=$p['name'];select_field('plan_id','Paket',$plans);select_field('months','Dönem',[1=>'1 ay',3=>'3 ay',12=>'12 ay']);
 input('email','Test ödeyen e-posta',base_user()['email']??'','email','required maxlength="100"');input('user_name','Test ödeyen ad soyad','','text','required maxlength="60"');input('user_phone','Test ödeyen telefon','','tel','required maxlength="20"');input('user_address','Test ödeyen adres','','text','required maxlength="400"');
 echo '<label class="wide"><input type="checkbox" name="confirm_test" value="1" required> Yalnız PayTR test ödemesi açılacağını onaylıyorum.</label>';input('current_password','Kobivira yönetici şifreniz','','password','required autocomplete="current-password"');form_end('PayTR test ödeme ekranını aç');echo '</section>';
 panel('Son 50 test');table_start(['Referans','Firma · paket','Tutar','Durum']);$rows=query('SELECT t.*,c.name company_name FROM paytr_test_attempts t JOIN companies c ON c.id=t.company_id ORDER BY t.id DESC LIMIT 50')->fetchAll();foreach($rows as $r)echo '<tr><td>'.a('paytr_test',esc($r['merchant_oid']),['id'=>$r['id']]).'</td><td>'.esc($r['company_name'].' · '.$r['plan_name'].' · '.$r['months'].' ay').'</td><td>'.money($r['amount']).'</td><td>'.esc(paytr3623_labels()[$r['status']]??$r['status']).'</td></tr>';table_end(count($rows),4);echo '</section>';
}
