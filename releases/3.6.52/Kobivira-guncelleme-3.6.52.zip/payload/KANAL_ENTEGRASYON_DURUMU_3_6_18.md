# Kobivira — Entegrasyon durumu, 3.6.18

Bu liste kodun mevcut kapsamı ve bu görüşmede doğrulanan süreçlere dayanır. 3.6.18 arayüz ve firma adresi sürümüdür; yeni bir dış kanal adaptörü eklememiştir. Test ortamında görülen sonuç canlı firma aktivasyonunun yerine geçmez.

| Alan | Mevcut durum | Kalan iş |
| --- | --- | --- |
| EDM e-Fatura / e-Arşiv / e-SMM | Servis istemcileri, firma hesabı, belge hazırlama, onaylı kuyruk, durum ve PDF/XML akışları var. Önceki test gönderim/indirmelerinde sonuç alındı. | Firmanın kendi canlı hesabı, yetkileri ve VKN eşleşmesiyle kontrollü canlı doğrulama; e-Arşiv/e-SMM GİB raporlarının ve iptal raporunun ayrıca doğrulanması. |
| EDM e-İrsaliye | Gönderim, alım, PDF/XML ve yanıt kuyrukları var. Sağlayıcı mailde kontrol ettiği belgede kabul sonucu bildirdi. | Kobivira üzerinden kabul/ret/kısmi kabul sonuçlarının yeni, takip edilen belgelerle tamamlanması. Ortak test hesabında başka kullanımın yanıt vermesi bizim akışımızın kanıtı sayılmaz. |
| EDM e-İhracat | Mal ihracı senaryosu ve durum/PDF/XML akışı var. | Önceki başarısız belgenin teknik nedeninin çözülmesi; nihai gümrük/GİB sonucunun doğrulanması. |
| EDM müşteri açılışı / kontör satın alma | Gelir paylaşımı modelinde EDM'nin bildirdiği manuel satış/aktivasyon süreci var; müşteri/kontör satın alma API'si verilmedi. | Müşteri adına başvuru/tahsilat/hesaba kontör yükletme yetkisi, faturalandırma ve müşteri ilişkilendirmesi yazılı netleştirilmeli. Kobivira paket bakiyesi EDM bakiyesi yerine kullanılmamalı. |
| PayTR | Ayar alanları bulunuyor; mevcut servis merkezindeki hazırlık kaydı gerçek ödeme sayfası açmıyor. | Üyelik ödeme başlatma, bildirim imzası, tekrar bildirim koruması, başarılı ödeme sonrası doğru sipariş/paket güncellemesi ve başarısız/iade senaryoları. |
| iyzico | Alternatif sağlayıcı ayar alanı var. | Seçilirse ayrıca gerçek adaptör ve ödeme testleri gerekir; PayTR yerine kendiliğinden çalışmaz. |
| Otomatik banka bağlantısı | Banka dosyası eşleştirme ile otomatik banka API bağlantısı ayrı işlerdir. Dosya eşleştirme modülü var; otomatik akış adaptörü hazır değil. | Sağlayıcı ve banka kapsamı seçimi, yetkilendirme, işlem alma, mükerrer işlem/kur/hesap eşleştirme testleri. |
| Pazaryeri / e-ticaret / haricî CRM | Servis alanı var; mağaza sipariş/stok/fiyat eşitleyen canlı kanal adaptörü yok. Dahili CRM modülü bundan ayrıdır. | Kanal ve API seçimi, mağaza yetkisi, sipariş alma, ürün eşleştirme, stok/fiyat, iptal/iade ve tekrar deneme akışları. |
| Meta / Google reklam bağlantısı | Modül erişimi ve hazırlık ekranları var. | Kobivira uygulaması içinden canlı hesap yetkilendirme, veri alma/yayınlama adaptörü ve testleri. Başka araçtaki reklam hesabı bağlantısı bu uygulamanın entegrasyonu sayılmaz. |
| OCR / yapay zekâ hizmetleri | İnceleme kuyruğu ve kurallı rapor hazırlığı var. | Dış sağlayıcı adaptörü, veri işleme onayı, sonuç doğrulaması ve kullanım/maliyet kontrolleri. |
| E-posta / SMS | Yapılandırma ve gönderim altyapısı mevcut. | Hosting/sağlayıcı ayarlarıyla gerçek teslim ve hata/yeniden deneme kontrollerinin doğrulanması. |
| Turkcell e-Şirket | Bu görüşmede yeni teknik belgeleri henüz paylaşılmadı; adaptör eklenmedi. | Gelen API, test hesabı, ticari koşullar ve müşteri/aktivasyon/ödeme akışı incelenmeli. |

Elektronik belge kapsamı mevcut beş türdür. Bu sürüm e-Reçete/e-Bilet veya yeni e-belge türü eklemez. Hiçbir dış servis bekleyen/başarısızken arayüzde başarılı gösterilmez.
