<?php
declare(strict_types=1);
function plan3616_catalog(): array {
 $c=feature_catalog_base();$c['edocs'][1]='Elektronik belge bağlantısı';$c['advanced_edocs'][1]='İleri elektronik belgeler';
 foreach(['invoice'=>[2,'e-Fatura'],'archive'=>[2,'e-Arşiv'],'incoming'=>[2,'Gelen e-Faturalar'],'despatch'=>[3,'e-İrsaliye'],'incoming_despatch'=>[3,'Gelen e-İrsaliyeler'],'smm'=>[3,'e-SMM'],'export'=>[3,'e-İhracat']] as $k=>$v)$c['edoc_'.$k]=[$v[0],$v[1],true];
 $c['public_api'][1]='Salt okunur veri API erişimi';$c['meta_ads']=[3,'Meta reklam yönetimi',true];$c['google_ads']=[3,'Google reklam yönetimi',true];return $c;
}
function plan3616_selectable(): array {return array_diff_key(plan3616_catalog(),array_flip(['edocs','advanced_edocs']));}
function plan3616_defaults(): array {
 $out=[];foreach(['kobi'=>1,'plus'=>2,'business'=>3] as $code=>$level){$out[$code]=[];foreach(plan3616_selectable() as $key=>$v){if(in_array($key,['website','meta_ads','google_ads'],true)){$m=module351_config()[$key];if(in_array($code,$m['plans'],true))$out[$code][]=$key;}elseif($level>=$v[0])$out[$code][]=$key;}}return $out;
}
function plan3616_config(): array {
 if(isset($GLOBALS['plan3616_cache']))return $GLOBALS['plan3616_cache'];$raw=json_decode(setting('plan_features_3616',''),true);if($raw===null)return $GLOBALS['plan3616_cache']=['revision'=>0,'plans'=>plan3616_defaults()];
 if(!is_array($raw)||!is_int($raw['revision']??null)||!is_array($raw['plans']??null))throw new DomainException('Paket özellik ayarları okunamadı. Yönetici kontrolü gerekir.');
 foreach(['kobi','plus','business'] as $code)if(!is_array($raw['plans'][$code]??null)||array_diff($raw['plans'][$code],array_keys(plan3616_selectable())))throw new DomainException('Paket özellik ayarları geçersiz.');return $GLOBALS['plan3616_cache']=$raw;
}
function plan3616_has(string $code,string $key): bool {$code=$code==='business_plus'?'business':$code;return in_array($key,plan3616_config()['plans'][$code]??[],true);}
function plan3616_edoc_feature(string $kind): string {return match($kind){'invoice'=>'edoc_invoice','archive'=>'edoc_archive','smm'=>'edoc_smm','despatch'=>'edoc_despatch','export'=>'edoc_export',default=>throw new DomainException('Belge türü geçersiz.')};}
function edoc3616_allowed(string $kind): bool {return has_feature(plan3616_edoc_feature($kind));}
function edoc3616_any(): bool {foreach(['edoc_invoice','edoc_archive','edoc_incoming','edoc_despatch','edoc_incoming_despatch','edoc_smm','edoc_export'] as $key)if(has_feature($key))return true;return false;}
function plan3616_fields(string $code): void {
 $cfg=plan3616_config();hidden('feature_revision',$cfg['revision']);hidden('feature_selection',1);echo '<fieldset><legend>Paket özellikleri</legend><p>Yalnız seçili özellikler firma menüsünde görünür. e-Belge seçimi servis aktivasyonu yerine geçmez. Bağlı kayıt özellikleri gerektiğinde birlikte eklenir.</p>';
 echo '<p><button type="button" class="button quiet" data-features-select="all">Tümünü seç</button> <button type="button" class="button quiet" data-features-select="none">Seçimi temizle</button></p>';
 $groups=[];foreach(plan3616_selectable() as $key=>$v)$groups[plan3616_category($key)][$key]=$v;
 foreach($groups as $category=>$items){$count=count(array_intersect(array_keys($items),$cfg['plans'][$code]));echo '<details '.($category==='Elektronik Belgeler'?'open':'').'><summary>'.esc($category).' · '.$count.' / '.count($items).' seçili</summary><div class="form-stack">';foreach($items as $key=>$v)echo '<label><input type="checkbox" name="features[]" value="'.esc($key).'" '.(in_array($key,$cfg['plans'][$code],true)?'checked':'').'> '.esc($v[1]).(!launch3619_available($key)?' <small class="admin-availability3619">Müşteri erişimine kapalı · sağlayıcı bağlantısı tamamlanmalı</small>':'').'</label>';echo '</div></details>';}
 echo '</fieldset>';input('current_password','Mevcut yönetici şifreniz','','password','required autocomplete="current-password"');
}
function plan3616_save(string $code): void {
 if(!isset($_POST['feature_selection']))throw new DomainException('Paket formunu yenileyip tekrar kaydedin.');
 $selected=$_POST['features']??[];if(!is_array($selected)||array_filter($selected,fn($v)=>!is_string($v))||array_diff($selected,array_keys(plan3616_selectable())))throw new DomainException('Geçerli paket özelliklerini seçin.');
 $q=query("SELECT value FROM settings WHERE name='plan_features_3616' FOR UPDATE");$raw=$q->fetchColumn();if($raw===false)throw new DomainException('Paket özellikleri geçişi uygulanmamış.');$cfg=json_decode($raw,true,64,JSON_THROW_ON_ERROR);
 if(int_field('feature_revision',0,PHP_INT_MAX)!==$cfg['revision'])throw new DomainException('Paketler başka bir işlemde değiştirildi. Sayfayı yenileyip tekrar kaydedin.');
 // Required source-record capabilities; independent e-document kinds stay independent.
 $deps=['quotes'=>['bookkeeping'],'sharing'=>['bookkeeping'],'payment_links'=>['bookkeeping'],'statements'=>['bookkeeping'],'currency'=>['bookkeeping'],'cheques'=>['bookkeeping'],'staff_money'=>['bookkeeping'],'quantity'=>['bookkeeping'],'reminders'=>['bookkeeping'],'profit'=>['bookkeeping'],'projects'=>['bookkeeping'],'forecast'=>['bookkeeping'],'bank_match'=>['bookkeeping'],'reconciliation'=>['bookkeeping'],'aging'=>['bookkeeping'],'advanced_reports'=>['bookkeeping'],'templates'=>['bookkeeping'],'edoc_invoice'=>['bookkeeping'],'edoc_archive'=>['bookkeeping'],'edoc_smm'=>['bookkeeping','smm'],'edoc_despatch'=>['bookkeeping'],'edoc_export'=>['bookkeeping'],'returns'=>['bookkeeping'],'smm'=>['bookkeeping'],'orders'=>['bookkeeping'],'recurring'=>['bookkeeping'],'bulk'=>['bookkeeping']];
 foreach($selected as $key)foreach($deps[$key]??[] as $dep)$selected[]=$dep;
 $cfg['plans'][$code]=array_values(array_unique($selected));$cfg['revision']++;unset($GLOBALS['plan3616_cache']);query("UPDATE settings SET value=? WHERE name='plan_features_3616'",[json_encode($cfg,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);audit('plan.features_changed',['code'=>$code,'features'=>$cfg['plans'][$code]]);
}
function plan3616_nav_allowed(string $page,array $params): bool {
 if(!plan351_link_allowed($page,$params))return false;if(in_array($page,['edoc_center','incoming_invoices','settings','users','membership','service_center','migration','crm','projects','automation','repeat_rules','bulk_center','templates','approval_rules','bank_match','referrals','company_notices','support_center'],true)&&!firm_manager_visible3616())return false;
 if($page==='service_center')return has_feature('public_api');
 return true;
}
function plan3616_save_modules(array $modules): void {
 $row=query("SELECT value FROM settings WHERE name='plan_features_3616' FOR UPDATE")->fetchColumn();if($row===false)throw new DomainException('Paket özellik geçişi uygulanmamış.');$cfg=json_decode($row,true,64,JSON_THROW_ON_ERROR);
 foreach($cfg['plans'] as $code=>&$features)foreach($modules as $key=>$module){$features=array_values(array_diff($features,[$key]));if(in_array($code,$module['plans'],true))$features[]=$key;}unset($features);$cfg['revision']++;unset($GLOBALS['plan3616_cache']);query("UPDATE settings SET value=? WHERE name='plan_features_3616'",[json_encode($cfg,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);
}
function plan3616_feature_labels(string $code): array {$labels=[];foreach(plan3616_selectable() as $key=>$f){if(!plan3616_has($code,$key))continue;if(!launch3619_plan_has($code,$key))continue;$labels[]=$f[1];}return $labels;}
function nav3616_groups(): array {return [
 ['sales','sale','Satışlar',[
 ['documents','Teklifler',['kind'=>'quote']],['documents','Proformalar',['kind'=>'proforma']],['documents','Siparişler',['kind'=>'order']],['documents','Satış faturaları',['kind'=>'sale']],['returns','İade kayıtları',[]],['smm','Makbuz kayıtları',[]],['recurring','Tekrarlayan satışlar',[]],['shares','Müşteri paylaşımları',[]],['approvals','Onay bekleyenler',[]]]],
 ['edocs','sale','Elektronik Belgeler',[
 ['edoc_center','e-Fatura',['kind'=>'invoice']],['edoc_center','e-Arşiv',['kind'=>'archive']],['edoc_center','e-İrsaliye',['kind'=>'despatch']],['edoc_center','e-SMM',['kind'=>'smm']],['edoc_center','e-İhracat',['kind'=>'export']],['incoming_invoices','Gelen e-Faturalar',[]],['incoming_invoices','Gelen e-İrsaliyeler',['kind'=>'despatch']],['edoc_center','Bağlantı ayarları',['tab'=>'connection']]]],
 ['purchases','buy','Alışlar ve Giderler',[
 ['documents','Alış faturaları',['kind'=>'purchase']],['documents','Gider kayıtları',['kind'=>'expense']],['staff_money','Çalışan giderleri / avanslar',[]]]],
 ['contacts','people','Müşteri ve Tedarikçiler',[
 ['contacts','Müşteriler',['kind'=>'customer']],['contacts','Tedarikçiler',['kind'=>'supplier']],['contacts','Tüm cari kartları',[]],['reconciliations','Cari mutabakatlar',[]]]],
 ['products','box','Ürün ve Hizmetler',[
 ['products','Ürünler',['kind'=>'product']],['products','Hizmetler',['kind'=>'service']],['products','Fiyat listesi',['kind'=>'prices']],['quantity','Ürün miktar hareketleri',[]]]],
 ['money','wallet','Kasa ve Banka',[
 ['accounts','Kasa ve banka hesapları',[]],['payments','Tahsilat ve ödemeler',[]],['cheques','Çek takibi',[]],['cashflow','Nakit takvimi',[]],['reminders','Vade hatırlatmaları',[]],['bank_match','Banka dosyası eşleştirme',[]]]],
 ['work','people','İş ve Müşteri Takibi',[
 ['crm','Satış fırsatları',[]],['tasks','İş takibi',[]],['projects','İş / proje kârlılığı',[]],['automation','Takip kuralları',[]],['repeat_rules','Tekrarlayan belgeler',[]],['bulk_center','Toplu işlemler',[]]]],
 ['reports','chart','Raporlar',[
 ['reports','Satış raporu',['view'=>'sales']],['reports','Gider raporu',['view'=>'expenses']],['reports','Alacak ve borçlar',['view'=>'balances']],['reports','Kasa ve banka',['view'=>'cash']],['reports','Brüt kârlılık',['view'=>'profit']],['aging','Borç / alacak yaşlandırma',[]],['currency_report','Döviz / kur farkları',[]],['advanced_reports','Ayrıntılı raporlar',[]],['forecast','30 / 60 / 90 nakit öngörüsü',[]]]],
 ['web','spark','Web ve Reklam',[
 ['website','Web sitem',[]],['digital_ads','Meta reklam yönetimi',['channel'=>'meta']],['digital_ads','Google reklam yönetimi',['channel'=>'google']]]],
 ['settings','gear','Firma ve Ayarlar',[
 ['settings','Firma bilgileri',[]],['users','Şirket çalışanları',[]],['settings','SMMM / YMM erişimi',['section'=>'advisor']],['membership','Üyelik paketim',[]],['templates','Belge şablonları',[]],['approval_rules','Onay kuralları',[]],['migration','Veri taşıma merkezi',[]],['service_center','Servis merkezi',[]],['account','Şifre ve güvenlik',[]],['audit','İşlem geçmişi',[]],['referrals','Arkadaşını davet et',[]],['company_notices','Bildirimlerim',[]]]],
 ['support','people','Destek ve Rehberler',[
 ['library3616','Kullanım kütüphanesi',[]],['help','Destek taleplerim',[]],['support_center','Kobivira canlı destek',[]]]]
 ];}
function guide3616_catalog(): array {static $c;return $c??=json_decode(file_get_contents(__DIR__.'/Guide3616.json'),true,64,JSON_THROW_ON_ERROR);}
function guide3616_navigation(array $page): string {
 $g=guide3616_catalog()[$page['slug']]??null;if(!$g)return '';return '<section class="guide354-plans"><strong>Panelde nerede?</strong><p>'.esc($g['path']).'</p><a class="button" href="https://app.kobivira.com.tr/?'.esc(http_build_query(['page'=>$g['page']]+$g['params'])).'">Panelde bu bölümü aç</a><p>Giriş yaptıktan sonra, paketinizin ve kullanıcı yetkinizin kapsadığı bölümü açabilirsiniz.</p></section>';
}

function firm_manager_visible3616(): bool {return (current_user()['role']??'')==='company_admin'&&!support_context();}

function plan3616_category(string $key): string {
 if(str_starts_with($key,'edoc_'))return 'Elektronik Belgeler';
 return match($key){'bookkeeping','quotes','orders','returns','smm','sharing','recurring','templates'=>'Satışlar ve kayıtlar','currency','cheques','staff_money','reminders','bank_match','payment_links'=>'Kasa ve Banka','statements','aging','reconciliation','profit','forecast','advanced_reports','export'=>'Raporlar','tasks','projects','crm','automation','bulk'=>'İş ve Müşteri Takibi','approvals','roles','audit','approval_rules'=>'Firma ve yetkiler','quantity'=>'Ürün ve Hizmetler',default=>'Web, reklam ve servisler'};
}
