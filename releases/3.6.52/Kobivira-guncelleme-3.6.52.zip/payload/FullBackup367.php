<?php
declare(strict_types=1);

/** Full application snapshot. Caller must hold the exclusive application gate. */
final class FullBackup367 {
    public function __construct(private PDO $db) {}
    public static function folder(): string {
        $p=APP_ROOT.'/storage/full-backups';
        if(!is_dir($p)&&!mkdir($p,0700,true))throw new RuntimeException('Yedek klasörü oluşturulamadı.');
        if(is_link($p))throw new RuntimeException('Yedek klasörü bağlantı olamaz.');chmod($p,0700);return $p;
    }
    public static function key(bool $create=false): string {
        $p=APP_ROOT.'/config/backup367.key';
        if(!is_file($p)&&$create)atomic_write($p,random_bytes(SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_KEYBYTES));
        if(is_link($p)||!is_file($p))throw new DomainException('Yedek kurtarma anahtarı bulunamadı.');
        $key=file_get_contents($p);if(strlen($key)!==SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_KEYBYTES)throw new DomainException('Yedek kurtarma anahtarı geçersiz.');return $key;
    }
    public static function settings(): array {
        $p=self::folder().'/settings.json';$v=is_file($p)?json_decode(file_get_contents($p),true,16,JSON_THROW_ON_ERROR):[];
        return array_replace(['enabled'=>true,'time'=>'20:00','keep'=>7],$v);
    }
    public static function due(array $settings,array $state,DateTimeImmutable $now): bool {
        $local=$now->setTimezone(new DateTimeZone('Europe/Istanbul'));
        return !empty($settings['enabled'])&&$local->format('H:i')>=$settings['time']&&($state['scheduled_day']??'')!==$local->format('Y-m-d');
    }
    public static function state(): array {
        $p=self::folder().'/state.json';return is_file($p)?json_decode(file_get_contents($p),true,16,JSON_THROW_ON_ERROR):[];
    }
    public static function writeState(array $v): void {atomic_write(self::folder().'/state.json',json_encode($v,JSON_THROW_ON_ERROR));}
    public static function validName(string $n): bool {return (bool)preg_match('/^full-\d{8}-\d{6}-[a-f0-9]{12}\.kvbak$/D',$n);}
    public static function safePath(string $p): bool {
        if($p===''||strlen($p)>1000||str_contains($p,"\0")||str_contains($p,'\\')||str_starts_with($p,'/'))return false;
        foreach(explode('/',$p) as $part)if($part===''||$part==='.'||$part==='..')return false;
        return true;
    }
    private static function excluded(string $p): bool {
        foreach(['storage/full-backups','storage/backups','storage/staging','storage/sessions','storage/logs'] as $root)if($p===$root||str_starts_with($p,$root.'/'))return true;
        if(in_array($p,['config/backup367.key','config/install-token.txt','storage/request.lock','storage/maintenance.json'],true)||str_ends_with($p,'.tmp'))return true;
        // Only the active release is needed for this restore point.
        return str_starts_with($p,'releases/')&&$p!=='releases/'.APP_VERSION&&!str_starts_with($p,'releases/'.APP_VERSION.'/');
    }
    private function fileList(): array {
        $root=realpath(APP_ROOT);$out=[];
        $walk=function(string $dir,string $prefix='')use(&$walk,&$out,$root):void {
            $items=scandir($dir);if($items===false)throw new RuntimeException('Yedek dosya listesi okunamadı.');
            foreach($items as $name){if($name==='.'||$name==='..')continue;$rel=$prefix.$name;if(self::excluded($rel))continue;$path=$dir.'/'.$name;
                if(!self::safePath($rel)||is_link($path))throw new RuntimeException('Yedek kapsamındaki dosya yolu güvenli değil.');
                if(is_dir($path)){$walk($path,$rel.'/');continue;}
                if(!is_file($path)||!is_readable($path)||!str_starts_with((string)realpath($path),$root.'/'))throw new RuntimeException('Yedek kapsamındaki dosya okunamadı.');$out[$rel]=$path;
            }
        };$walk($root);ksort($out);return $out;
    }
    private static function writeAll($f,string $bytes): void {
        $length=strlen($bytes);$offset=0;while($offset<$length){$n=fwrite($f,substr($bytes,$offset));if(!$n)throw new RuntimeException('Yedek diske yazılamadı.');$offset+=$n;}
    }
    private static function crypt(string $input,string $output,string $key,bool $encrypt): void {
        $in=fopen($input,'rb');$out=fopen($output,'xb');if(!$in||!$out)throw new RuntimeException('Şifreli yedek dosyası açılamadı.');chmod($output,0600);
        try {
            if($encrypt){[$state,$header]=sodium_crypto_secretstream_xchacha20poly1305_init_push($key);self::writeAll($out,'KVB367'.$header);
                while(!feof($in)){$chunk=fread($in,1048576);if($chunk===false)throw new RuntimeException('Yedek okunamadı.');if($chunk==='')break;$cipher=sodium_crypto_secretstream_xchacha20poly1305_push($state,$chunk);self::writeAll($out,pack('N',strlen($cipher)).$cipher);}
                $cipher=sodium_crypto_secretstream_xchacha20poly1305_push($state,'','',SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL);self::writeAll($out,pack('N',strlen($cipher)).$cipher);
            }else{
                if(fread($in,6)!=='KVB367')throw new DomainException('Yedek dosya biçimi geçersiz.');$header=fread($in,SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_HEADERBYTES);$state=sodium_crypto_secretstream_xchacha20poly1305_init_pull($header,$key);$final=false;
                while(!feof($in)){$length=fread($in,4);if($length==='')break;if(strlen($length)!==4)throw new DomainException('Yedek kesilmiş.');$n=unpack('N',$length)[1];if($n<17||$n>1048593)throw new DomainException('Yedek parçası geçersiz.');$bytes='';while(strlen($bytes)<$n){$part=fread($in,$n-strlen($bytes));if($part===false||$part==='')throw new DomainException('Yedek parçası eksik.');$bytes.=$part;}$r=sodium_crypto_secretstream_xchacha20poly1305_pull($state,$bytes);if($r===false)throw new DomainException('Yedek şifresi veya bütünlüğü doğrulanamadı.');[$plain,$tag]=$r;self::writeAll($out,$plain);if($tag===SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL){$final=true;if(!feof($in)&&fread($in,1)!=='')throw new DomainException('Yedek sonundan sonra veri var.');break;}}
                if(!$final)throw new DomainException('Yedek tamamlanmamış.');
            }
        }finally{fclose($in);fclose($out);}
    }
    public function create(string $reason): array {
        $dir=self::folder();$key=self::key(true);$name='full-'.gmdate('Ymd-His').'-'.bin2hex(random_bytes(6)).'.kvbak';$plain=$dir.'/'.$name.'.zip.tmp';$encrypted=$dir.'/'.$name.'.tmp';$database=null;$zip=null;
        try{
            $database=(new Backup($this->db))->create();$dbPath=APP_ROOT.'/storage/backups/'.$database['file'];$files=$this->fileList();$manifest=['format'=>1,'version'=>APP_VERSION,'created_at'=>gmdate('c'),'database_sha256'=>$database['sha256'],'files'=>[]];
            $zip=new ZipArchive();if($zip->open($plain,ZipArchive::CREATE|ZipArchive::EXCL)!==true)throw new RuntimeException('Yedek arşivi oluşturulamadı.');if(!$zip->addFile($dbPath,'database.jsonl.gz'))throw new RuntimeException('Veritabanı arşive eklenemedi.');
            foreach($files as $rel=>$path){$hash=hash_file('sha256',$path);if(!$hash||!$zip->addFile($path,'files/'.$rel))throw new RuntimeException('Dosya arşive eklenemedi.');$manifest['files'][$rel]=['sha256'=>$hash,'bytes'=>filesize($path)];}
            if(!$zip->addFromString('snapshot.json',json_encode($manifest,JSON_THROW_ON_ERROR))||!$zip->close())throw new RuntimeException('Yedek arşivi tamamlanamadı.');$zip=null;chmod($plain,0600);
            self::crypt($plain,$encrypted,$key,true);$target=$dir.'/'.$name;if(!rename($encrypted,$target))throw new RuntimeException('Yedek etkinleştirilemedi.');
            $this->inspect($name);
            $meta=['file'=>$name,'version'=>APP_VERSION,'created_at'=>$manifest['created_at'],'reason'=>$reason,'bytes'=>filesize($target),'files'=>count($files),'sha256'=>hash_file('sha256',$target)];
            atomic_write($target.'.json',json_encode($meta,JSON_THROW_ON_ERROR));return $meta;
        }finally{if($zip instanceof ZipArchive)$zip->close();@unlink($plain);foreach(glob($plain.'.*')?:[] as $tmp)@unlink($tmp);@unlink($encrypted);if($database)@unlink(APP_ROOT.'/storage/backups/'.$database['file']);}
    }
    public function inspect(string $name): array {
        if(!self::validName($name))throw new DomainException('Yedek adı geçersiz.');$dir=self::folder();$path=$dir.'/'.$name;
        if(!is_file($path)||is_link($path))throw new DomainException('Yedek bulunamadı.');$plain=$dir.'/verify-'.bin2hex(random_bytes(8)).'.zip.tmp';
        try{
            self::crypt($path,$plain,self::key(),false);$z=new ZipArchive();if($z->open($plain,ZipArchive::CHECKCONS)!==true)throw new DomainException('Yedek arşivi okunamadı.');
            try{$raw=$z->getFromName('snapshot.json');if(!is_string($raw)||strlen($raw)>16777216)throw new DomainException('Yedek manifesti geçersiz.');$m=json_decode($raw,true,64,JSON_THROW_ON_ERROR);
                if(($m['format']??null)!==1||!preg_match('/^\d+\.\d+\.\d+$/D',$m['version']??'')||!is_array($m['files']??null)||!isset($m['files']['config/app.php'],$m['files']['storage/current.json'],$m['files']['releases/'.$m['version'].'/Modules.php']))throw new DomainException('Yedek zorunlu dosyaları eksik.');
                $expected=['snapshot.json'=>true,'database.jsonl.gz'=>true];foreach($m['files'] as $rel=>$entry){if(!self::safePath($rel)||!is_array($entry)||!preg_match('/^[a-f0-9]{64}$/D',$entry['sha256']??'')||!is_int($entry['bytes']??null)||$entry['bytes']<0||$rel==='config/backup367.key')throw new DomainException('Yedek dosya bilgisi geçersiz.');$expected['files/'.$rel]=true;}
                if($z->numFiles!==count($expected))throw new DomainException('Yedek dosya sayısı uyuşmuyor.');for($i=0;$i<$z->numFiles;$i++){ $entry=$z->statIndex($i);if(!isset($expected[$entry['name']]))throw new DomainException('Yedekte beklenmeyen dosya var.');unset($expected[$entry['name']]);}if($expected)throw new DomainException('Yedek dosyası eksik.');
                $verify=function(string $entry,string $hash,?int $size=null)use($z){$f=$z->getStream($entry);if(!$f)throw new DomainException('Yedek içeriği okunamadı.');$ctx=hash_init('sha256');$bytes=hash_update_stream($ctx,$f);fclose($f);if(!hash_equals($hash,hash_final($ctx))||($size!==null&&$bytes!==$size))throw new DomainException('Yedek içerik özeti uyuşmuyor.');};
                if(!preg_match('/^[a-f0-9]{64}$/D',$m['database_sha256']??''))throw new DomainException('Veritabanı özeti geçersiz.');$verify('database.jsonl.gz',$m['database_sha256']);foreach($m['files'] as $rel=>$entry)$verify('files/'.$rel,$entry['sha256'],$entry['bytes']);return $m;
            }finally{$z->close();}
        }finally{@unlink($plain);}
    }
    public static function listing(): array {
        $rows=[];foreach(glob(self::folder().'/full-*.kvbak.json')?:[] as $p){$m=json_decode(file_get_contents($p),true);if(is_array($m)&&self::validName($m['file']??'')&&is_file(self::folder().'/'.$m['file']))$rows[]=$m;}usort($rows,fn($a,$b)=>strcmp($b['file'],$a['file']));return $rows;
    }
    public static function prune(int $keep): void {
        // Only this module's completed automatic backups are rotated; manual snapshots remain.
        $rows=array_values(array_filter(self::listing(),fn($r)=>$r['reason']==='scheduled'));foreach(array_slice($rows,$keep) as $r){@unlink(self::folder().'/'.$r['file']);@unlink(self::folder().'/'.$r['file'].'.json');}
    }
    /** Restore is intentionally CLI-only and requires an explicit all-company confirmation. */
    public function restore(string $name): void {
        if(PHP_SAPI!=='cli')throw new DomainException('Geri yükleme yalnız sunucu komut satırından yapılır.');$m=$this->inspect($name);$dir=self::folder();$plain=$dir.'/restore-'.bin2hex(random_bytes(8)).'.zip.tmp';$stage=$dir.'/restore-stage-'.bin2hex(random_bytes(8));$dbName='backup-restore-'.bin2hex(random_bytes(8)).'.jsonl.gz';$moves=[];$switched=false;
        try{
            self::crypt($dir.'/'.$name,$plain,self::key(),false);if(!mkdir($stage,0700))throw new RuntimeException('Kurtarma alanı açılamadı.');$z=new ZipArchive();if($z->open($plain)!==true)throw new RuntimeException('Kurtarma arşivi açılamadı.');
            try{
                $copy=function(string $entry,string $target)use($z){$in=$z->getStream($entry);if(!$in)throw new RuntimeException('Kurtarma girdisi okunamadı.');$parent=dirname($target);if(!is_dir($parent)&&!mkdir($parent,0700,true))throw new RuntimeException('Kurtarma klasörü açılamadı.');$out=fopen($target,'xb');if(!$out)throw new RuntimeException('Kurtarma dosyası açılamadı.');chmod($target,0600);try{if(stream_copy_to_stream($in,$out)===false)throw new RuntimeException('Kurtarma dosyası yazılamadı.');}finally{fclose($in);fclose($out);}};
                $copy('database.jsonl.gz',APP_ROOT.'/storage/backups/'.$dbName);foreach($m['files'] as $rel=>$entry)$copy('files/'.$rel,$stage.'/new/'.$rel);
            }finally{$z->close();}
            // Keep current server database credentials; recover the snapshot's encryption key and settings.
            $cfg=require $stage.'/new/config/app.php';$cfg['database']=config()['database'];atomic_write($stage.'/new/config/app.php',"<?php return ".var_export($cfg,true).';');
            foreach(array_keys($m['files']) as $rel){$target=APP_ROOT.'/'.$rel;clearstatcache(true,$target);$parent=dirname($target);$probe=$parent;while(str_starts_with($probe,APP_ROOT)&&$probe!==APP_ROOT){if(is_link($probe))throw new DomainException('Kurtarma hedefi bağlantı olamaz.');$probe=dirname($probe);}if(is_link($target)||is_dir($target))throw new DomainException('Kurtarma dosya hedefi uygun değil.');if(!is_dir($parent)&&!mkdir($parent,0700,true))throw new RuntimeException('Kurtarma hedefi açılamadı.');$old=null;if(is_file($target)){$old=$stage.'/old/'.$rel;if(!is_dir(dirname($old)))mkdir(dirname($old),0700,true);if(!rename($target,$old))throw new RuntimeException('Mevcut dosya korunamadı.');}$moves[]=[$target,$old];if(!rename($stage.'/new/'.$rel,$target))throw new RuntimeException('Kurtarma dosyası etkinleştirilemedi.');}
            (new Backup($this->db))->restore(['file'=>$dbName,'sha256'=>$m['database_sha256']]);$switched=true;
            // Remove authenticated sessions; restored permissions must take effect at next login.
            foreach(glob(APP_ROOT.'/storage/sessions/sess_*')?:[] as $p)if(is_file($p)&&!is_link($p))@unlink($p);
        }finally{
            if(!$switched)foreach(array_reverse($moves) as [$target,$old]){if(is_file($target))@unlink($target);if($old&&is_file($old))@rename($old,$target);}
            @unlink(APP_ROOT.'/storage/backups/'.$dbName);@unlink($plain);if(is_dir($stage))Updater::remove_tree($stage);
        }
    }
}

function backup367_guard(): void {
    if((base_user()['role']??'')!=='platform_admin'||support_context()||isset($_GET['support'])||!empty($GLOBALS['follow_mode'])){http_response_code(403);throw new DomainException('Yedekler yalnız platform yöneticisine açıktır.');}
}
function backup367_post(string $action): never {
    backup367_guard();reauthenticate(base_user());$dir=FullBackup367::folder();
    if($action==='settings'){$time=required_field('backup_time',5);if(!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/D',$time))throw new DomainException('Geçerli yedek saati seçin.');$keep=int_field('backup_keep',2,30);FullBackup367::key(true);atomic_write($dir.'/settings.json',json_encode(['enabled'=>isset($_POST['enabled']),'time'=>$time,'keep'=>$keep],JSON_THROW_ON_ERROR));flash('Yedek ayarı kaydedildi. Otomatik çalışma için ekrandaki sunucu zamanlayıcısı kurulmalıdır.');}
    elseif($action==='create'){if(is_file($dir.'/pending.json'))throw new DomainException('Bir elle yedekleme talebi zaten bekliyor.');FullBackup367::key(true);atomic_write($dir.'/pending.json',json_encode(['actor'=>(int)base_user()['id'],'requested_at'=>gmdate('c')],JSON_THROW_ON_ERROR));flash('Tam yedekleme sıraya alındı. Sunucu zamanlayıcısının bir sonraki çalışmasında başlayacak.');}
    elseif(in_array($action,['download','key'],true)){
        if($action==='key'){$bytes=base64_encode(FullBackup367::key())."\n";$filename='Kobivira-yedek-kurtarma-anahtari.txt';}
        else{$name=required_field('backup_file',100);if(!FullBackup367::validName($name)||is_link($dir.'/'.$name)||!is_file($dir.'/'.$name))throw new DomainException('Yedek bulunamadı.');$meta=json_decode((string)file_get_contents($dir.'/'.$name.'.json'),true);if(!hash_equals($meta['sha256']??'',hash_file('sha256',$dir.'/'.$name)))throw new DomainException('Yedek dosyası doğrulanamadı.');$filename=$name;}
        audit('backup.download',['reason'=>$action==='key'?'Kurtarma anahtarı indirildi':'Şifreli tam yedek indirildi']);header('Content-Type: application/octet-stream');header('Content-Disposition: attachment; filename="'.$filename.'"');header('Cache-Control: private, no-store');header('X-Content-Type-Options: nosniff');if($action==='key')echo $bytes;else readfile($dir.'/'.$name);exit;
    }else throw new DomainException('Yedek işlemi geçersiz.');
    audit('backup.'.$action);redirect('backups');
}
function backup367_view(): void {
    backup367_guard();$s=FullBackup367::settings();$state=FullBackup367::state();heading('Sistem yedekleri','Yönetim ve tüm firmalar için şifreli veritabanı, dosya, ayar ve çalışan sürüm yedeği.');
    panel('Çalışma durumu');if(empty($state['heartbeat'])||time()-(int)strtotime($state['heartbeat'])>180)echo '<p role="status">Sunucu zamanlayıcısının düzenli çalıştığı henüz doğrulanmadı. Otomatik yedek etkin kabul edilmemelidir.</p>';echo '<p>Son zamanlayıcı kontrolü: '.esc($state['heartbeat']??'Henüz çalışmadı').'</p><p>Son başarılı yedek: '.esc($state['last_success']??'Henüz yok').'</p><p>Son sonuç: '.esc($state['message']??'Sunucu zamanlayıcısı henüz doğrulanmadı.').'</p>';if(is_file(FullBackup367::folder().'/pending.json'))echo '<p>Elle yedekleme isteği sırada.</p>';echo '</section>';
    panel('Otomatik yedekleme','Saat Türkiye saatidir. Son başarılı otomatik yedekler saklanır; elle alınan yedekler otomatik silinmez.');form_start('backups','settings');echo '<label><input type="checkbox" name="enabled" value="1" '.($s['enabled']?'checked':'').'> Günlük otomatik yedeklemeyi aç</label>';input('backup_time','Günlük saat',$s['time'],'time','required');input('backup_keep','Saklanacak otomatik yedek sayısı',$s['keep'],'number','required min="2" max="30"');input('current_password','Yönetici şifreniz','','password','required autocomplete="current-password"');form_end('Yedek ayarlarını kaydet');echo '</section>';
    panel('Elle tam yedek al','İstek sıraya alınır. Zamanlayıcı başladığında kısa süreli bakım kilidiyle tutarlı kopya hazırlanır.');form_start('backups','create');input('current_password','Yönetici şifreniz','','password','required autocomplete="current-password"');form_end('Tam yedeklemeyi sıraya al');echo '</section>';
    panel('Kurtarma anahtarı','Şifreli yedeği açmak için gerekir. Bir kez indirip sunucudan ayrı, güvenli bir yerde saklayın. Sunucu tamamen kaybolursa yedek dosyası tek başına yeterli değildir.');echo '<form method="post" action="'.esc(url('backups')).'">'.csrf_field();hidden('action','key');input('current_password','Yönetici şifreniz','','password','required autocomplete="current-password"');submit('Kurtarma anahtarını indir');echo '</form></section>';
    panel('Tamamlanan yedekler');table_start(['Zaman · UTC','Tür','Sürüm','Boyut','İndir']);$rows=FullBackup367::listing();foreach($rows as $r){echo '<tr><td>'.esc($r['created_at']).'</td><td>'.esc($r['reason']==='scheduled'?'Otomatik':'Elle / geri yükleme öncesi').'</td><td>'.esc($r['version']).'</td><td>'.number_format($r['bytes']/1048576,2,',','.').' MB</td><td><form method="post" action="'.esc(url('backups')).'">'.csrf_field();hidden('action','download');hidden('backup_file',$r['file']);input('current_password','Yönetici şifresi','','password','required autocomplete="current-password"');submit('Şifreli yedeği indir');echo '</form></td></tr>';}table_end(count($rows),5);echo '</section>';
    panel('Sunucu zamanlayıcısı ve geri yükleme');$command='php '.escapeshellarg(APP_ROOT.'/KobiviraCron.php');echo '<p>Hosting panelinde aşağıdaki komutu her dakika çalıştırın. PHP yolunu hostinginizin PHP 8.2+ CLI yolu ile değiştirin. Komut güncel sürümü işaretçiden bulur; sonraki güncellemelerde yeniden tanımlamak gerekmez.</p><pre>'.esc('* * * * * '.$command.' --run').'</pre><p>Geri yükleme tüm firmaları seçilen tarihe döndürür. Panelden tek tıklamayla yapılmaz; önce doğrulama, mevcut durumun kurtarma yedeği ve açık sunucu onayı gerekir. Ayrıntılar sürümdeki YEDEKLEME_3_6_7.md dosyasındadır.</p><p>Yedek yalnız bu uygulamanın özel kurulum klasörünü kapsar; hosting hesabı, e-posta, haricî dosya depoları ve bu klasör dışındaki web dosyaları hosting yedeğiyle korunmalıdır. Aynı sunucudaki yedek, sunucunun tamamının kaybına karşı tek başına koruma sağlamaz.</p></section>';
}
