<?php
declare(strict_types=1);
function marketing3632_phone():string {$v=cms_s('phone','0850 304 7681',1);$digits=preg_replace('/\D/','',$v);return '<a class="kv32-phone" href="tel:'.esc(str_starts_with($digits,'0')?'+90'.substr($digits,1):'+'.$digits).'">'.esc($v).'</a>';}
function marketing3632_home(string $body):string {
 if(!str_contains($body,'kv32-hero'))return commerce_home($body).migration_promo();
 // Explicitly published statistics remain available; hide their empty placeholder state.
 if(setting('public_metrics_enabled','0')==='1')$body.=str_replace('class="kv-impact wrap"','class="kv-impact wrap" hidden data-kv32-metrics',commerce_stats());
 return $body.'<section class="kv32-wrap kv32-credit-link kv36-editable">'.quick3636_control('https://app.kobivira.com.tr/?page=credits').'<div><h2>Elektronik belge için kontör seçenekleri</h2><p>Güncel paketleri ve kullanım koşullarını inceleyin.</p></div><a class="kv32-text-link" href="paketler.html#kontor-fiyatlari">Kontör paketlerini inceleyin →</a></section>'.commerce_faq().migration_promo();
}
function marketing3632_scope():string {
 $rows=['base_records'=>'Satış, alış, gider ve cari hesap','edocs'=>'e-Fatura, e-Arşiv ve gelen e-Fatura','edoc_despatch'=>'e-İrsaliye','edoc_smm'=>'e-SMM','edoc_export'=>'e-İhracat'];
 // All labels below derive from the actual admin-configured package catalog.
 $out='<div class="kv32-package-scope">';foreach(['kobi'=>'KOBİ','plus'=>'KOBİ Plus','business'=>'KOBİ Business'] as $code=>$label){$out.='<article><h3>'.$label.'</h3><p>'.esc(package3627_intro($code)).'</p><ul>';foreach(package3627_summary($code) as $feature)$out.='<li>'.esc($feature).'</li>';$out.='</ul></article>';}return $out.'</div>';
}
function marketing3632_reviews(int $sid):string {
 if($sid!==1)return '';$rows=query('SELECT id,display_name,company_name,person_role,quote FROM cms_reviews WHERE site_id=1 AND is_published=1 AND consent_confirmed=1 AND customer_verified=1 ORDER BY sort_order,id LIMIT 4')->fetchAll();if(!$rows)return '';
 $out='<section class="kv32-soft"><div class="kv32-wrap kv32-section"><header class="kv32-section-head"><span class="kv32-eyebrow">İŞİN İÇİNDEN DENEYİMLER</span><h2>Her işletmenin<br>kendi hikâyesi var.</h2><p>Kobivira’yı kullanan işletmelerden, kendi sözleriyle.</p></header><div class="kv32-stories">';foreach($rows as $i=>$r){$initial=mb_substr($r['company_name']?:$r['display_name'],0,1);$out.='<article class="kv32-story kv36-editable '.($i===0?'kv32-story-featured':'').'">'.quick3636_control(quick3636_url('reviews',(int)$r['id'])).'<span class="kv32-story-quote" aria-hidden="true">“</span><blockquote>'.esc($r['quote']).'</blockquote><div class="kv32-story-person"><span class="kv32-avatar" aria-hidden="true">'.esc($initial).'</span><div><strong>'.esc($r['display_name']).'</strong><span>'.esc(implode(' · ',array_filter([$r['person_role'],$r['company_name']]))).'</span></div></div></article>';}
 return $out.'</div></div></section>';
}
function marketing3632_footer(int $sid,string $brand):string {
 $logo=cms_s('logo_url','assets/kobivira-logo.png',$sid);$mark=$logo==='assets/kobivira-logo.png'?'<svg viewBox="350 220 590 600" aria-hidden="true"><image href="assets/kobivira-logo.png" width="1254" height="1254"/></svg>':($logo!==''?'<img src="'.esc($logo).'" alt="'.esc($brand).'">':'');
 $out='<footer class="footer kv32-footer kv36-editable">'.quick3636_control(quick3636_url('settings')).'<div class="kv32-footer-grid"><div class="kv32-footer-brand"><a class="logo" href="index.html">'.$mark.'<span>'.esc($brand).'</span></a><p>'.esc(cms_s('footer_text','İşinizin hesabı, kontrolünüzde.',$sid)).'</p><span class="kv32-footer-caption">BİZE ULAŞIN</span>'.marketing3632_phone().'<a href="mailto:'.esc(cms_s('contact_email','info@kobivira.com.tr',$sid)).'">'.esc(cms_s('contact_email','info@kobivira.com.tr',$sid)).'</a>'.footer3630_social($sid).'</div>';
 $scopes=footer3630_titles();$order=['footer_product','footer_resources','footer_company','footer_legal'];foreach($order as $scope){$title=cms_s($scope.'_title',$scopes[$scope],1);$links='';foreach(query('SELECT * FROM cms_nav WHERE site_id=1 AND scope=? AND is_visible=1 ORDER BY sort_order,id',[$scope]) as $n)$links.='<a href="'.esc($n['url']).'">'.esc($n['label']).'</a>';$out.='<section class="kv32-footer-group kv34-footer-group"><h3>'.esc($title).'</h3><nav aria-label="'.esc($title).'">'.$links.'</nav></section>';}
 return $out.'</div>'.tools3639_footer().'<div class="kv32-footer-payments">'.footer3630_payments($sid).'</div><div class="footer-bottom"><span>© '.date('Y').' Kobivira — İşletmeler için online ön muhasebe, gelir-gider ve finans takibi. Tüm hakları Kobivira.com’a aittir.</span><a href="#top">Yukarı ↑</a></div></footer>';
}
