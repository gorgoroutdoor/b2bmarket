# Kobivira 3.6.0 — Kütüphane güncellemesi

3.5.9 üzerine yönetim panelinden yüklenen imzalı tam sürüm güncellemesidir; yeniden kurulum değildir.

## Kurulum

Platform yöneticisi → Sistem → Sürüm güncellemeleri → bu ZIP dosyasını seçin → paket doğrulama ve güncelleme adımlarını tamamlayın.
Yükleme öncesi güncel hosting yedeğinizi saklayın. Güncelleyici ayrıca kendi veritabanı yedeğini oluşturur.
Bu paket yalnız 3.5.9 başlangıcını kabul eder. Kurulu sürüm farklıysa önce o sürüme uygun paket gerekir.

## Kapsam

- 77 rehber, 474 numaralı adım, 156 soru / yanıt, 60 firma menü hedefi.
- Her rehber: kullanılabilen paketler, menü yolu, ön koşullar, işlem sırası, sonuç, sorun kontrolü ve ilgili bağlantılar.
- Mevcut sayfa adresleri korunur. Yeni içerik veritabanına 032 migration ile bir kez işlenir.
- Mevcut rehber içerikleri değişmeden önce Site yönetimi → Tanıtım sitesi → İçerik geçmişi altında saklanır.
- Yöneticiye özel rehberler genel kütüphaneye açılmaz; firma web sitelerinin içerikleri güncellenmez.
- Rehberlerin mevcut taslak / yayın durumu ve özel SEO alt yazısı korunur. Yeni rehberler yayında eklenir.
- Standart rehberde başlık, açıklama ve HTML içerik yenilenir; eski metin alanları önceki içerikle birlikte geçmişte saklanır.
- Rehber alanında aynı adresi kullanan farklı türde özel sayfa varsa güncelleme o içeriği ezmek yerine durur; güncelleyicinin geri dönüş akışı geçerlidir.
- CSS / tema / görsel / tarayıcı kodları, paket fiyatı, kullanıcı kotası, veri taşıma kotası ve firma finans verisi değişmez.

## Yönetim ve destek kullanımı

Site yönetimi → Tanıtım sitesi → Sayfalar → Kütüphane bölümünden başlıkla arayın, içeriği düzenleyin, yayın durumunu değiştirin.
Kütüphane girişi: https://kobivira.com.tr/kutuphane.html
Tüm işlemler dizini: https://kobivira.com.tr/rehber-menu.html
Örnek destek bağlantısı: https://kobivira.com.tr/rehber-teklif.html
Belirli bir adım: https://kobivira.com.tr/rehber-teklif.html#adim-7
Bu sayfalar üyelik gerektirmeden okunur; firma özel verisi veya paylaşım tokenı içermez.
Destek mesajının içinde doğrudan bağlantıyı paylaşabilirsiniz. Mevcut sohbet uygulamasına otomatik rehber önerme veya link seçici eklenmedi.

## Gerçek işlem sınırları

Rehber metni yeni finansal işlev veya gerçek servis bağlantısı açmaz. e-Belge, kartlı tahsilat, OCR ve reklam bağlantılarında mevcut hazırlık durumları açıkça ayrılır.
Teklif / proforma / sipariş kabulü gelir veya tahsilat değildir. Kesinleşmiş satış finansal kaydı, gerçek ödeme para hareketini oluşturur.
KOBİ / Plus / Business yetkileri mevcut sunucu kontrollerinden gelir. Kullanıcı izinleri ve üyelik bitişi ayrıca uygulanır.

## Rehber adresleri

- Başlangıç — İlk kez kullanıyorum: nereden başlamalıyım?: https://kobivira.com.tr/rehber-baslangic.html
- Başlangıç — Genel Bakış ve Sıradaki Adım nasıl kullanılır?: https://kobivira.com.tr/rehber-genel-bakis.html
- Satışlar — Teklif nasıl oluşturulur ve müşteriye gönderilir?: https://kobivira.com.tr/rehber-teklif.html
- Satışlar — Proforma nasıl oluşturulur?: https://kobivira.com.tr/rehber-proforma.html
- Satışlar — Sipariş nasıl oluşturulur ve satışa dönüştürülür?: https://kobivira.com.tr/rehber-siparis.html
- Satışlar — Satış faturası kaydı nasıl oluşturulur?: https://kobivira.com.tr/rehber-satis-faturasi.html
- Alışlar — Alış faturası nasıl kaydedilir?: https://kobivira.com.tr/rehber-alis-faturasi.html
- Giderler — Yeni gider nasıl kaydedilir?: https://kobivira.com.tr/rehber-giderler.html
- Satışlar — Güvenli belge bağlantısı ve müşteri yanıtı: https://kobivira.com.tr/rehber-paylasim.html
- Satışlar — Müşterinin değişiklik istediği belge nasıl revize edilir?: https://kobivira.com.tr/rehber-revizyon.html
- Satışlar — İptal edilen ticari belge nasıl yeniden düzenlenir?: https://kobivira.com.tr/rehber-iptal-geri-al.html
- Müşteri ve Tedarikçiler — Yeni müşteri ve cari kart nasıl eklenir?: https://kobivira.com.tr/rehber-musteriler.html
- Müşteri ve Tedarikçiler — Tedarikçi kartı nasıl oluşturulur ve kullanılır?: https://kobivira.com.tr/rehber-tedarikciler.html
- Müşteri ve Tedarikçiler — Tüm cari kartları ve doğru cari türü: https://kobivira.com.tr/rehber-tum-cariler.html
- Ürün ve Hizmetler — Ürün kartı nasıl eklenir?: https://kobivira.com.tr/rehber-urunler.html
- Ürün ve Hizmetler — Hizmet kartı nasıl eklenir?: https://kobivira.com.tr/rehber-hizmetler.html
- Ürün ve Hizmetler — Fiyat listesi nasıl incelenir ve güncellenir?: https://kobivira.com.tr/rehber-fiyat-listesi.html
- Para — Kasa ve banka hesabı nasıl açılır?: https://kobivira.com.tr/rehber-hesaplar.html
- Para — Tahsilat veya ödeme nasıl kaydedilir?: https://kobivira.com.tr/rehber-tahsilat.html
- Para — Hesaplar arası para aktarımı nasıl kaydedilir?: https://kobivira.com.tr/rehber-aktarim.html
- Para — Nakit takvimindeki vadeler nasıl takip edilir?: https://kobivira.com.tr/rehber-nakit-takvimi.html
- Para — Vadesi geçen ve yaklaşan belgeler nasıl görülür?: https://kobivira.com.tr/rehber-hatirlatma.html
- Müşteri ve Tedarikçiler — Cari hesap ekstresi PDF / Excel nasıl alınır?: https://kobivira.com.tr/rehber-cari-ekstre.html
- Satışlar — Faturaya bağlı kısmi veya tam iade nasıl yapılır?: https://kobivira.com.tr/rehber-iade.html
- Satışlar — Serbest meslek makbuzu kaydı ve tahsilatı: https://kobivira.com.tr/rehber-smm.html
- Para — Alınan veya verilen çek nasıl takip edilir?: https://kobivira.com.tr/rehber-cek.html
- Para — Çalışan gideri, avans ve geri ödeme: https://kobivira.com.tr/rehber-calisan-gideri.html
- Ürün ve Hizmetler — Ürün miktar hareketi ve barkod nasıl kaydedilir?: https://kobivira.com.tr/rehber-miktar.html
- Para — Banka dosyası nasıl yüklenir ve eşleştirilir?: https://kobivira.com.tr/rehber-banka-eslestirme.html
- Raporlar — Hangi finans raporunu kullanmalıyım?: https://kobivira.com.tr/rehber-raporlar.html
- Raporlar — Satış raporu nasıl incelenir?: https://kobivira.com.tr/rehber-rapor-satis.html
- Raporlar — Gider raporu nasıl incelenir?: https://kobivira.com.tr/rehber-rapor-gider.html
- Raporlar — Alacak ve borçlar nasıl okunur?: https://kobivira.com.tr/rehber-rapor-bakiye.html
- Raporlar — Kasa ve banka dönem raporu nasıl kullanılır?: https://kobivira.com.tr/rehber-rapor-kasa-banka.html
- Raporlar — Brüt kârlılık raporu nasıl yorumlanır?: https://kobivira.com.tr/rehber-kar.html
- Raporlar — Borç / alacak yaşlandırma raporu: https://kobivira.com.tr/rehber-yaslandirma.html
- Raporlar — Cari mutabakat bağlantısı nasıl oluşturulur?: https://kobivira.com.tr/rehber-mutabakat.html
- Raporlar — Dövizli kayıt ve kur farkı nasıl takip edilir?: https://kobivira.com.tr/rehber-doviz.html
- Raporlar — Kategori ve etiketle ayrıntılı rapor alma: https://kobivira.com.tr/rehber-ayrintili-rapor.html
- Raporlar — İş / proje kârlılığı nasıl takip edilir?: https://kobivira.com.tr/rehber-proje.html
- Raporlar — 30 / 60 / 90 günlük nakit öngörüsü: https://kobivira.com.tr/rehber-ongoru.html
- Ayarlar — Firma bilgileri, logo ve IBAN nasıl tamamlanır?: https://kobivira.com.tr/rehber-firma-bilgileri.html
- Ayarlar — Firma doğrulama evrakları nasıl gönderilir?: https://kobivira.com.tr/rehber-firma-dogrulama.html
- Ayarlar — E-posta ve cep telefonu nasıl doğrulanır?: https://kobivira.com.tr/rehber-iletisim-dogrulama.html
- Ayarlar — Kobivira mesajları ve bildirimler nerede?: https://kobivira.com.tr/rehber-mesajlar.html
- Ayarlar — Şirket çalışanı ekleme ve bölüm yetkileri: https://kobivira.com.tr/rehber-kullanicilar.html
- Ayarlar — SMMM / YMM erişimi nasıl verilir?: https://kobivira.com.tr/rehber-mali-musavir.html
- Satışlar — Çalışan işlemleri nasıl onaylanır veya reddedilir?: https://kobivira.com.tr/rehber-onaylar.html
- Ayarlar — Tutar eşiği ve iki aşamalı onay nasıl tanımlanır?: https://kobivira.com.tr/rehber-onay-kurallari.html
- Ayarlar — Paket, kalan süre ve kontör nereden görülür?: https://kobivira.com.tr/rehber-uyelik.html
- Ayarlar — Paket satın alma ve havale bildirimi nasıl yapılır?: https://kobivira.com.tr/rehber-odeme-etkinlestirme.html
- Ayarlar — Kontör bakiyesi ve satın alma talebi: https://kobivira.com.tr/rehber-kontor.html
- Ayarlar — Üyelik ödemesi için iade talebi nasıl gönderilir?: https://kobivira.com.tr/rehber-uyelik-iadesi.html
- Ayarlar — Deneme veya ücretli süre dolduğunda ne yapılır?: https://kobivira.com.tr/rehber-sure-bitisi.html
- Ayarlar — Şifre, profil fotoğrafı ve hesap güvenliği: https://kobivira.com.tr/rehber-guvenlik.html
- Ayarlar — İşlem geçmişinden kim ne yaptı nasıl görülür?: https://kobivira.com.tr/rehber-islem-gecmisi.html
- Ayarlar — Yazılı destek talebi ve rehber bağlantıları: https://kobivira.com.tr/rehber-destek-talebi.html
- Ayarlar — Canlı destek sırası, kod ve izinli bağlantı: https://kobivira.com.tr/rehber-canli-destek.html
- Ayarlar — Yeni iş oluşturma, sonlandırma ve tamamlama: https://kobivira.com.tr/rehber-is-takibi.html
- Ayarlar — Satış fırsatı ve görüşme notu nasıl tutulur?: https://kobivira.com.tr/rehber-crm.html
- Satışlar — Aylık tekrarlayan satış taslağı oluşturma: https://kobivira.com.tr/rehber-tekrarlayan-satis.html
- Ayarlar — Haftalık, aylık veya yıllık belge tekrarı: https://kobivira.com.tr/rehber-tekrar-kurallari.html
- Ayarlar — Takip kuralları ve panel bildirimleri: https://kobivira.com.tr/rehber-otomasyon.html
- Ayarlar — Belgelerin kategori ve etiketini toplu güncelleme: https://kobivira.com.tr/rehber-toplu-islem.html
- Ayarlar — Belge başlığı, koşul ve dipnot şablonu: https://kobivira.com.tr/rehber-sablon.html
- Ayarlar — Davet bağlantısı ve referans süre hakkı: https://kobivira.com.tr/rehber-arkadasini-davet-et.html
- Veri taşıma — Verilerimi başka programdan Kobivira’ya nasıl taşırım?: https://kobivira.com.tr/rehber-veri-tasima.html
- Veri taşıma — CSV / Excel sütunları ve fatura satırları nasıl hazırlanır?: https://kobivira.com.tr/rehber-veri-aktarimi.html
- Veri taşıma — Faturaya orijinal XML / PDF eki nasıl bağlanır?: https://kobivira.com.tr/rehber-veri-aktarim-ekleri.html
- Satışlar — Elektronik belge hazırlığı nasıl kullanılır?: https://kobivira.com.tr/rehber-elektronik-belge.html
- Satışlar — e-Fatura, e-Arşiv, e-SMM, e-İrsaliye ve e-İhracat: https://kobivira.com.tr/rehber-ebelge-turleri.html
- Giderler — Gelen e-Fatura ile alış / gider kaydı arasındaki fark: https://kobivira.com.tr/rehber-gelen-efatura.html
- Ayarlar — Servis merkezi ve hazırlık işlemleri nasıl okunur?: https://kobivira.com.tr/rehber-servisler.html
- Web ve Reklam — Kurumsal web sitesi nasıl yönetilir?: https://kobivira.com.tr/rehber-web-sitesi.html
- Web ve Reklam — Meta reklam yönetimi alanı: https://kobivira.com.tr/rehber-meta-reklam.html
- Web ve Reklam — Google reklam yönetimi alanı: https://kobivira.com.tr/rehber-google-reklam.html
- Başlangıç — Tüm kategoriler: hangi işlem nereden yapılır?: https://kobivira.com.tr/rehber-menu.html
