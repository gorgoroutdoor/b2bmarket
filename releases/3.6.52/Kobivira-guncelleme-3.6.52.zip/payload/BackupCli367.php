<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(404);return;}
define('APP_ROOT',dirname(__DIR__,2));$pointer=json_decode(file_get_contents(APP_ROOT.'/storage/current.json'),true,16,JSON_THROW_ON_ERROR);$v=$pointer['version']??'';if(!preg_match('/^\d+\.\d+\.\d+$/D',$v))exit(1);define('APP_VERSION',$v);define('RELEASE_ROOT',APP_ROOT.'/releases/'.$v);require RELEASE_ROOT.'/Modules.php';
$operation=$argv[1]??'--run';if(!in_array($operation,['--run','--now','--verify','--restore'],true)){fwrite(STDERR,"Geçersiz komut.\n");exit(1);}
$gate=fopen(APP_ROOT.'/storage/request.lock','c');if(!$gate||!flock($gate,LOCK_EX|LOCK_NB)){fwrite(STDERR,"Uygulama meşgul; sonraki çalışmada yeniden denenir.\n");exit(2);}if(is_file(APP_ROOT.'/storage/maintenance.json')){$m=json_decode((string)file_get_contents(APP_ROOT.'/storage/maintenance.json'),true);if($operation!=='--restore'||($m['phase']??'')!=='full_restore'){fwrite(STDERR,"Bakım sürüyor; yedek başlatılmadı.\n");exit(2);}}
$state=FullBackup367::state();$state['heartbeat']=gmdate('c');FullBackup367::writeState($state);$job=new FullBackup367(db());$maintenance=false;$exitCode=0;
try{
    $run=function()use($operation,$argv,$job,&$state,&$maintenance):void {
    if($operation==='--verify'){$job->inspect($argv[2]??'');echo "Şifre ve tüm dosya özetleri doğrulandı.\n";return;}
    if($operation==='--restore'){
        if(($argv[3]??'')!=='--confirm-all-companies')throw new DomainException('Geri yükleme tüm firmaları etkiler. --confirm-all-companies açık onayı gerekir.');
        $job->inspect($argv[2]??'');atomic_write(APP_ROOT.'/storage/maintenance.json',json_encode(['phase'=>'full_restore','snapshot'=>$argv[2]],JSON_THROW_ON_ERROR));$maintenance=true;
        $safety=$job->create('pre-restore');$job->restore($argv[2]);$state['message']='Tam yedekten geri yüklendi. Geri yükleme öncesi kurtarma yedeği: '.$safety['file'];FullBackup367::writeState($state);echo "Veritabanı ve yedekteki uygulama dosyaları geri yüklendi. Yeniden giriş gerekir.\n";return;
    }
    $s=FullBackup367::settings();$now=new DateTimeImmutable('now',new DateTimeZone('Europe/Istanbul'));$today=$now->format('Y-m-d');$pending=FullBackup367::folder().'/pending.json';$manual=$operation==='--now'||is_file($pending);$due=FullBackup367::due($s,$state,$now);
    if(!$manual&&!$due){echo "Yedek zamanı gelmedi; kontrol kaydedildi.\n";return;}
    if($operation!=='--now'&&isset($state['last_failure'])&&time()-(int)$state['last_failure']<900){echo "Başarısız yedek 15 dakika sonra yeniden denenecek.\n";return;}
    atomic_write(APP_ROOT.'/storage/maintenance.json',json_encode(['phase'=>'full_backup'],JSON_THROW_ON_ERROR));$maintenance=true;$meta=$job->create($manual?'manual':'scheduled');
    $state['last_success']=$meta['created_at'];$state['message']='Tam yedek oluşturuldu ve dosya bütünlüğü doğrulandı.';$state['last_file']=$meta['file'];unset($state['last_failure']);if($due)$state['scheduled_day']=$today;FullBackup367::writeState($state);if(is_file($pending))unlink($pending);FullBackup367::prune((int)$s['keep']);echo $state['message']."\n";
    };$run();
}catch(Throwable $e){$state['last_failure']=time();$state['message']='İşlem başarısız; son başarılı yedek korunuyor. Sunucu hata günlüğünü inceleyin.';FullBackup367::writeState($state);error_log('Kobivira backup: '.$e->getMessage());fwrite(STDERR,$state['message']."\n");$exitCode=1;
}finally{if($maintenance&&($operation!=='--restore'||$exitCode===0))@unlink(APP_ROOT.'/storage/maintenance.json');flock($gate,LOCK_UN);fclose($gate);}

exit($exitCode);
