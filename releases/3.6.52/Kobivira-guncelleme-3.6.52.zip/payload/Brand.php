<?php
declare(strict_types=1);
function brand_mark(): string {return '<svg class="brand-logo" viewBox="350 220 590 600" role="img" aria-label="Kobivira"><image href="?page=brand_asset" width="1254" height="1254"/></svg>';}
function brand_asset(): never {if($_SERVER['REQUEST_METHOD']!=='GET'){http_response_code(405);exit;}header('Content-Type: image/png');header('Cache-Control: public,max-age=86400');$a=json_decode(file_get_contents(__DIR__.'/BrandAsset.json'),true,4,JSON_THROW_ON_ERROR);echo base64_decode($a['png'],true);exit;}
