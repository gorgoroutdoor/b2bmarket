<?php
declare(strict_types=1);
/** EDM e-İrsaliye sandbox. Separate sessions and document storage from e-Fatura. */
final class EdmDespatch369 {
    public const ENDPOINT='https://test.edmbilisim.com.tr/EFaturaEDM21ea/EIrsaliyeEDM.svc';
    private string $session='0';
    public function __construct(private string $username,private string $password,private string $company,private ?Closure $transport=null,private string $environment='sandbox'){
        $this->endpoint();
        if($username===''||$password===''||!preg_match('/^\d{10,11}$/D',$company))throw new DomainException('e-İrsaliye test hesabı ve firma bilgileri eksik.');
    }
    public function endpoint():string{if(!in_array($this->environment,['sandbox','live'],true))throw new DomainException('e-Belge ortamı geçersiz.');return $this->environment==='sandbox'?self::ENDPOINT:'https://portal2.edmbilisim.com.tr/EFaturaEDM/EIrsaliyeEDM.svc';}
    public function call(string $method,Closure $body): DOMDocument {
        $allowed=['Login','CheckCounter','CheckUser','GetDespatch','SendDespatch','GetDespatchStatus','GetEnvelope','SendDespatchResponseWithServerSign'];
        if(!in_array($method,$allowed,true))throw new DomainException('EDM işlemi desteklenmiyor.');
        $d=new DOMDocument('1.0','UTF-8');$env=$d->createElementNS('http://schemas.xmlsoap.org/soap/envelope/','s:Envelope');$d->appendChild($env);$b=$d->createElementNS('http://schemas.xmlsoap.org/soap/envelope/','s:Body');$env->appendChild($b);$r=$d->createElementNS('http://tempuri.org/',$method.'Request');$b->appendChild($r);
        $h=$d->createElementNS('','REQUEST_HEADER');$r->appendChild($h);
        foreach(['SESSION_ID'=>$this->session,'CLIENT_TXN_ID'=>Edm361Client::uuid(),'ACTION_DATE'=>gmdate('c'),'REASON'=>'Kobivira firma bazlı EDM test işlemi','APPLICATION_NAME'=>'Kobivira','HOSTNAME'=>'kobivira','CHANNEL_NAME'=>$this->company,'COMPRESSED'=>'N'] as $k=>$v)Edm361Client::add($h,$k,$v);
        $body($r);$bytes=$d->saveXML();
        if($this->transport)$response=($this->transport)($this->endpoint(),$method.'Request',$bytes);
        else {
            $ctx=stream_context_create(['http'=>['method'=>'POST','header'=>"Content-Type: text/xml; charset=utf-8\r\nSOAPAction: \"".$method."Request\"\r\nConnection: close\r\n",'content'=>$bytes,'timeout'=>25,'ignore_errors'=>true,'follow_location'=>0,'max_redirects'=>0],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'allow_self_signed'=>false]]);
            $stream=@fopen($this->endpoint(),'rb',false,$ctx);if(!$stream)throw new DomainException('EDM test servisine ulaşılamadı. İşlem sonucu bilinmiyor; belgeyi yeniden göndermeden durumunu sorgulayın.');
            try{$response=stream_get_contents($stream,12582913);$meta=stream_get_meta_data($stream);}finally{fclose($stream);}
            if($response===false||!empty($meta['timed_out']))throw new DomainException('EDM yanıt süresi aşıldı. İşlem sonucu bilinmiyor; önce durum sorgulayın.');
            $http=$meta['wrapper_data'][0]??'';if(!preg_match('~^HTTP/\S+ (200|500)\b~',$http))throw new DomainException('EDM HTTP yanıtı uygun değil; yönlendirme izlenmedi.');
        }
        $result=Edm361Client::xml($response);$xp=new DOMXPath($result);
        if($xp->query('/*[local-name()="Envelope"]/*[local-name()="Body"]')->length!==1)throw new DomainException('EDM SOAP yanıtı bekleniyor.');
        if($xp->query('//*[local-name()="Fault"]')->length){$fault=Edm361Client::text($result,'//*[local-name()="faultcode"]');if(preg_match('/(?:^|:)InvalidSecurity$/D',$fault))throw new DomainException('EDM oturumu doğrulanamadı. Bağlantı kontrolünü yeniden çalıştırın.');$code=Edm361Client::text($result,'//*[local-name()="ERROR_CODE"]');$safe=preg_match('/^\d{1,6}$/D',$code)?' ('.$code.')':'';$detail=Edm361Client::text($result,'//*[local-name()="ERROR_LONG_DES"]')?:Edm361Client::text($result,'//*[local-name()="ERROR_SHORT_DES"]');
            $detail=str_replace(array_filter([$this->username,$this->password,$this->session],static fn($v)=>$v!==''&&$v!=='0'),'[gizlendi]',$detail);$detail=preg_replace('/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/i','[kimlik gizlendi]',$detail);$detail=mb_substr(strip_tags($detail),0,1200);
            throw new DomainException('EDM servis işlemini reddetti'.$safe.'.'.($detail!==''?' Teknik açıklama: '.$detail:' Belge ve servis bilgilerini kontrol edin.'),preg_match('/^\d{1,6}$/D',$code)?(int)$code:0);}
        if($xp->query('//*[local-name()="'.$method.'Response"]')->length!==1)throw new DomainException('EDM beklenen işlem yanıtını dönmedi.');
        $return=Edm361Client::text($result,'//*[local-name()="RETURN_CODE"]');if($return!==''&&$return!=='0')throw new DomainException('EDM başarısız işlem kodu döndürdü.');
        return $result;
    }
    public function login(): void {
        $r=$this->call('Login',function($e){foreach(['USER_NAME'=>$this->username,'PASSWORD'=>$this->password] as $k=>$v){$n=$e->ownerDocument->createElementNS('',$k);$n->appendChild($e->ownerDocument->createTextNode($v));$e->appendChild($n);}});
        $s=Edm361Client::text($r,'//*[local-name()="SESSION_ID"]');if(!preg_match('/^[a-f0-9-]{36}$/iD',$s))throw new DomainException('EDM geçerli oturum vermedi.');$this->session=$s;
    }
    public function balance():string{$d=$this->call('CheckCounter',static function($e){});$v=Edm361Client::text($d,'//*[local-name()="COUNTER_LEFT"]');if(!preg_match('/^-?\d+(?:\.\d+)?$/D',$v))throw new DomainException('e-İrsaliye bakiyesi doğrulanamadı.');return $v;}
    public static function info(string $xml,bool $outgoing=false):array{
        $d=Edm361Client::xml($xml);if($d->documentElement->localName!=='DespatchAdvice'||$d->documentElement->namespaceURI!=='urn:oasis:names:specification:ubl:schema:xsd:DespatchAdvice-2')throw new DomainException('UBL DespatchAdvice XML gerekir.');
        $p='/*[local-name()="DespatchAdvice"]';$get=static fn($path)=>Edm361Client::text($d,$path);$party=static function($role)use($d,$p){$nodes=(new DOMXPath($d))->query($p.'/*[local-name()="'.$role.'"]/*[local-name()="Party"]/*[local-name()="PartyIdentification"]/*[local-name()="ID"][@schemeID="VKN" or @schemeID="TCKN"]');if($nodes->length!==1)throw new DomainException('İrsaliye tarafı tek bir VKN/TCKN içermelidir.');return trim($nodes->item(0)->textContent);};
        $a=['uuid'=>$get($p.'/*[local-name()="UUID"]'),'number'=>$get($p.'/*[local-name()="ID"]'),'profile'=>$get($p.'/*[local-name()="ProfileID"]'),'sender'=>$party('DespatchSupplierParty'),'recipient'=>$party('DeliveryCustomerParty'),'date'=>$get($p.'/*[local-name()="IssueDate"]'),'type'=>$get($p.'/*[local-name()="DespatchAdviceTypeCode"]')];Edm361Client::validUuid($a['uuid']);
        if(!preg_match('/^[A-Z0-9]{3}\d{13}$/D',$a['number'])||$a['profile']!=='TEMELIRSALIYE'||$a['type']!=='SEVK'||!preg_match('/^\d{10,11}$/D',$a['sender'])||!preg_match('/^\d{10,11}$/D',$a['recipient'])||!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$a['date']))throw new DomainException('İrsaliye numarası, senaryo, taraf veya tarih bilgisi geçersiz.');
        if($outgoing){
        $address=$p.'/*[local-name()="Shipment"]/*[local-name()="Delivery"]/*[local-name()="DeliveryAddress"]';
        foreach(['CitySubdivisionName','CityName','PostalZone'] as $field)if($get($address.'/*[local-name()="'.$field.'"]')==='')throw new DomainException('İrsaliye sevk teslim adresinde il, ilçe ve posta kodu gerekir.');
        if($get($address.'/*[local-name()="Country"]/*[local-name()="Name"]')===''||!preg_match('/^\d{5}$/D',$get($address.'/*[local-name()="PostalZone"]')))throw new DomainException('İrsaliye sevk teslim ülke ve beş haneli posta kodu gerekir.');
        $drivers=[];foreach((new DOMXPath($d))->query($p.'/*[local-name()="Shipment"]/*[local-name()="ShipmentStage"]/*[local-name()="DriverPerson"]/*[local-name()="NationalityID"]') as $driver){$identity=trim($driver->textContent);if($identity===''||isset($drivers[$identity]))throw new DomainException('İrsaliyede sürücü kimlik bilgileri boş veya mükerrer olamaz.');$drivers[$identity]=true;}
        }
        $lines=(new DOMXPath($d))->query($p.'/*[local-name()="DespatchLine"]');if($lines->length<1||$lines->length>100)throw new DomainException('Test irsaliyesi 1–100 satır içermeli.');$ids=[];$a['lines']=[];
        foreach($lines as $n){$id=Edm361Client::text($n,'./*[local-name()="ID"]');$qty=Edm361Client::text($n,'./*[local-name()="DeliveredQuantity"]');$unit=Edm361Client::text($n,'./*[local-name()="DeliveredQuantity"]/@unitCode');$name=Edm361Client::text($n,'./*[local-name()="Item"]/*[local-name()="Name"]');if($id===''||isset($ids[$id])||!preg_match('/^\d+(?:\.\d{1,6})?$/D',$qty)||(float)$qty<=0||$unit===''||$name==='')throw new DomainException('İrsaliye satır kimliği, miktarı, birimi veya mal adı geçersiz.');$ids[$id]=true;$a['lines'][]=['id'=>$id,'quantity'=>$qty,'unit'=>$unit,'name'=>$name];}return $a;
    }
    public function aliases(string $tax):array{
        if(!preg_match('/^\d{10,11}$/D',$tax))throw new DomainException('VKN/TCKN geçersiz.');$d=$this->call('CheckUser',static function($e)use($tax){$u=$e->ownerDocument->createElementNS('','USER');$e->appendChild($u);Edm361Client::add($u,'IDENTIFIER',$tax);});$result=['GB'=>[],'PK'=>[]];
        foreach((new DOMXPath($d))->query('//*[local-name()="CheckUserResponse"]/*[local-name()="USER"]') as $u){$get=static fn($k)=>Edm361Client::text($u,'./*[local-name()="'.$k.'"]');if($get('IDENTIFIER')!==$tax)throw new DomainException('e-İrsaliye mükellef yanıtı farklı firmaya ait.');$unit=$get('UNIT');$alias=$get('ALIAS');if($get('ALIAS_REMOVAL_TIME')!==''||!isset($result[$unit])||!str_starts_with($alias,'urn:mail:'))continue;$result[$unit][]=$alias;}return $result;
    }
    public function get(string $direction,string $uuid='',string $format='XML',string $start='',string $end=''):DOMDocument{
        if(!in_array($direction,['IN','OUT'],true)||!in_array($format,['XML','PDF'],true))throw new DomainException('İrsaliye yönü veya biçimi geçersiz.');if($uuid!=='')Edm361Client::validUuid($uuid);
        return $this->call('GetDespatch',static function($e)use($direction,$uuid,$format,$start,$end){$k=$e->ownerDocument->createElementNS('','DESPATCH_SEARCH_KEY');$e->appendChild($k);$fields=['LIMIT'=>$uuid!==''?'1':'100'];if($uuid!=='')$fields['UUID']=$uuid;if($start!=='')$fields['START_DATE']=$start;if($end!=='')$fields['END_DATE']=$end;$fields+=['READ_INCLUDED'=>'true','DIRECTION'=>$direction];foreach($fields as $n=>$v)Edm361Client::add($k,$n,$v);foreach(['HEADER_ONLY'=>'N','DESPATCH_CONTENT_TYPE'=>$format] as $n=>$v){$k=$e->ownerDocument->createElementNS('',$n);$k->textContent=$v;$e->appendChild($k);}});
    }
    public static function content(DOMDocument $d,array $expected,string $format):string{
        $nodes=(new DOMXPath($d))->query('//*[local-name()="GetDespatchResponse"]/*[local-name()="DESPATCH"]');if($nodes->length!==1)throw new DomainException('EDM tek bir irsaliye döndürmedi.');$n=$nodes->item(0);if(strtolower($n->getAttribute('UUID'))!==strtolower($expected['uuid'])||$n->getAttribute('ID')!==$expected['number'])throw new DomainException('İrsaliye UUID/numara eşleşmedi.');
        foreach(['SENDER'=>'sender','RECEIVER'=>'recipient','PROFILEID'=>'profile'] as $remote=>$local)if(Edm361Client::text($n,'./*[local-name()="HEADER"]/*[local-name()="'.$remote.'"]')!==$expected[$local])throw new DomainException('İrsaliye başlığı taraf/senaryo eşleşmedi.');
        $bytes=base64_decode(Edm361Client::text($n,'./*[local-name()="CONTENT"]'),true);if($bytes===false||$bytes===''||strlen($bytes)>8388608)throw new DomainException('İrsaliye içeriği boş veya geçersiz.');
        if($format==='PDF'){if(!str_starts_with($bytes,'%PDF-'))throw new DomainException('Geçerli irsaliye PDF alınamadı.');}else{$a=self::info($bytes);foreach(['uuid','number','sender','recipient','profile'] as $k)if(($k==='uuid'?strtolower($a[$k]):$a[$k])!==($k==='uuid'?strtolower($expected[$k]):$expected[$k]))throw new DomainException('İndirilen irsaliye XML eşleşmedi.');}return $bytes;
    }
    public function status(array $expected,string $direction):DOMDocument{
        // Query by UUID and direction first: status alone does not reliably isolate a self-addressed document.
        self::content($this->get($direction,$expected['uuid']),$expected,'XML');
        $r=$this->call('GetDespatchStatus',static function($e)use($expected,$direction){$n=$e->ownerDocument->createElementNS('','DESPATCH');$n->setAttribute('UUID',$expected['uuid']);$n->setAttribute('ID',$expected['number']);$n->setAttribute('TRXID','0');$e->appendChild($n);$h=Edm361Client::add($n,'HEADER');foreach(['ISSUE_DATESpecified'=>'false','GIB_STATUS_CODESpecified'=>'false','CDATESpecified'=>'false','DIRECTION'=>$direction,'EARCHIVESpecified'=>'false'] as $k=>$v)Edm361Client::add($h,$k,$v);$m=Edm361Client::add($h,'SUPPLIER_MOBILE');$m->setAttributeNS('http://www.w3.org/2001/XMLSchema-instance','i:nil','true');});
        if(strtolower(Edm361Client::text($r,'//*[local-name()="DESPATCH_STATUS"]/@UUID'))!==strtolower($expected['uuid']))throw new DomainException('Durum yanıtı farklı irsaliyeye ait.');$dir=Edm361Client::text($r,'//*[local-name()="DESPATCH_STATUS"]/*[local-name()="DIRECTION"]');if($dir!==''&&!in_array($dir,$direction==='IN'?['IN','Gelen']:['OUT','Giden'],true))throw new DomainException('EDM durum yanıtının belge yönü eşleşmedi.');
        try{$history=$this->envelope($expected['uuid']);$parent=(new DOMXPath($r))->query('//*[local-name()="DESPATCH_STATUS"]')->item(0);if($parent)foreach($history as $key=>$value)Edm361Client::add($parent,$key,$value);}catch(DomainException){/* Preserve document status if the optional history service is unavailable. */}
        return $r;
    }
    public function envelope(string $uuid):array{
        Edm361Client::validUuid($uuid);$d=$this->call('GetEnvelope',static function($e)use($uuid){$n=$e->ownerDocument->createElementNS('','UUID');$n->textContent=$uuid;$e->appendChild($n);});$rows=[];
        foreach((new DOMXPath($d))->query('//*[local-name()="DespatchEnvelopeActivityListEntity"]') as $n){$get=static fn($k)=>Edm361Client::text($n,'./*[local-name()="'.$k.'"]');if(strtolower($get('DespatchUUID'))!==strtolower($uuid))throw new DomainException('Zarf geçmişi başka irsaliyeye ait.');$rows[]=['ENVELOPE_HISTORY_STATUS'=>$get('EnvelopeHistoryStatus'),'ENVELOPE_HISTORY_MESSAGE'=>mb_substr($get('EnvelopeHistoryStatusMessage'),0,1000),'ENVELOPE_HISTORY_DATE'=>$get('EnvelopeHistoryInsertDate')];}
        usort($rows,static fn($a,$b)=>strcmp($b['ENVELOPE_HISTORY_DATE'],$a['ENVELOPE_HISTORY_DATE']));return $rows[0]??[];
    }
    public static function quantity(string $v):int{
        $v=str_replace(',','.',trim($v));if(!preg_match('/^(0|[1-9]\d{0,11})(?:\.(\d{1,6}))?$/D',$v,$m))throw new DomainException('Miktar 0 veya pozitif olmalı; en fazla 6 ondalık basamak kullanılabilir.');
        return (int)$m[1]*1000000+(int)str_pad($m[2]??'',6,'0');
    }
    public static function quantityText(int $v):string{$whole=intdiv($v,1000000);$fraction=rtrim(str_pad((string)($v%1000000),6,'0',STR_PAD_LEFT),'0');return (string)$whole.($fraction!==''?'.'.$fraction:'');}
    public static function responsePlan(array $info,string $decision,array $accepted,string $reason):array{
        if(!in_array($decision,['KABUL','RED','KISMI KABUL'],true))throw new DomainException('İrsaliye yanıt türü geçersiz.');$reason=trim($reason);if(mb_strlen($reason)>1000||($decision!=='KABUL'&&$reason===''))throw new DomainException('Ret ve kısmi kabul için en fazla 1000 karakterlik gerekçe gerekir.');
        if($decision==='KISMI KABUL'&&(!array_is_list($accepted)||count($accepted)!==count($info['lines'])))throw new DomainException('Her irsaliye satırı için kabul edilen miktarı girin.');
        $rows=[];$hasAccepted=false;$hasRejected=false;
        foreach($info['lines'] as $index=>$line){$quantity=self::quantity($line['quantity']);if($quantity<=0)throw new DomainException('Belge satır miktarı pozitif olmalıdır.');$value=$accepted[$index]??'0';if($decision==='KISMI KABUL'&&!is_string($value))throw new DomainException('Satır miktarı metin olarak girilmelidir.');$take=match($decision){'KABUL'=>$quantity,'RED'=>0,default=>self::quantity($value)};if($take>$quantity)throw new DomainException('Kabul edilen miktar, gönderilen miktarı aşamaz.');$reject=$quantity-$take;$hasAccepted=$hasAccepted||$take>0;$hasRejected=$hasRejected||$reject>0;
            $rows[]=['LINENUMBER'=>(string)($index+1),'DESPATCHLINEID'=>$line['id'],'QUANTITY'=>self::quantityText($quantity),'MEASUREUNITCODE'=>$line['unit'],'ACCEPTEDQUANTITY'=>self::quantityText($take),'REJECTEDQUANTITY'=>self::quantityText($reject),'REJECTREASON'=>$reject>0?$reason:'','OVERSUPPLYQUANTITY'=>'0','SHORTQUANTITY'=>'0'];
        }
        if($decision==='KISMI KABUL'&&(!$hasAccepted||!$hasRejected))throw new DomainException('Kısmi kabulde hem kabul edilen hem reddedilen miktar bulunmalıdır. Tümü için Kabul veya Ret kullanın.');return $rows;
    }
    public function respond(array $info,string $decision,array $accepted,string $reason):void{
        Edm361Client::validUuid($info['uuid']);if(($info['recipient']??'')!==$this->company||($info['profile']??'')!=='TEMELIRSALIYE')throw new DomainException('Yalnız firmaya gelen temel test irsaliyesine yanıt verilebilir.');$rows=self::responsePlan($info,$decision,$accepted,$reason);
        $r=$this->call('SendDespatchResponseWithServerSign',static function($e)use($info,$decision,$rows){$n=$e->ownerDocument->createElementNS('','DESPATCHLINERESPONSE');$e->appendChild($n);Edm361Client::add($n,'UUID',$info['uuid']);Edm361Client::add($n,'STATUS',$decision);if($decision!=='KABUL')foreach($rows as $line){$x=Edm361Client::add($n,'RESPONSELINES');foreach($line as $key=>$value)Edm361Client::add($x,$key,$value);}});
        if(Edm361Client::text($r,'//*[local-name()="RETURN_CODE"]')!=='0')throw new DomainException('İrsaliye yanıt isteğinin sonucu doğrulanamadı. Aynı yanıtı yeniden göndermeden durum sorgulayın.');
    }
    public function send(string $xml,string $gb,string $pk):DOMDocument{
        $a=self::info($xml,true);if($a['sender']!==$this->company)throw new DomainException('İrsaliye göndericisi test firmasıyla eşleşmiyor.');if(!in_array($gb,$this->aliases($this->company)['GB'],true)||!in_array($pk,$this->aliases($a['recipient'])['PK'],true))throw new DomainException('Gönderici GB ve alıcı PK etiketleri e-İrsaliye servisinde doğrulanmalıdır.');
        $result=$this->call('SendDespatch',static function($e)use($a,$xml,$gb,$pk){foreach(['SENDER'=>[$a['sender'],$gb],'RECEIVER'=>[$a['recipient'],$pk]] as $name=>[$tax,$alias]){$n=$e->ownerDocument->createElementNS('',$name);$n->setAttribute('vkn',$tax);$n->setAttribute('alias',$alias);$e->appendChild($n);}$n=$e->ownerDocument->createElementNS('','DESPATCH');$n->setAttribute('UUID',$a['uuid']);$n->setAttribute('ID',$a['number']);$n->setAttribute('TRXID','0');$e->appendChild($n);Edm361Client::add($n,'CONTENT',base64_encode($xml));});
        $nodes=(new DOMXPath($result))->query('//*[local-name()="SendDespatchResponse"]/*[local-name()="DESPATCH"]');
        if($nodes->length!==1||strtolower($nodes->item(0)->getAttribute('UUID'))!==strtolower($a['uuid']))throw new DomainException('Gönderim yanıtı irsaliye UUID ile eşleşmedi. Yeniden göndermeden durum sorgulayın.');
        $number=$nodes->item(0)->getAttribute('ID');if($number!==''&&$number!==$a['number'])throw new DomainException('EDM farklı irsaliye numarası döndürdü; teknik inceleme gerekir.');return $result;
    }
}
function despatch369_guard():int{$cid=edm361_company();if(!owner())need_feature('edoc_despatch');return $cid;}
function despatch369_client(int $cid):EdmDespatch369{
    edm361_client($cid); // Revalidates the same credentials against the single VKN before opening the other service.
    $a=edm361_account($cid);$v=json_decode(open_code($a['credentials']),true,16,JSON_THROW_ON_ERROR);$c=new EdmDespatch369($v['username'],$v['password'],$a['tax_number']);$c->login();return $c;
}
function despatch369_row(int $cid,int $id):array{$r=query('SELECT * FROM edm_despatch_test_documents WHERE company_id=? AND id=?',[$cid,$id])->fetch();if(!$r)throw new DomainException('İrsaliye test kaydı bu firmada bulunamadı.');$a=EdmDespatch369::info(open_code($r['payload']));$account=edm361_account($cid);if($a[$r['direction']==='IN'?'recipient':'sender']!==($account['tax_number']??'')||strtolower($a['uuid'])!==strtolower($r['uuid'])||$a['number']!==$r['number']||$a['profile']!==$r['profile']||!hash_equals($r['payload_hash'],hash('sha256',open_code($r['payload']))))throw new DomainException('İrsaliye test kaydının kimliği doğrulanamadı.');return $r;}
function despatch369_status(DOMDocument $d):array{
    $x=new DOMXPath($d);$node=$x->query('//*[local-name()="DESPATCH_STATUS"]')->item(0)??$x->query('//*[local-name()="DESPATCH"]/*[local-name()="HEADER"]')->item(0);$out=[];
    if($node)foreach(['STATUS','STATUS_DESCRIPTION','GIB_STATUS_CODE','GIB_STATUS_DESCRIPTION','RESPONSE_CODE','RESPONSE_DESCRIPTION','ENVELOPE_IDENTIFIER','DIRECTION','ENVELOPE_HISTORY_STATUS','ENVELOPE_HISTORY_MESSAGE','ENVELOPE_HISTORY_DATE'] as $k)$out[$k]=mb_substr(Edm361Client::text($node,'./*[local-name()="'.$k.'"]'),0,500);
    $out['STATUS']=$out['STATUS']??'Yanıt alındı; son durum sorgulanmalı';if($out['STATUS']==='')$out['STATUS']='Yanıt alındı; son durum sorgulanmalı';return $out;
}
function despatch369_save_status(int $cid,int $id,DOMDocument $d):void{$s=despatch369_status($d);query('UPDATE edm_despatch_test_documents SET provider_status=?,provider_details=?,updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?',[mb_substr($s['STATUS'],0,100),json_encode($s,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE),$cid,$id]);}
function despatch369_stage(int $cid,string $xml,string $direction='OUT',string $status='XML hazırlandı; EDM’ye gönderilmedi'):int{
    $a=EdmDespatch369::info($xml,$direction==='OUT');$account=edm361_account($cid);if(!$account||!$account['enabled']||$a[$direction==='OUT'?'sender':'recipient']!==$account['tax_number'])throw new DomainException('İrsaliye test firmasıyla eşleşmiyor.');
    query('INSERT INTO edm_despatch_test_documents(company_id,direction,uuid,number,profile,payload,payload_hash,provider_status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())',[$cid,$direction,strtolower($a['uuid']),$a['number'],$a['profile'],seal_code($xml),hash('sha256',$xml),mb_substr($status,0,100)]);return (int)db()->lastInsertId();
}
function despatch369_post(string $action):never{
    $cid=despatch369_guard();$params=['company_id'=>$cid,'kind'=>'despatch'];$a=edm361_account($cid);if(!$a||!$a['enabled'])throw new DomainException('Önce firma EDM test hesabını etkinleştirin.');
    if(!in_array($action,['check','stage','sample','sync','status','send','accept','reject','partial'],true))throw new DomainException('e-İrsaliye test işlemi geçersiz.');
    edm363_rate($cid,match($action){'sample'=>'stage','partial'=>'reject',default=>$action});
    if($action==='sample'||$action==='stage'){
        if($action==='sample'){
            if($a['tax_number']!=='3230512384')throw new DomainException('Hazır örnek yalnız EDM 3230512384 test hesabına aittir. Firmanıza uygun XML yükleyin.');
            $key='despatch369-stage-'.$cid;if((int)query('SELECT GET_LOCK(?,0)',[$key])->fetchColumn()!==1)throw new DomainException('Örnek hazırlanıyor; listeyi kontrol edin.');
            try{$prefix='KVI'.date('Y');$max=(int)query("SELECT COALESCE(MAX(CAST(RIGHT(number,9) AS UNSIGNED)),0) FROM edm_despatch_test_documents WHERE company_id=? AND direction='OUT' AND number LIKE ?",[$cid,$prefix.'%'])->fetchColumn();if($max>=999999999)throw new DomainException('Test seri sınırına ulaşıldı.');$id=despatch369_stage($cid,despatch369_sample($prefix.str_pad((string)($max+1),9,'0',STR_PAD_LEFT)));}finally{query('SELECT RELEASE_LOCK(?)',[$key]);}
        }else{$f=$_FILES['ubl']??null;if(!$f||$f['error']!==UPLOAD_ERR_OK||$f['size']>2097152||!is_uploaded_file($f['tmp_name']))throw new DomainException('En fazla 2 MB UBL DespatchAdvice XML yükleyin.');$id=despatch369_stage($cid,file_get_contents($f['tmp_name']));}
        audit('edm.despatch_stage',['company'=>$cid,'reason'=>'Yalnız yerel test XML hazırlığı']);flash('Test irsaliyesi hazırlandı; henüz EDM’ye gönderilmedi.');redirect('edm_test',$params+['id'=>$id]);
    }
    if(in_array($action,['status','send','accept','reject','partial'],true)){$id=int_field('id',1,PHP_INT_MAX);$r=despatch369_row($cid,$id);if($action==='send'&&($r['direction']!=='OUT'||$r['attempted_at']||!isset($_POST['confirm_test'])))throw new DomainException('Yalnız gönderim denenmemiş OUT kaydı açık onayla gönderilebilir.');if(in_array($action,['accept','reject','partial'],true)&&($r['direction']!=='IN'||!empty($r['response_attempted_at'])||!isset($_POST['confirm_test'])))throw new DomainException('Yalnız henüz yanıt denenmemiş IN kaydı açık onayla yanıtlanabilir.');if($action==='status'&&!edm363_status_due($cid,1000000000+$id)){flash('30 saniye dolmadı; son kayıtlı durum gösteriliyor.');redirect('edm_test',$params+['id'=>$id]);}}
    $c=despatch369_client($cid);
    if($action==='check'){$balance=$c->balance();$aliases=$c->aliases($a['tax_number']);$_SESSION['despatch369_check']=['company'=>$cid,'balance'=>$balance,'aliases'=>$aliases];flash('e-İrsaliye oturumu, bakiye ve firma etiketleri sorgulandı.');redirect('edm_test',$params);}
    if($action==='sync'){
        $start=date_field('start');$end=date_field('end');$days=(strtotime($end)-strtotime($start))/86400;if($days<0||$days>7)throw new DomainException('En fazla 7 günlük tarih aralığı kullanın.');$d=$c->get('IN','','XML',$start,$end);$count=0;
        foreach((new DOMXPath($d))->query('//*[local-name()="GetDespatchResponse"]/*[local-name()="DESPATCH"]') as $n){$xml=base64_decode(Edm361Client::text($n,'./*[local-name()="CONTENT"]'),true);if(!$xml)throw new DomainException('Gelen irsaliye XML içeriği okunamadı.');$i=EdmDespatch369::info($xml);if($i['recipient']!==$a['tax_number']||strtolower($i['uuid'])!==strtolower($n->getAttribute('UUID'))||$i['number']!==$n->getAttribute('ID'))throw new DomainException('Gelen irsaliyenin firma/kimlik eşleşmesi doğrulanamadı.');$old=query("SELECT * FROM edm_despatch_test_documents WHERE company_id=? AND direction='IN' AND uuid=?",[$cid,strtolower($i['uuid'])])->fetch();
            if($old){if(!hash_equals($old['payload_hash'],hash('sha256',$xml)))throw new DomainException('Aynı UUID için irsaliye içeriği değişti.');$id=(int)$old['id'];}else $id=despatch369_stage($cid,$xml,'IN','EDM’den alındı');
            $wrapper=new DOMDocument();$wrapper->appendChild($wrapper->importNode($n,true));despatch369_save_status($cid,$id,$wrapper);$count++;
        }flash($count.' gelen test irsaliyesi sorgulandı. 100 sonuç varsa tarih aralığını daraltın.');redirect('edm_test',$params);
    }
    $lock='despatch369-'.$cid.'-'.$id;if((int)query('SELECT GET_LOCK(?,0)',[$lock])->fetchColumn()!==1)throw new DomainException('İrsaliye üzerinde işlem var.');
    try{$r=despatch369_row($cid,$id);$info=EdmDespatch369::info(open_code($r['payload']));
        if($action==='send'){
            if($r['direction']!=='OUT'||$r['attempted_at'])throw new DomainException('Bu irsaliyenin gönderimi daha önce denendi. Tekrar gönderilmez.');
            $gb=required_field('sender_alias',250);$pk=required_field('recipient_alias',250);$sa=$c->aliases($info['sender']);$ra=$c->aliases($info['recipient']);if(!in_array($gb,$sa['GB'],true)||!in_array($pk,$ra['PK'],true))throw new DomainException('Etiketleri e-İrsaliye bağlantı kontrolünden seçin.');
            query("UPDATE edm_despatch_test_documents SET attempted_at=UTC_TIMESTAMP(),provider_status='Gönderim denendi; sonuç henüz doğrulanmadı',updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?",[$cid,$id]);$result=$c->send(open_code($r['payload']),$gb,$pk);despatch369_save_status($cid,$id,$result);
        }elseif(in_array($action,['accept','reject','partial'],true)){
            if($r['direction']!=='IN'||!empty($r['response_attempted_at']))throw new DomainException('Bu irsaliyeye yanıt daha önce denendi. Durum sorgulayın.');
            $decision=match($action){'accept'=>'KABUL','reject'=>'RED','partial'=>'KISMI KABUL'};$reason=$action==='accept'?'':required_field('reason',1000);$accepted=$action==='partial'?($_POST['accepted']??[]):[];if(!is_array($accepted))throw new DomainException('Satır miktarları geçersiz.');EdmDespatch369::responsePlan($info,$decision,$accepted,$reason);
            $current=$c->status($info,'IN');despatch369_save_status($cid,$id,$current);if(despatch369_status($current)['STATUS']!=='RECEIVE - WAIT_APPLICATION_RESPONSE')throw new DomainException('Yanıt gönderilmedi. EDM henüz kabul/ret beklenen durumu doğrulamadı. Önce durum sorgulayın.');
            $payload=seal_code(json_encode(['decision'=>$decision,'accepted'=>$accepted,'reason'=>$reason],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE));
            query("UPDATE edm_despatch_test_documents SET response_attempted_at=UTC_TIMESTAMP(),response_decision=?,response_payload=?,provider_status='Yanıt denendi; son durum sorgulanmalı',updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?",[$decision,$payload,$cid,$id]);
            $c->respond($info,$decision,$accepted,$reason);query('UPDATE edm_despatch_test_documents SET response_acknowledged_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?',[$cid,$id]);despatch369_save_status($cid,$id,$c->status($info,'IN'));
        }else despatch369_save_status($cid,$id,$c->status($info,$r['direction']));
    }catch(DomainException $e){
        $error=['ERROR_CODE'=>(string)$e->getCode(),'ERROR_MESSAGE'=>mb_substr($e->getMessage(),0,1500)];
        query('UPDATE edm_despatch_test_documents SET provider_details=?,updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?',[json_encode($error,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE),$cid,$id]);throw $e;
    }finally{query('SELECT RELEASE_LOCK(?)',[$lock]);}
    audit('edm.despatch_action',['company'=>$cid,'reason'=>$action.' · yalnız test ortamı']);flash('e-İrsaliye servis yanıtı kaydedildi.');redirect('edm_test',$params+['id'=>$id]);
}
function despatch369_download():void{
    if(!isset($_GET['download']))return;$cid=despatch369_guard();$format=$_GET['download'];if(!is_string($format)||!in_array($format,['XML','PDF'],true))throw new DomainException('İrsaliye indirme biçimi geçersiz.');$id=filter_var($_GET['id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);if(!$id)throw new DomainException('Geçerli test irsaliyesi seçin.');$r=despatch369_row($cid,$id);if($r['direction']==='OUT'&&!$r['attempted_at'])throw new DomainException('İrsaliye henüz EDM’ye gönderilmedi.');throttle('despatch369-download-'.$cid,60);$a=EdmDespatch369::info(open_code($r['payload']));$bytes=EdmDespatch369::content(despatch369_client($cid)->get($r['direction'],$r['uuid'],$format),$a,$format);
    audit('edm.despatch_download',['company'=>$cid,'reason'=>$format.' · yalnız test ortamı']);header('Content-Type: '.($format==='PDF'?'application/pdf':'application/xml; charset=UTF-8'));header('Content-Disposition: attachment; filename="kobivira-irsaliye-test-'.$a['uuid'].'.'.strtolower($format).'"');header('X-Content-Type-Options: nosniff');header('Cache-Control: private, no-store, max-age=0');header('Content-Length: '.strlen($bytes));echo $bytes;exit;
}
function despatch369_view():void{
    if(!owner())need_feature('edoc_despatch');
    if(owner()){panel('e-İrsaliye test firması');echo '<form method="get" class="form-grid">';hidden('page','edm_test');hidden('kind','despatch');select_field('company_id','Firma',[0=>'Firma seçin']+query("SELECT id,name FROM companies WHERE status='active' ORDER BY name LIMIT 2000")->fetchAll(PDO::FETCH_KEY_PAIR),(int)($_GET['company_id']??0));submit('e-İrsaliye testini aç');echo '</form></section>';if(empty($_GET['company_id']))return;}
    $cid=despatch369_guard();$p=['company_id'=>$cid,'kind'=>'despatch'];$a=edm361_account($cid);panel('e-İrsaliye test bağlantısı','Aynı firmaya ait EDM kullanıcı bilgileri, ayrı e-İrsaliye test servisiyle kullanılır. Muhasebe ve stok hareketi oluşmaz.');echo '<p>'.a('edm_test','e-Fatura / e-Arşiv testine dön',['company_id'=>$cid],'button').'</p>';
    if(!$a||!$a['enabled']){echo '<p>Önce e-Fatura test alanından firma EDM hesabını etkinleştirin.</p></section>';return;}
    echo '<p>Test adresi: <code>'.esc(EdmDespatch369::ENDPOINT).'</code></p>';form_start('edm_test','despatch_check',$p);hidden('company_id',$cid);form_end('e-İrsaliye bağlantısını ve etiketleri kontrol et');
    $check=$_SESSION['despatch369_check']??[];if(($check['company']??0)===$cid){echo '<p>Son sorgudaki test kontör bakiyesi: '.esc($check['balance']).'</p>';foreach(['GB'=>'Gönderici GB','PK'=>'Alıcı PK'] as $k=>$label)echo '<p>'.esc($label).': '.esc(implode(' · ',$check['aliases'][$k])).'</p>';}echo '</section>';
    $id=(int)($_GET['id']??0);if($id){$r=despatch369_row($cid,$id);$i=EdmDespatch369::info(open_code($r['payload']));panel($r['number'],$r['provider_status']);foreach(['uuid'=>'UUID','sender'=>'Gönderici VKN/TCKN','recipient'=>'Alıcı VKN/TCKN','date'=>'Tarih','profile'=>'Senaryo'] as $k=>$label)echo '<p>'.esc($label).': '.esc($i[$k]).'</p>';echo '<p>Belge yönü: <strong>'.esc($r['direction']).'</strong></p><p>'.a('edm_test','İrsaliye test listesine dön',$p,'button').'</p>';
        $details=json_decode($r['provider_details']??'{}',true)?:[];foreach(['ENVELOPE_HISTORY_STATUS'=>'Zarf geçmişi durum kodu','ENVELOPE_HISTORY_MESSAGE'=>'Zarf geçmişi açıklaması','ENVELOPE_HISTORY_DATE'=>'Zarf geçmişi zamanı','ERROR_CODE'=>'Servis hata kodu','ERROR_MESSAGE'=>'Servis hata açıklaması','GIB_STATUS_CODE'=>'GİB durum kodu','GIB_STATUS_DESCRIPTION'=>'GİB açıklaması','RESPONSE_CODE'=>'Yanıt kodu','RESPONSE_DESCRIPTION'=>'Yanıt açıklaması','ENVELOPE_IDENTIFIER'=>'Zarf UUID'] as $k=>$label)if(($details[$k]??'')!=='')echo '<p>'.esc($label).': '.esc($details[$k]).'</p>';
        table_start(['Satır','Mal','Miktar','Birim']);foreach($i['lines'] as $line)echo '<tr><td>'.esc($line['id']).'</td><td>'.esc($line['name']).'</td><td>'.esc($line['quantity']).'</td><td>'.esc($line['unit']).'</td></tr>';table_end(count($i['lines']),4);
        if($r['direction']==='IN'||$r['attempted_at']){form_start('edm_test','despatch_status',$p+['id'=>$id]);hidden('company_id',$cid);hidden('id',$id);form_end('İrsaliye durumunu sorgula');echo '<p>Durum aynı belge için en az 30 saniye arayla sorgulanır.</p><p>'.a('edm_test','EDM’den irsaliye PDF indir',$p+['id'=>$id,'download'=>'PDF'],'button').' '.a('edm_test','EDM’den irsaliye XML indir',$p+['id'=>$id,'download'=>'XML'],'button').'</p>';}
        if($r['direction']==='OUT'&&!$r['attempted_at']){form_start('edm_test','despatch_send',$p+['id'=>$id]);hidden('company_id',$cid);hidden('id',$id);$gb=$check['aliases']['GB']??[];$pk=$i['recipient']===$a['tax_number']?($check['aliases']['PK']??[]):[];
            if(($check['company']??0)===$cid&&$gb&&$pk){$pick=static fn($items,$default)=>in_array($default,$items,true)?$default:$items[0];select_field('sender_alias','e-İrsaliye gönderici GB etiketi',array_combine($gb,$gb),$pick($gb,'urn:mail:defaultgb@edmbilisim.com.tr'));select_field('recipient_alias','e-İrsaliye alıcı PK etiketi',array_combine($pk,$pk),$pick($pk,'urn:mail:defaultpk@edmbilisim.com.tr'));}else{input('sender_alias','e-İrsaliye gönderici GB etiketi','','text','required maxlength="250"');input('recipient_alias','e-İrsaliye alıcı PK etiketi','','text','required maxlength="250"');echo '<p>Önce bağlantı kontrolünü çalıştırın. Başka alıcının etiketi gönderim öncesinde servisten doğrulanır.</p>';}
            echo '<label class="wide"><input type="checkbox" name="confirm_test" value="1" required> Bu irsaliyeyi yalnız EDM test ortamına göndermek istiyorum.</label>';form_end('Test irsaliyesini EDM’ye gönder');
        }elseif($r['direction']==='OUT')echo '<p>Gönderim denemesi kayıtlı; aynı belge yeniden gönderilmez. Durum sorgulayın.</p>';
        if($r['direction']==='OUT'){$in=query("SELECT id FROM edm_despatch_test_documents WHERE company_id=? AND direction='IN' AND uuid=?",[$cid,$r['uuid']])->fetchColumn();if($in)echo '<p>'.a('edm_test','İrsaliyenin gelen kaydını aç',$p+['id'=>(int)$in],'button').'</p>';else echo '<p>Gelen kaydı görmek için listeye dönüp gelen irsaliyeleri sorgulayın.</p>';}
        if($r['direction']==='IN')despatch3612_response_view($r,$i,$p,$cid);
        echo '<p>Yalnız EDM test ortamı. Kabul, ret ve kısmi kabul testlerini ayrı belgeler üzerinde yapın.</p></section>';return;
    }
    panel('Örnek test irsaliyesi hazırla','EDM’den EDM’ye örnek hazırlanır. Hazırlamak belge göndermez. Örnekteki sevkiyat bilgileri yalnız test içindir.');if($a['tax_number']==='3230512384'){form_start('edm_test','despatch_sample',$p);hidden('company_id',$cid);form_end('Örnek e-İrsaliye hazırla');}echo '</section>';
    panel('UBL irsaliye XML yükle','Kendi test belgeniz için kullanın; en fazla 2 MB. EDM gönderim sırasında şema ve belge kontrollerini yapar.');form_start('edm_test','despatch_stage',$p);hidden('company_id',$cid);input('ubl','UBL DespatchAdvice XML','','file','required accept=".xml"');form_end('İrsaliye XML’ini test listesine ekle');echo '</section>';
    panel('Gelen test irsaliyeleri');form_start('edm_test','despatch_sync',$p);hidden('company_id',$cid);input('start','Başlangıç',date('Y-m-d',time()-7*86400),'date','required');input('end','Bitiş',today(),'date','required');form_end('EDM’den gelen test irsaliyelerini getir');echo '</section>';
    panel('e-İrsaliye test kayıtları');table_start(['İrsaliye','Yön','EDM durumu','']);$rows=query('SELECT id,number,direction,provider_status FROM edm_despatch_test_documents WHERE company_id=? ORDER BY id DESC LIMIT 100',[$cid])->fetchAll();foreach($rows as $r)echo '<tr><td>'.esc($r['number']).'</td><td>'.esc($r['direction']).'</td><td>'.esc($r['provider_status']).'</td><td>'.a('edm_test','İncele',$p+['id'=>$r['id']]).'</td></tr>';table_end(count($rows),4);echo '</section>';
}

function despatch3612_response_view(array $r,array $info,array $params,int $cid):void{
    if(!empty($r['response_attempted_at'])){
        echo '<p>Kayıtlı irsaliye yanıt denemesi: <strong>'.esc($r['response_decision']).'</strong></p>';
        $expected=match($r['response_decision']){'KABUL'=>'ACCEPT - SUCCEED','RED'=>'REJECT - SUCCEED','KISMI KABUL'=>'PARTIALACCEPT - SUCCEED',default=>''};$final=$r['provider_status']===$expected;
        echo '<p>'.($final?'EDM yanıtı başarıyla tamamlandı.':'Yanıt denemesi kayıtlı; sonucu yalnız EDM durumuyla doğrulayın.').' Aynı irsaliyeye ikinci yanıt gönderilmez.</p>';return;
    }
    if($r['provider_status']!=='RECEIVE - WAIT_APPLICATION_RESPONSE'){echo '<p>Kabul/ret alanı için EDM’nin RECEIVE - WAIT_APPLICATION_RESPONSE durumuna ulaşması gerekir. WAIT_SYSTEM_RESPONSE aşamasında yanıt gönderilmez. İrsaliye durumunu sorgulayın.</p>';return;}
    echo '<h3>Gelen test irsaliyesine yanıt</h3><p>Bu belge için tek bir yanıt seçin. Ret ve kısmi kabul diğer ayrı test belgelerinde denenebilir.</p>';
    foreach(['accept'=>'Test irsaliyesini kabul et','reject'=>'Test irsaliyesini reddet','partial'=>'Test irsaliyesine kısmi kabul gönder'] as $action=>$label){
        form_start('edm_test','despatch_'.$action,$params+['id'=>$r['id']]);hidden('company_id',$cid);hidden('id',$r['id']);
        if($action==='partial'){echo '<p>Her satırda kabul ettiğiniz miktarı girin. Kalan miktar ret olarak gönderilir. Eksik/fazla teslimat bu testin kapsamı dışındadır.</p>';foreach($info['lines'] as $index=>$line)input('accepted['.$index.']',$line['id'].' · '.$line['name'].' · Gönderilen: '.$line['quantity'].' '.$line['unit'],$line['quantity'],'number','required min="0" max="'.esc($line['quantity']).'" step="0.000001"');}
        if($action!=='accept')textarea('reason',$action==='partial'?'Kısmi ret gerekçesi':'Ret gerekçesi','','required maxlength="1000"');
        echo '<label class="wide"><input type="checkbox" name="confirm_test" value="1" required> Bu irsaliye yanıtını EDM test ortamında göndermek istiyorum.</label>';form_end($label);
    }
}
