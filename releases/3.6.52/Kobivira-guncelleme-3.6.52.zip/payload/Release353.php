<?php
declare(strict_types=1);
function form353_ajax(): bool {return ($_SERVER['REQUEST_METHOD']??'')==='POST'&&($_SERVER['HTTP_X_KOBIVIRA_FORM']??'')==='1';}
function form353_response(bool $ok,string $message,?string $redirect=null,int $status=200): never {
 http_response_code($status);header_remove('Location');header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode(['ok'=>$ok,'message'=>$message,'field'=>$GLOBALS['validation_field']??null,'redirect'=>$redirect,'action'=>$ok?null:($GLOBALS['validation_action']??null)],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);exit;
}
function promotion353_upload(): never {
 admin351_guard();reauthenticate(base_user());$old=$_GET['site']??null;$_GET['site']=1;$dest=null;
 try{cms_tx(function()use(&$dest){cms_upload_locked($dest);$id=(int)db()->lastInsertId();$c=promotion352_config();$c['image_id']=$id;query('INSERT INTO settings(name,value) VALUES (?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',['promotion352',json_encode($c,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);audit('promotion.image_uploaded',['id'=>$id]);});}catch(Throwable $e){if($dest&&is_file($dest))unlink($dest);throw $e;}finally{if($old===null)unset($_GET['site']);else $_GET['site']=$old;}
 if(form353_ajax()){$image=query('SELECT id,name,filename FROM cms_media WHERE site_id=1 AND id=?',[(int)promotion352_config()['image_id']])->fetch();header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>true,'message'=>'Görsel yüklendi ve seçildi. Diğer form bilgileriniz korunuyor.','image'=>$image],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);exit;}flash('Görsel yüklendi ve popup için seçildi.');redirect('promotion_admin');
}
function promotion353_upload_view(): void {
 panel('Popup görseli yükle','İsteğe bağlı. PNG, JPG veya WebP; en fazla 4 MB. Görselsiz kullanım için yukarıdaki Görsel listesinden Görselsiz kullan seçeneğini kaydedin.');form_start('promotion_admin','upload_image');input('image','Yeni görsel','','file','required accept="image/png,image/jpeg,image/webp"');input('name','Görsel adı','','text','maxlength="200"');input('current_password','Mevcut yönetici şifreniz','','password','required');form_end('Görseli yükle ve seç');$c=promotion352_config();$url=promotion352_image((int)$c['image_id']);if($url){$file=query('SELECT filename FROM cms_media WHERE site_id=1 AND id=?',[$c['image_id']])->fetchColumn();echo '<p><img class="popup353-image" src="'.esc('https://kobivira.com.tr/index.php?media='.rawurlencode($file)).'" alt="Seçili popup görseli"></p>';}echo '</section>';
}
function promotion353_visitor(array $c): string {
 if(($c['visitor_mode']??'browser')==='ip')return hash_hmac('sha256','popup353:ip:'.($_SERVER['REMOTE_ADDR']??''),config()['app_key']);
 $v=$_COOKIE['kv_popup353']??'';if(!is_string($v)||!preg_match('/^[a-f0-9]{32}$/D',$v)){$v=bin2hex(random_bytes(16));$_COOKIE['kv_popup353']=$v;$https=!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off';setcookie('kv_popup353',$v,['expires'=>time()+86400*30,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);}
 return hash_hmac('sha256','popup353:browser:'.$v,config()['app_key']);
}
function promotion353_claim(): array {
 check_csrf();$c=promotion352_config();if(!$c['enabled'])return ['ok'=>true,'show'=>false,'retry_after'=>86400];$hash=promotion353_visitor($c);$day=(new DateTimeImmutable('now',new DateTimeZone('Europe/Istanbul')))->format('Y-m-d');$limit=max(1,min(100,(int)$c['daily_limit']));$delay=max(1,min(1440,(int)$c['cooldown_minutes']))*60;
 return transaction(function()use($hash,$day,$limit,$delay){query('DELETE FROM popup_impressions WHERE day<DATE_SUB(UTC_DATE(),INTERVAL 8 DAY)');query('INSERT IGNORE INTO popup_impressions(day,visitor_hash,views) VALUES (?,?,0)',[$day,$hash]);$r=query('SELECT * FROM popup_impressions WHERE day=? AND visitor_hash=? FOR UPDATE',[$day,$hash])->fetch();$nextDay=(new DateTimeImmutable('tomorrow',new DateTimeZone('Europe/Istanbul')))->getTimestamp()-time();if((int)$r['views']>=$limit)return ['ok'=>true,'show'=>false,'retry_after'=>max(1,$nextDay)];$last=$r['last_shown']?strtotime($r['last_shown'].' UTC'):0;$retry=$last+$delay-time();if($retry>0)return ['ok'=>true,'show'=>false,'retry_after'=>$retry];query('UPDATE popup_impressions SET views=views+1,last_shown=UTC_TIMESTAMP() WHERE day=? AND visitor_hash=?',[$day,$hash]);return ['ok'=>true,'show'=>true,'retry_after'=>$delay,'remaining'=>max(0,$limit-(int)$r['views']-1)];});
}
function promotion353_public_claim(): never {
 header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');try{if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);throw new DomainException('Geçersiz istek.');}echo json_encode(promotion353_claim(),JSON_THROW_ON_ERROR);}catch(DomainException $e){if(http_response_code()<400)http_response_code(422);echo json_encode(['ok'=>false,'show'=>false,'message'=>$e->getMessage()],JSON_UNESCAPED_UNICODE);}catch(Throwable $e){error_log((string)$e);http_response_code(500);echo '{"ok":false,"show":false}';}exit;
}
