# Kobivira 3.6.2 — EDM test oturumu düzeltmesi

22 Ekim 2026. Bu sürüm yalnız 3.6.1 üzerine kurulabilir.

## Bulunan hata

Kullanıcının bildirdiği “EDM servis işlemini reddetti. Hesap yetkisi ve belge bilgilerini kontrol edin.” mesajı gerçek EDM test servisinde yeniden üretildi. Kullanıcı adı ve şifreyle Login başarılı oldu. Test hesabının GetCompany yanıtında tek VKN olarak 3230512384 döndü.

Deney 1: Login → CheckCounter başarılı.
Deney 2: Login → GetCompany → CheckCounter, SOAP InvalidSecurity / “The caller was not authenticated by the service.” hatası verdi.
Deney 3: Login → GetCompany → Login → CheckCounter başarılı.

Bulgular, GetCompany çağrısının önceki oturumu bu hesap/servis üzerinde geçersiz kıldığına işaret ediyor. Bu nedenle firma eşleşmesi korundu, eşleşmeden sonra taze oturum açılması eklendi. Hata kullanıcı şifresini değiştirerek giderilecek bir sorun değildir.

## Değişiklik

Edm361Client::connect() ilk giriş, firma doğrulama ve oturum yenilemeyi tek yerde toplar. Yönetici ve firma panelindeki tüm EDM işlemleri aynı bağlantı yolunu kullanır. Kontör sorgusu veya fatura gönderimi otomatik tekrar edilmez. Firma eşleşmezse ikinci girişe ve belge işlemine geçilmez. InvalidSecurity yanıtı artık ayrı, sırlardan arındırılmış oturum hatasıyla gösterilir.

Mevcut şifreli hesaplar, test belgeleri, kontör, abonelik, fiyat ve site içeriği korunur. Yeni migration yoktur; önceki 33 migration değişmedi. Yeni bir ürün veya e-belge modülü eklenmedi. e-Reçete/e-Bilet bu sürümün kapsamında değildir.

## Yapılan testler

- Gerçek EDM test hesabı: giriş, firma eşleşmesi, oturum yenileme ve kontör okuma başarılı. Bakiye test ortamı verisidir, satın alınmış üretim kontörü anlamına gelmez.
- Ağ kısıtı nedeniyle bu çalışma ortamındaki PHP doğrudan DNS çözemedi. Gerçek servise giden SOAP gövdeleri ve yanıtlar uygulama istemcisiyle oluşturulup çözümlendi; HTTPS taşıması ortamın proxy desteğini kullanan Python köprüsü üzerinden yapıldı. Kullanıcının sunucusuna giriş veya kurulum yapılmadı.
- GetCompany sonrasında oturumu iptal eden sahte servisle eski hata yeniden üretildi; yeni akışın başarıyla tamamlandığı ve yanlış firma eşleşmesinde durduğu doğrulandı.
- Önceki SOAP, veritabanı, firma/paket yetkisi, CSRF, dosya yükleme ve mükerrer kayıt kontrolleri yeni kodla çalıştırıldı.
- PHP/JavaScript sözdizimi, tasarım varlıkları ve eski migration bütünlüğü kontrol edildi.
- İmzalı 3.6.1 → 3.6.2 gerçek yerel güncelleme; paket kurcalama engeli; kayıtlı şifreli EDM hesabı ve test belgelerinin aynen korunması test edildi.

Bu çalışmada fatura gönderilmedi, kabul/ret işlemi yapılmadı. Başarılı bağlantı, fatura alım/gönderiminin veya üretim onayının tamamlandığı anlamına gelmez. 3.6.1 inceleme raporu ve test kayıtları önceki sürümün tarihsel bulgularıdır; bağlantı testi için güncel sonuç bu nottur.

## Kurulum ve yeniden deneme

1. Kobivira yönetici panelindeki Sistem → Sürüm güncellemeleri alanından Kobivira-guncelleme-3.6.2.zip dosyasını yükleyin. Normal güncelleyici yedek alır.
2. EDM test alanında kayıtlı kullanıcı/şifreyi koruyun. Test VKN/TCKN alanı 3230512384 olmalıdır; gerçek şirket VKN’siyle karıştırmayın.
3. “Hesabı, firma eşleşmesini ve bakiyeyi test et” düğmesine basın. Firma paneli de bu düzeltmeyi kullanır.
4. Başarıda bağlantı sonucu ve EDM test bakiyesi görünür. Başka hata çıkarsa mesajını paylaşın; şifre veya oturum anahtarını paylaşmayın.

Test parolası, oturum anahtarları, ham servis yanıtları ve imzalama özel anahtarı pakete dahil edilmez.
