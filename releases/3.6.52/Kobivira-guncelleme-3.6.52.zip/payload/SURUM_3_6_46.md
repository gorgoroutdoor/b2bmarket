# 3.6.46 — Sürüm geçmişi ve firma silme kayıt temizliği

3.6.45 üzerine imzalı güncelleme. Yeni migration yoktur.

3.6.45 değişiklikleri ayrı Markdown dosyasında bulunmasına rağmen yönetimdeki release_history.json kataloğuna eklenmemişti. Eksik 3.6.45 kaydı ve bu sürümün kaydı eklenir; önceki kayıtlar değiştirilmez. Yönetim → Sistem → Güncellemeler bölümündeki sürüm filtresinden ayrıntılar görülebilir.

Firma silme, e-posta ve mobil kod kayıtlarını kullanıcıdan önce açıkça temizler. Önceki veritabanı kısıtları bu kayıtları zaten otomatik siliyordu; bu değişiklik kullanıcı tarafından bildirilen silme hatasının nedeni olarak doğrulanmamıştır. Eski JSONL güncelleme yedekleri temizlenirken kullanıcı kimliğine bağlı iki doğrulama tablosu da hesaba katılır. Başka firmaların kayıtları korunur. Yönetici şifresi, firma unvanı, SİL ve onay kutusu gereklilikleri korunur.

Gerçek firmanın silinmesi veya hosting değişikliği yapılmadı. Kullanıcıdaki silme sorununun kesin nedeni için ekrandaki hata mesajı gereklidir. E-postanın spama düşmesine yönelik DNS değişikliği bu sürümde yapılmaz; SPF/DKIM durumu hostingden incelenmelidir.
