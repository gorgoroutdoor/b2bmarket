<?php
declare(strict_types=1);
/** Import source tax totals without inventing a tax rate or silently dropping taxes. */
function ubl356_taxes(DOMXPath $xp,DOMNode $node): array {
 $out=['vat'=>0,'extra'=>0];$total=0;$parts=0;
 foreach($xp->query('a:TaxTotal',$node) as $tax){
  $amount=scaled(trim($xp->evaluate('string(c:TaxAmount)',$tax))?:'0');$total+=$amount;
  foreach($xp->query('a:TaxSubtotal',$tax) as $sub){$code=trim($xp->evaluate('string(a:TaxCategory/a:TaxScheme/c:TaxTypeCode)',$sub));if(!preg_match('/^\d{4}$/D',$code))throw new DomainException('XML vergi türü belirtilmemiş veya tanınmıyor.');$n=scaled(trim($xp->evaluate('string(c:TaxAmount)',$sub))?:'0');$out[$code==='0015'?'vat':'extra']+=$n;$parts+=$n;}
 }
 if($parts===0&&$total>0&&$node instanceof DOMElement&&$node->localName==='Invoice'&&$xp->evaluate('count(a:TaxTotal/a:TaxSubtotal)',$node)==0){$out=['vat'=>0,'extra'=>0];foreach($xp->query('a:InvoiceLine',$node) as $line){$t=ubl356_taxes($xp,$line);$out['vat']+=$t['vat'];$out['extra']+=$t['extra'];}$parts=$out['vat']+$out['extra'];}
 if($parts!==$total)throw new DomainException('XML vergi alt kırılımları toplam vergiyle uyuşmuyor.');return $out;
}
function ubl356_withholding(DOMXPath $xp,DOMNode $node): int {
 $total=0;foreach($xp->query('a:WithholdingTaxTotal',$node) as $tax){$n=scaled(trim($xp->evaluate('string(c:TaxAmount)',$tax))?:'0');$parts=0;foreach($xp->query('a:TaxSubtotal',$tax) as $sub){$code=trim($xp->evaluate('string(a:TaxCategory/a:TaxScheme/c:TaxTypeCode)',$sub));if(!preg_match('/^6\d{2}$/D',$code))throw new DomainException('Bu XML kesinti türü KDV tevkifatı olarak aktarılamıyor.');$parts+=scaled(trim($xp->evaluate('string(c:TaxAmount)',$sub))?:'0');}if($parts!==$n)throw new DomainException('XML tevkifat kırılımı uyuşmuyor.');$total+=$n;}return $total;
}
function migration356_return_source(array $x,string $target): array {
 need_feature('returns');$kind=$target==='sale'?'purchase':'sale';
 $rows=query("SELECT d.* FROM documents d JOIN contacts c ON c.company_id=d.company_id AND c.id=d.contact_id WHERE d.company_id=? AND d.kind IN (".($kind==='sale'?"'sale'":"'purchase','expense'").") AND d.status='posted' AND d.return_of_id IS NULL AND (d.external_number=? OR d.number=?) AND c.tax_number=?",[company_id(),$x['return_reference'],$x['return_reference'],$x['tax_number']])->fetchAll();
 if(count($rows)!==1)throw new DomainException('İadenin kaynak faturası bulunamadı veya birden fazla eşleşme var. Önce kaynak faturayı aktarın.');$d=$rows[0];
 if($d['currency']!==$x['currency']||$x['issue_date']<$d['issue_date']||($x['currency']!=='TRY'&&(int)$d['fx_rate']!==$x['fx_rate']))throw new DomainException('İade para birimi, kuru veya tarihi kaynak faturayla uyuşmuyor.');return $d;
}
function migration356_return(array $x,string $target,array $options): int {
 need_feature('returns');require_document_capacity();if(($options['mode']??'draft')!=='posted')throw new DomainException('İade aktarımı kaynak faturayı düzeltir. Dosyayı Kesinleşmiş seçeneğiyle yeniden ön izleyip onaylayın.');
 $d=migration356_return_source($x,$target);tenant_row('documents',(int)$d['id'],true);$qs=[];$used=[];
 foreach($x['lines'] as $line){$matches=[];foreach(query('SELECT * FROM document_lines WHERE company_id=? AND document_id=?',[company_id(),$d['id']]) as $l)if($l['label']===$line['label']&&(int)$l['vat']===$line['vat']&&!isset($used[$l['id']]))$matches[]=$l;if(count($matches)!==1)throw new DomainException('İade satırı kaynak faturayla tekil eşleşmedi: '.$line['label']);$l=$matches[0];$used[$l['id']]=true;$qs[$l['id']]=$line['quantity'];}
 $id=ledger_return_create((int)$d['id'],$qs,$x['issue_date'],'Dosyadan aktarılan iade · '.$x['number'],substr(hash('sha256','return356|'.company_id().'|'.invoice_identity($x,$d['kind'])),0,32));$r=tenant_row('documents',$id);
 if(-(int)$r['native_total']!==$x['total']||-(int)$r['native_tax']!==$x['tax']||-(int)$r['native_subtotal']!==$x['net'])throw new DomainException('İade toplamı kaynak faturanın kalan tutar / miktarlarıyla uyuşmuyor. Hiçbir iade kaydedilmedi.');
 foreach($x['lines'] as $line){$l=query('SELECT * FROM document_lines WHERE company_id=? AND document_id=? AND label=?',[company_id(),$id,$line['label']])->fetch();if(!$l||-(int)$l['net']!==$line['net']||-(int)$l['tax']!==$line['tax'])throw new DomainException('İade satır tutarları kaynak faturanın miktar dağılımıyla uyuşmuyor.');}
 query('UPDATE documents SET external_number=?,source_kind=?,source_identity=?,electronic_type=? WHERE company_id=? AND id=?',[$x['number'],'file_return',invoice_identity($x,$d['kind']),$x['electronic_type'],company_id(),$id]);return $id;
}
