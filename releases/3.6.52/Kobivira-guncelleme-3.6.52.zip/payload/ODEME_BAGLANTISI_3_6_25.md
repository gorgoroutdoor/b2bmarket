# 3.6.25 — Bekleyen ödeme talebini açma

3.6.24 üzerine yüklenir. Paket satın alırken farklı paket, dönem veya yöntemle sonuçlanmamış talep çakışması oluşursa uyarı altında **Ödeme talebini aç** düğmesi gösterilir. Düğme genel listeye değil, o firmaya ait mevcut bekleyen ödeme kaydına gider. Kart veya havale talebinin durumunu ya da tutarını değiştirmez ve yeni ödeme başlatmaz.

Sayfa içi form uyarısı ve JavaScript olmadan verilen standart HTML yanıtı desteklenir. Form alanları korunur. Sayfa içi hata düğmesi yalnız aynı kaynaktaki HTTP/HTTPS bağlantılarını kabul eder; etiket ve mesaj HTML olarak çalıştırılmaz.

Doğrulama: 3.6.24 → 3.6.25 imzalı kurulum; firma, üyelik, ödeme ve migration kayıtlarının korunması; iki firmayla 14 yerel HTTP kontrolü; 8 DOM kontrolü; değişen 3 PHP dosyasının sözdizimi kontrolü. 45 mevcut migration dosyası değiştirilmedi. Bu sürümde gerçek PayTR isteği veya ödeme yapılmadı.
