# Kobivira 3.6.39 — Ücretsiz hesaplama araçları

3.6.38 üzerine yüklenen imzalı tam güncelleme paketidir. **Yönetim → Sistem → Sürüm güncellemeleri** alanına ZIP olarak yüklenir. Ayrı sayfa veya resim yükleme gerekmez.

## Otomatik eklenenler

**Araçlar** dizini: `araclar.html`.

1. KDV Hesaplama — `kdv-hesaplama.html`
2. Kâr Marjı Hesaplama — `kar-marji-hesaplama.html`
3. İskonto Hesaplama — `iskonto-hesaplama.html`
4. KDV Tevkifat Hesaplama — `tevkifat-hesaplama.html`
5. Stopaj Hesaplama — `stopaj-hesaplama.html`
6. Fatura Toplamı Hesaplama — `fatura-hesaplama.html`
7. Satış Fiyatı Hesaplama — `satis-fiyati-hesaplama.html`
8. Vade Farkı Hesaplama — `vade-farki-hesaplama.html`
9. Komisyon Hesaplama — `komisyon-hesaplama.html`

Ana menüye **Araçlar** açılır menüsü eklenir. Footer'da dokuz aracın bağlantısı kompakt, masaüstünde üç, mobilde iki sütunlu ayrı bölümde listelenir; Kaynaklar alanından tüm araçlara ulaşılır. Mevcut footer bağlantıları, logo, SEO metni ve ödeme logoları kaldırılmaz.

Dokuz aracın her biri hazır hesaplama alanı, sonuç kartı, özgün kullanım makalesi, formül, sayısal örnek, üç sık sorulan soru ve ilgili Kobivira özellik / rehber bağlantılarıyla gelir. Metinler ve tasarım Kobivira için hazırlanmıştır; Parola metni, görseli, CSS'i veya sayfa kodu pakete dahil edilmemiştir.

## Kullanım ve yönetim

Araçlar üyelik veya firma girişi istemez. Hesaplama JavaScript ile tarayıcıda yapılır; girilen tutarlar hesaplama amacıyla sunucuya gönderilmez ve kaydedilmez. Araçlar ödeme almaz, resmî belge düzenlemez ve firma kayıtlarına işlem oluşturmaz.

Yönetici oturumunda ilgili sayfanın **Bu sayfayı düzenle** veya içerik bölümünün **Düzenle** bağlantısı kendi CMS kaydını açar. Başlık, makale, formül açıklaması, örnek ve soru/yanıt metinleri mevcut alanlardan düzenlenebilir. Sayfa adresleri sabittir. Hesaplama algoritması yazılımda kalır; metin düzenlemesi algoritmayı değiştirmez. Metinlerde oran/örnek değiştirirken hesapla tutarlı kalmasına dikkat edin.

Araç bağlantıları Site yönetiminin menü kayıtlarında **Araçlar / Menü ve footer** kapsamında düzenlenebilir. Gizlenen bağlantı açılır menüden ve footer araç bölümünden kaldırılır. Taslak yapılan araç dizin ve menü listelerinde görünmez. Aynı adreste önceden oluşturulmuş bir CMS sayfası varsa içeriği üzerine yazılmaz. Kurulum yalnız ana Kobivira sitesine kayıt ekler.

## Hesaplama kapsamları

- KDV: hariç tutardan vergi ekleme ve dahil tutardan matrah ayrıştırma. Hazır oranlar hızlı seçim içindir; ürün/hizmet sınıflandırması yapılmaz.
- Kâr marjı: satış üzerinden marj ile maliyet üzerinden kâr oranı ayrı gösterilir. Sıfır paydada oran hesaplanamaz olarak belirtilir.
- İskonto: en fazla üç ardışık yüzde; her aşama kuruşa yuvarlanır. KDV eklenmez.
- Tevkifat: seçilen pay hesaplanan KDV'ye uygulanır; kapsam, alıcı koşulları ve mevzuattaki alt sınır otomatik doğrulanmaz.
- Stopaj: tek oranlı brüt/net hesabı; ücret bordrosu, KDV veya başka kesinti dahil değildir.
- Fatura: en fazla 20 satır; üç ondalığa kadar miktar, KDV hariç birim fiyat, iskonto ve KDV. Her satırın bedeli, indirimi ve KDV'si kuruşa yuvarlanır; satırlar toplanır. Tevkifat, stopaj ve ÖTV dahil değildir.
- Satış fiyatı: maliyet ve ek giderden hedef marj veya maliyet üzerine kâr; KDV ayrı gösterilir.
- Vade farkı: basit hesap; aylık 30, yıllık 365, günlük 1 gün bazlı. Vergi yalnız vade farkına uygulanır. Hukuki uygulanabilirlik veya yasal faiz oranı belirlenmez.
- Komisyon: satış üzerinden oran ve sabit komisyon, ayrıca komisyonun KDV'si. Hedef net hesabı gerçek hesaplanan netle birlikte gösterilir. Satışın KDV'si veya diğer masraflar ayrıca hesaplanmaz.

Ondalık ve kuruş işlemleri BigInt sabit nokta aritmetiğiyle yapılır. Kullanıcı girişleri negatif olamaz; zarar ve net eksi tutarları sonuçta gösterilebilir. Yüzde ve tutar sınırları denetlenir. Türkçe `1.234,56` ve noktalı `1234.56` giriş desteklenir; `1.000` tutar alanında bin olarak yorumlanır. Tutar alanlarında en fazla iki, fatura miktarında üç ondalık basamak kullanılabilir.

## Kontroller

- İzole veritabanında imzalı **3.6.38 → 3.6.39** güncellemesi başarılıdır.
- **649** aritmetik testi, **462** PHP/veritabanı kontrolü, **248** HTTP kontrolü ve **59** DOM etkileşim testi başarılıdır.
- **179** PHP dosyasının sözdizimi denetlenmiştir.
- Önceki 50 özellik sayfası, formlar ve rehber bağlantıları kontrol edilmiştir; firma, kullanıcı, ödeme, kontör, paket ve hukuk kayıtlarının korunduğu doğrulanmıştır.
- Yeni göç: `051_public_calculators.php`. Önceki göçlerin içerikleri ve sağlama değerleri değiştirilmemiştir.
- Bu oturumdaki yerel ön izlemeye bulut tarayıcısı erişemediği için masaüstü/mobil görsel tarayıcı kontrolü tamamlanamamıştır. DOM testleri görsel yerleşim testi olarak sunulmaz.

Vergisel kapsam kaynakları 24.10.2026 tarihinde GİB kaynaklarından kontrol edilmiş; ilgili sayfalara kaynak bağlantıları konmuştur. Kullanıcı kendi işlemine uygulanacak oranı ve koşulları ayrıca belirlemelidir. Araçlar beyanname, resmî belge veya mali müşavirlik hizmeti üretmez.
