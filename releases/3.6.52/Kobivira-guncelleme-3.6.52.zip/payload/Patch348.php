<?php
declare(strict_types=1);
/** 3.4.8: shared safeguards; no package entitlement or visual theme changes. */
function credit_order_admin_notice(int $id): void {
 $r=query('SELECT o.*,c.name company_name FROM credit_orders o JOIN companies c ON c.id=o.company_id WHERE o.id=?',[$id])->fetch();
 if(!$r||$r['status']!=='reported')return;
 $event='credit-order:'.$id.':reported';
 admin_notification((int)$r['company_id'],$event,'credit_transfer_report','Yeni kontör havale bildirimi',$r['company_name'].' · '.$r['reference'].' · '.$r['quantity'].' kontör · '.money((int)$r['total']),$id);
 query("UPDATE admin_notifications SET target_page='credits' WHERE company_id=? AND event_key=?",[$r['company_id'],$event]);
}
function kv_page(int $total,int $size=50): array {
 $raw=$_GET['p']??'1';$page=is_scalar($raw)&&ctype_digit((string)$raw)?max(1,(int)$raw):1;
 $pages=max(1,(int)ceil($total/$size));$page=min($page,$pages);
 return ['total'=>$total,'page'=>$page,'pages'=>$pages,'size'=>$size,'offset'=>($page-1)*$size];
}
function kv_pager(array $p): void {
 if($p['total']===0)return;
 $params=[];foreach(['kind','status','view','from','to','account','q'] as $key)if(isset($_GET[$key])&&is_string($_GET[$key]))$params[$key]=$_GET[$key];
 $page=is_string($_GET['page']??null)?$_GET['page']:'dashboard';
 echo '<div class="panel-bottom">'.($p['offset']+1).'–'.min($p['offset']+$p['size'],$p['total']).' / '.$p['total'].' kayıt · Sayfa '.$p['page'].' / '.$p['pages'].' ';
 if($p['page']>1)echo a($page,'Önceki',$params+['p'=>$p['page']-1],'button');
 if($p['page']<$p['pages'])echo ' '.a($page,'Sonraki',$params+['p'=>$p['page']+1],'button');
 echo '</div>';
}
function kv_doc_sql(): string {
 return " FROM documents d LEFT JOIN contacts c ON c.company_id=d.company_id AND c.id=d.contact_id LEFT JOIN (SELECT company_id,document_id,SUM(amount) paid FROM (SELECT company_id,document_id,amount FROM payments WHERE reversed_at IS NULL UNION ALL SELECT company_id,return_of_id document_id,-total amount FROM documents WHERE return_of_id IS NOT NULL AND status='posted') movements WHERE company_id=? GROUP BY company_id,document_id) p ON p.company_id=d.company_id AND p.document_id=d.id WHERE d.company_id=?";
}
function kv_doc_page(string $where='',array $args=[],bool $due=false): array {
 $params=[company_id(),company_id(),...$args];
 $page=kv_page((int)query('SELECT COUNT(*)'.kv_doc_sql().$where,$params)->fetchColumn());
 $order=$due?'d.due_date,d.id':'d.issue_date DESC,d.id DESC';
 $rows=query('SELECT d.*,c.name contact_name,COALESCE(p.paid,0)+d.staff_settled paid'.kv_doc_sql().$where.' ORDER BY '.$order.' LIMIT '.$page['size'].' OFFSET '.$page['offset'],$params)->fetchAll();
 return [$rows,$page];
}
/** Caller holds the site's row lock until its media row has been inserted. */
function cms_media_capacity(int $sid,int $bytes,int $files=1): void {
 if($bytes<0||$files<0)throw new DomainException('Görsel boyutu geçersiz.');
 if(!db()->inTransaction())throw new LogicException('Görsel kotası işlem kilidi gerektirir.');
 if(!query('SELECT id FROM cms_sites WHERE id=? FOR UPDATE',[$sid])->fetchColumn())throw new DomainException('Site bulunamadı.');
 $used=0;$count=0;
 foreach(query('SELECT filename FROM cms_media WHERE site_id=?',[$sid]) as $r){
  $count++;$name=$r['filename'];
  if(preg_match('/^[a-f0-9]{32}\.(png|jpg|webp)$/D',$name)){$path=APP_ROOT.'/storage/site-media/'.$name;if(is_file($path))$used+=(int)filesize($path);}
 }
 if($count+$files>500||$used+$bytes>268435456)throw new DomainException('Site görsel alanınız doldu. Yeni görsel yüklemek için Kobivira ile iletişime geçin.');
}
