(() => {
 const f=document.getElementById('migration-upload');if(!f)return;
 const filter=f.elements.source_filter;const options=[...f.elements.source.options].map(o=>[o.value,o.text]);filter?.addEventListener('input',()=>{const current=f.elements.source.value;f.elements.source.replaceChildren(...options.filter(([v,t])=>t.toLocaleLowerCase('tr').includes(filter.value.toLocaleLowerCase('tr'))).map(([v,t])=>{const o=new Option(t,v);o.selected=v===current;return o;}));});
 const status=document.getElementById('migration-progress'),button=f.querySelector('button');
 f.addEventListener('submit',async e=>{e.preventDefault();button.disabled=true;
 const csrf=document.querySelector('input[name="csrf"]')?.value||document.body.dataset.csrf;
 const post=async(action,fields)=>{const d=new FormData();d.set('csrf',csrf);d.set('action',action);for(const [k,v] of Object.entries(fields))d.set(k,v);const r=await fetch('?page=migration',{method:'POST',body:d,credentials:'same-origin',cache:'no-store'});if(!r.ok){const t=await r.text();const doc=new DOMParser().parseFromString(t,'text/html');throw new Error(doc.querySelector('[role="alert"],.alert,.error')?.textContent.trim()||'İşlem tamamlanamadı. Dosya boyutunu, kotanızı ve oturumunuzu kontrol edin.');}const ct=r.headers.get('content-type')||'';if(!ct.includes('application/json'))throw new Error('Oturum süresi dolmuş olabilir. Sayfayı yenileyin.');return r.json();};
 try{const file=f.elements.file.files[0];if(!file)throw new Error('Dosya seçin.');status.textContent='Yükleme hazırlanıyor…';const j=await post('begin',{file_name:file.name,file_bytes:file.size,source:f.elements.source.value,target:f.elements.target.value});let offset=0;
 while(offset<file.size){const result=await post('chunk',{id:j.id,offset,chunk:file.slice(offset,offset+1048576)});if(result.offset<=offset)throw new Error('Yükleme ilerlemedi.');offset=result.offset;status.textContent='Yükleniyor: %'+Math.floor(offset/file.size*100);}
 status.textContent='Dosya doğrulanıyor…';const done=await post('finish',{id:j.id});location.href=done.url;
 }catch(err){status.textContent=err.message;button.disabled=false;}});
})();
