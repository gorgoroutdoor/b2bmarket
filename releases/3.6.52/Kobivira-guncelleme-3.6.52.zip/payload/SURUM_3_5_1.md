# Kobivira 3.5.1

3.5.0 üzerine yönetim panelinden yüklenir. Tek imzalı ZIP; yeni kurulum yapılmaz. Genel panel tasarımı, renkler, mevcut CSS dosyaları ve logolar korunur. Tanıtım sitesinde yalnız istenen istatistik kartları, özellikler menüsü ve veri taşıma bölümü yenilenir.

## Paketler

Yalnız KOBİ, KOBİ Plus ve KOBİ Business atanır / satılır. Business Plus plan satırı geçmiş ödeme ve denetim kayıtları için saklanır, yeni atamalara kapalıdır. Mevcut abonelikleri, bitiş tarihleri ve firma verileri korunarak Business’a geçirilir.

- KOBİ: müşteri / tedarikçi, ürün / hizmet, satış / alış faturası ve gider kaydı, tahsilat / ödeme, kasa / banka ve temel gelir / gider / KDV raporları.
- KOBİ Plus: KOBİ kapsamı + teklif / proforma / sipariş, cari ekstre, iade, döviz, çek, çalışan giderleri, makbuz kayıtları, tekrarlar ve iş takibi.
- KOBİ Business: Plus kapsamı + yaşlandırma / mutabakat, CRM, proje kârlılığı, nakit öngörüsü, gelişmiş raporlar / onaylar, otomasyon, toplu işlemler ve banka dosyası eşleştirme.

Paket dışı menüler gizlenir; GET / POST üzerinden doğrudan erişim de denetlenir. Kullanıcı / çalışan izinleri paket izinlerinin üzerine uygulanmaya devam eder. Standart deneme 15 gün ve 5 cari / 5 belge sınırıyla gelişmiş özellikleri inceletir. Ücretli paket, atandıktan / etkinleştirildikten sonra kendi kapsamıyla kullanılır. Süresi biten hesap kayıtlarını görür; yeni işlem yapamaz.

## Yönetici modül seçimi

Paketler → Modül ve paket erişimleri: web sitesi, Meta reklam, Google reklam için ayrı aç / kapat ve KOBİ / Plus / Business paket seçimi vardır. Varsayılan hepsi kapalı, seçili kapsam Business’tır. Yönetici diğer paketleri de seçebilir. Etkin web sitesi modülünde firmaya ayrıca site atanır. Reklam modülleri gerçek API bağlantısı geliştirilene kadar hazırlık ekranıdır; bu ayarlar reklam yayınlamaz veya harcama başlatmaz.

## Tanıtım sitesi

Özellikler başlığı masaüstünde üzerine gelince, mobilde dokununca açılır. Günlük muhasebe, satış / ekip, raporlama, elektronik belge ve taşıma / yardım başlıkları yayımlanmış rehberlere bağlanır. Klavye, Escape ve odak davranışları eklenir.

İstatistik kartlarında rakam ve ₺ bölünmez. Yazı boyutu kullanılabilir genişliğe uyarlanır; kartlar aynı yükseklikte tutulur. Sayılar ve elle / otomatik istatistik ayarları değiştirilmez.

Veri taşıma bölümü iki sütunlu satış kartıdır: kısa ana mesaj, 3 ay avantajı, belirgin ana düğme, rehber ve aktarım akışı. Altındaki program / logo şeridi sağdan sola hareket eder; üzerine gelince veya odaklanınca durur. Hareket azaltma tercihine uyar. Kart ile footer arası masaüstünde 48, mobilde 32 pikseldir.

Site yönetimi → Veri taşıma tanıtımı: başlık, açıklama, düğme yazısı, program adı, logo, bağlantı, sıra ve görünürlük yönetilir. Logoyu Tanıtım sitesi → Görseller’e yükleyip program kaydından seçin. Logosuz program adıyla görünür. Bunlar dosya kaynaklarıdır; özel API entegrasyonu iddiası değildir.

## Kayıt ekranı ve metinler — ilk yapılacak ayar

Site yönetimi → Hukuki metinler alanından Kullanım Şartları, Gizlilik Politikası ve KVKK Aydınlatma Metni içeriklerini doldurun ve her birini yayımlayın. Mevcut kullanım / gizlilik sayfaları varsa taslak olarak kopyalanır; kendiliğinden yayımlanmaz. KVKK metni yönetici tarafından eklenmelidir. Üç metin yayımlanana kadar yeni kayıt tamamlanmaz; mevcut üyelerin girişi etkilenmez. Bu sürüm hukuk metni yazmaz / hukuki uygunluk onayı vermez.

HTML editöründe kalın / italik / liste / başlık / bağlantı ve kaynak düzenleme vardır. Aktif kod ve tehlikeli HTML kaldırılır. Yayın her seferinde yeni sürüm oluşturur. Kayıt sırasında üç metnin sürümü, içerik özeti, kullanıcı / firma ve kabul zamanı saklanır. Yeni yayın eski kabul kayıtlarını değiştirmez.

Üye girişi → Kayıt ol ekranında, oluşturma düğmesinden hemen önce onay kutusu ve üç bağlantı görünür. Kutucuk varsayılan boş, sunucu kontrolü zorunludur. Bağlantılar formu kaybetmeden açılır pencerede veya ayrı sekmede açılır. Giriş ekranında onay kutusu yoktur. Metin arada değişirse eski sürümle kayıt reddedilir. Site alt sayfaları da yayımlanmış güncel metin kaynağını gösterir.

## Sınırlar

Gerçek e-Belge / POS / SMS / banka / reklam API bağlantıları bu sürümün kapsamı değildir. Yerel ön muhasebe kaydı resmî e-Fatura gönderimi değildir. Canlı sunucuya erişilmedi. Gerçek masaüstü / mobil tarayıcı görsel testi tamamlanamadı; tarayıcı indirme başarısız oldu. Formlar gerçek HTTP ile, yeni istemci davranışları Node etkileşim testleriyle, kart sığdırması modellenmiş genişliklerde kontrol edildi. Bunlar gerçek cihaz ekran testi olarak sunulmaz.
