# Kobivira 3.6.17

Bu imzalı güncelleme **3.6.16 üzerine** kurulur. Yönetim → Sistem → Sürüm güncellemeleri alanından ZIP dosyası olduğu gibi yüklenir. İmzalama anahtarı önceki kurulumla aynıdır; yeni anahtar yüklemek gerekmez. Bu çalışma hosting üzerine uygulanmamıştır.

## İnceleme sonucu ve düzeltmeler

Gönderilen 3.6.16 arşivinin ZIP bütünlüğü, dosya özetleri ve imzası doğrulandı. Ana menüler yeniden taşınmadı. Aşağıdaki akış hataları düzeltildi:

- Gelen e-Fatura/e-İrsaliye ayrıntısından kabul, ret, kısmi kabul, durum kontrolü ve PDF/XML işlemleri aynı gelen belge kutusunu ve türünü korur. İşlem sonrasında giden listeye dönülmez. Eski giden-merkez bağlantısıyla açılmış gelen belge doğru gelen kutusuna yönlendirilir.
- Tür parametresi bulunmayan belge bağlantısında başlık, aktif menü ve paket yetkisi firmaya ait gerçek belgeye göre çözülür. Gelen ekrandan giden belge açılması, farklı tür gösterilmesi ve başka firmanın belge kimliği kullanılması reddedilir.
- Genel Belge oluştur düğmesi ilk türü sessizce seçmez; kullanılabilir belge türlerini gösterir.
- Her belge listesinde Tüm belgeler, Taslaklar ve Giden belgeler görünümleri bulunur. Genel liste bağlantılarında boş tür parametresi üretilmez.
- e-SMM için yalnız onaylanmış makbuzlar; diğer türler için onaylanmış normal satışlar listelenir. İadeler ve taslak muhasebe kayıtları seçeneklere karıştırılmaz. İlk 500 kayıt dışındaki geçerli bir kaynağa doğrudan bağlantı da korunur.
- Aynı satış kaynağı için başka türde fatura zaten varsa, yeniden hazırlama o belgeyi sessizce döndürmez. Aynı türün yinelenen hazırlama isteği mevcut kaydı döndürmeye devam eder. İrsaliye kaynağı fatura kaynağından ayrı tutulur.
- Gelen irsaliye listesindeki muhasebe sütunu yerine belge yanıtı gösterilir. İrsaliyeye yanlışlıkla fatura muhasebe içeri alma işlemi sunulmaz. Eşitleme mesajı seçilen türe uygundur.
- Bağlantı ayarları açıldığında belge türü menüsü ayrıca seçili kalmaz. Firma bağlantı kodundaki erişilemeyen test hesabı devralma dalı temizlendi; yönetim test alanı korundu.
- Kullanım kütüphanesi erişimi diğer firma ekranları gibi askıya alma, ekip ve destek oturumu kontrollerinden geçer. Mevcut rehber yolları ve ana menü isimleri korunur.

## Korunanlar

Önceki 40 veri geçişinin, imza doğrulayıcının ve mevcut CSS dosyalarının içerikleri değişmedi. Yeni veritabanı geçişi gerekmez. Paket seçimleri, firma kayıtları, abonelikler, fiyatlar, müşteriler, muhasebe belgeleri ve test kayıtları silinmez. Belge numaraları ve mükerrer gönderimi engelleyen kalıcı deneme işaretleri korunur. Servis endpoint'leri, kontör hesabı, UBL üretimi ve resmî gönderim protokolü bu revizyon kapsamında değiştirilmedi.

## Doğrulama

- İzole MariaDB/PHP ortamında 266 başarılı kontrol: gerçek imza ve 3.6.16 → 3.6.17 kurulumu, eski geçişlerin tekrarlanabilmesi, mevcut verilerin/paketlerin korunması, üç paketin menüleri, yetki ayrımı, taslak/gönderilen filtreleri, belge türü seçimleri, gelen belge formları ve indirme bağlantıları.
- Gerçek gelen fatura ve irsaliye POST yönlendirme yolları sentetik kayıtlarla çalıştırıldı; yalnız kuyruk kaydı oluşturuldu, sağlayıcıya belge/yanıt gönderilmedi.
- 151 PHP dosyasında sözdizimi kontrolü yapıldı; tam firma yerleşimi hem e-Fatura hem gelen irsaliye ayrıntısıyla üretildi. Görsel tarayıcı kontrolü bu ortamda tamamlanamadı; tarayıcı kurulumu indirilemedi.
- Önceki 40 geçiş ve mevcut stiller bayt karşılaştırmasıyla doğrulandı. Ayrıntılı başarılı kontroller Revision3617TestResults.json dosyasındadır.

Bu sürümde canlı EDM servisine yeni istek/gönderim testi yapılmadı. Önceki irsaliye nihai yanıtı ve ihracat başarısızlık incelemesi sonuçlanmış sayılmaz. PayTR entegrasyonu eklenmedi. Gerçek firma canlı hesabı ve yönetimin hizmet izinleri gerekli olmaya devam eder. Sağlayıcıdan bekleyen veya başarısız dönen işlem başarılı gösterilmez.
