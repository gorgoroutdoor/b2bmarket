<?php
declare(strict_types=1);
function e_document_guide(): void {need_feature('edocs');panel('Elektronik Belgeler');echo '<p>'.a('edoc_center','Elektronik Belgeleri aç',[],'button primary').' '.a('edoc_center','Bağlantı ayarları',['tab'=>'connection'],'button').'</p></section>';}
