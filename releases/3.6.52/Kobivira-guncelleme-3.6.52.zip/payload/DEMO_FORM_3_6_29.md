# Kobivira 3.6.29 — Ortak elektronik belge formları

3.6.28 üzerine imzalı güncellemedir. Mevcut panel tasarımı ve menü düzeni korunur. Veritabanı şeması değişmez; 46 eski migration aynıdır.

## Aynı formlar

Ücretli e-Belge ekranlarındaki alanlar ayrı önizleme kopyaları yerine EdocForms3629.php içindeki ortak alan oluşturucularından gelir. Aynı oluşturucular demoda da kullanılır:

- e-Fatura: alıcı konum bilgileri, TCKN adı/soyadı, senaryo, posta kutusu, satır birim kodu, istisna alanları.
- e-Arşiv: alıcı konum bilgileri, TCKN adı/soyadı, satır birim kodu, istisna alanları.
- e-İrsaliye: alıcı ve teslim bilgileri, PK/GB, araç, sürücü, sevk zamanı ve satır birim kodları.
- e-SMM: alıcı konum ve kimlik adı/soyadı, istisna alanları.
- e-İhracat: alıcı konum ve teslim adresi, teslim şekli, taşıma türü, paket miktarı, satır birimi ve GTİP.
- Gelen e-Fatura/e-İrsaliye: aynı başlangıç/bitiş alanları, sorgu düğmesi ve kutu tablosu.
- Bağlantı ayarları: aynı servis kimlik bilgileri, firma konum alanları ve hesap şifresi formu.

Demoda ortak kaynak seçim formu ve boş belge hazırlama alanları birlikte gösterilir. Gerçek müşteri, kaynak belge, servis şifresi ve sağlayıcı belgesi okunmaz. Kaynak satırlara bağlı alanların bir boş satırı görünür. Ücretli hesapta gerçek kaynak kaydı seçildiğinde gerekli alanlar ve gerçek kaynak satırlarının sayısı gösterilir. Ödeme sonrasında demo değerleri belgeye aktarılmaz.

## Kilit

Demo alanları sunucudan disabled ve aria-disabled gelir; tarayıcı kodunun çalışmasına bağlı değildir. Ortak form parçalarında form etiketleri etkisiz kapsayıcıya çevrilir, gizli işlem alanları kaldırılır, kaynak oluşturma bağlantıları etkisiz gösterilir. Yeni bir gizli deneme gönderim yolu eklenmez. Mevcut yetkilendirme doğrudan POST taleplerini reddeder. Kayıt, hazırlama, gönderim, eşitleme, kabul/ret/kısmi kabul, iptal ve durum işlemleri demoda açılmaz. GET üzerinden id/download verilmesi gerçek belgelere eriştirmez.

Etkin ücretli üyelik, demo önizlemesinden çıkar ve seçilen paketin mevcut yetkilerini kullanır. KOBİ, Plus ve Business kapsamları ve yönetici paket ayarları değişmez. Servis işlemleri ayrıca mevcut firma bağlantısı, yönetici canlı kullanım izni, belge türü yetkisi ve sağlayıcı kontrollerine tabidir. Ödeme tek başına servis hesabı veya kontör oluşturmaz. GİB'den yeni müşterinin adres/iletişim bilgilerini sorgulama bu sürümde eklenmedi.

## Doğrulama

108 PHP/veritabanı kontrolü, 63 yerel HTTP kontrolü; ortak alan karşılaştırması, her demo kontrolünün kilidi, gizli alan/işlem bağlantısı bulunmaması ve doğrudan işlem engelleri dahil. Alıcı otomatik doldurma için 9 ve firma kimliği için 3 mevcut DOM kontrolü. PHP kaynak sözdizimi ve migration değişmezliği kontrol edildi. Gerçek ödeme veya sağlayıcı servisi çağrısı, canlı fatura testi ve hosting kurulumu yapılmadı. Tam tarayıcı görsel kontrolü yapılmadı.
