# Kobivira 3.6.34

3.6.33 üzerine imzalı tam güncelleme paketi.

## Sayfanın başından hızlı düzenleme

Tanıtım sitesinde platform yöneticisinin oturumu açıkken sayfanın başında **Bu sayfayı düzenle** bağlantısı görünür. Yeni sekmede ilgili sayfanın mevcut yönetim kaydı açılır. Ana sayfa bağlantısı ana sayfa bloklarını; hukuki sayfa bağlantısı sürümlü hukuki metin editörünü açar. Firma kullanıcıları ve ziyaretçiler bu bağlantıyı göremez.

Yönetici önce app.kobivira.com.tr üzerinden giriş yapmalı, sonra tanıtım sayfasını yenilemelidir. Ana alan adı ile uygulama alt alan adı arasındaki oturum kontrolü yalnız resmi Kobivira adreslerine açık, önbelleğe alınmayan salt okunur bir istek kullanır. Düzenleme yetkileri mevcut yönetim kontrollerinde ayrıca doğrulanır. Oturum çerezinin alan adı genişletilmez.

## Ana sayfa kategori görselleri

**Tanıtım sitesi → Ana sayfa blokları → “İşinizin hangi adımındasınız?” alanını içeren blok → Düzenle → Kategori görselleri**

Altı başlığın her biri için ayrı görsel seçilebilir. Önce **Tanıtım sitesi → Görseller** alanından PNG, JPG veya WebP yükleyin; sonra ilgili kategorinin seçicisinden yüklediğiniz görseli seçip bloğu kaydedin. Mevcut yükleme sınırı 4 MB ve en fazla 6000 pikseldir. Panel ekran görüntüsü için 1440 piksel veya üzeri genişlik önerilir.

Görsel lacivert–turkuaz başlıklı çerçevede, oranı korunarak gösterilir; ziyaretçi Görseli büyüt bağlantısından ayrı sekmede açabilir. Hiç görsel seçilmemişse sahte belge tablosu veya örnek bakiye yerine konu başlıklı marka görseli kullanılır. Gerçek panel görüntülerini yönetici yükleyip seçer; bu paket firmanın özel verilerini içeren ekran görüntüleri yüklemez.

Her özellik sayfasının mevcut **Özellik sayfası görseli** seçimi de korunur. İlgili ürün sayfasındaki hızlı düzenle bağlantısından bu seçiciye ulaşılabilir.

## Özellik menüsü

Masaüstünde dört dikey sütun vardır. Kategoriler bu sütunların içinde gruplanır; ayrı bir ikinci blok sırasına düşmez. Tüm mevcut özellik bağlantıları, ikonlar ve kısa açıklamalar korunur. Menü yüksekliği açık ekran alanına göre sınırlandırılır. Mobilde mevcut tek kaydırma alanı kullanılır.

## Footer

- Tıklanarak açılan başlıklar kaldırıldı. Masaüstü ve mobilde bağlantılar sürekli görünür.
- Mobilde bağlantı grupları iki sütun, sonraki gruplar alt satırdadır.
- Logo altındaki uzun ön muhasebe açıklaması önceki içerik geçmişinden geri alınır. Geçmişte uygun metin bulunmazsa kurulumdaki ön muhasebe açıklaması kullanılır. **Tanıtım sitesi → Site / SEO ayarları → Footer alt metni** alanından düzenlenebilir.
- Visa, Mastercard, TROY ve PayTR logolarının altında küçük ödeme açıklaması bulunur.
- En altta yıl, ön muhasebe açıklaması ve “Tüm hakları Kobivira.com’a aittir.” ifadesi bulunur.
- Kayan logo şeridi daha belirgin kart çerçeveleriyle gösterilir. Gerçek logolar **Veri taşıma tanıtımı → Program logoları** alanından seçilir. Logo yüklenmemiş kayıtta program adı gösterilir.

## Kullanıcı adı

Firma panelinde sol alttaki hesap simgesi → **Hesap bilgilerim → Kullanıcı bilgilerim → Ad soyad → Adımı kaydet**.

Yalnız oturum sahibinin adı güncellenir; sol menü bir sonraki sayfa yüklemesinde yeni adı gösterir. Başka kullanıcı kimliği göndererek ad değiştirilemez. Destek veya izleme oturumundan profil düzenlemesi yapılamaz. İşlem geçmişine kayıt alınır.

## Kayıt kartı

Kayıt kartı içeriğinin yüksekliğine uyarlanır. Oturum açıkken hesap bağlantısı veya ziyaretçi kaydı kapalıyken açıklama gösterildiğinde büyük boş alan bırakmaz. Yeni kayıt ayarı otomatik değiştirilmez. Formu açmak için **Sistem → Genel ayarlar → Ziyaretçi kaydı → Açık** seçilip kaydedilir. Önceki CSRF, hukuki metin onayı ve üyelik kuralları aynıdır.

## Kurulum ve doğrulama

Mevcut sürüm 3.6.33 iken yönetimdeki sürüm güncelleme ekranından ZIP paketini yükleyin. Sonra tanıtım sitesini Ctrl+F5 ile yenileyin. Oturumunuzu açık tutarak bir özellik sayfasında Bu sayfayı düzenle bağlantısını kontrol edin.

Yerel PHP/MySQL ortamında gerçek güncelleyiciyle imza ve migration kurulumu; firma, kullanıcı, paket, ödeme ve hukuki kayıtların korunması; yönetici bağlantısının yetki/Origin kontrolleri; kendi adını düzenleme; kategori görseli atama ve başka siteye ait görselin reddi; kayıt akışı test edildi. Tarayıcıda dört sütun, mobil footer, görsel çerçevesi, kompakt kart ve farklı ekran genişlikleri kontrol edildi. Canlı hosting dağıtımı yapılmadı.
