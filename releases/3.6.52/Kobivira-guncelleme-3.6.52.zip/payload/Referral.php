<?php
declare(strict_types=1);
function referral_input(): string {$s=strtoupper(trim(is_string($_POST['referral_code']??null)?$_POST['referral_code']:''));if($s!==''&&!preg_match('/^[A-F0-9]{16}$/D',$s))throw new DomainException('Referans kodunu kontrol edin veya bu alanı boş bırakın.');return $s;}
function referral_attach(int $cid,string $code): void {
 if($code==='')return;if(setting('referral_enabled','1')!=='1')throw new DomainException('Referans programı şu anda kapalı. Kodsuz kayıt oluşturabilirsiniz.');
 $r=query("SELECT r.company_id FROM referral_codes r JOIN companies c ON c.id=r.company_id WHERE r.code=? AND c.status='active'",[$code])->fetch();if(!$r||(int)$r['company_id']===$cid)throw new DomainException('Referans kodu bulunamadı veya kullanılamıyor. Kodu kontrol edin.');
 query('INSERT INTO referral_links(company_id,referrer_company_id,code,created_at) VALUES (?,?,?,UTC_TIMESTAMP())',[$cid,$r['company_id'],$code]);
}
function referral_code(int $cid): string {$code=query('SELECT code FROM referral_codes WHERE company_id=?',[$cid])->fetchColumn();if($code)return $code;$code=strtoupper(bin2hex(random_bytes(8)));query('INSERT IGNORE INTO referral_codes(company_id,code,created_at) VALUES (?,?,UTC_TIMESTAMP())',[$cid,$code]);return (string)query('SELECT code FROM referral_codes WHERE company_id=?',[$cid])->fetchColumn();}
function referral_apply_bank(int $cid): void {
 // Called within the same transaction as payment approval; entitlement stays on the current paid plan.
 $c=query('SELECT status FROM companies WHERE id=? FOR UPDATE',[$cid])->fetch();if(!$c||$c['status']!=='active')return;
 $s=query('SELECT * FROM subscriptions WHERE company_id=? FOR UPDATE',[$cid])->fetch();if(!$s||!$s['has_paid_membership'])return;
 $rewards=query('SELECT id,days FROM referral_rewards WHERE company_id=? AND applied_at IS NULL ORDER BY id FOR UPDATE',[$cid])->fetchAll();$days=array_sum(array_column($rewards,'days'));if(!$days)return;
 $now=new DateTimeImmutable('now',new DateTimeZone('UTC'));$start=$s['status']==='active'&&$s['paid_until']&&strtotime($s['paid_until'].' UTC')>time()?new DateTimeImmutable($s['paid_until'],new DateTimeZone('UTC')):$now;
 $end=$start->modify('+'.$days.' days')->format('Y-m-d H:i:s');query("UPDATE subscriptions SET status='active',paid_until=?,period_started_at=COALESCE(period_started_at,UTC_TIMESTAMP()) WHERE company_id=?",[$end,$cid]);
 foreach($rewards as $r)query('UPDATE referral_rewards SET applied_at=UTC_TIMESTAMP() WHERE id=? AND applied_at IS NULL',[$r['id']]);
 company_notice($cid,'referral:applied:'.end($rewards)['id'],'Referans süre hakkınız uygulandı',$days.' gün ücretsiz kullanım süresi mevcut paketinize eklendi. Yeni bitiş: '.date_tr($end).'. Kontör ve ek servis verilmez.','membership');
}
function referral_on_payment(array $payment): void {
 if((int)$payment['total']<=0)return;$r=query('SELECT * FROM referral_links WHERE company_id=? FOR UPDATE',[$payment['company_id']])->fetch();if(!$r||$r['status']!=='pending')return;
 // Only the referred company's first approved, positive payment can earn the reward.
 if(query("SELECT id FROM payment_orders WHERE company_id=? AND status='approved' AND id<>? AND total>0 LIMIT 1",[$payment['company_id'],$payment['id']])->fetchColumn())return;
 if(!query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$r['referrer_company_id']])->fetchColumn())return;
 $ownTax=(string)query('SELECT tax_number FROM companies WHERE id=?',[$r['referrer_company_id']])->fetchColumn();$newTax=(string)query('SELECT tax_number FROM companies WHERE id=?',[$r['company_id']])->fetchColumn();if($ownTax!==''&&$newTax!==''&&$ownTax===$newTax){query("UPDATE referral_links SET status='ineligible',reason='Aynı vergi / T.C. numarasıyla referans ödülü oluşturulamaz.' WHERE id=?",[$r['id']]);return;}
 $days=max(1,min(90,(int)setting('referral_reward_days','30')));
 query('INSERT INTO referral_rewards(company_id,referred_company_id,referral_id,payment_order_id,days,created_at) VALUES (?,?,?,?,?,UTC_TIMESTAMP())',[$r['referrer_company_id'],$r['company_id'],$r['id'],$payment['id'],$days]);
 query("UPDATE referral_links SET status='rewarded' WHERE id=?",[$r['id']]);
 company_notice((int)$r['referrer_company_id'],'referral:earned:'.$r['id'],'Referans ödülünüz hazır',$days.' günlük süre hakkı kazandınız. Aktif veya geçmiş ücretli üyeliğinize uygulanır; henüz ücretli üyeliğiniz yoksa ilk paket etkinleştirmesinde kullanılır.','membership');
 admin_notification((int)$r['referrer_company_id'],'referral:earned:'.$r['id'],'referral_reward','Referans süre ödülü kazanıldı',$days.' günlük hak kaydedildi; ayrıntıları referans yönetiminden inceleyin.',0);
 query("UPDATE admin_notifications SET target_page='marketing_admin',target_id=0 WHERE event_key=? AND company_id=?",['referral:earned:'.$r['id'],$r['referrer_company_id']]);referral_apply_bank((int)$r['referrer_company_id']);audit('referral.rewarded',['company'=>$r['referrer_company_id'],'referral'=>$r['id'],'days'=>$days]);
}
function referrals_view(): void {
 firm_manager();heading('Arkadaşını davet et','İlk onaylı ücretli üyelikte 30 gün ücretsiz kullanım hakkı kazanın.');$cid=company_id();$code=referral_code($cid);$link=setting('public_app_url','https://app.kobivira.com.tr/').'?page=register&ref='.$code;
 panel('Size özel davet bağlantısı');echo '<p>Bağlantınızı davet etmek istediğiniz işletmeyle paylaşın. Kod yeni firma kaydında görünür; sonradan değiştirilemez.</p><label class="field">Referans kodunuz<input readonly value="'.esc($code).'" aria-label="Referans kodunuz"></label><label class="field wide">Davet bağlantınız<input readonly value="'.esc($link).'" aria-label="Davet bağlantınız"></label><p class="field-hint">Bağlantıya tıklamak veya demo açmak ödül kazandırmaz. İlk pozitif ödeme Kobivira tarafından onaylandığında bir kez 30 gün kazanırsınız. Kontör / ek servis dahil değildir. Henüz ücretli paketi olmayan hesapta hak ilk etkinleştirmeye kadar saklanır. Askıdaki hesaba süre uygulanmaz.</p></section>';
 $pending=(int)query('SELECT COALESCE(SUM(days),0) FROM referral_rewards WHERE company_id=? AND applied_at IS NULL',[$cid])->fetchColumn();panel('Referans hareketleriniz',$pending.' gün uygulanmayı bekleyen süre hakkı');table_start(['Referans kaydı','Durum','Süre hakkı','Uygulama']);$rows=query('SELECT l.id,l.status,l.reason,l.created_at,r.days,r.applied_at FROM referral_links l LEFT JOIN referral_rewards r ON r.referral_id=l.id WHERE l.referrer_company_id=? ORDER BY l.id DESC LIMIT 100',[$cid])->fetchAll();foreach($rows as $r)echo '<tr><td>Davet #'.(int)$r['id'].'<small>'.date_tr($r['created_at']).'</small></td><td>'.($r['status']==='rewarded'?'Ödül kazanıldı':($r['status']==='ineligible'?'Koşullar karşılanmadı · '.esc($r['reason']):'İlk ödeme onayı bekleniyor')).'</td><td>'.($r['days']?(int)$r['days'].' gün':'—').'</td><td>'.($r['applied_at']?date_tr($r['applied_at']):($r['days']?'Ücretli etkinleştirme bekleniyor':'—')).'</td></tr>';table_end(count($rows),4,'Henüz referans kaydınız yok.');echo '</section>';
}
