<?php
declare(strict_types=1);
/** Temporary registration approval is not proof of possession of a phone number. */
function phone3651_enabled():bool{return setting('temporary_register3651','0')==='1'&&phone3644_config()['mode']==='off';}
function phone3651_eligible(array $u):bool{
 if(!phone3651_enabled()||($u['role']??'')!=='company_admin'||empty($u['registration_mobile_required'])||empty($u['is_active'])||!empty($u['is_deleted']))return false;
 // Only the authenticated registration flow uses this helper; require a genuinely verified email.
 return mail3650_user((int)$u['company_id'],(int)$u['id'])!==null&&!email3643_pending($u);
}
function phone3651_accepted(array $u):bool{return phone3651_eligible($u)&&!empty($u['login_mobile_temporary_at'])&&($u['login_mobile']??'')!==''&&($u['login_mobile_temporary_number']??'')===$u['login_mobile'];}
function phone3651_visible_code(array $u,string $ticket):?string{
 if(!phone3651_eligible($u)||!preg_match('/^[a-f0-9]{64}$/D',$ticket))return null;
 $r=query("SELECT * FROM account_mobile_codes WHERE user_id=? AND purpose='register' AND mode='temp' AND ticket_hash=? AND phone=? AND expires_at>UTC_TIMESTAMP() AND attempts<5 AND send_state='test'",[$u['id'],hash('sha256',$ticket),$u['login_mobile']])->fetch();
 if(!$r||!is_string($r['test_cipher']))return null;$code=open_code($r['test_cipher']);return preg_match('/^[0-9]{6}$/D',$code)?$code:null;
}
function phone3651_note(array $u,string $ticket):void{
 $code=phone3651_visible_code($u,$ticket);if($code===null)return;
 echo '<p class="mail43-success" role="status">Netgsm onayı beklenirken geçici kayıt kodunuz: <strong data-temporary-register-code>'.esc($code).'</strong></p><p class="mail43-small">Bu kod SMS ile gönderilmedi ve telefon numarasını doğrulamaz. Yalnız bu kayıt ekranında geçici devam içindir. Kod 10 dakika geçerlidir; yeni kod önceki kodu geçersiz kılar. Gerçek SMS hizmeti açıldığında telefonunuzu yeniden doğrulamanız gerekir.</p>';
}
