# Kobivira 3.5.8

3.5.7 üzerine admin panelinden yüklenen imzalı güncellemedir. Yeni kurulum değildir. Tasarım ve tüm mevcut CSS / görsel dosyaları korunur. Yeni alanlar mevcut panel / düğme bileşenlerini kullanır. Fiyat, indirim ve kullanıcı kotaları değiştirilmez.

## Kullanım
1. Müşteri teklif, proforma veya sipariş bağlantısından Değişiklik istiyorum yanıtını ve açıklamasını gönderir.
2. Firma yöneticisi Satışlar → Müşteri paylaşımları içindeki Değişiklik talebi / revizyon bağlantısından ilgili belgeye gider. Müşteri açıklaması ve Revizyon oluştur düğmesi burada görünür.
3. Revizyon oluştur, önceki belgeye bağlı yeni bir taslak oluşturur. Müşteri, kalemler, miktar, fiyat, indirim, KDV, para birimi ve kayıtlı belge bilgileri taşınır. Orijinal belge değiştirilmez.
4. Düzenle ile gerekli değişiklikleri kaydedip Kesinleştir düğmesiyle yeniden onaylayın. Önceki müşteri bağlantıları bu onay sırasında kapanır; taslak aşamasında açık kalır.
5. Müşteri paylaşımları bölümünden yeni revizyon belgesini seçip yeni bağlantı oluşturun ve müşterinize iletin. Yeni bağlantı yeni ticari yanıta açıktır; önceki belgeler / açıklamalar geçmişte kalır.

## Sınırlar ve korumalar
- Akış firma yöneticisi içindir. KOBİ teklif / proforma, Plus ve Business ayrıca sipariş revizyonu kullanır. Mevcut paket, kullanıcı ve süre kontrolleri korunur.
- Müşteri değişiklik talebi olmadan bu akıştan revizyon açılamaz. Satış faturası revize edilmez; resmî e-Belge kabul / ret işlemi yapılmaz.
- Aynı kaynak için iki aktif revizyon taslağı oluşturulmaz. İstek tekrarlanırsa mevcut revizyon açılır. İptal edilmiş, hiç onaylanmamış revizyon taslağı geçmişte tutulur; kaynak için yeniden taslak açılabilir.
- Siparişe veya satışa dönüştürülmüş kaynak revize edilemez. Aktif revizyonu olan eski belge yeni paylaşım ve dönüşüm listelerinden çıkarılır / sunucuda engellenir. Orijinal PDF görüntülenebilir.
- Kaynak belge taslak oluşturulduktan sonra değişmiş veya iptal edilmişse yeni revizyon onaylanmaz. İşlem geri alınır; önceki bağlantılar kısmen kapanmaz.
- Onaylanmış revizyon iptal edilse bile önceki paylaşım kendiliğinden açılmaz. Yeni ticari işlem için güncel belge ayrıca değerlendirilmelidir.
- Müşteri yanıtı firmaya uygulama bildirimi olarak kaydedilir. E-posta / SMS gönderimi ayrıca mevcut servis ayarlarına bağlıdır; bu sürüm dış servis bağlantısı yapmaz.

## Teknik
030_document_revisions migration'ı revizyon geçmişi tablosu ekler. Önceki 29 migration korunur. Yeni tablo firma silme ve yedek temizliğine dahildir. Geçmiş müşteri açıklamaları record_shares içinde, revizyon ilişkisi document_revisions içinde tutulur. İmzalı güncelleyici ve geri dönüş mekanizması korunur.
