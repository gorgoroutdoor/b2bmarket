# Kobivira 3.6.36 — Kartın üzerinden düzenleme

3.6.35 üzerine imzalı tam güncelleme.

## Kullanım

Yönetici hesabınızla app.kobivira.com.tr üzerinde giriş yapın. Aynı tarayıcıda tanıtım sitesini açıp yenileyin. İçerik kartları ve bölümler üzerindeki **Düzenle** bağlantıları yalnız platform yöneticisine görünür.

Düzenle bağlantısı yeni sekmede ilgili yönetim kaydını açar; metinlerde ilgili metin alanına, görsellerde ilgili görsel alanına kaydırır. Ana sayfa blokları listesinde tekrar kayıt aramak gerekmez.

Kapsam: ana sayfa metin blokları, hero fotoğrafı ve panel görseli, altı kategori metni ve görseli, paket kartları, müşteri yorumları, blog ve özellik kartları, sık sorulan sorular, veri taşıma tanıtımı, kampanya ve footer. Diğer içerik sayfalarında bölüm/kart kontrolleri ve ilgili sayfanın düzenleme bağlantısı bulunur. Rehber ve yazı kartları kendi sayfa kayıtlarını açar. Hukuki sayfaların üst düzenleme bağlantısı mevcut sürümlü hukuki metin editörünü açar.

Paket, yorum, blog ve soru bağlantıları aynı genel ekrana yönlenmez; kendi yönetim kaydı veya alanına gider. Paket fiyatı ve paket yetkilerinin mevcut kuralları korunur.

## Görseli tek ekrandan değiştirme

1. İlgili görselin üzerindeki **Düzenle** düğmesine basın.
2. Açılan alanda **Görsel yükle / değiştir** ile dosya seçin. Mevcut özel görsel varsa ön izlemesi görünür. Önceden yüklediğiniz görselleri listeden de seçebilirsiniz.
3. Aynı ekrandaki **Kaydet** düğmesine basın. Yüklenen dosya doğrudan bu görsele bağlanır.

Ana sayfa hero fotoğrafı, hero panel ekranı, altı kategori görseli ve ayrı özellik sayfası görsellerinde doğrudan yükleme desteklenir. Görsel kütüphanesine ayrı bir işlem için gitmek gerekmez. PNG, JPG ve WebP; dosya başına en fazla 4 MB ve 6000 piksel. Hostinginizin PHP yükleme limitleri de geçerlidir.

Başarısız bir kayıtta aynı işlemde yüklenmiş dosyalar temizlenir; veritabanı işlemleri geri alınır. Başka siteye ait görselin seçilmesine izin verilmez. Önceki görseller otomatik silinmez.

## Yetki ve görünüm

Ziyaretçi ve firma kullanıcıları düzenleme düğmelerini göremez. Düzenleme sayfalarındaki yetki, CSRF ve site kapsamı kontrolleri devam eder. Ana alan adından uygulama oturumuna yalnız resmi Kobivira adreslerine açık, önbelleğe alınmayan bir okuma isteği yapılır. Görünür düğmeler yönetimdeki yazma yetkilerinin yerine geçmez.

Yöneticiye özel düğmeler haricinde ziyaretçinin sayfa düzeni korunur. Yeni veritabanı migration yoktur. Paket, ödeme, üyelik ve hukuki metin verileri güncelleyici tarafından değiştirilmez.

## Kurulum

Mevcut sürüm 3.6.35 iken yönetimdeki sürüm güncelleme ekranından ZIP dosyasını yükleyin. Tanıtım sitesinde Ctrl+F5 yapın. Bir görselin üzerindeki Düzenle düğmesinin doğrudan ilgili dosya alanını açtığını kontrol edin.

Yerel gerçek güncelleyiciyle 3.6.35 → 3.6.36 kurulumu, 315 PHP/veritabanı ve 144 HTTP kontrolü geçti. Doğrudan çok parçalı dosya yükleme, hatalı ikinci dosyada geri alma ve dosya temizliği, yönetici/firma ayrımı, kart bağlantıları ve mevcut kayıtların korunması doğrulandı. Tarayıcıda yönetici ve ziyaretçi görünümü, alan bağlantısı, kart yerleşimi ve farklı ekran genişlikleri kontrol edildi. Canlı hosting dağıtımı yapılmadı.
