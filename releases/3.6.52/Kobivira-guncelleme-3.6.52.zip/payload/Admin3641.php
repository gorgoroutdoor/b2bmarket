<?php
declare(strict_types=1);
function admin3641_enabled():bool {return (base_user()['role']??'')==='platform_admin'&&!support_context()&&!isset($_GET['support'])&&empty($GLOBALS['follow_mode']);}
function admin3641_guard():void {if(!admin3641_enabled()){http_response_code(403);throw new DomainException('Bu bölüm yalnız kendi yönetim oturumunuzda kullanılabilir.');}}
function admin3641_icons():array {return ['grid'=>'Genel bakış','people'=>'Firmalar / ekip','box'=>'Paket / ürün','wallet'=>'Ödeme','spark'=>'Tanıtım','sale'=>'Belge','chart'=>'Rapor','gear'=>'Ayar','clock'=>'Takip','search'=>'Arama'];}
function admin3641_catalog():array {
 $rows=[
 ['overview','grid','Genel Bakış',[
  ['dashboard','dashboard','Yönetim özeti',[],'genel ana sayfa'],['pending','admin_pending','Bekleyen işlemler',[],'onay havale evrak destek'],['favorites','admin_favorites','Favorilerim',[],'sık kullanılan']]],
 ['firms','people','Firmalar',[
  ['companies','companies','Firma listesi',[],'müşteri üyelik firma hesap'],['company_new','companies','Yeni firma oluştur',['view'=>'new'],'kayıt ekle'],['verification','verification','Firma doğrulama talepleri',[],'evrak onay ret'],['firm_sites','site_admin','Firma web siteleri',['site'=>1,'view'=>'sites'],'kurumsal site']]],
 ['billing','wallet','Paketler ve Ödemeler',[
  ['plans','plans','Paket ve fiyatlar',[],'kobi plus business fiyat abonelik'],['features','admin_plan_features','Paket özellikleri',[],'özellik yetki kapsam'],['modules','module_admin','Ek modül erişimleri',[],'web reklam'],['payments','billing','Ödeme kayıtları',[],'kart paytr satış tahsilat'],['transfers','billing','Bekleyen havaleler',['state'=>'reported'],'eft banka onay'],['credits','admin_credits','Firma kontör yönetimi',[],'bakiye yükle düş'],['credit_orders','credits','Kontör paketleri ve talepleri',[],'kontör fiyat satış']]],
 ['content','sale','Site ve İçerikler',[
  ['home','site_admin','Ana sayfa',['site'=>1,'view'=>'blocks'],'hero kart görsel blok'],['feature_pages','site_admin','Özellik sayfaları',['site'=>1,'view'=>'pages','section'=>'features'],'tanıtım ürün özellik metni'],['tools','site_admin','Hesaplama araçları',['site'=>1,'view'=>'pages','section'=>'tools'],'kdv stopaj iskonto hesap'],['pages','site_admin','Diğer bilgi sayfaları',['site'=>1,'view'=>'pages','section'=>'general'],'hakkımızda iletişim sayfa'],['blog','site_admin','Blog yazıları',['site'=>1,'view'=>'pages','kind'=>'article'],'makale seo içerik'],['library','site_admin','Kullanım kütüphanesi',['site'=>1,'view'=>'pages','kind'=>'guide'],'rehber nasıl yapılır'],['media','site_admin','Görseller',['site'=>1,'view'=>'media'],'resim fotoğraf yükle'],['site_menu','site_admin','Site menüleri ve footer',['site'=>1,'view'=>'nav'],'üst alt menü bağlantı'],['site_settings','site_admin','Site ve SEO ayarları',['site'=>1,'view'=>'settings'],'logo telefon iletişim sosyal medya arama motoru'],['legal','legal_admin','Hukuki metinler',[],'kvkk gizlilik sözleşme iade'],['content_history','site_admin','İçerik geçmişi',['site'=>1,'view'=>'history'],'önceki sürüm içerik geri yükleme']]],
 ['marketing','spark','Pazarlama',[
  ['campaigns','migration_admin','Kampanya ayarları',[],'veri taşıma kampanya'],['applications','promotion_admin','Tanıtım pencereleri ve başvurular',[],'popup form potansiyel müşteri'],['migration_copy','launch_admin','Veri taşıma tanıtımı',[],'logo şeridi program kampanya başlık'],['referrals','marketing_admin','Tavsiye ve referanslar',[],'davet kazan referans'],['reviews','site_admin','Müşteri yorumları',['site'=>1,'view'=>'reviews'],'deneyim onay yorum']]],
 ['support','people','Destek ve İletişim',[
  ['tickets','help','Destek talepleri',[],'mesaj yazılı destek'],['live','support_desk','Canlı destek sırası',[],'temsilci görüşme'],['notifications','notifications','Bildirimler',[],'uyarı haber'],['delivery','delivery','E-posta ve SMS gönderimleri',[],'iletişim netgsm eposta mail']]],
 ['integrations','grid','Entegrasyonlar',[
  ['paytr','service_admin','PayTR ödeme ayarları',['provider'=>'paytr'],'mağaza merchant api kart'],['edoc','service_admin','e-Belge sağlayıcı ayarları',['provider'=>'edoc'],'edm entegratör e-fatura e-arşiv canlı'],['edoc_test','edm_test','e-Belge doğrulama alanı',[],'edm test kabul ret irsaliye smm'],['services','service_admin','Diğer servis bağlantıları',[],'api banka ocr yapay zeka zamanlayıcı']]],
 ['system','gear','Sistem',[
  ['platform','platform','Genel ayarlar',[],'kayıt deneme banka bilgileri'],['backups','backups','Yedekleme',[],'yedek kurtarma'],['updates','updates','Sürüm güncellemeleri',[],'zip imza yükle güncelleme'],['audit','audit','İşlem geçmişi',[],'kayıt log denetim'],['menu','admin_menu','Yönetici menü düzeni',[],'kategori ikon sıra taşı düzenle']]]
 ];$groups=[];$items=[];foreach($rows as $rank=>[$id,$icon,$label,$children]){$groups[$id]=['label'=>$label,'icon'=>$icon,'order'=>($rank+1)*10];foreach($children as $i=>[$key,$page,$name,$params,$aliases])$items[$key]=['page'=>$page,'label'=>$name,'params'=>$params,'aliases'=>$aliases,'group'=>$id,'order'=>($i+1)*10];}return ['groups'=>$groups,'items'=>$items];
}
function admin3641_key():string {return 'admin_menu_3641_'.(int)base_user()['id'];}
function admin3641_raw():string {return setting(admin3641_key(),'');}
function admin3641_state():array {
 $base=admin3641_catalog();$defaults=['groups'=>$base['groups'],'items'=>array_map(fn($i)=>['group'=>$i['group'],'order'=>$i['order']],$base['items']),'favorites'=>['companies','verification','transfers','home','feature_pages','library']];
 $saved=json_decode(admin3641_raw(),true);if(!is_array($saved))return $defaults;
 try{return admin3641_validate($saved);}catch(DomainException){return $defaults;}
}
function admin3641_validate(array $v):array {
 $base=admin3641_catalog();$groups=$v['groups']??null;$items=$v['items']??null;$favorites=$v['favorites']??[];
 if(!is_array($groups)||count($groups)<1||count($groups)>20||!is_array($items)||!is_array($favorites)||count($favorites)>20)throw new DomainException('Menü düzenini kontrol edin. En fazla 20 kategori ve 20 favori kullanılabilir.');
 $clean=[];foreach($groups as $id=>$g){if(!is_string($id)||!preg_match('/^[a-z][a-z0-9_]{0,35}$/D',$id)||!is_array($g))throw new DomainException('Kategori bilgisi geçersiz.');$label=$g['label']??null;$icon=$g['icon']??null;$order=filter_var($g['order']??null,FILTER_VALIDATE_INT);if(!is_string($label)||trim($label)===''||mb_strlen($label)>60||preg_match('/[\x00-\x1f\x7f]/u',$label)||!is_string($icon)||!isset(admin3641_icons()[$icon])||$order===false||$order<0||$order>9999)throw new DomainException('Kategori adı, ikon veya sıra bilgisini kontrol edin.');$clean[$id]=['label'=>trim($label),'icon'=>$icon,'order'=>$order];}
 if(array_diff(array_keys($items),array_keys($base['items']))||array_diff(array_keys($base['items']),array_keys($items)))throw new DomainException('Tüm yönetim bağlantıları menüde bulunmalıdır.');
 $placement=[];foreach($base['items'] as $id=>$i){$row=$items[$id]??null;$order=is_array($row)?filter_var($row['order']??null,FILTER_VALIDATE_INT):false;$group=$row['group']??null;if(!is_string($group)||!isset($clean[$group])||$order===false||$order<0||$order>9999)throw new DomainException('Bağlantı kategorisini ve sırasını kontrol edin.');$placement[$id]=['group'=>$group,'order'=>$order];}
 foreach($favorites as $id)if(!is_string($id)||!isset($base['items'][$id]))throw new DomainException('Favori bağlantısı geçersiz.');
 return ['groups'=>$clean,'items'=>$placement,'favorites'=>array_values(array_unique($favorites))];
}
function admin3641_groups():array {$s=admin3641_state();$base=admin3641_catalog();$groups=$s['groups'];uasort($groups,fn($a,$b)=>$a['order']<=>$b['order']);$out=[];foreach($groups as $id=>$g){$links=[];foreach($s['items'] as $key=>$row)if($row['group']===$id)$links[$key]=$row;uasort($links,fn($a,$b)=>$a['order']<=>$b['order']);$children=[];foreach($links as $key=>$row){$item=$base['items'][$key];$children[]=[$item['page'],$item['label'],$item['params']];}if($children)$out[]=[$id,$g['icon'],$g['label'],$children];}return $out;}
function admin3641_url(string $id):string {$i=admin3641_catalog()['items'][$id]??null;if(!$i)throw new DomainException('Yönetim bağlantısı bulunamadı.');return url($i['page'],$i['params']);}
function admin3641_context():array {
 $c=$_GET;$c['page']=is_string($c['page']??null)?$c['page']:'dashboard';
 if($c['page']==='site_admin'){$c['site']=(int)($c['site']??1);$c['view']=$c['view']??'dashboard';if($c['site']!==1)$c['view']='sites';
  if($c['view']==='pages'){$kind=$c['kind']??'';$slug='';if((int)($c['edit']??0)>0){$r=query('SELECT slug,kind FROM cms_pages WHERE site_id=? AND id=?',[$c['site'],(int)$c['edit']])->fetch();if($r){$slug=$r['slug'];$kind=$r['kind'];}}
   if(in_array($kind,['article','guide'],true)){$c['kind']=$kind;unset($c['section']);}else{$c['section']=$slug!==''?(product3633_item($slug)?'features':((isset(tools3639_catalog()[$slug])||$slug==='araclar')?'tools':'general')):($c['section']??'general');}
  }
 }return $c;
}
function admin3641_current():?string {
 $c=admin3641_context();$winner=null;$score=-1;foreach(admin3641_catalog()['items'] as $id=>$i){if($i['page']!==$c['page'])continue;$match=true;foreach($i['params'] as $key=>$v)if((string)($c[$key]??'')!==(string)$v)$match=false;if($match&&count($i['params'])>$score){$winner=$id;$score=count($i['params']);}}
 if($c['page']==='companies'&&isset($c['edit']))return 'companies';if($c['page']==='site_admin'&&($c['view']??'')==='dashboard')return 'home';return $winner;
}
function admin3641_active(string $page,array $params):bool {$id=admin3641_current();if(!$id)return false;$item=admin3641_catalog()['items'][$id];return $page===$item['page']&&$params===$item['params'];}
function admin3641_search_form():string {return '<form class="admin41-search" method="get" role="search"><input type="hidden" name="page" value="admin_search"><label>'.icon('search').'<input type="search" name="q" aria-label="Yönetimde ara" placeholder="Yönetimde ara…" maxlength="100" value="'.esc(($_GET['page']??'')==='admin_search'&&is_string($_GET['q']??null)?$_GET['q']:'').'"></label><button type="submit">Ara</button></form>';}
function admin3641_breadcrumb():void {
 if(!admin3641_enabled())return;$id=admin3641_current();$state=admin3641_state();$item=$id?(admin3641_catalog()['items'][$id]??null):null;
 echo '<div class="admin41-context"><nav aria-label="Yönetim konumu">'.a('dashboard','Yönetim');if($item){$group=$state['items'][$id]['group'];echo '<span>/</span>'.a('admin_search',esc($state['groups'][$group]['label']),['group'=>$group]).'<span>/</span><strong>'.esc($item['label']).'</strong>';}echo '</nav><div class="admin41-context-actions">';if($id&&$id!=='favorites'){form_start('admin_menu','favorite',[],'inline-form');hidden('item',$id);submit(in_array($id,$state['favorites'],true)?'★ Favorilerimde':'☆ Favoriye ekle','quiet');echo '</form>';}echo a('admin_menu','Menüyü düzenle',[],'button quiet').'</div></div>';
}
function admin3641_cards(array $ids,bool $groupLabel=true):void {
 $base=admin3641_catalog();$state=admin3641_state();echo '<div class="admin41-cards">';foreach($ids as $id){if(!isset($base['items'][$id]))continue;$i=$base['items'][$id];$g=$state['groups'][$state['items'][$id]['group']];echo '<a href="'.esc(admin3641_url($id)).'">'.icon($g['icon']).'<strong>'.esc($i['label']).'</strong>'.($groupLabel?'<small>'.esc($g['label']).'</small>':'').'</a>';}echo '</div>';
}
function admin3641_dashboard():void {
 heading('Genel Bakış','Bekleyen işler ve sık kullandığınız bölümler.',a('companies','Yeni firma',['view'=>'new'],'button primary'));
 $counts=query("SELECT COUNT(*) total,SUM(status='active') active FROM companies")->fetch();$paid=(int)query("SELECT COUNT(*) FROM subscriptions WHERE status='active' AND paid_until>UTC_TIMESTAMP()")->fetchColumn();
 echo '<div class="stats-grid">';foreach([['Toplam firma',(int)$counts['total']],['Erişimi açık firma',(int)$counts['active']],['Aktif ücretli üyelik',$paid]] as [$l,$n])echo '<article class="stat-card"><span>'.esc($l).'</span><strong>'.$n.'</strong></article>';echo '</div>';
 admin3641_pending_cards();panel('Favorilerim');admin3641_cards(admin3641_state()['favorites']);echo '</section>';
 panel('Yönetim bölümleri');echo '<div class="admin41-cards">';foreach(admin3641_groups() as [$id,$ico,$label,$children])echo '<a href="'.esc(url('admin_search',['group'=>$id])).'">'.icon($ico).'<strong>'.esc($label).'</strong><small>'.count($children).' bölüm</small></a>';echo '</div></section>';
}
function admin3641_pending_cards():void {
 $rows=[['verification','Firma doğrulama',"SELECT COUNT(*) FROM verification_requests WHERE status='pending'"],['transfers','Havale bildirimi',"SELECT COUNT(*) FROM payment_orders WHERE status='reported' AND payment_method<>'card'"],['tickets','Yeni destek mesajı',"SELECT COUNT(*) FROM help_tickets WHERE admin_unread=1"],['live','Canlı destek sırası',"SELECT COUNT(*) FROM support_queue WHERE status='waiting'"]];
 echo '<section class="panel"><h2>Bekleyen işlemler</h2><div class="admin41-cards admin41-pending">';foreach($rows as [$id,$label,$sql])echo '<a href="'.esc(admin3641_url($id)).'"><strong>'.(int)query($sql)->fetchColumn().'</strong><span>'.esc($label).'</span><small>İlgili bölümü aç →</small></a>';echo '</div></section>';
}
function admin3641_fold(string $s):string {return strtr(mb_strtolower($s,'UTF-8'),['ı'=>'i','İ'=>'i','ş'=>'s','ğ'=>'g','ü'=>'u','ö'=>'o','ç'=>'c',"i\u{0307}"=>'i']);}
function admin3641_search_view():void {
 heading('Yönetimde ara','İşlem adı, konu veya kategoriyle arayın.');echo admin3641_search_form();$q=field_get3641('q',100);$group=field_get3641('group',36);$s=admin3641_state();if($group!==''&&!isset($s['groups'][$group]))throw new DomainException('Kategori bulunamadı.');$ids=[];
 foreach(admin3641_catalog()['items'] as $id=>$i){$g=$s['items'][$id]['group'];if($group!==''&&$g!==$group)continue;$text=admin3641_fold($i['label'].' '.$i['aliases'].' '.$s['groups'][$g]['label']);$hit=true;foreach(preg_split('/\s+/u',admin3641_fold(trim($q)),-1,PREG_SPLIT_NO_EMPTY) as $term)if(!str_contains($text,$term))$hit=false;if($hit)$ids[]=$id;}
 panel($group!==''?$s['groups'][$group]['label']:'Yönetim bağlantıları',count($ids).' sonuç');admin3641_cards($ids);if(!$ids)echo '<p>Eşleşen bölüm bulunamadı. Başka bir işlem adı deneyin.</p>';echo '</section>';
}
function field_get3641(string $name,int $max):string {$v=$_GET[$name]??'';if(!is_string($v)||mb_strlen($v)>$max)throw new DomainException('Arama bilgisini kontrol edin.');return $v;}
function admin3641_editor():void {
 $s=admin3641_state();$base=admin3641_catalog();$choices=[];foreach($s['groups'] as $id=>$g)$choices[$id]=$g['label'];heading('Yönetici menü düzeni','Bu düzen yalnız sizin yönetici hesabınıza kaydedilir. İşlem yetkilerini değiştirmez.');
 panel('Kategoriler ve bağlantılar');form_start('admin_menu','save');hidden('revision',hash('sha256',admin3641_raw()));
 foreach($s['groups'] as $id=>$g){echo '<details class="admin41-category wide"><summary>'.icon($g['icon']).esc($g['label']).'</summary><div class="form-grid">';input('groups['.$id.'][label]','Kategori adı',$g['label'],'text','required maxlength="60"');select_field('groups['.$id.'][icon]','İkon',admin3641_icons(),$g['icon']);input('groups['.$id.'][order]','Kategori sırası',$g['order'],'number','min="0" max="9999" required');echo '</div><div class="admin41-editor-scroll"><table><thead><tr><th>Bölüm</th><th>Gösterileceği kategori</th><th>Sıra</th><th>Favori</th></tr></thead><tbody>';
  foreach($s['items'] as $key=>$r){if($r['group']!==$id)continue;echo '<tr><th scope="row">'.esc($base['items'][$key]['label']).'</th><td>';select_field('items['.$key.'][group]','Kategori',$choices,$r['group']);echo '</td><td>';input('items['.$key.'][order]','Bölüm sırası',$r['order'],'number','required min="0" max="9999"');echo '</td><td><label><input type="checkbox" name="favorites[]" value="'.esc($key).'" '.(in_array($key,$s['favorites'],true)?'checked':'').'> Favori</label></td></tr>';}
  echo '</tbody></table></div></details>';
 }form_end('Menü düzenini kaydet');echo '</section>';
 panel('Yeni kategori');form_start('admin_menu','add_group');input('label','Kategori adı','','text','required maxlength="60"');select_field('icon','İkon',admin3641_icons(),'grid');form_end('Kategoriyi ekle');echo '</section>';
 $empty=[];foreach($s['groups'] as $id=>$g)if(!array_filter($s['items'],fn($i)=>$i['group']===$id))$empty[$id]=$g['label'];if($empty){panel('Boş kategoriler');form_start('admin_menu','remove_group');select_field('group','Silinecek boş kategori',$empty,array_key_first($empty));form_end('Boş kategoriyi kaldır');echo '</section>';}
 panel('Varsayılan düzen');echo '<p>Kendi kategori ve favori düzeninizi başlangıç yapısına döndürür. Firma veya site içeriği değişmez.</p>';form_start('admin_menu','reset');form_end('Varsayılan menüye dön');echo '</section>';
}
function admin3641_post(string $action):void {
 admin3641_guard();$return='menu';transaction(function()use($action,&$return){$key=admin3641_key();$r=query('SELECT value FROM settings WHERE name=? FOR UPDATE',[$key])->fetchColumn();$raw=$r===false?'':(string)$r;$s=admin3641_state();
  if($action==='reset'){$next='';}
  else{if($action==='save'){if(!hash_equals(hash('sha256',$raw),required_field('revision',64)))throw new DomainException('Menü başka bir sekmede değişti. Sayfayı yenileyin.');$s=admin3641_validate(['groups'=>$_POST['groups']??null,'items'=>$_POST['items']??null,'favorites'=>$_POST['favorites']??[]]);}
   elseif($action==='favorite'){$id=required_field('item',60);if(!isset(admin3641_catalog()['items'][$id]))throw new DomainException('Bağlantı bulunamadı.');$s['favorites']=in_array($id,$s['favorites'],true)?array_values(array_diff($s['favorites'],[$id])):[...$s['favorites'],$id];$return=$id;}
   elseif($action==='add_group'){if(count($s['groups'])>=20)throw new DomainException('En fazla 20 kategori oluşturabilirsiniz.');$s['groups']['custom_'.bin2hex(random_bytes(5))]=['label'=>required_field('label',60),'icon'=>choice('icon',array_keys(admin3641_icons())),'order'=>min(9999,count($s['groups'])*10+10)];}
   elseif($action==='remove_group'){$id=required_field('group',36);if(!isset($s['groups'][$id])||array_filter($s['items'],fn($i)=>$i['group']===$id))throw new DomainException('Yalnız boş kategori kaldırılabilir.');unset($s['groups'][$id]);}
   else throw new DomainException('Menü işlemi bulunamadı.');$next=json_encode(admin3641_validate($s),JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
  }query('INSERT INTO settings(name,value) VALUES (?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',[$key,$next]);audit('admin.menu_updated',['reason'=>'Kendi yönetici menüsü: '.$action]);
 });flash('Yönetici menünüz kaydedildi.');$i=admin3641_catalog()['items'][$return];redirect($i['page'],$i['params']);
}
function admin3641_view(string $page):void {
 admin3641_guard();if($page==='admin_menu'){admin3641_editor();return;}if($page==='admin_search'){admin3641_search_view();return;}if($page==='admin_pending'){heading('Bekleyen işlemler');admin3641_pending_cards();return;}if($page==='admin_favorites'){heading('Favorilerim','Sık kullandığınız yönetim bağlantıları.');admin3641_cards(admin3641_state()['favorites']);return;}
 if($page==='admin_plan_features'){admin3641_features_view();return;}if($page==='admin_credits'){heading('Firma kontör yönetimi','Önce işlem yapılacak firmayı seçin.');$q=field_get3641('q',100);echo '<form method="get" class="filter-bar"><input type="hidden" name="page" value="admin_credits">';input('q','Firma ara',$q,'search','maxlength="100"');submit('Ara');echo '</form>';panel('Firmalar');$rows=query('SELECT id,name,credits_balance FROM companies WHERE name LIKE ? ORDER BY name LIMIT 50',['%'.$q.'%'])->fetchAll();table_start(['Firma','Kontör','İşlem']);foreach($rows as $r)echo '<tr><td>'.esc($r['name']).'</td><td>'.(int)$r['credits_balance'].'</td><td>'.a('companies','Kontör işlemlerini aç',['edit'=>$r['id'],'view'=>'credits'],'button quiet').'</td></tr>';table_end(count($rows),3);echo '<p>En fazla 50 firma gösterilir. Arama ile listeyi daraltın.</p></section>';return;}
}
function admin3641_cms_section():string {if(!admin3641_enabled()||cms_sid()!==1)return '';if(($_GET['view']??'')!=='pages')return '';if(in_array($_GET['kind']??'',['article','guide'],true))return (string)$_GET['kind'];$v=$_GET['section']??'general';if(!is_string($v)||!in_array($v,['features','tools','general'],true))throw new DomainException('İçerik bölümü bulunamadı.');return $v;}
function admin3641_cms_where(array &$args):string {
 $section=admin3641_cms_section();if(!in_array($section,['features','tools','general'],true))return '';
 $features=array_keys(visual3638_defaults());$tools=[...array_keys(tools3639_catalog()),'araclar'];$slugs=$section==='features'?$features:($section==='tools'?$tools:[...$features,...$tools,...array_values(legal3630_slugs()),'ana-sayfa']);$args=[...$args,...$slugs];return ' AND slug '.($section==='general'?'NOT IN':'IN').' ('.implode(',',array_fill(0,count($slugs),'?')).')'." AND kind='page'";
}
function admin3641_cms_title(string $view):string {
 $section=admin3641_cms_section();return ['features'=>'Özellik sayfaları','tools'=>'Hesaplama araçları','article'=>'Blog yazıları','guide'=>'Kullanım kütüphanesi','general'=>'Diğer bilgi sayfaları'][$section]??['dashboard'=>'Site yönetimi','blocks'=>'Ana sayfa','sites'=>'Firma web siteleri','media'=>'Görseller','nav'=>'Site menüleri ve footer','settings'=>'Site ve SEO ayarları','reviews'=>'Müşteri yorumları','history'=>'İçerik geçmişi','plans'=>'Paket sunumu','features'=>'Paket karşılaştırması'][$view]??'Site ve içerikler';
}
function admin3641_cms_rows(string $where,array $args):array {
 $count=(int)query('SELECT COUNT(*) FROM cms_pages WHERE '.$where,$args)->fetchColumn();$pages=max(1,(int)ceil($count/50));$page=max(1,min($pages,(int)($_GET['p']??1)));$GLOBALS['admin41_cms_pager']=[$page,$pages,$count];return query('SELECT * FROM cms_pages WHERE '.$where.' ORDER BY kind,title LIMIT 50 OFFSET '.(($page-1)*50),$args)->fetchAll();
}
function admin3641_cms_pager():void {
 if(!isset($GLOBALS['admin41_cms_pager']))return;[$page,$pages,$count]=$GLOBALS['admin41_cms_pager'];echo '<div class="panel-bottom"><span>'.$count.' kayıt · Sayfa '.$page.' / '.$pages.'</span><span>';$args=array_intersect_key($_GET,array_flip(['site','section','kind','q']));if($page>1)echo cms_link('pages','Önceki',$args+['p'=>$page-1]);if($page<$pages)echo cms_link('pages','Sonraki',$args+['p'=>$page+1]);echo '</span></div>';
}
function admin3641_price_features(string $code):void {
 $cfg=plan3616_config();hidden('feature_revision',$cfg['revision']);hidden('feature_selection',1);foreach($cfg['plans'][$code] as $key)hidden('features[]',$key);echo '<p>'.a('admin_plan_features','Bu paketin özelliklerini düzenle').'</p>';input('current_password','Mevcut yönetici şifreniz','','password','required autocomplete="current-password"');
}
function admin3641_features_view():void {
 heading('Paket özellikleri','Her paketin kullanabileceği işlevleri seçin. Paket fiyatları ayrı bölümden yönetilir.');echo '<div class="plan-grid">';foreach(query("SELECT id,code,name FROM plans WHERE code IN ('kobi','plus','business') ORDER BY FIELD(code,'kobi','plus','business')") as $p){panel($p['name']);form_start('admin_plan_features','save',[],'form-stack');hidden('code',$p['code']);plan3616_fields($p['code']);form_end('Paket özelliklerini kaydet');echo '</section>';}echo '</div>';
}
function admin3641_features_post(string $action):void {
 admin3641_guard();if($action!=='save')throw new DomainException('İşlem geçersiz.');reauthenticate(base_user());$code=choice('code',['kobi','plus','business']);transaction(fn()=>plan3616_save($code));flash('Paket özellikleri kaydedildi.');redirect('admin_plan_features');
}
