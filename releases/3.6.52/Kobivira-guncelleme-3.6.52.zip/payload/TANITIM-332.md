# Kobivira 3.3.2 tanıtım ve kütüphane

Bu paket yalnızca 3.3.1 üzerine yüklenir. Yönetim → Sistem → Sürüm güncellemeleri bölümünden imzalı ZIP yüklenir. Firma kayıtları ve geçmiş sürüm açıklamaları korunur. Veritabanı değişikliği güncelleyici tarafından uygulanır.

Yükleme sonrası yönetici Genel Bakış sayfasındaki **Tanıtımı görüntüle** bağlantısı siteyi açar. **Site dosyalarını indir** düğmesi statik yayın dosyalarını üretir. İndirilen ZIP'in içindeki dosyaların tamamı apyon.com.tr için tanımlı web köküne, mevcut dosyaların yedeği alındıktan sonra yüklenebilir. SaaS test paneli test.apyon.com.tr adresinde kalır. Bu güncelleme alan adı, DNS veya mevcut ana site dosyalarını otomatik değiştirmez.

Firma ve yönetici ekranının altındaki **Kullanım kütüphanesi** bağlantısı rehberleri ayrı sekmede açar. Kütüphane, kategori ve paket filtreleriyle 55 rehber içerir. Tanıtım dosyaları 69 HTML sayfasıdır; panel ön izlemesi uygulamanın kendi PHP ekran çıktısından, yalnızca geçici test verileriyle üretilir. Gerçek firma hesaplarına örnek veri eklenmez.

Yeni aylık fiyatlar henüz işletme sahibi tarafından belirtilmedi. KOBİ / Plus / Business kartları bu nedenle fiyat güncelleniyor gösterir. Fiyatlar kesinleşince kaynak fiyat yapılandırmasıyla site yeniden üretilmelidir; bu teslimde ticari fiyat taahhüdü yoktur. Paneldeki paket ücretleri yönetici tarafından ayrıca yönetilir. Kullanıcı ve kontör kotaları satın alma öncesi panelden kontrol edilir.

Kurumsal CMS, blog ve SEO yönetim paneli sonraki aşamadadır. Sayfalar başlık ve açıklamalarıyla hazırdır; davetli test sırasında arama motorlarına kapalıdır. Nihai ticari / hukuki metinler satışa hazırlık aşamasında tamamlanacaktır. Gerçek ödeme, SMS, dış servis ve iki aşamalı doğrulama etkinleştirilmez.

Özgün logo korunmuştur; panel yapısı değiştirilmeden marka işareti ve küçük yüzey düzenlemeleri yapılmıştır. 3.3.2 için kullanıcı tarafından verilen premium görünüm / logo uygulaması talimatı tasarım kilidinin bu değişiklikler için istisnasıdır.
