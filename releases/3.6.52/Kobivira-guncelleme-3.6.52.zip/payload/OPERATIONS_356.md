# Canlı kabul kontrolü · 3.5.6

Bu çalışma canlı sunucuya işlem yapmadı. Yerel testler hosting zamanlayıcısının tanımlı olduğunu kanıtlamaz.

1. Yönetimden sürümü, sürüm geçmişini, önceki fiyat / indirim / kullanıcı kotası değerlerini kontrol edin.
2. Ayrı test firmalarıyla üç paketi, süresi dolmuş üyelikte salt okunur erişimi ve yönetici / çalışan / SMMM ayrımını gerçek kullanımda kontrol edin.
3. KOBİ ile teklif / proforma / PDF; Plus ile cari ekstre / kısmi iade; Business ile onay / otomasyon akışını tamamlayın. Eksik alan hatasında form değerlerinin korunmasını masaüstü ve gerçek mobil cihazda kontrol edin.
4. Hosting zamanlayıcısı mevcut özel saas dizininin SchedulerCli.php aracını PHP CLI ile uygun aralıkta çalıştırmalıdır. Çıktıyı ve sunucu hata günlüğünü inceleyin. Aynı gün mükerrer bildirim oluşmamalı, süresi bitmiş firmada yeni kayıt açılmamalıdır. Bu sürüm canlı cron eklemedi veya değiştirmedi.
5. Veritabanı, kobivira-private dizini ve web köklerini kapsayan tam hosting yedeği alın. Uygulama yedeği veritabanını kapsar; yüklenen logo / evrak / site medyası / yapılandırma için dosya yedeği de gerekir. Farklı test ortamına geri yükleyin, canlı veritabanında prova yapmayın.
6. Taşınacak firmadan gerçek CSV / XLSX / UBL örneği alın. Ön izleme ve aktarılan toplamları kaynak dosyayla karşılaştırın. Dosya görülmeden sağlayıcının bütün biçimleri için hazır uyumluluk onayı vermeyin.
7. Abonelik iadesini ayrı test ortamında sınayın. Canlı iade kaydı yalnız gerçek banka hareketiyle oluşturulmalıdır. Yönetici bildirimi ve firma karar mesajını kontrol edin.
8. Son güvenlik incelemesi, gerçek cihaz / Safari ve eşzamanlı çok firma yük testi ayrıca yapılmalıdır. Yerel işlev testleri tam kapsamlı sızma testi değildir.
