# 3.6.44 — Mobil doğrulama, şifre yenileme ve sayaç

3.6.43 üzerine imzalı güncelleme olarak yüklenir. Yeni 053 migration mevcut hesapların girişini engellemez. Yeni internet sitesi kayıtlarında cep telefonu zorunludur: önce e-posta, sonra cep telefonu doğrulanır. Telefon doğrulanmadan yeni firmanın panel işlemleri açılamaz.

## Yönetim ayarları

Yönetim → Destek ve İletişim → E-posta ve SMS gönderimleri sayfasında “Mobil üyelik doğrulaması ve şifre yenileme” bölümünü açın.

- Kapalı: yeni kayıtlar mobil onay bekler. Bu durumda yeni müşterilerin üyelik aktivasyonu tamamlanamaz.
- Test: önce test için oluşturduğunuz firmayı mevcut ödeme testi ayarıyla test firması olarak işaretleyin. Mobil bölümünde aynı firmayı ve kayıt sırasında kullanılan cep telefonunu seçin. Yönetici şifrenizle kaydedin. Yalnız bu firma ve telefon için rastgele deneme kodu üretilir. Firma giriş yapıp kod istediğinde kod bu yönetim bölümünde görünür. Herkese açık sabit test şifresi yoktur. Test sonucu gerçek telefon doğrulaması olarak kaydedilmez.
- Canlı: Netgsm SMS/OTP yetkisi, kullanıcı bilgileri, parola ve onaylı gönderici başlığı girildikten sonra etkinleştirilir. Bu sürüm gerçek Netgsm hesabıyla gönderim yapılarak doğrulanmamıştır; API onayından sonra gerçek telefonla uçtan uca test yapılmalıdır.

Test modundan canlıya geçildiğinde test doğrulaması gerçek SMS doğrulamasının yerine geçmez. Mevcut hesaplar Hesabım bölümündeki “Telefonumu doğrula” bağlantısıyla telefonlarını doğrulayabilir. İlk telefon tanımlaması mevcut hesap şifresini gerektirir.

## Kullanıcı akışı

Kayıt formunda cep telefonu alanı vardır. E-posta doğrulamasından sonra mobil doğrulama sayfası açılır. SMS kodu 10 dakika geçerlidir. Yeniden gönderim için 60 saniye beklenir. İki süre ekranda ayrı sayaçla gösterilir; bekleme sıfırlandığında kod iste düğmesi açılır. Bekleme, tek kullanım, son kullanma tarihi ve yanlış kod denemeleri sunucuda da kontrol edilir. Günlük gönderim sınırı uygulanır.

Gerçek SMS ile doğrulanan telefon, firmanın kayıtlı iletişim telefonuyla aynıysa firma doğrulama alanına da otomatik yansır. Farklı bir numara doğrulanmış sayılmaz.

“Şifremi unuttum” sayfasında kayıtlı e-posta ve daha önce doğrulanmış cep telefonu girilir. Kod ve yeni şifre ile şifre yenilenir; eski giriş oturumları geçersiz olur. Telefonunu henüz doğrulamayan eski hesap SMS ile şifre yenileyemez. Hesabın varlığını açıklamamak için eşleşmeyen bilgilerde de genel mesaj gösterilir.

## E-posta hatasının incelenmesi

SMTP: mail.kobivira.com.tr / 465 / SSL; kullanıcı ve gönderen info@kobivira.com.tr. Parola, bu posta kutusunun parolasıdır. Yönetici işlem onayındaki şifre ise panel yönetici şifresidir.

Aynı yönetim sayfasından deneme e-postası gönderin. Başarısız üyelik gönderimlerinde güvenli hata özeti gösterilir; örneğin SMTP 535 posta kullanıcı adı/parola doğrulamasının başarısız olduğunu belirtir. Tam SMTP yanıtları ve parolalar gösterilmez. Gerçek sunucunun SMTP bağlantısı ve posta teslimi bu çalışma ortamında doğrulanmadı. Bu sürüm, gönderim hatasının nedenini yönetimde ayırmayı sağlar; teslimin başarılı olduğu iddia edilmez.

## Veri taşıma kampanyası

3 ay ücretsiz kullanım hediyesine kontör ve ücretli servisler dahil değildir. Üyelik ekranında açıklanır; kampanya nedeniyle kontör yüklenmez. Yıllık ücretli Plus paketinin ayrı hediye kuralı değiştirilmez.

PayTR ayarları ve ödeme akışı değiştirilmez. Sunucunuza otomatik yükleme, gerçek SMS/e-posta gönderimi veya gerçek ödeme yapılmamıştır.
