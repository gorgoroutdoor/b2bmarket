<?php
declare(strict_types=1);
function pricing_can_sell(array $plan): bool {
 if(!in_array($plan['code']??'',['kobi','plus','business'],true)||empty($plan['is_active'])||($plan['monthly_price']??null)===null)return false;
 try{return scaled((string)$plan['monthly_price'])>0;}catch(DomainException $e){return false;}
}
function pricing_quote(array $plan,int $months): array {
 if(!pricing_can_sell($plan))throw new DomainException(($plan['code']??'')==='business_plus'?'Bu paket satışa açık değildir.':'Bu paket şu anda satın alınamıyor.');
 if(!in_array($months,[1,3,12],true))throw new DomainException('Geçerli ödeme dönemi seçin.');
 $monthly=scaled((string)$plan['monthly_price']);$d=commerce_discount($plan['code'],$months);$q=commerce_quote($monthly*$months,(int)$plan['vat_rate'],$d['bps']);return ['months'=>$months,'monthly_net'=>$monthly,'discount_source'=>$d['source']]+$q;
}
function pricing_intent(): ?array {
 $v=$_SESSION['package_intent']??null;if(!is_array($v)||!in_array($v['plan']??'',['kobi','plus','business'],true)||!in_array($v['period']??'',['monthly','annual'],true)||(int)($v['expires']??0)<time())return null;return $v;
}
function pricing_capture_intent(): void {
 if($_SERVER['REQUEST_METHOD']!=='GET'||!in_array($_GET['page']??'',['login','register','membership'],true))return;
 if(!is_string($_GET['plan']??null)||!in_array($_GET['plan'],['kobi','plus','business'],true)||!is_string($_GET['period']??null)||!in_array($_GET['period'],['monthly','annual'],true))return;
 $_SESSION['package_intent']=['plan'=>$_GET['plan'],'period'=>$_GET['period'],'expires'=>time()+3600];
}
function pricing_order_summary(array $order): string {
 $p=query('SELECT * FROM payment_pricing WHERE payment_order_id=?',[$order['id']])->fetch();if(!$p)return '';
 return '<div class="info-note"><strong>'.('Seçilen dönem · %'.commerce_percent((int)$p['discount_basis_points']).' indirim').'</strong><p>İndirimsiz net: '.money($p['base_net']).' · İndirim: '.money($p['discount_amount']).' · İndirimli net: '.money($order['net']).' + KDV</p>'.((int)$p['months']===12?'<p>12 aylık bedel tek seferde ödenir. Aylık karşılık ayrı bir aylık tahsilat değildir.</p>':'').'</div>';
}
function pricing_member_prices(array $plan): string {
 if(($plan['code']??'')==='business_plus')return '<div class="info-note"><strong>Satışa kapalı</strong><p>Bu paket satın alınamaz.</p></div>';
 if(!pricing_can_sell($plan))return '';
 try{$q=pricing_quote($plan,12);}catch(DomainException $e){return '<p class="field-hint">Yıllık ödeme için fiyat bilgisini yöneticiyle doğrulayın.</p>';}
 return ($plan['code']==='plus'?'<p class="field-hint">'.esc(gift354_copy()).'</p>':'').'<div class="info-note"><strong>Yıllık ödemede %'.commerce_percent($q['discount_basis_points']).' indirim</strong><p>'.money($q['base_net']).' yerine <strong>'.money($q['net']).' + KDV / yıl</strong>.</p><p>Yıllık KDV dahil: '.money($q['total']).' · Net tasarruf: '.money($q['discount_amount']).'.</p><p>Aylık net karşılığı yaklaşık '.money(intdiv($q['net']+6,12)).'. 12 aylık bedel tek seferde ödenir.</p></div>';
}
