# Kobivira tam sistem yedeği

Bu sürüm 3.6.6 üzerine kurulur. Mevcut tasarım, veritabanı şeması ve EDM test bağlantısı korunur. Bu geliştirme, e-belge bağlantılarının canlı kullanıma hazır olduğu anlamına gelmez.

## Yönetim ekranı

Sistem → Sistem yedekleri yalnız platform yöneticisine açıktır. Firma, destek temsilcisi ve destek/izleme oturumları tam yedeklere erişemez. Ayar değiştirme, elle yedek isteme, yedek ve kurtarma anahtarı indirme yönetici şifresi ve CSRF kontrolü gerektirir.

Varsayılan günlük saat 20:00 Europe/Istanbul; son 7 başarılı otomatik yedek saklanır. Saat ve otomatik yedek sayısı panelden değiştirilebilir. Elle ve geri yükleme öncesinde alınan yedekler otomatik temizlenmez. Yerel yedekler disk tüketir; boş alan izlenmelidir.

Elle yedek düğmesi isteği sıraya alır. Sunucudaki zamanlayıcı bir sonraki çalışmasında yedeği oluşturur. İşin tamamlandığı hem son sonuç alanından hem tamamlanan yedekler listesinden doğrulanmalıdır; sıraya alınması başarı anlamına gelmez.

## Hosting zamanlayıcısı

Bu paket hosting paneline cron kaydı eklemez. Kurulumdan sonra yedekleme ekranındaki sunucunuza ait komutu hosting görev/zamanlayıcı alanına ekleyin. Her dakika çalıştırın. PHP komutunu, hostinginizin PHP 8.2 veya üzeri CLI yürütücüsüyle değiştirin.

```text
* * * * * /HOSTING/PHP/YOLU /UYGULAMA_KLASORU/releases/3.6.7/BackupCli367.php --run
```

Komut kurulu güncel sürümü storage/current.json üzerinden bulur; başlatıcı dosyayı silmeyin. Zamanlayıcının son kontrol zamanı panelde görünür. Son üç dakika içinde kontrol kaydı yoksa çalışma doğrulanmış sayılmaz. Sunucu saat dilimi farklı olsa da günlük karar Türkiye saatine göre verilir. Saat geçildiyse aynı gün ilk uygun çalışmada yedek alınır. İşlem kilidi meşgulse sonraki dakika tekrar denenir; hata sonrası 15 dakika beklenir.

Tek seferlik anında sunucu yedeği:

```text
/HOSTING/PHP/YOLU /UYGULAMA_KLASORU/releases/3.6.7/BackupCli367.php --now
```

Yedekleme, uygulamanın diğer istekleriyle aynı kilidi kullanır. Veritabanı ve dosya tutarlılığı için yedek boyunca istekler kısa süre bekleyebilir. Büyük kurulumlarda iş süresi ve disk ihtiyacı ayrıca ölçülmelidir; bu sürüm test ortamında doğrulanmıştır.

## Neler saklanır?

Uygulamaya ayrılmış veritabanındaki tüm tablolar: tüm firmalar, kullanıcılar, muhasebe/CRM/stok kayıtları, paket/ödeme kayıtları, işlem geçmişleri ve entegrasyon ayarları dahil. APP_ROOT özel uygulama klasöründeki config, yüklenen firma belgeleri/görselleri, veri taşıma dosyaları, kök dosyalar ve çalışan sürümün kaynakları da saklanır.

Diğer yedekler, geçici güncelleme alanı, giriş oturumları, sunucu logları, önceki pasif sürümler, kurulum tokeni ve yedek kurtarma anahtarı arşive dahil edilmez. Kaynak alandaki sembolik bağlantı veya okunamayan dosya eksik yedek diye sessiz atlanmaz; iş başarısız gösterilir.

APP_ROOT dışındaki public_html/index.php gibi web başlangıç dosyaları, hosting hesabı/e-posta, DNS/SSL, cron tanımları ve haricî depolama bu yedeğin kapsamında değildir. Hosting tam yedeğini de koruyun. Aynı diskteki kopya sunucunun tamamen kaybına karşı yeterli değildir; şifreli yedek ve ayrı kurtarma anahtarının sunucu dışında güvenli kopyasını saklayın. Haricî depoya otomatik gönderim bu sürümde bulunmaz.

## Şifreleme ve anahtar

Yedek .kvbak biçiminde doğrulanmış akış şifrelemesiyle saklanır. Dosya ve veritabanı özetleri kaydedilir; tamamlananlar listesine eklenmeden şifreli dosya açılıp tüm iç dosya özetleri doğrulanır. Kurtarma anahtarı config/backup367.key dosyasındadır ve hiçbir yedeğin içine konulmaz.

Önce panelden ayarları kaydedin, ardından Kurtarma anahtarını indir düğmesiyle anahtarı indirip ayrı yerde saklayın. Anahtar olmadan yedek açılamaz. Anahtarı silmeyin veya değiştirmeyin. Anahtar ve yedek dosyalarını e-postayla ya da sohbet içinde paylaşmayın.

## Geri yükleme

Geri yükleme tüm firmaları seçilen anın veritabanı durumuna döndürür; daha sonraki işlemler o veritabanında bulunmaz. Önce seçilen yedeği doğrulayın. Güncel durumun geri dönüş kopyası otomatik alınır. Panelden yanlışlıkla tek tıklamayla başlatılmaz; sunucu komut satırından açık onay gerekir. Gerçek bir olayda işlemi yetkili teknik yönetici yapmalıdır.

```text
/HOSTING/PHP/YOLU /UYGULAMA_KLASORU/releases/3.6.7/BackupCli367.php --verify full-YYYYMMDD-HHMMSS-xxxxxxxxxxxx.kvbak
/HOSTING/PHP/YOLU /UYGULAMA_KLASORU/releases/3.6.7/BackupCli367.php --restore full-YYYYMMDD-HHMMSS-xxxxxxxxxxxx.kvbak --confirm-all-companies
```

Şifre ve bütün dosya özetleri doğrulanmadan canlı veri değiştirilmez. Önce dosyalar hazırlanır, mevcut dosyalar geçici korunur, veritabanı aşamalı doğrulamayla değiştirilir. Dosya/veritabanı kurtarması başarısızsa bakım açık kalabilir; hata günlüğü ve geri yükleme öncesi yedekle teknik inceleme gerekir. Bakım işaretini veri tutarlılığını doğrulamadan kaldırmayın. Yarım kalan full_restore işlemi aynı açık onayla CLI üzerinden yeniden kurtarılabilir; başka güncelleme bakımına müdahale edilmez.

Sunucunun mevcut veritabanı bağlantı bilgileri korunur; yedekteki uygulama şifreleme anahtarı/ayarları geri gelir. Kullanıcı oturumları kapatılır. Yedekte bulunan dosyalar geri yazılır; sonradan oluşmuş, artık veritabanında referansı kalmayan ek dosyalar otomatik silinmez.

Tamamen yeni sunucuda önce çalışabilir Kobivira özel klasör yapısını ve doğru veritabanı bağlantısını kurun. Eski yedeği storage/full-backups alanına, ayrı indirilmiş kurtarma anahtarının base64 çözülmüş 32 baytını config/backup367.key alanına güvenli dosya izinleriyle koyun. Uygulama klasörü dışındaki web başlangıç dosyalarını hosting yedeğinden alın. Ardından doğrulama ve geri yükleme komutlarını çalıştırın. Sadece .kvbak dosyasının yüklenmesi yeni sunucuyu kendiliğinden kurmaz.

## Doğrulama kapsamı

Test ortamında günlük Türkiye saati sınırı, aynı güne tekrar yedek üretmeme, elle kuyruk, şifreleme, kaynak dosyalar ve firma eklerinin dahil olması, bozulmuş dosya/yanlış anahtar reddi, eski yedek rotasyonu ve gerçek CLI geri yükleme denendi. Değişen veritabanı kaydı, dosya ve uygulama başlangıç dosyası geri getirildi. Admin HTTP ekranı, CSRF ve şifre tekrar kontrolü de sınandı.

Bu sonuçlar kullanıcının hostingindeki cron kaydının kurulup çalıştığını göstermez. Canlı kurulumdan sonra bir elle yedek, indirme, zamanlayıcı sağlık kontrolü ve ayrı bir kopya ortamda geri yükleme provası yapılmalıdır.
