<?php
declare(strict_types=1);
function mail3644_error(string $phase,int $code=0):string {
 $labels=['greeting'=>'Sunucu karşılama yanıtı','hello'=>'Sunucu tanıtımı','tls'=>'TLS bağlantısı','auth'=>'SMTP kullanıcı adı / posta şifresi','sender'=>'Gönderen adresi','recipient'=>'Alıcı adresi','data'=>'İleti kabulü','smtp'=>'Sunucu yanıtı'];
 return 'SMTP'.($code?' '.$code:'').' · '.($labels[$phase]??$labels['smtp']).' doğrulanamadı.';
}
function mail3644_reply($s,array $expected,string $phase):void {
 $last='';for($i=0;$i<100;$i++){$line=fgets($s,2048);if($line===false)throw new DomainException(mail3644_error($phase));$last=$line;if(strlen($line)<4||$line[3]!=='-')break;}
 if(!in_array((int)substr($last,0,3),$expected,true))throw new DomainException(mail3644_error($phase,(int)substr($last,0,3)));
}
function mail3644_command($s,string $line,array $expected,string $phase):void {$wire=$line."\r\n";$off=0;while($off<strlen($wire)){$n=fwrite($s,substr($wire,$off));if($n===false||$n===0)throw new DomainException(mail3644_error($phase));$off+=$n;}mail3644_reply($s,$expected,$phase);}
function mail3644_safe_error(Throwable $e):string {
 $message=$e->getMessage();if($e instanceof DomainException&&(str_starts_with($message,'SMTP')||in_array($message,['E-posta gönderimi yapılandırılmayı bekliyor.','E-posta ayarları geçersiz.','SMTP bağlantısı kurulamadı.','SMTP güvenli bağlantısı kurulamadı.','E-posta sunucusuna ileti tamamlanamadı.'],true)))return mb_substr($message,0,250);
 return 'E-posta gönderimi tamamlanamadı. SMTP denemesini yönetimden çalıştırın.';
}
