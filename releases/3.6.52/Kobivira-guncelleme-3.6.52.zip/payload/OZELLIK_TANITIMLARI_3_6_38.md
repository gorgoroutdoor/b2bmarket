# Kobivira 3.6.38 — Özellik sayfalarına hazır kodlu tanıtımlar

Bu paket 3.6.37 üzerine yüklenir. Yönetim panelindeki **Sistem → Sürüm güncellemeleri** alanından imzalı ZIP dosyasını yükleyin. Dosyayı açıp PHP dosyalarını tek tek kopyalamanız gerekmez.

## Yüklemeden sonra

Özellik kataloğundaki 50 sayfanın tanıtım alanları otomatik olarak kendi konusuna uygun HTML/CSS kartlarıyla açılır. Her sayfanın başlığı, örnek tablo kayıtları ve iki özet kartı hazırdır. Resim hazırlama, yükleme veya 50 sayfayı tek tek etkinleştirme işlemi gerekmez. Sayfa başlıkları, kayıt formları, rehber bağlantıları, paket kapsamı ve mevcut ana sayfa korunur.

Bu alanlar gerçek firma verisi çekmez. Ziyaretçiye işlevi anlatan temsili örneklerdir; altında “Örnek verilerle temsili görünüm” yazısı bulunur. Firma panelinin ekran görüntüsü veya canlı işlem sonucu olarak sunulmaz. E-Belge alanlarının bu şekilde gösterilmesi firma aktivasyonu, kontör veya sağlayıcı işlemi başlatmaz. Kapalı özellikler etkinleştirilmez; mevcut görünürlük kuralları korunur.

## İleride düzenlemek isterseniz

Yönetici oturumuyla ilgili sayfayı açın. Tanıtım alanının üzerindeki **Düzenle** bağlantısına basın. Doğrudan bu sayfanın **Tanıtım alanı** bölümüne gidersiniz.

- Varsayılan seçim: **Kodlu tasarım · resim yüklemek gerekmez**.
- **Tanıtım alanındaki metinleri ve örnek kayıtları düzenle** bölümünde başlık, açıklama, tablo ve özet kartlarının metinlerini değiştirebilirsiniz. Tutarlar örnek düz metindir; değiştirdiğiniz toplamların tutarlılığını kontrol edin.
- **Bu sayfanın örnek metinlerini varsayılana döndür** kutusu yalnız bu sayfanın örnek metinlerini sıfırlar.
- Daha önce yüklenmiş resimler silinmez. **Yüklediğim görseli kullan** seçeneğiyle mevcut görsele dönebilirsiniz. Tekrar kodlu tasarımı seçmek görsel dosyasını silmez.

Bu değişiklikler yalnız Kobivira platform yöneticisinin ana site yetkisiyle kaydedilir. Firma yöneticisi, ziyaretçi veya başka site hesabı bu alanları değiştiremez. Metinler HTML olarak çalıştırılmaz. Mevcut CSRF, işlem ve içerik sürüm denetimleri kullanılmaya devam eder.

## Kontroller

İzole veritabanında imzalı 3.6.37 → 3.6.38 güncellemesi, 370 PHP/veritabanı kontrolü ve 200 HTTP sayfa kontrolü başarılıdır. Kontroller 50 sayfanın kendi tanıtımını, kayıt formunu ve rehberini; metin kaydetme/sıfırlama, yetkisiz yazmayı engelleme, metin kaçışını ve mevcut görsellerin korunmasını kapsar. Kullanıcı, firma, abonelik, paket, ödeme, kontör ve hukuk kayıtlarının değişmediği doğrulanmıştır.

Mobil yerleşim dar alanda tabloyu tam genişlikte, özet kartlarını altında gösterecek şekilde kodlanmıştır. Bu oturumda yerel ön izlemeye tarayıcı erişimi sağlanamadığından masaüstü/mobil görsel tarayıcı kontrolü tamamlanamamıştır. Yeni veritabanı göçü veya canlı servis çağrısı yoktur.
