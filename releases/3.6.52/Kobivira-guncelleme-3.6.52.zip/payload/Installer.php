<?php
declare(strict_types=1);
function install_app(): void {
    if(is_file(APP_ROOT.'/config/installed.lock'))throw new DomainException('Kurulum tamamlanmış.');
    $expected=trim((string)file_get_contents(APP_ROOT.'/config/install-token.txt'));
    if(!hash_equals($expected,required_field('install_token',128)))throw new DomainException('Kurulum anahtarı hatalı.');
    $name=required_field('name',100);$email=email_field();$pass=password_field();
    $c=['host'=>required_field('db_host',100),'port'=>int_field('db_port',1,65535),'name'=>required_field('db_name',64),'user'=>required_field('db_user',100),'password'=>is_string($_POST['db_password']??null)?$_POST['db_password']:''];
    foreach(['/config','/storage','/storage/logs','/storage/backups','/storage/staging','/storage/sessions','/releases'] as $dir)if(!is_dir(APP_ROOT.$dir)||!is_writable(APP_ROOT.$dir))throw new DomainException('Uygulama klasörü yazılabilir değil: '.$dir);
    $pdo=connect_db($c);if($pdo->query('SHOW TABLES')->fetchColumn()!==false)throw new DomainException('Yeni kurulum için BOŞ bir veritabanı seçin.');
    (new Migrator($pdo))->run(RELEASE_ROOT.'/migrations');
    $q=$pdo->prepare("INSERT INTO users(name,email,password_hash,role,created_at) VALUES (?,?,?,'platform_admin',UTC_TIMESTAMP())");$q->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);
    atomic_write(APP_ROOT.'/config/app.php',"<?php\nreturn ".var_export(['database'=>$c,'app_key'=>bin2hex(random_bytes(32))],true).";\n");
    atomic_write(APP_ROOT.'/config/installed.lock',gmdate('c'));@unlink(APP_ROOT.'/config/install-token.txt');flash('Kurulum tamamlandı. Platform yöneticisi hesabınızla giriş yapın.');redirect('login');
}
