# 3.6.49 — Sabit cron ve güncelleme saklama politikası

3.6.48 üzerine imzalı güncellemedir. Yeni 054 migration uygulamanın özel kurulum köküne KobiviraCron.php sabit giriş dosyasını oluşturur. Daha eski migration dosyaları değiştirilmez.

## Kurulumdan sonra bir kez

cPanel Cron Jobs içindeki mevcut görevde yalnız komutu değiştirin; yeni bir kopya görev eklemeyin:

```
/usr/local/bin/php '/home/kobiviracom/kobivira-private/saas/KobiviraCron.php' --run
```

Bu dosya current.json üzerinden çalışan sürümün BackupCli367.php dosyasını bulur. Sonraki sürümlerde komuttaki yol değişmez. Günlük yedek etkinliği ve e-belge kuyruğu mevcut ayarlarıyla çalışır. --tasks seçeneği aynı sabit dosyadan SchedulerCli.php işlerini çalıştırır; bu seçim otomatik yeni cron görevi oluşturmaz.

Yönetim → Sistem → Güncellemeler içindeki “Güncelleme yedekleri ve disk kullanımı” bölümünü açın. cPanel görevlerindeki bütün eski releases yollarını sabit dosyaya taşıdıktan sonra onay kutusunu ve mevcut yönetici şifrenizi kullanarak eski sürüm temizliğini açın. Bu onaydan önce sürüm klasörleri otomatik kaldırılmaz. Sabit dosyanın içeriği beklenen dosyayla aynı değilse sürüm temizliği yapılmaz.

## Neler korunur?

- Çalışan sürüm her zaman korunur.
- En son 10 başarılı, kayıtlı ve mevcut güncelleme yedeği korunur.
- Korunan yedeklerin geri dönüş için ihtiyaç duyduğu önceki sürümler ve ilgili sürümler korunur. Normal ardışık güncellemelerde bu, güncel sürüm dahil yaklaşık 11 klasördür. Kurulum geçmişine göre sayı değişebilir.
- Başarısız veya yarım kalan güncellemelerin mevcut kurtarma dosyaları ayrıca korunur; bu istisnada toplam 10'dan fazla dosya kalabilir.
- Şifreli günlük tam sistem yedekleri mevcut ayrı saklama ayarını kullanır. Tanınmayan veya güncelleme kayıtlarıyla ilişkisiz dosyalar otomatik silinmez.
- Firma veritabanı, evraklar, yüklenen görseller, e-posta kutuları, ayarlar ve anahtarlar bu temizlikle silinmez.

## Neler temizlenir?

İlk kurulumdan sonra ve sonraki başarılı güncellemelerden sonra saklama kontrolü sıraya alınır. Yönetimin güncelleme ekranı veya mevcut CLI görevi kontrolü çalıştırır. Eski kayıtlı güncelleme yedekleri 10 adet saklama kuralına göre kaldırılır. Cron geçişi onaylandıktan sonra korunması gerekmeyen, sürüm biçimindeki eski releases klasörleri de kaldırılır. Bu eski kopyalar kalıcı olarak kaldırılır; bu noktalara geri dönüş yapılamaz. Sürüm geçmişi kaydı korunur.

Bir turda ayrılan işlem süresi dolarsa temizlik beklemede kalır; yönetimde “Eski dosya temizliğini sürdür” düğmesiyle veya cronun sonraki çalışmasıyla devam eder. Bakım veya kilit çakışması varsa dosya temizliği yapılmaz. Disk tablosunda uzun süren ölçümün kısmi kaldığı açıkça belirtilir.

## Güncelleme biçimi

Paket hâlâ tam uygulama dosyalarını taşır ve ayrı sürüm klasörüne kurulur; bu güvenli geçiş/geri dönüş düzeni korunur. Firma veritabanı sıfırlanmaz; yalnız yeni migration uygulanır. Diskte sınırsız eski paket birikmesi saklama politikasıyla önlenir. Fark paketi veya dosya bazlı indirme bu sürümde yapılmamıştır.

Gerçek hostingte cron değişikliği ve temizlik çalışması kullanıcı tarafından kurulumdan sonra yapılmalıdır. Bu geliştirme sırasında sunucuya erişilmedi veya gerçek yedek silinmedi.
