# 3.6.9 — e-İrsaliye test alanı

EDM test alanındaki e-İrsaliye düğmesi ayrı servisi açar. Aynı firmanın şifreli EDM hesabı kullanılır; her dış bağlantıda e-Fatura servisinden tek VKN eşleşmesi tekrar doğrulanıp e-İrsaliye servisinde ayrı oturum açılır. APPLICATION_NAME daima Kobivira'dır. Endpoint sabit olarak https://test.edmbilisim.com.tr/EFaturaEDM21ea/EIrsaliyeEDM.svc adresidir; canlı yönlendirme ve otomatik belge yeniden gönderimi yoktur.

## Kullanım

1. 3.6.8 üzerine imzalı güncellemeyi yükleyin.
2. Sistem → EDM test alanı → e-İrsaliye test alanını aç; firmayı seçin.
3. e-İrsaliye bağlantısını ve etiketleri kontrol et düğmesine bir kez basın.
4. Örnek e-İrsaliye hazırla düğmesi EDM 3230512384 test firmasından aynı firmaya güncel tarihli, KVI serili, yeni UUID'li dört satırlı bir XML hazırlar. Bu adım dışarı belge göndermez. Örnekteki sevkiyat ve kişi bilgileri test içindir, gerçek sevkiyatta kullanılmaz. Aynı oturumda kendi XML'inizi de yükleyebilirsiniz.
5. GB ve PK etiketlerini seçin; varsayılan EDM etiketleri mevcutsa önceden seçilir. Onay kutusunu işaretleyip Test irsaliyesini EDM'ye gönder düğmesine bir kez basın.
6. Aynı belge için en az 30 saniye arayla durum sorgulayın. Gönderim yanıtı yalnız kuyruğa alınmayı gösterebilir; başarıyla gönderildiğini söylemek için son servis/GİB durumlarını doğrulayın.
7. Listeye dönüp en fazla 7 günlük aralıkta gelen test irsaliyelerini getirin. IN kaydını açıp durumu ve gerçek EDM PDF/XML indirmesini kontrol edin.

Gönderim denemesi servisten önce kalıcı kaydedilir. Zaman aşımı veya belirsiz hata olursa aynı belge yeniden gönderilmez; UUID ile teknik inceleme gerekir. Yanlış etiket veya mükellefiyet halinde e-Arşiv irsaliyeye kendiliğinden çevrilmez. İrsaliye satırlarını stok/muhasebe hareketine veya yerel kontör defterine işlemez.

## Kapsam ve yetki

Bu sürüm gönderme, alma, durum/GİB yanıt alanları ve PDF/XML indirme testlerini kapsar. Kabul/ret/kısmi kabul yanıtı henüz bu ekranda sunulmaz; sonraki adımdır. Normal firma e-belge taslağını otomatik resmî irsaliyeye dönüştürmez. Canlıya hazır olduğu iddia edilmez. Firma tarafı ücretli advanced_edocs yetkisi ister; Plus için bu alan açılmaz, Business veya yetkisi tanımlanmış firmalar kullanabilir. Platform yöneticisi firma seçerek test edebilir. Destek/izleme oturumları kapalıdır.

## Veri ve kurulum

Mevcut 34 migration değişmedi. 035 ile firma/yön/UUID ve firma/yön/numara benzersizliğine sahip ayrı test tablosu eklenir. Payload şifreli tutulur; XML DTD/ENTITY engeli, kimlik/firma/senaryo kontrolleri, PDF imzası kontrolü, 8 MB indirme ve 2 MB yükleme sınırları vardır. Tek UUID ile farklı içerik gelirse kayıt üzerine yazılmaz. Silme ve tam yedekleme kapsamına yeni tablo dahildir. CSS/tasarım dosyaları değişmez.

Kaynaklar: gönderilen E-İrsaliye Teknik Doküman.zip içindeki API v4.1.1 ve Request-Response belgeleri; Irsaliye-Ornek1.xml; gönderilen endpoint listesi; test servisinden alınan singleWsdl. Oluşturulan SOAP istekleri güncel WSDL şemasına karşı doğrulandı. Kullanıcının mevcut e-Arşiv testi KVA2026000000001 için CANCELLED - SUCCEED ekranı doğrulandı; GİB iptal raporunun tamamlandığı ayrıca doğrulanmalıdır.
