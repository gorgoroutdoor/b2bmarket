<?php
declare(strict_types=1);
return function(PDO $db): void {
 $catalog=json_decode(file_get_contents(dirname(__DIR__).'/Guide360.json'),true,64,JSON_THROW_ON_ERROR);
 if(($catalog['version']??'')!=='3.6.0'||count($catalog['guides']??[])!==77)throw new RuntimeException('Kütüphane içerik kataloğu doğrulanamadı.');
 $owns=!$db->inTransaction();if($owns)$db->beginTransaction();
 try{
  foreach($catalog['guides'] as $r){
   if(!preg_match('/^rehber-[a-z0-9-]+$/D',$r['slug'])||$r['category']==='Yönetim'||in_array($r['slug'],['rehber-yonetim','rehber-surumler'],true))throw new RuntimeException('Rehber kapsamı doğrulanamadı.');
   $q=$db->prepare('SELECT * FROM cms_pages WHERE site_id=1 AND slug=? FOR UPDATE');$q->execute([$r['slug']]);$old=$q->fetch(PDO::FETCH_ASSOC);
   if($old){
    // Never repurpose a custom non-guide page or expose a private management guide.
    if($old['kind']!=='guide')throw new RuntimeException('Kütüphane adresi başka içerikte kullanılıyor: '.$r['slug']);
    if($old['category']==='Yönetim')continue;
    $q=$db->prepare("INSERT INTO cms_history(site_id,entity,entity_id,action,snapshot,actor_id,created_at) VALUES (1,'pages',?,'library360',?,0,UTC_TIMESTAMP())");$q->execute([$old['id'],json_encode($old,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);
    // Retain URL, ID, publishing status, custom SEO article, and all unrelated content.
    $q=$db->prepare("UPDATE cms_pages SET title=?,description=?,category=?,plan_level=?,content_html=?,fields='[]',revision=revision+1,updated_at=UTC_TIMESTAMP() WHERE site_id=1 AND id=?");
    $q->execute([$r['title'],$r['description'],$r['category'],$r['level'],$r['content_html'],$old['id']]);
   }else{
    $q=$db->prepare("INSERT INTO cms_pages(site_id,slug,kind,title,description,category,plan_level,content_html,fields,layout,status,seo_article,updated_at) VALUES (1,?,'guide',?,?,?,?,?,'[]','standard','published','',UTC_TIMESTAMP())");$q->execute([$r['slug'],$r['title'],$r['description'],$r['category'],$r['level'],$r['content_html']]);
   }
  }
  if($owns)$db->commit();
 }catch(Throwable $e){if($owns&&$db->inTransaction())$db->rollBack();throw $e;}
};
