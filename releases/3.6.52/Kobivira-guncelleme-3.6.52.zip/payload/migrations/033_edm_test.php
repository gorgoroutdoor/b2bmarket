<?php
declare(strict_types=1);
return function(PDO $db): void {
    $db->exec("CREATE TABLE edm_test_accounts(company_id BIGINT UNSIGNED PRIMARY KEY,tax_number VARCHAR(11) NOT NULL UNIQUE,credentials TEXT NOT NULL,enabled TINYINT NOT NULL DEFAULT 0,checked_at DATETIME NULL,provider_balance VARCHAR(60) NULL,last_result VARCHAR(500) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $db->exec("CREATE TABLE edm_test_documents(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,direction VARCHAR(3) NOT NULL,uuid CHAR(36) NOT NULL,number VARCHAR(60) NOT NULL,profile VARCHAR(60) NOT NULL,payload MEDIUMTEXT NOT NULL,payload_hash CHAR(64) NOT NULL,provider_status VARCHAR(100) NOT NULL,attempted_at DATETIME NULL,response_decision VARCHAR(10) NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,UNIQUE KEY tenant_document(company_id,direction,uuid)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
};
