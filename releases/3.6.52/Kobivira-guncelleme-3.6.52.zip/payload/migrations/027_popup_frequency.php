<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("CREATE TABLE popup_impressions(day DATE NOT NULL,visitor_hash CHAR(64) NOT NULL,views INT UNSIGNED NOT NULL DEFAULT 0,last_shown DATETIME NULL,PRIMARY KEY(day,visitor_hash)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
};
