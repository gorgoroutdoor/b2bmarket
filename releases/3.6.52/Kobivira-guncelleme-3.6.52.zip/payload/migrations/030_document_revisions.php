<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("CREATE TABLE document_revisions(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,parent_id BIGINT UNSIGNED NOT NULL,document_id BIGINT UNSIGNED NOT NULL,change_share_id BIGINT UNSIGNED NOT NULL,source_fingerprint CHAR(64) NOT NULL,request_key CHAR(32) NOT NULL,created_by BIGINT UNSIGNED NOT NULL,created_at DATETIME NOT NULL,published_at DATETIME NULL,UNIQUE KEY(company_id,document_id),UNIQUE KEY(company_id,request_key),KEY(company_id,parent_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
};
