<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("ALTER TABLE contacts ADD contact_person VARCHAR(100) NOT NULL DEFAULT '',ADD tax_office VARCHAR(100) NOT NULL DEFAULT ''");
 $db->exec('ALTER TABLE documents ADD contact_snapshot TEXT NULL');
 $db->exec("UPDATE documents d JOIN contacts c ON c.company_id=d.company_id AND c.id=d.contact_id SET d.contact_snapshot=JSON_OBJECT('name',c.name,'tax_number',c.tax_number,'tax_office',c.tax_office,'address',COALESCE(c.address,''),'contact_person',c.contact_person,'phone',c.phone,'email',c.email)");
 $db->exec('CREATE TABLE release_notes(version VARCHAR(24) PRIMARY KEY,content MEDIUMTEXT NOT NULL,created_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
 require_once __DIR__.'/../ReleaseHistory.php';sync_release_catalog($db,__DIR__.'/../release_history.json');
};
