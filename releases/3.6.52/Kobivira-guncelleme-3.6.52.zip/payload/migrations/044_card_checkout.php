<?php
declare(strict_types=1);
return function(PDO $db):void {
 $db->exec("ALTER TABLE payment_orders ADD payment_method VARCHAR(12) NOT NULL DEFAULT 'transfer'");
 $db->exec("CREATE TABLE gateway_payments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,membership_order_id BIGINT UNSIGNED NULL,credit_order_id BIGINT UNSIGNED NULL,order_kind VARCHAR(20) NOT NULL,provider VARCHAR(20) NOT NULL DEFAULT 'paytr',mode VARCHAR(12) NOT NULL,amount BIGINT UNSIGNED NOT NULL,currency CHAR(3) NOT NULL DEFAULT 'TL',merchant_oid VARCHAR(64) NOT NULL UNIQUE,
 credential_cipher TEXT NOT NULL,token_cipher TEXT NULL,status VARCHAR(20) NOT NULL DEFAULT 'created',detail VARCHAR(500) NOT NULL DEFAULT '',callback_status VARCHAR(10) NULL,callback_amount BIGINT UNSIGNED NULL,callback_count INT UNSIGNED NOT NULL DEFAULT 0,callback_conflict TINYINT UNSIGNED NOT NULL DEFAULT 0,callback_at DATETIME NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,
 UNIQUE KEY membership_attempt(membership_order_id),UNIQUE KEY credit_attempt(credit_order_id),KEY company_created(company_id,id),FOREIGN KEY(company_id) REFERENCES companies(id),FOREIGN KEY(membership_order_id) REFERENCES payment_orders(id),FOREIGN KEY(credit_order_id) REFERENCES credit_orders(id)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
};
