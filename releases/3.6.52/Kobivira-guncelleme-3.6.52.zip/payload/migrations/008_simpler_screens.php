<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("ALTER TABLE tasks ADD status VARCHAR(16) NOT NULL DEFAULT 'open',ADD category VARCHAR(24) NOT NULL DEFAULT 'general',ADD description TEXT NULL,ADD updated_at DATETIME NULL,ADD closed_at DATETIME NULL,ADD completed_at DATETIME NULL,ADD INDEX tasks_status_due(company_id,status,due_date)");
 $db->exec("UPDATE tasks SET status=CASE WHEN done=1 THEN 'completed' ELSE 'open' END");
 $db->exec('ALTER TABLE subscriptions ADD period_started_at DATETIME NULL');
 // Past payments establish activation dates, not an exact current-period start.
 // Unknown historical paid starts deliberately remain NULL rather than invented.
 if(!function_exists('sync_release_catalog'))require_once __DIR__.'/../ReleaseHistory.php';sync_release_catalog($db,__DIR__.'/../release_history.json');
};
