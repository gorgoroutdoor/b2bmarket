<?php
declare(strict_types=1);
return function(PDO $db):void {
 $db->exec("ALTER TABLE registration_email_checks ADD last_error VARCHAR(300) NOT NULL DEFAULT ''");
 $db->exec("ALTER TABLE users ADD login_mobile VARCHAR(10) NOT NULL DEFAULT '',ADD login_mobile_verified_number VARCHAR(10) NULL,ADD login_mobile_verified_at DATETIME NULL,ADD login_mobile_test_verified_at DATETIME NULL,ADD registration_mobile_required TINYINT UNSIGNED NOT NULL DEFAULT 0");
 $db->exec("CREATE TABLE account_mobile_codes(user_id BIGINT UNSIGNED NOT NULL,purpose VARCHAR(16) NOT NULL,phone VARCHAR(10) NOT NULL,mode VARCHAR(8) NOT NULL,ticket_hash CHAR(64) NOT NULL,code_hash VARCHAR(255) NOT NULL,test_cipher TEXT NULL,expires_at DATETIME NOT NULL,requested_at DATETIME NOT NULL,window_start DATETIME NOT NULL,send_count INT UNSIGNED NOT NULL,attempts INT UNSIGNED NOT NULL DEFAULT 0,send_state VARCHAR(16) NOT NULL DEFAULT 'pending',PRIMARY KEY(user_id,purpose),UNIQUE KEY mobile_ticket(ticket_hash),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("INSERT IGNORE INTO settings(name,value) VALUES ('mobile3644_config','{\"mode\":\"off\",\"test_company\":0,\"test_phone\":\"\"}')");
};
