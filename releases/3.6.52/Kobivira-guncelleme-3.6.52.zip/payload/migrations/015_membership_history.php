<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("ALTER TABLE subscriptions ADD has_paid_membership TINYINT NOT NULL DEFAULT 0");
 $db->exec("UPDATE subscriptions s SET has_paid_membership=1 WHERE s.status='active' OR s.paid_until IS NOT NULL OR s.period_started_at IS NOT NULL OR EXISTS(SELECT 1 FROM payment_orders p WHERE p.company_id=s.company_id AND p.status='approved')");
};
