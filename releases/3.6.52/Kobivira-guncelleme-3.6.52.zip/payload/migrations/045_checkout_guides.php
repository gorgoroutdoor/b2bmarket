<?php
declare(strict_types=1);
return function(PDO $db):void {
 $guides=json_decode(file_get_contents(dirname(__DIR__).'/Guide3624Update.json'),true,32,JSON_THROW_ON_ERROR);$db->beginTransaction();
 try{foreach($guides as $g){$q=$db->prepare("SELECT * FROM cms_pages WHERE site_id=1 AND slug=? AND kind='guide' FOR UPDATE");$q->execute([$g['slug']]);$old=$q->fetch(PDO::FETCH_ASSOC);if(!$old)continue;$q=$db->prepare("INSERT INTO cms_history(site_id,entity,entity_id,action,snapshot,actor_id,created_at) VALUES (1,'pages',?,'checkout3624',?,0,UTC_TIMESTAMP())");$q->execute([$old['id'],json_encode($old,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);$q=$db->prepare('UPDATE cms_pages SET title=?,description=?,content_html=?,revision=revision+1,updated_at=UTC_TIMESTAMP() WHERE id=? AND site_id=1');$q->execute([$g['title'],$g['title'],$g['content_html'],$old['id']]);}$db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
};
