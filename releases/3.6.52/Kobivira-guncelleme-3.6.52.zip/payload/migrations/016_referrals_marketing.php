<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("ALTER TABLE companies ADD public_metrics_included TINYINT NOT NULL DEFAULT 0");
 $db->exec("CREATE TABLE referral_codes(company_id BIGINT UNSIGNED PRIMARY KEY,code CHAR(16) UNIQUE NOT NULL,created_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("CREATE TABLE referral_links(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,referrer_company_id BIGINT UNSIGNED NOT NULL,code CHAR(16) NOT NULL,status VARCHAR(16) NOT NULL DEFAULT 'pending',reason VARCHAR(300) NOT NULL DEFAULT '',created_at DATETIME NOT NULL,UNIQUE KEY referred_company(company_id),KEY referrer(referrer_company_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("CREATE TABLE referral_rewards(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,referred_company_id BIGINT UNSIGNED NOT NULL,referral_id BIGINT UNSIGNED UNIQUE NOT NULL,payment_order_id BIGINT UNSIGNED UNIQUE NOT NULL,days INT NOT NULL,applied_at DATETIME NULL,created_at DATETIME NOT NULL,KEY company_rewards(company_id,applied_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 foreach(['public_metrics_enabled'=>'0','marketing_video_url'=>'','referral_enabled'=>'1','referral_reward_days'=>'30'] as $k=>$v){$q=$db->prepare('INSERT IGNORE INTO settings(name,value) VALUES (?,?)');$q->execute([$k,$v]);}
};
