<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("ALTER TABLE verification_documents ADD review_status VARCHAR(24) NOT NULL DEFAULT 'pending',ADD review_note VARCHAR(1000) NOT NULL DEFAULT '',ADD reviewed_by BIGINT UNSIGNED NULL,ADD reviewed_at DATETIME NULL,ADD review_revision INT UNSIGNED NOT NULL DEFAULT 0");
 // Retain only approvals for exact document versions in an approved historical snapshot.
 // Never approve every upload merely because its company was once approved.
 $rs=$db->query("SELECT * FROM verification_requests WHERE status='approved' AND reviewed_by IS NOT NULL AND reviewed_at IS NOT NULL ORDER BY reviewed_at,id")->fetchAll(PDO::FETCH_ASSOC);
 $q=$db->prepare("UPDATE verification_documents SET review_status='approved',reviewed_by=?,reviewed_at=?,review_revision=1 WHERE company_id=? AND id=? AND sha256=? AND review_status='pending'");
 foreach($rs as $r){$s=json_decode($r['snapshot'],true);if(!is_array($s)||!is_array($s['documents']??null))continue;foreach($s['documents'] as $d){if(!is_array($d)||!isset($d['id'],$d['sha256'])||!preg_match('/^[a-f0-9]{64}$/D',(string)$d['sha256']))continue;$q->execute([$r['reviewed_by'],$r['reviewed_at'],$r['company_id'],(int)$d['id'],$d['sha256']]);}}
 if(!function_exists('sync_release_catalog'))require_once __DIR__.'/../ReleaseHistory.php';sync_release_catalog($db,__DIR__.'/../release_history.json');
};
