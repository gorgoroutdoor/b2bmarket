<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("ALTER TABLE companies ADD bank_account_name VARCHAR(160) NOT NULL DEFAULT '',ADD bank_name VARCHAR(160) NOT NULL DEFAULT '',ADD bank_account_holder VARCHAR(160) NOT NULL DEFAULT '',ADD bank_iban VARCHAR(34) NOT NULL DEFAULT '',ADD bank_branch VARCHAR(160) NOT NULL DEFAULT ''");
 $db->exec('ALTER TABLE documents ADD discount_total BIGINT NOT NULL DEFAULT 0,ADD bank_snapshot TEXT NULL');
 $db->exec('ALTER TABLE document_lines ADD discount_rate INT NOT NULL DEFAULT 0,ADD discount_amount BIGINT NOT NULL DEFAULT 0');
 if(!function_exists('sync_release_catalog'))require_once __DIR__.'/../ReleaseHistory.php';sync_release_catalog($db,__DIR__.'/../release_history.json');
};
