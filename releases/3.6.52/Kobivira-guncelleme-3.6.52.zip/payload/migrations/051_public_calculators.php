<?php
declare(strict_types=1);
return function(PDO $db):void {
 $pages=json_decode(file_get_contents(dirname(__DIR__).'/Tools3639Pages.json'),true,32,JSON_THROW_ON_ERROR);$db->beginTransaction();try{
 foreach($pages as $p){$q=$db->prepare('SELECT id FROM cms_pages WHERE site_id=1 AND slug=? FOR UPDATE');$q->execute([$p['slug']]);if($q->fetchColumn())continue;
 $q=$db->prepare("INSERT INTO cms_pages(site_id,slug,kind,title,description,category,content_html,fields,layout,status,seo_article,updated_at) VALUES (1,?,'page',?,?,'Araçlar',?,?,'standard','published','',UTC_TIMESTAMP())");$q->execute([$p['slug'],$p['title'],$p['description'],$p['html'],json_encode($p['fields'],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);
 }
 $nav=function(string $scope,string $label,string $url,int $order)use($db):void{$q=$db->prepare('SELECT id FROM cms_nav WHERE site_id=1 AND scope=? AND url=? FOR UPDATE');$q->execute([$scope,$url]);if(!$q->fetchColumn()){$q=$db->prepare('INSERT INTO cms_nav(site_id,scope,label,url,sort_order,is_visible) VALUES (1,?,?,?,?,1)');$q->execute([$scope,$label,$url,$order]);}};
 $nav('header','Araçlar','araclar.html',25);$nav('footer_resources','Hesaplama araçları','araclar.html',35);
 $items=json_decode(file_get_contents(dirname(__DIR__).'/Tools3639Catalog.json'),true,32,JSON_THROW_ON_ERROR);foreach($items as $i=>$item)$nav('tools',$item['title'],$item['slug'].'.html',($i+1)*10);
 $db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
};
