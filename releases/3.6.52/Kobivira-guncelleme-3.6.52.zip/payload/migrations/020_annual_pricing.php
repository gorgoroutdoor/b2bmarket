<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("CREATE TABLE payment_pricing (payment_order_id BIGINT UNSIGNED PRIMARY KEY,months INT NOT NULL,monthly_net BIGINT NOT NULL,base_net BIGINT NOT NULL,discount_basis_points INT NOT NULL,discount_amount BIGINT NOT NULL,created_at DATETIME NOT NULL,FOREIGN KEY(payment_order_id) REFERENCES payment_orders(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $changes=json_decode(file_get_contents(dirname(__DIR__).'/site/PricingCopy.json'),true,32,JSON_THROW_ON_ERROR);
 $actor=(int)$db->query("SELECT id FROM users WHERE role='platform_admin' ORDER BY id LIMIT 1")->fetchColumn();
 $db->beginTransaction();try{foreach($changes as $change){
  $q=$db->prepare('SELECT * FROM cms_pages WHERE site_id=1 AND slug=? FOR UPDATE');$q->execute([$change['slug']]);$row=$q->fetch(PDO::FETCH_ASSOC);if(!$row)continue;
  $fields=json_decode($row['fields'],true,32,JSON_THROW_ON_ERROR);$key=$change['field'];if(($fields[$key]['value']??null)!==$change['old'])continue;
  $q=$db->prepare("INSERT INTO cms_history(site_id,entity,entity_id,action,snapshot,actor_id,created_at) VALUES (1,'pages',?,'release_3_4_6',?,?,UTC_TIMESTAMP())");$q->execute([$row['id'],json_encode($row,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$actor]);
  $fields[$key]['value']=$change['new'];$q=$db->prepare('UPDATE cms_pages SET fields=?,revision=revision+1,updated_at=UTC_TIMESTAMP() WHERE id=? AND site_id=1');$q->execute([json_encode($fields,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$row['id']]);
 }$db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
};
