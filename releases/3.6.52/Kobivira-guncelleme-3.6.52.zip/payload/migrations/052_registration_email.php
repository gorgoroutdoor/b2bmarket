<?php
declare(strict_types=1);
return function(PDO $db):void {
 $db->exec("ALTER TABLE users ADD registration_email_required TINYINT UNSIGNED NOT NULL DEFAULT 0, ADD registration_email_verified_at DATETIME NULL, ADD registration_email_verified_address VARCHAR(190) NULL");
 $db->exec("CREATE TABLE registration_email_checks (user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,email VARCHAR(190) NOT NULL,token_hash CHAR(64) NOT NULL,expires_at DATETIME NOT NULL,requested_at DATETIME NOT NULL,last_sent_at DATETIME NULL,last_result VARCHAR(24) NOT NULL DEFAULT 'pending',window_start DATETIME NOT NULL,send_count INT UNSIGNED NOT NULL DEFAULT 1,UNIQUE KEY registration_email_token(token_hash),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("INSERT IGNORE INTO settings(name,value) VALUES ('registration_email_verify3643','1')");
 $host=$db->query("SELECT value FROM settings WHERE name='delivery_smtp_host'")->fetchColumn();
 if($host===false||trim((string)$host)===''){$q=$db->prepare('INSERT INTO settings(name,value) VALUES (?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)');foreach(['smtp_host'=>'mail.kobivira.com.tr','smtp_port'=>'465','smtp_mode'=>'ssl','smtp_user'=>'info@kobivira.com.tr','smtp_from'=>'info@kobivira.com.tr'] as $k=>$v)$q->execute(['delivery_'.$k,$v]);}
};
