<?php
declare(strict_types=1);
return function(PDO $db):void {
 $rows=json_decode(file_get_contents(dirname(__DIR__).'/Legal3630Seed.json'),true,32,JSON_THROW_ON_ERROR);$db->beginTransaction();try{
 foreach($rows as $r){
  $q=$db->prepare('SELECT * FROM cms_pages WHERE site_id=1 AND slug=? FOR UPDATE');$q->execute([$r['slug']]);$page=$q->fetch(PDO::FETCH_ASSOC);
  $q=$db->prepare('SELECT * FROM legal_pages WHERE doc_key=?');$q->execute([$r['key']]);$registered=$q->fetch(PDO::FETCH_ASSOC);if(!$registered){$q=$db->prepare('INSERT INTO legal_pages(doc_key,title,created_at) VALUES (?,?,UTC_TIMESTAMP())');$q->execute([$r['key'],$page['title']??$r['title']]);}
  $q=$db->prepare('SELECT * FROM legal_versions WHERE doc_key=? AND is_published=1 ORDER BY id DESC LIMIT 1');$q->execute([$r['key']]);$v=$q->fetch(PDO::FETCH_ASSOC);
  if(!$v&&!($registered['archived']??false)){$html=$page['content_html']??$r['html'];foreach(json_decode($page['fields']??'[]',true)??[] as $k=>$field)$html=str_replace('{{field:'.$k.'}}',htmlspecialchars((string)$field['value'],ENT_QUOTES,'UTF-8'),$html);$q=$db->prepare('INSERT INTO legal_versions(doc_key,title,content_html,is_published,created_by,created_at,published_at) VALUES (?,?,?,1,NULL,UTC_TIMESTAMP(),UTC_TIMESTAMP())');$q->execute([$r['key'],$page['title']??$r['title'],$html]);$v=['title'=>$page['title']??$r['title'],'content_html'=>$html];}
  if(!$page){$q=$db->prepare("INSERT INTO cms_pages(site_id,slug,kind,title,description,category,content_html,fields,status,seo_article,updated_at) VALUES (1,?,'page',?,?,'Sözleşmeler ve Politikalar',?,'[]',?,'',UTC_TIMESTAMP())");$q->execute([$r['slug'],$v['title']??$r['title'],$r['title'],'<section class="wrap prose"><h1>'.htmlspecialchars($v['title']??$r['title'],ENT_QUOTES,'UTF-8').'</h1>'.($v['content_html']??$r['html']).'</section>',$v?'published':'draft']);}
  $q=$db->prepare("SELECT id FROM cms_nav WHERE site_id=1 AND url=? AND scope LIKE 'footer_%' LIMIT 1");$q->execute([$r['slug'].'.html']);if(!$q->fetchColumn()){$q=$db->prepare("INSERT INTO cms_nav(site_id,scope,label,url,sort_order,is_visible) VALUES (1,'footer_legal',?,?,?,?)");$q->execute([$r['title'],$r['slug'].'.html',10+array_search($r,$rows,true)*10,$v?1:0]);}
 }
 foreach(['footer_product_title'=>'Ürün ve Hizmetler','footer_resources_title'=>'Kaynaklar','footer_legal_title'=>'Sözleşmeler ve Politikalar','footer_company_title'=>'Kurumsal','instagram_url'=>'https://www.instagram.com/kobivira/','facebook_url'=>'https://www.facebook.com/kobivira/','footer_social_enabled'=>'1','footer_payments_enabled'=>'1'] as $k=>$v){$q=$db->prepare('INSERT IGNORE INTO cms_settings(site_id,name,value) VALUES (1,?,?)');$q->execute([$k,$v]);}
 $db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
};
