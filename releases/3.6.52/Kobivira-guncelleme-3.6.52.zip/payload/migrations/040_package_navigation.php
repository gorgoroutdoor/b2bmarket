<?php
declare(strict_types=1);
return function(PDO $db): void {
 // Initialize once from the prior catalogue. Existing prices, limits, grants and records are untouched.
 $catalog=require dirname(__DIR__).'/PackageDefaults3616.php';$mods=$db->query("SELECT value FROM settings WHERE name='module_access_351'")->fetchColumn();$mods=json_decode($mods===false?'{}':$mods,true)?:[];
 foreach($catalog as $code=>&$keys)foreach(['website','meta_ads','google_ads'] as $module){$plans=$mods[$module]['plans']??['business'];if(in_array($code,$plans,true))$keys[]=$module;}unset($keys);
 $q=$db->prepare("INSERT IGNORE INTO settings(name,value) VALUES ('plan_features_3616',?)");$q->execute([json_encode(['revision'=>0,'plans'=>$catalog],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);
 $data=json_decode(file_get_contents(dirname(__DIR__).'/Guide3616Update.json'),true,64,JSON_THROW_ON_ERROR);
 $owns=!$db->inTransaction();if($owns)$db->beginTransaction();
 try{foreach($data['guides'] as $g){
  $q=$db->prepare('SELECT * FROM cms_pages WHERE site_id=1 AND slug=? FOR UPDATE');$q->execute([$g['slug']]);$old=$q->fetch(PDO::FETCH_ASSOC);
  if($old){if($old['kind']!=='guide'||$old['category']==='Yönetim')continue;
   $q=$db->prepare("INSERT INTO cms_history(site_id,entity,entity_id,action,snapshot,actor_id,created_at) VALUES (1,'pages',?,'navigation3616',?,0,UTC_TIMESTAMP())");$q->execute([$old['id'],json_encode($old,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);
   $q=$db->prepare('UPDATE cms_pages SET title=?,description=?,category=?,content_html=?,revision=revision+1,updated_at=UTC_TIMESTAMP() WHERE site_id=1 AND id=?');$q->execute([$g['title'],$g['description'],$g['category'],$g['content_html'],$old['id']]);
  }else{$q=$db->prepare("INSERT INTO cms_pages(site_id,slug,kind,title,description,category,plan_level,content_html,fields,layout,status,seo_article,updated_at) VALUES (1,?,'guide',?,?,?,?,?,'[]','standard','published','',UTC_TIMESTAMP())");$q->execute([$g['slug'],$g['title'],$g['description'],$g['category'],$g['level'],$g['content_html']]);}
 }if($owns)$db->commit();}catch(Throwable $e){if($owns&&$db->inTransaction())$db->rollBack();throw $e;}
};
