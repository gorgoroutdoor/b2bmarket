<?php
declare(strict_types=1);
return function(PDO $db): void {
 // Backfill only explicit revision relationships published by 3.5.8; never guess unrelated copies.
 $db->exec("UPDATE documents d JOIN document_revisions r ON r.company_id=d.company_id AND r.parent_id=d.id SET d.status='superseded' WHERE r.published_at IS NOT NULL AND d.status='approved' AND d.kind IN ('quote','proforma','order')");
 $db->exec("UPDATE record_shares s JOIN document_revisions r ON r.company_id=s.company_id AND r.parent_id=s.document_id SET s.revoked_at=COALESCE(s.revoked_at,UTC_TIMESTAMP()) WHERE r.published_at IS NOT NULL");
};
