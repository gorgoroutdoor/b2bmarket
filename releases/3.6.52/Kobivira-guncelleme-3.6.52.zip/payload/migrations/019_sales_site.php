<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("CREATE TABLE cms_reviews(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,site_id BIGINT UNSIGNED NOT NULL,display_name VARCHAR(100) NOT NULL,company_name VARCHAR(180) NOT NULL DEFAULT '',person_role VARCHAR(100) NOT NULL DEFAULT '',quote TEXT NOT NULL,source_reference VARCHAR(500) NOT NULL DEFAULT '',consent_confirmed TINYINT NOT NULL DEFAULT 0,customer_verified TINYINT NOT NULL DEFAULT 0,is_published TINYINT NOT NULL DEFAULT 0,sort_order INT NOT NULL DEFAULT 0,revision INT NOT NULL DEFAULT 1,created_by BIGINT UNSIGNED NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,INDEX site_public(site_id,is_published,sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $patch=json_decode(file_get_contents(dirname(__DIR__).'/site/LaunchPatch.json'),true,64,JSON_THROW_ON_ERROR);
 $actor=(int)$db->query("SELECT id FROM users WHERE role='platform_admin' ORDER BY id LIMIT 1")->fetchColumn();
 $fetch=function(string $sql,array $args)use($db){$q=$db->prepare($sql);$q->execute($args);return $q->fetch(PDO::FETCH_ASSOC);};
 $run=function(string $sql,array $args)use($db){$q=$db->prepare($sql);$q->execute($args);};
 $history=function(string $entity,int $id,array $snapshot)use($run,$actor){$run("INSERT INTO cms_history(site_id,entity,entity_id,action,snapshot,actor_id,created_at) VALUES (1,?,?,'release_3_4_1',?,?,UTC_TIMESTAMP())",[$entity,$id,json_encode($snapshot,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$actor]);};
 $db->beginTransaction();try{
 foreach($patch['settings'] as $key=>$change){$r=$fetch('SELECT value FROM cms_settings WHERE site_id=1 AND name=? FOR UPDATE',[$key]);if($r&&$r['value']===$change['old']){$history('settings',0,[$key=>$r['value']]);$run('UPDATE cms_settings SET value=? WHERE site_id=1 AND name=?',[$change['new'],$key]);}}
 foreach(['blocks'=>'block_key','pages'=>'slug'] as $table=>$identity)foreach($patch[$table] as $change){$old=$change['old'];$new=$change['new'];$current=$fetch('SELECT * FROM cms_'.$table.' WHERE site_id=1 AND '.$identity.'=? FOR UPDATE',[$old[$identity]]);if(!$current)continue;$update=[];
  if($change['replace_layout']){foreach(['content_html','fields','title'] as $key)if($current[$key]!==$new[$key])$update[$key]=$new[$key];}
  else{
   foreach(['content_html','title','description'] as $key)if(isset($old[$key],$new[$key],$current[$key])&&$old[$key]!==$new[$key]&&$current[$key]===$old[$key])$update[$key]=$new[$key];
   $fields=json_decode($current['fields'],true,32,JSON_THROW_ON_ERROR);$before=$fields;$original=json_decode($old['fields'],true,32,JSON_THROW_ON_ERROR);$changed=json_decode($new['fields'],true,32,JSON_THROW_ON_ERROR);
   foreach($changed as $key=>$value)if(isset($fields[$key],$original[$key])&&$fields[$key]['value']===$original[$key]['value']&&$original[$key]['value']!==$value['value'])$fields[$key]['value']=$value['value'];
   if($fields!==$before)$update['fields']=json_encode($fields,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
  }
  if($update){$history($table,(int)$current['id'],$current);$run('UPDATE cms_'.$table.' SET '.implode(',',array_map(fn($k)=>$k.'=?',array_keys($update))).',revision=revision+1,updated_at=UTC_TIMESTAMP() WHERE site_id=1 AND id=?',[...array_values($update),$current['id']]);}
 }
 foreach($patch['plans'] as $change){$current=$fetch('SELECT * FROM cms_plans WHERE site_id=1 AND code=? FOR UPDATE',[$change['old']['code']]);if($current&&$current['features']===$change['old']['features']){$history('plans',(int)$current['id'],$current);$run('UPDATE cms_plans SET features=?,revision=revision+1 WHERE site_id=1 AND id=?',[$change['new']['features'],$current['id']]);}}
 foreach($patch['nav'] as $change){$old=$change['old'];$current=$fetch('SELECT * FROM cms_nav WHERE site_id=1 AND scope=? AND url=? FOR UPDATE',[$old['scope'],$old['url']]);if($current&&$current['label']===$old['label']){$history('nav',(int)$current['id'],$current);$run('UPDATE cms_nav SET label=? WHERE site_id=1 AND id=?',[$change['new']['label'],$current['id']]);}}
 $db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
};
