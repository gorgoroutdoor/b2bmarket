<?php
declare(strict_types=1);
return function(PDO $db):void {
 require_once dirname(__DIR__).'/Workspace3619.php';
 $data=json_decode(file_get_contents(dirname(__DIR__).'/Guide3619Update.json'),true,64,JSON_THROW_ON_ERROR);
 $owns=!$db->inTransaction();if($owns)$db->beginTransaction();
 try {
  $history=$db->prepare("INSERT INTO cms_history(site_id,entity,entity_id,action,snapshot,actor_id,created_at) VALUES (1,?,?,'workspace3619',?,0,UTC_TIMESTAMP())");
  foreach($data['guides'] as $g){
   $q=$db->prepare('SELECT * FROM cms_pages WHERE site_id=1 AND slug=? FOR UPDATE');$q->execute([$g['slug']]);$old=$q->fetch(PDO::FETCH_ASSOC);
   if($old){
    if($old['kind']!=='guide'||$old['category']==='Yönetim')continue;
    $history->execute(['pages',$old['id'],json_encode($old,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);
    $q=$db->prepare('UPDATE cms_pages SET title=?,description=?,category=?,content_html=?,revision=revision+1,updated_at=UTC_TIMESTAMP() WHERE site_id=1 AND id=?');
    $q->execute([$g['title'],$g['description'],$g['category'],$g['content_html'],$old['id']]);
   }else{
    $q=$db->prepare("INSERT INTO cms_pages(site_id,slug,kind,title,description,category,plan_level,content_html,fields,layout,status,seo_article,updated_at) VALUES (1,?,'guide',?,?,?,?,?,'[]','standard','published','',UTC_TIMESTAMP())");
    $q->execute([$g['slug'],$g['title'],$g['description'],$g['category'],$g['level']??3,$g['content_html']]);
   }
  }
  // Only the Kobivira marketing site is revised. Other companies' websites are untouched.
  foreach(['cms_pages'=>'pages','cms_blocks'=>'blocks'] as $table=>$entity){
   foreach($db->query('SELECT * FROM '.$table.' WHERE site_id=1')->fetchAll(PDO::FETCH_ASSOC) as $old){
    if($table==='cms_pages'&&in_array($old['slug'],['kullanim','gizlilik','kvkk'],true))continue;
    $fields=json_decode($old['fields']?:'{}',true);if(!is_array($fields))$fields=[];
    foreach($fields as &$f)if(is_array($f)&&is_string($f['value']??null))$f['value']=launch3619_public_copy($f['value']);unset($f);
    $newFields=json_encode($fields,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);
    $content=launch3619_public_copy($old['content_html']);
    if($newFields!==$old['fields']||$content!==$old['content_html']){
     $history->execute([$entity,$old['id'],json_encode($old,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);
     $q=$db->prepare('UPDATE '.$table.' SET fields=?,content_html=?,revision=revision+1,updated_at=UTC_TIMESTAMP() WHERE site_id=1 AND id=?');$q->execute([$newFields,$content,$old['id']]);
    }
   }
  }
  foreach(['kobi'=>'Günlük ön muhasebe ve güvenli belge paylaşımı.','plus'=>'Satış, finans ve elektronik belge yönetimi.','business'=>'Gelişmiş iş araçları ve elektronik belgeler.'] as $code=>$description){
   $q=$db->prepare('SELECT * FROM cms_plans WHERE site_id=1 AND code=?');$q->execute([$code]);$r=$q->fetch(PDO::FETCH_ASSOC);if(!$r)continue;
   $history->execute(['plans',$r['id'],json_encode($r,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);
   $q=$db->prepare('UPDATE cms_plans SET description=?,features=? WHERE site_id=1 AND code=?');$q->execute([$description,'',$code]);
  }
  foreach($db->query('SELECT * FROM cms_nav WHERE site_id=1')->fetchAll(PDO::FETCH_ASSOC) as $r){$label=launch3619_public_copy($r['label']);if($label!==$r['label']){$history->execute(['nav',$r['id'],json_encode($r,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)]);$q=$db->prepare('UPDATE cms_nav SET label=? WHERE site_id=1 AND id=?');$q->execute([$label,$r['id']]);}}
  if($owns)$db->commit();
 }catch(Throwable $e){if($owns&&$db->inTransaction())$db->rollBack();throw $e;}
};
