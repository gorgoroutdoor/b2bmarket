<?php
declare(strict_types=1);
return function(PDO $db):void{
    $db->exec("CREATE TABLE edm_despatch_test_documents(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,direction VARCHAR(3) NOT NULL,uuid CHAR(36) NOT NULL,number VARCHAR(16) NOT NULL,profile VARCHAR(30) NOT NULL,payload MEDIUMTEXT NOT NULL,payload_hash CHAR(64) NOT NULL,provider_status VARCHAR(100) NOT NULL,provider_details TEXT NULL,attempted_at DATETIME NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,UNIQUE KEY tenant_uuid(company_id,direction,uuid),UNIQUE KEY tenant_number(company_id,direction,number)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
};
