<?php
declare(strict_types=1);
return function(PDO $db):void {
 $db->exec('ALTER TABLE companies ADD account_number CHAR(8) NULL, ADD UNIQUE KEY company_account_number(account_number)');
 require_once dirname(__DIR__).'/Company3618.php';
 $last=0;do{$q=$db->prepare('SELECT id FROM companies WHERE id>? ORDER BY id LIMIT 250');$q->execute([$last]);$rows=$q->fetchAll(PDO::FETCH_COLUMN);foreach($rows as $cid){company3618_ensure_route(company3618_number((int)$cid,$db));$last=(int)$cid;}}while(count($rows)===250);
};
