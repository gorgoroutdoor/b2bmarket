<?php
declare(strict_types=1);
return function(PDO $db):void {
 $db->exec("CREATE TABLE automatic_emails3650(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,kind VARCHAR(24) NOT NULL,event_key VARCHAR(190) NOT NULL,recipient VARCHAR(190) NOT NULL,payload TEXT NOT NULL,status VARCHAR(20) NOT NULL DEFAULT 'pending',attempts INT UNSIGNED NOT NULL DEFAULT 0,attempted_at DATETIME NULL,next_at DATETIME NOT NULL,accepted_at DATETIME NULL,last_error VARCHAR(300) NOT NULL DEFAULT '',created_at DATETIME NOT NULL,UNIQUE KEY company_event(company_id,event_key),KEY dispatch(status,next_at,id),KEY company_history(company_id,id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("CREATE TABLE automatic_email_state3650(company_id BIGINT UNSIGNED PRIMARY KEY,low_active TINYINT NOT NULL DEFAULT 0,low_epoch BIGINT UNSIGNED NOT NULL DEFAULT 0,queued_epoch BIGINT UNSIGNED NOT NULL DEFAULT 0) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 // Do not backfill historic registrations or modify SMTP, phone, payment or package settings.
 $db->exec("INSERT IGNORE INTO settings(name,value) VALUES ('automatic_email3650','{\"enabled\":true,\"low_daily\":false}')");
};
