<?php
declare(strict_types=1);
return function(PDO $db): void {
 $q=$db->prepare('INSERT INTO settings(name,value) VALUES (?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)');
 foreach(['support_email'=>'info@kobivira.com.tr','public_app_url'=>'https://app.kobivira.com.tr/','public_site_url'=>'https://kobivira.com.tr/'] as $k=>$v)$q->execute([$k,$v]);
};
