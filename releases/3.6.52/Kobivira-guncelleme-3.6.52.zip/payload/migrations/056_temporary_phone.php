<?php
declare(strict_types=1);
return function(PDO $db):void{
 $db->exec("ALTER TABLE users ADD login_mobile_temporary_at DATETIME NULL, ADD login_mobile_temporary_number VARCHAR(10) NULL");
 $raw=$db->query("SELECT value FROM settings WHERE name='mobile3644_config'")->fetchColumn();$v=$raw===false?[]:json_decode($raw,true,16,JSON_THROW_ON_ERROR);$enable=($v['mode']??'off')==='off'?'1':'0';
 // Never alter live Netgsm or the existing designated test account configuration.
 $q=$db->prepare("INSERT IGNORE INTO settings(name,value) VALUES ('temporary_register3651',?)");$q->execute([$enable]);
};
