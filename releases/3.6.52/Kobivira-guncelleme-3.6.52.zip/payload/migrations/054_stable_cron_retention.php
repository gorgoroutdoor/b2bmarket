<?php
declare(strict_types=1);
return function(PDO $db):void {
 require_once dirname(__DIR__).'/Retention3649.php';retention3649_install();
 $db->exec("INSERT IGNORE INTO settings(name,value) VALUES ('retention3649_stable_cron','0')");retention3649_queue();
};
