<?php
declare(strict_types=1);
return function(PDO $db):void{
    $db->exec('ALTER TABLE edm_despatch_test_documents ADD COLUMN response_attempted_at DATETIME NULL,ADD COLUMN response_decision VARCHAR(20) NULL,ADD COLUMN response_payload TEXT NULL,ADD COLUMN response_acknowledged_at DATETIME NULL');
};
