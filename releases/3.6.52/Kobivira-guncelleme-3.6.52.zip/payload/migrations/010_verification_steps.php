<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("ALTER TABLE verification_documents ADD business_type VARCHAR(24) NOT NULL DEFAULT 'company',ADD INDEX verification_kind(company_id,business_type,doctype,is_current)");
 $db->exec("UPDATE verification_documents d JOIN companies c ON c.id=d.company_id SET d.business_type=CASE WHEN c.business_type='sole' THEN 'sole' ELSE 'company' END");
 $db->exec("ALTER TABLE contact_codes ADD source_value VARCHAR(190) NOT NULL DEFAULT ''");
 $db->exec("UPDATE contact_codes x JOIN companies c ON c.id=x.company_id SET x.source_value=CASE WHEN x.channel='email' THEN c.email ELSE c.phone END");
 if(!function_exists('sync_release_catalog'))require_once __DIR__.'/../ReleaseHistory.php';sync_release_catalog($db,__DIR__.'/../release_history.json');
};
