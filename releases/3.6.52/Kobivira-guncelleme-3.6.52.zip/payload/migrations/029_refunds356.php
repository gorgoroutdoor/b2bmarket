<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("CREATE TABLE membership_effects356(payment_order_id BIGINT UNSIGNED PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,before_state TEXT NOT NULL,after_state TEXT NOT NULL,created_at DATETIME NOT NULL,KEY(company_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("CREATE TABLE membership_refunds356(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,payment_order_id BIGINT UNSIGNED NOT NULL,request_key CHAR(32) NOT NULL,requested_amount BIGINT UNSIGNED NOT NULL,amount BIGINT UNSIGNED NOT NULL DEFAULT 0,status VARCHAR(20) NOT NULL DEFAULT 'requested',reason VARCHAR(500) NOT NULL,admin_note VARCHAR(500) NOT NULL DEFAULT '',bank_reference VARCHAR(100) NULL,paid_date DATE NULL,membership_action VARCHAR(20) NOT NULL DEFAULT 'keep',retain_referral TINYINT NOT NULL DEFAULT 0,created_by BIGINT UNSIGNED NOT NULL,decided_by BIGINT UNSIGNED NULL,created_at DATETIME NOT NULL,decided_at DATETIME NULL,UNIQUE KEY(company_id,request_key),UNIQUE KEY(bank_reference),KEY(company_id,payment_order_id),KEY(status,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
};
