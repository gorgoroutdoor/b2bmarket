<?php
declare(strict_types=1);
return function(PDO $db): void {
 $db->exec("INSERT IGNORE INTO settings(name,value) VALUES ('legal_publish_lock','1')");
 $db->exec("UPDATE subscriptions s JOIN plans p ON p.id=s.plan_id SET s.plan_id=(SELECT id FROM plans WHERE code='business') WHERE p.code='business_plus'");
 $db->exec("UPDATE plans SET is_active=0 WHERE code='business_plus'");$db->exec("UPDATE cms_plans SET is_visible=0 WHERE site_id=1 AND code='business_plus'");
 $db->exec("CREATE TABLE marketing_sources(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,logo_media_id BIGINT UNSIGNED NULL,guide_slug VARCHAR(110) NOT NULL DEFAULT 'rehber-veri-tasima',sort_order INT NOT NULL DEFAULT 0,is_visible TINYINT NOT NULL DEFAULT 1) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("CREATE TABLE legal_versions(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,doc_key VARCHAR(20) NOT NULL,title VARCHAR(160) NOT NULL,content_html MEDIUMTEXT NOT NULL,is_published TINYINT NOT NULL DEFAULT 0,created_by BIGINT UNSIGNED NULL,created_at DATETIME NOT NULL,published_at DATETIME NULL,KEY published_doc(doc_key,is_published,id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $db->exec("CREATE TABLE registration_consents(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,doc_key VARCHAR(20) NOT NULL,version_id BIGINT UNSIGNED NOT NULL,content_hash CHAR(64) NOT NULL,accepted_at DATETIME NOT NULL,FOREIGN KEY(company_id) REFERENCES companies(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 foreach(['Paraşüt','Logo İşbaşı','EDM','Uyumsoft','e-Logo','Sovos','Turkcell e-Şirket'] as $i=>$name){$q=$db->prepare('INSERT INTO marketing_sources(name,sort_order) VALUES (?,?)');$q->execute([$name,($i+1)*10]);}
 $q=$db->prepare("UPDATE cms_plans SET description=?,features=?,revision=revision+1 WHERE site_id=1 AND code=?");foreach([
 ['Günlük işlerinizi tek panelde yönetin.',"Müşteri / tedarikçi ve ürün / hizmet kartları\nSatış / alış faturası ve gider kaydı\nTahsilat / ödeme, kasa ve banka takibi\nGelir, gider ve KDV raporları",'kobi'],
 ['Tekliften tahsilata kadar işinizi takip edin.',"KOBİ özelliklerinin tamamı\nTeklif, proforma ve sipariş\nDöviz, çek, iade ve cari ekstre\nSerbest meslek makbuzu kayıtları\nTekrarlayan belgeler ve iş takibi",'plus'],
 ['Gelişmiş analiz ve iş yönetimiyle büyüyün.',"KOBİ Plus özelliklerinin tamamı\nYaşlandırma ve cari mutabakat\nCRM, proje kârlılığı ve nakit öngörüsü\nGelişmiş rapor ve onay kuralları\nOtomasyon, toplu işlemler ve banka dosyası eşleştirme\nYönetici etkinleştirdiğinde web / reklam modülleri",'business']
 ] as $r)$q->execute($r);
 // Update active CMS copy; previous release history and migrations remain immutable.
 foreach(['cms_pages','cms_blocks'] as $table){$rows=$db->query("SELECT * FROM $table WHERE site_id=1")->fetchAll(PDO::FETCH_ASSOC);foreach($rows as $r){$html=str_replace(['KOBİ Business Plus','Business Plus','business_plus'],['KOBİ Business','Business','business'],$r['content_html']);$fields=str_replace(['KOBİ Business Plus','Business Plus','business_plus'],['KOBİ Business','Business','business'],$r['fields']);
 if($table==='cms_pages'&&$r['slug']==='paketler'){$html=str_replace('<th>{{field:10}}</th>','',$html);$html=preg_replace('~<th[^>]*>\s*KOBİ Business(?:\s*<small>.*?</small>)?\s*</th>~s','<th>KOBİ Business</th>',$html);$html=preg_replace('~(<th>KOBİ Business</th>)(\s*<th>KOBİ Business</th>)~s','$1',$html);}
 $title=str_replace(['KOBİ Business Plus','Business Plus'],['KOBİ Business','Business'],$r['title']);$q=$db->prepare("UPDATE $table SET title=?,content_html=?,fields=?,revision=revision+1,updated_at=UTC_TIMESTAMP() WHERE id=?");$q->execute([$title,$html,$fields,$r['id']]);}}
 $db->exec("UPDATE payment_orders o JOIN plans p ON p.id=o.plan_id SET o.plan_id=(SELECT id FROM plans WHERE code='business') WHERE p.code='business_plus' AND o.status IN ('awaiting_transfer','reported')");
 $db->exec('UPDATE cms_pages SET plan_level=3 WHERE site_id=1 AND plan_level=4');$db->exec('UPDATE cms_features SET min_level=3 WHERE site_id=1 AND min_level=4');
};
