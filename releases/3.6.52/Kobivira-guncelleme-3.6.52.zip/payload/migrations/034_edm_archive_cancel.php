<?php
declare(strict_types=1);
return function(PDO $db): void {
    $db->exec('ALTER TABLE edm_test_documents ADD COLUMN cancel_attempted_at DATETIME NULL');
};
