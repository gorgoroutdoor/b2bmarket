<?php
declare(strict_types=1);
return function(PDO $db):void {
 $db->exec("ALTER TABLE gateway_payments ADD test_activation TINYINT UNSIGNED NOT NULL DEFAULT 0");
 $db->exec("CREATE TABLE checkout_test_accounts(company_id BIGINT UNSIGNED PRIMARY KEY,before_state TEXT NOT NULL,last_state TEXT NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,FOREIGN KEY(company_id) REFERENCES companies(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
};
