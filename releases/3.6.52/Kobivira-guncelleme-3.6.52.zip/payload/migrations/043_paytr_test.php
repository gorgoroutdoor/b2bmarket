<?php
declare(strict_types=1);
return function(PDO $db):void {
 $db->exec("CREATE TABLE paytr_test_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,plan_id INT UNSIGNED NOT NULL,plan_name VARCHAR(160) NOT NULL,months INT UNSIGNED NOT NULL,amount BIGINT UNSIGNED NOT NULL,merchant_oid VARCHAR(64) NOT NULL UNIQUE,request_key CHAR(32) NOT NULL,actor_id BIGINT UNSIGNED NOT NULL,
 credential_cipher TEXT NOT NULL,token_cipher TEXT NULL,status VARCHAR(20) NOT NULL DEFAULT 'created',detail VARCHAR(500) NOT NULL DEFAULT '',callback_status VARCHAR(10) NULL,callback_amount BIGINT UNSIGNED NULL,callback_count INT UNSIGNED NOT NULL DEFAULT 0,callback_conflict TINYINT UNSIGNED NOT NULL DEFAULT 0,callback_at DATETIME NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,
 UNIQUE KEY actor_request(actor_id,request_key),KEY company_created(company_id,id),FOREIGN KEY(company_id) REFERENCES companies(id),FOREIGN KEY(plan_id) REFERENCES plans(id),FOREIGN KEY(actor_id) REFERENCES users(id)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
};
