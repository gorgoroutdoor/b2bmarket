<?php
declare(strict_types=1);
function mail3652_mobile_ready(array $u):bool{return phone3644_verified($u,false)||phone3651_accepted($u);}
/** Post-commit best-effort delivery; durable CLI queue remains the fallback. */
function mail3652_flush(?Closure $sender=null):int{
 if(db()->inTransaction()||is_file(APP_ROOT.'/storage/maintenance.json'))return 0;
 $gate=fopen(APP_ROOT.'/storage/request.lock','c');if(!$gate||!flock($gate,LOCK_SH|LOCK_NB)){if($gate)fclose($gate);return 0;}try{if(is_file(APP_ROOT.'/storage/maintenance.json'))return 0;
 $ids=$GLOBALS['registration3652_users']??[];$GLOBALS['registration3652_users']=[];$done=0;
 foreach(array_slice(array_keys($ids),0,2) as $uid)$done+=mail3650_dispatch($sender,3,(int)$uid);
 return $done;}finally{flock($gate,LOCK_UN);fclose($gate);}
}
function mail3652_register():void{
 if(PHP_SAPI==='cli')return;
 register_shutdown_function(static function(){
  $requestGate=null;try{
   $requestGate=fopen(APP_ROOT.'/storage/request.lock','c');if(!$requestGate||!flock($requestGate,LOCK_SH|LOCK_NB))return;
   if(db()->inTransaction()||is_file(APP_ROOT.'/storage/maintenance.json'))return;
   // Only the signed-in, enrolled account is reconciled; uniqueness prevents repeat mail.
   $u=base_user();if($u&&$u['role']==='company_admin'&&!empty($u['registration_email_required'])&&!email3643_pending($u))transaction(fn()=>mail3650_registration((int)$u['id'],true));
   if(empty($GLOBALS['registration3652_users']))return;
   if(session_status()===PHP_SESSION_ACTIVE)session_write_close();
   if(function_exists('fastcgi_finish_request'))fastcgi_finish_request();
   mail3652_flush();
  }catch(Throwable){error_log('Kobivira kayıt e-postası gönderimi tamamlanamadı; kalıcı kuyruktan kontrol edin.');}finally{if(is_resource($requestGate)){flock($requestGate,LOCK_UN);fclose($requestGate);}}
 });
}
