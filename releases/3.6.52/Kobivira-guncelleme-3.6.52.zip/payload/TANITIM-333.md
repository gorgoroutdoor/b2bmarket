# Kobivira 3.3.3

3.3.2 üzerine yüklenir. Tek ZIP, Sistem → Sürüm güncellemeleri alanındandır. Veritabanı geçişi otomatik uygulanır.

Yönetici ana sayfasındaki Tanıtımı görüntüle düğmesi güncel siteyi açar. Site dosyalarını indir düğmesi statik alan adı yayınını hazırlar. apyon.com.tr dosyaları otomatik değiştirilmez.

Ana sayfa ürün anlatımı, video alanı, paketler, üç blog yazısı, referans ve kullanıcı deneyimi alanları içerir. Örnek veri ve panel kütüphanedeki Panel deneyimi bölümüne taşındı. İç bağlantılar iframe içinde yeni bir site oluşturmaz; üst pencereye çıkar. Header ve footer kütüphane bağlantıları korunur.

Sistem → Tanıtım ve referanslar: HTTPS MP4 video bağlantısı, hangi gerçek firmaların anonim istatistiklere dahil edileceği ve yayın anahtarı. Varsayılan yayın kapalıdır; 20 firma / 50 aktif kullanıcı / 100 belge eşiği altında sayılar gösterilmez. Rakamlar aşağı yuvarlanır. Bu rakamlar ön muhasebe kayıtlarını anlatır; resmî kesilmiş fatura veya gerçek tahsilat hacmi diye sunulmaz. Firma, kişi, müşteri veya belge kimliği paylaşılmaz.

Firma → Ayarlar → Arkadaşını davet et: kod ve kayıt bağlantısı; ödül geçmişi. Her yeni firmanın ilk pozitif, yönetici onaylı ödemesi bir kez 30 gün verir. Reddedilen ödeme ve yenileme ödül vermez. Aynı vergi numarasıyla ödül oluşturulmaz. Kod sonradan değişmez. Aktif veya geçmiş ücretli üyelikte mevcut pakete süre eklenir; hiç ödeme yapmamış veya askıda hesapta hak bekletilir. İlk ücretli etkinleştirmede bekleyen haklar uygulanır. Paket, kontör ve ek servisler değişmez.

Gerçek marka logoları / yayın izni verilmiş kullanıcı yorumları ve ürün videosu henüz verilmedi; bunların yerine gerçekmiş gibi içerik üretilmedi. Üç başlangıç blog yazısı hazırdır; blog yönetim CMS’si sonraki aşamadadır. Yeni sayısal paket fiyatları halen beklenmektedir. Gerçek ödeme, e-Belge, SMS ve diğer entegrasyonlar açılmadı.

Kontroller: imzalı 3.3.2→3.3.3 yükleme, kayıt / paket yetkileri, referans ödülü ve mükerrer işlem, red / yenileme / aynı vergi kontrolü, anonim toplamlarda eşikler / yuvarlama / ters kayıt ve iç aktarım dışlama, kamuya açık yanıtların kimlik içermemesi, site dışa aktarma yetkisi, mobil panel taşması, site bağlantıları ve DOM etkileşimleri. Tanıtım sitesinin tarayıcı görsel kontrolü bu ortamda yapılamadı.
