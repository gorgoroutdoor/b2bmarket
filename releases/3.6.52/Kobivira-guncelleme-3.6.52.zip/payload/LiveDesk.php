<?php
declare(strict_types=1);
function desk_company_admin(): array {
    $u=base_user();if(!$u||$u['role']!=='company_admin'||$u['company_status']!=='active'||support_context()){http_response_code(403);throw new DomainException('Bu işlem firma yöneticisine aittir.');}return $u;
}
function desk_sync(): void {
    query("UPDATE support_requests r JOIN subscriptions s ON s.company_id=r.company_id SET r.status='revoked',r.code_hash=NULL,r.code_cipher=NULL,r.monitor_state=NULL,r.ended_at=UTC_TIMESTAMP() WHERE r.status IN ('requested','awaiting','active') AND NOT (s.status='active' AND s.paid_until>UTC_TIMESTAMP())");
    query("UPDATE support_queue q JOIN subscriptions s ON s.company_id=q.company_id SET q.status='cancelled',q.ended_at=UTC_TIMESTAMP(),q.updated_at=UTC_TIMESTAMP() WHERE q.status IN ('waiting','scheduled','connecting') AND NOT (s.status='active' AND s.paid_until>UTC_TIMESTAMP())");
    query("UPDATE support_requests SET monitor_state=NULL WHERE monitor_state IS NOT NULL AND (status<>'active' OR expires_at<=UTC_TIMESTAMP())");
    query("UPDATE support_queue q JOIN support_requests r ON r.queue_id=q.id SET q.status='completed',q.ended_at=UTC_TIMESTAMP(),q.updated_at=UTC_TIMESTAMP() WHERE q.status='connecting' AND (r.status NOT IN ('requested','awaiting','active') OR r.expires_at<=UTC_TIMESTAMP())");
}
function desk_time(?string $v): string {return $v?(new DateTimeImmutable($v,new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Europe/Istanbul'))->format('d.m.Y H:i'):'Henüz atanmadı';}
function desk_state(string $s): string {return ['waiting'=>'Sırada','scheduled'=>'Saat atandı','connecting'=>'Bağlantı aşamasında','completed'=>'Tamamlandı','cancelled'=>'İptal edildi'][$s]??$s;}
function desk_queue_data(int $cid): ?array {
    $r=query("SELECT q.*,u.name agent_name FROM support_queue q LEFT JOIN users u ON u.id=q.assigned_to WHERE q.company_id=? AND q.status IN ('waiting','scheduled','connecting') ORDER BY q.id DESC LIMIT 1",[$cid])->fetch();if(!$r)return null;
    // Queue position is within the assigned representative's open workload; unassigned requests use their own FIFO.
    $r['position']=$r['status']==='connecting'?0:1+(int)query("SELECT COUNT(*) FROM support_queue WHERE status IN ('waiting','scheduled','connecting') AND assigned_to <=> ? AND id<>? AND (status='connecting' OR COALESCE(scheduled_at,created_at)<COALESCE(?,?) OR (COALESCE(scheduled_at,created_at)=COALESCE(?,?) AND id<?))",[$r['assigned_to'],$r['id'],$r['scheduled_at'],$r['created_at'],$r['scheduled_at'],$r['created_at'],$r['id']])->fetchColumn();
    return ['id'=>(int)$r['id'],'subject'=>$r['subject'],'status'=>$r['status'],'agent'=>$r['agent_name'],'scheduled_at'=>$r['scheduled_at']?strtotime($r['scheduled_at'].' UTC'):null,'scheduled_label'=>desk_time($r['scheduled_at']),'duration'=>(int)$r['duration_minutes'],'position'=>$r['position'],'server_time'=>time()];
}
function desk_post(string $action): void {
    if(support_context()||isset($_GET['support'])){http_response_code(403);throw new DomainException('Destek bağlantısından yeni talep yönetilemez.');}
    desk_sync();$u=base_user();
    if($action==='join'){
        desk_company_admin();require_paid_support((int)$u['company_id']);throttle('desk_join_'.$u['id'],12);$subject=required_field('subject',300);
        transaction(function()use($u,$subject){query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$u['company_id']]);if(query("SELECT id FROM support_queue WHERE company_id=? AND status IN ('waiting','scheduled','connecting') FOR UPDATE",[$u['company_id']])->fetchColumn())throw new DomainException('Açık bir destek talebiniz var. Sıranızı bu ekrandan takip edebilirsiniz.');query("INSERT INTO support_queue(company_id,requested_by,subject,status,created_at,updated_at) VALUES (?,?,?,'waiting',UTC_TIMESTAMP(),UTC_TIMESTAMP())",[$u['company_id'],$u['id'],$subject]);audit('desk.joined',['queue_id'=>(int)db()->lastInsertId()]);});flash('Destek talebiniz sıraya alındı. Saat atandığında ve sıranız yaklaştığında panelinizde bildirim gösterilecek.');redirect('support_center');
    }
    if($action==='cancel_queue'){
        desk_company_admin();$id=int_field('id',1,PHP_INT_MAX);
        transaction(function()use($u,$id){query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$u['company_id']]);$q=query('SELECT * FROM support_queue WHERE id=? AND company_id=? FOR UPDATE',[$id,$u['company_id']])->fetch();if(!$q){http_response_code(404);throw new DomainException('Talep bulunamadı.');}if(!in_array($q['status'],['waiting','scheduled','connecting'],true))return;query("UPDATE support_queue SET status='cancelled',ended_at=UTC_TIMESTAMP(),updated_at=UTC_TIMESTAMP() WHERE id=?",[$id]);query("UPDATE support_requests SET status='revoked',code_hash=NULL,code_cipher=NULL,monitor_state=NULL,ended_at=UTC_TIMESTAMP() WHERE queue_id=? AND status IN ('requested','awaiting','active')",[$id]);audit('desk.cancelled',['queue_id'=>$id]);});flash('Destek talebiniz ve varsa bağlantınız sonlandırıldı.');redirect('support_center');
    }
    require_owner();
    if(in_array($action,['add_agent','toggle_agent','reset_agent'],true)){
        if($u['role']!=='platform_admin'){http_response_code(403);throw new DomainException('Destek ekibini yalnızca platform yöneticisi yönetebilir.');}
        reauthenticate($u);
        if($action==='add_agent'){
            $name=required_field('name',100);$email=email_field();$password=password_field();
            transaction(function()use($name,$email,$password){query("INSERT INTO users(name,email,password_hash,role,is_active,created_at) VALUES (?,?,?,'support_agent',1,UTC_TIMESTAMP())",[$name,$email,password_hash($password,PASSWORD_DEFAULT)]);$id=(int)db()->lastInsertId();query("INSERT INTO support_agents(user_id,availability,last_seen) VALUES (?,'offline',UTC_TIMESTAMP())",[$id]);audit('desk.agent_created',['id'=>$id]);});flash('Destek temsilcisi oluşturuldu. Temsilci kendi hesabıyla giriş yapıp destek durumunu Müsait yapabilir.');redirect('support_desk');
        }
        $id=int_field('id',1,PHP_INT_MAX);$password=$action==='reset_agent'?password_field():null;
        transaction(function()use($id,$action,$password){$agent=query("SELECT * FROM users WHERE id=? AND role='support_agent' FOR UPDATE",[$id])->fetch();if(!$agent)throw new DomainException('Destek temsilcisi bulunamadı.');if($action==='reset_agent')query('UPDATE users SET password_hash=?,session_version=session_version+1 WHERE id=?',[password_hash($password,PASSWORD_DEFAULT),$id]);else query('UPDATE users SET is_active=1-is_active,session_version=session_version+1 WHERE id=?',[$id]);query("UPDATE support_agents SET availability='offline' WHERE user_id=?",[$id]);query("UPDATE support_requests SET status='revoked',code_hash=NULL,code_cipher=NULL,monitor_state=NULL,ended_at=UTC_TIMESTAMP() WHERE actor_id=? AND status IN ('requested','awaiting','active')",[$id]);query("UPDATE support_queue SET assigned_to=NULL,scheduled_at=NULL,status='waiting',updated_at=UTC_TIMESTAMP() WHERE assigned_to=? AND status='scheduled'",[$id]);audit('desk.agent_updated',['id'=>$id,'operation'=>$action]);});desk_sync();flash('Temsilci hesabı güncellendi. Açık bağlantıları ve oturumları kapatıldı.');redirect('support_desk');
    }
    if($action==='availability'){
        $state=choice('availability',['available','busy','offline']);query('INSERT INTO support_agents(user_id,availability,last_seen) VALUES (?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE availability=VALUES(availability),last_seen=UTC_TIMESTAMP()',[$u['id'],$state]);flash('Destek durumunuz güncellendi.');redirect('support_desk');
    }
    if($action==='schedule'){
        $id=int_field('id',1,PHP_INT_MAX);$minutes=int_field('duration_minutes',5,120);$v=required_field('scheduled_at',16);$d=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',$v,new DateTimeZone('Europe/Istanbul'));if(!$d||$d->format('Y-m-d\TH:i')!==$v||$d->getTimestamp()<time()-60||$d->getTimestamp()>time()+90*86400)throw new DomainException('Şimdi ile 90 gün sonrası arasında geçerli bir destek saati seçin.');$stamp=$d->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        transaction(function()use($u,$id,$stamp,$minutes){$agent=query('SELECT * FROM support_agents WHERE user_id=? FOR UPDATE',[$u['id']])->fetch();if(!$agent||$agent['availability']==='offline')throw new DomainException('Önce destek durumunuzu Müsait veya Meşgul yapın.');$q=query('SELECT * FROM support_queue WHERE id=? FOR UPDATE',[$id])->fetch();if(!$q||!in_array($q['status'],['waiting','scheduled'],true))throw new DomainException('Bu talep artık planlanamaz.');if($q['assigned_to']&&(int)$q['assigned_to']!==(int)$u['id'])throw new DomainException('Bu talep başka bir temsilciye atanmış.');$conflict=query("SELECT id FROM support_queue WHERE assigned_to=? AND id<>? AND status IN ('scheduled','connecting') AND COALESCE(scheduled_at,UTC_TIMESTAMP())<DATE_ADD(?,INTERVAL ? MINUTE) AND DATE_ADD(COALESCE(scheduled_at,UTC_TIMESTAMP()),INTERVAL duration_minutes MINUTE)>? FOR UPDATE",[$u['id'],$id,$stamp,$minutes,$stamp])->fetchColumn();if($conflict)throw new DomainException('Bu saatte başka destek kaydınız var. Çakışmayan bir zaman seçin.');query("UPDATE support_queue SET status='scheduled',assigned_to=?,scheduled_at=?,duration_minutes=?,updated_at=UTC_TIMESTAMP() WHERE id=?",[$u['id'],$stamp,$minutes,$id]);audit('desk.scheduled',['queue_id'=>$id,'scheduled_at'=>$stamp]);});flash('Destek saati firmaya bildirildi. Saatler Türkiye saatidir.');redirect('support_desk');
    }
    if($action==='delay'){
        $id=int_field('id',1,PHP_INT_MAX);$delay=int_field('delay_minutes',1,120);$q=query('SELECT * FROM support_queue WHERE id=?',[$id])->fetch();if(!$q||$q['status']!=='scheduled'||(int)$q['assigned_to']!==(int)$u['id'])throw new DomainException('Yalnızca kendi planlanmış desteğinize ek süre verebilirsiniz.');$start=max(time(),strtotime($q['scheduled_at'].' UTC'));$d=(new DateTimeImmutable('@'.($start+$delay*60)))->setTimezone(new DateTimeZone('Europe/Istanbul'));$_POST['scheduled_at']=$d->format('Y-m-d\TH:i');$_POST['duration_minutes']=$q['duration_minutes'];desk_post('schedule');return;
    }
    if($action==='release_queue'){
        $id=int_field('id',1,PHP_INT_MAX);transaction(function()use($u,$id){$q=query('SELECT * FROM support_queue WHERE id=? FOR UPDATE',[$id])->fetch();if(!$q||(int)$q['assigned_to']!==(int)$u['id']||$q['status']!=='scheduled')throw new DomainException('Yalnızca kendi planlanmış talebinizi sıraya bırakabilirsiniz.');query("UPDATE support_queue SET status='waiting',assigned_to=NULL,scheduled_at=NULL,updated_at=UTC_TIMESTAMP() WHERE id=?",[$id]);audit('desk.released',['queue_id'=>$id]);});flash('Talep ortak sıraya bırakıldı.');redirect('support_desk');
    }
    throw new DomainException('Geçersiz destek işlemi.');
}
function desk_params(): array {
    $p=[];foreach(['id','kind','view','from','to','edit','q','p'] as $key){$v=$_POST['location_'.$key]??null;if(!is_string($v))continue;if($key==='q'){if(mb_strlen($v)<=80&&!preg_match('/[\x00-\x1f]/',$v))$p[$key]=$v;}elseif(preg_match('/^[a-z0-9_-]{1,30}$/D',$v))$p[$key]=$v;}return $p;
}
function desk_monitor_record(array $r): void {
    $page=is_string($_POST['current_page']??null)?$_POST['current_page']:'';
    if(!in_array($page,['support_workspace','documents','document','newdocument','contacts','contact','products','accounts','payments','cashflow','reminders','reports','settings','tasks'],true))return;
    $params=desk_params();$saveGet=$_GET;$_GET=['page'=>$page]+$params+['support'=>$saveGet['support']??''];
    try{if(!support_route_allowed())return;}finally{$_GET=$saveGet;}
    $dialog=in_array($_POST['dialog']??'',['quick-contact-dialog','quick-add'],true)?$_POST['dialog']:'';
    // A small allowlist of business fields only. Passwords, tokens, file inputs and account security are never captured.
    $allowed=desk_fields();$raw=json_decode(is_string($_POST['form_state']??null)?substr($_POST['form_state'],0,40000):'[]',true);$clean=[];
    if(is_array($raw))foreach(array_slice($raw,0,200) as $field){if(!is_array($field)||!is_string($field['name']??null)||!is_string($field['value']??null))continue;$name=$field['name'];if(!in_array($name,$allowed,true)&&!preg_match('/^lines\[\d{1,3}\]\[(product_id|label|quantity|price|vat)\]$/D',$name))continue;$clean[]=['name'=>$name,'value'=>mb_substr($field['value'],0,1000),'zone'=>($field['zone']??'')==='quick-contact-dialog'?'quick-contact-dialog':'main'];}
    $state=json_encode($clean,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);if(strlen($state)>32000)$state='[]';
    query('UPDATE support_requests SET monitor_page=?,monitor_params=?,monitor_dialog=?,monitor_state=?,monitor_seen=UTC_TIMESTAMP() WHERE id=? AND status=\'active\'',[ $page,json_encode($params,JSON_THROW_ON_ERROR),$dialog,seal_code($state),$r['id']]);
}
function desk_fields(): array {return ['recipient[name]','recipient[tax_number]','recipient[tax_office]','recipient[address]','recipient[contact_person]','recipient[phone]','recipient[email]','contact_person','tax_office','contact_id','issue_date','due_date','description','name','kind','email','phone','tax_number','address','note','code','unit','price','cost','vat','type','opening_balance','account_id','document_id','direction','amount','paid_date','title','due_at','status'];}
function desk_monitor_data(array $r): array {
    $r=query('SELECT * FROM support_requests WHERE id=?',[$r['id']])->fetch();$events=query('SELECT id,action,metadata,created_at FROM audit_logs WHERE company_id=? AND support_request_id=? ORDER BY id DESC LIMIT 15',[$r['company_id'],$r['id']])->fetchAll();
    $state=$r['monitor_state']?json_decode(open_code($r['monitor_state']),true):[];
    $captionParams=json_decode($r['monitor_params'],true)?:[];if(in_array($r['monitor_page'],['document','newdocument'],true)&&isset($captionParams['id'])){$kind=query('SELECT kind FROM documents WHERE company_id=? AND id=?',[$r['company_id'],(int)$captionParams['id']])->fetchColumn();if($kind)$captionParams['kind']=$kind;}
    return ['request_id'=>(int)$r['id'],'page'=>$r['monitor_page'],'caption'=>page_caption($r['monitor_page'],$captionParams),'dialog'=>$r['monitor_dialog'],'fields'=>$state?:[],'seen'=>$r['monitor_seen']?strtotime($r['monitor_seen'].' UTC'):null,'revision'=>hash('sha256',$r['monitor_page'].$r['monitor_params'].($events[0]['id']??0)),'events'=>array_map(fn($e)=>['id'=>(int)$e['id'],'label'=>desk_event_label($e['action']),'time'=>desk_time($e['created_at'])],$events),'follow_url'=>'?page=support_follow&id='.$r['id']];
}
function desk_event_label(string $a): string {return ['document.saved'=>'Belge taslağı kaydedildi','document.posted'=>'Belge kesinleştirildi','document.cancelled'=>'Belge iptal edildi','contact.saved'=>'Müşteri / tedarikçi kaydedildi','contact.quick_created'=>'Hızlı müşteri / tedarikçi eklendi','product.saved'=>'Ürün / hizmet kaydedildi','payment.created'=>'Tahsilat / ödeme kaydedildi','payment.reversed'=>'Tahsilat / ödeme geri alındı','settings.saved'=>'Firma bilgileri güncellendi','company.settings'=>'Firma bilgileri güncellendi','task.created'=>'İş takibi kaydı oluşturuldu','document.derived'=>'Belgeden yeni taslak oluşturuldu','document.approved'=>'Belge onaylandı','document.pending'=>'Belge onaya gönderildi','account.created'=>'Kasa / banka hesabı oluşturuldu','accounts.transferred'=>'Hesaplar arası aktarım yapıldı','support.approved'=>'Firma bağlantıya izin verdi','support.requested'=>'Bağlantı talebi oluşturuldu','support.code_verified'=>'Bağlantı kodu doğrulandı','support.revoked'=>'Bağlantı sonlandırıldı'][$a]??'İşlem kaydedildi: '.$a;}
function desk_follow_response(): never {
    $u=desk_company_admin();require_paid_support((int)$u['company_id']);$id=(int)($_GET['id']??0);$r=query("SELECT r.*,c.status company_status,c.name company_name,u.is_active approver_active,u.session_version current_approver_version FROM support_requests r JOIN companies c ON c.id=r.company_id JOIN users u ON u.id=r.approved_by AND u.company_id=r.company_id WHERE r.id=? AND r.company_id=? AND r.approved_by=?",[$id,$u['company_id'],$u['id']])->fetch();
    if(!$r||$r['status']!=='active'||strtotime($r['expires_at'].' UTC')<=time()||!(int)$r['approver_active']||(int)$r['approver_version']!==(int)$r['current_approver_version']){http_response_code(403);exit('Canlı izleme kapalı. Bağlantı sona erdi veya izin geri alındı.');}
    $helper=query("SELECT * FROM users WHERE id=? AND company_id=? AND role='support' AND is_active=0",[$r['helper_user_id'],$r['company_id']])->fetch();if(!$helper){http_response_code(403);exit('Canlı izleme kapalı.');}
    $r['permissions']=json_decode($r['permissions'],true,16,JSON_THROW_ON_ERROR);$r['helper']=$helper;$GLOBALS['follow_context']=$r;$GLOBALS['follow_mode']=true;
    $params=json_decode($r['monitor_params'],true)?:[];$page=$r['monitor_page'];$_GET=['page'=>$page]+$params;
    if(!support_route_allowed()){http_response_code(403);exit('Bu bölüm için izleme izni yok.');}
    header_remove('X-Frame-Options');$nonce=$GLOBALS['nonce'];header("Content-Security-Policy: default-src 'none'; style-src 'nonce-$nonce'; script-src 'none'; img-src 'self' data:; base-uri 'none'; form-action 'none'; frame-ancestors 'self'");
    $GLOBALS['authorized']=true;render($page,null);exit;
}
