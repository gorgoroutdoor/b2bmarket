# Kobivira · Demo kapsamı ve kullanım

3.3.1 güncellemesi ortak demo erişimini uygular. Bu kılavuz 3.3.0 ile gelen işlevleri ve güncel demo kurallarını açıklar.

## Yükleme

3.2.1 veya güncelleme manifestinin kabul ettiği önceki sürümde platform yöneticisi olarak Sistem → Sürüm güncellemeleri bölümüne gidin. İmzalı Kobivira-guncelleme-3.3.0.zip dosyasını açmadan seçin, yönetici şifrenizle yükleyin. Önce otomatik yedek alınır; 014 numaralı migration yeni alanları oluşturur. Eski kayıtlar korunur. Tasarımın bütün CSS dosyaları önceki sürümle aynıdır. Bakımda kalan bir güncellemede aynı ekrandaki yedekten geri alma işlemini kullanın.

## Paketlerin amacı

- KOBİ: elektronik belge demo hazırlığı, cari / ürün kartları ve güvenli müşteri belge paylaşımı. Resmî gönderimler sağlayıcı bağlantısına kadar kapalıdır. Ön muhasebe yazma özellikleri Plus gerektirir; geçmiş kayıtlar okunur.
- KOBİ Plus: KOBİ + satış / alış / gider, teklif / proforma / sipariş, kasa / banka, tahsilat / ödeme, döviz, çek, çalışan gider / avans, ürün miktarı ve barkod, işler, standart rapor ve haftalık / aylık / yıllık tekrarlar.
- KOBİ Business: Plus + proje sonucu, CRM fırsat / etkileşim geçmişi, 30 / 60 / 90 nakit öngörüsü, tutar eşiğiyle ön kontrol ve yönetici onayı, gelişmiş takip kuralları, banka dosyası eşleştirme, toplu kategori / etiket, ayrıntılı rapor, düzenlenebilir çıktı metinleri ve salt okunur firma API erişimi.

OCR, AI, otomatik banka, pazaryeri / CRM ve API hakları Business'tadır; Plus için platform yöneticisi süreli ek hizmet yetkisi tanımlayabilir. OCR ve AI bu sürümde hazırlık akışıdır, bağlı dış servis yoktur. Müşteri kartları, danışman erişimi ve temel güvenlik bütün paketlerde vardır. Kullanıcı kotaları mevcut plan kayıtlarından gelir; bu sürüm fiyat veya hediye kontör tanımlamaz.

Paket karşılaştırması, menü ve sunucu yetkisi aynı FeatureCatalog.php kataloğunu kullanır. Menüde görünmeyen bölüme doğrudan POST göndermek hak kazandırmaz. Çalışanların erişimi paket hakkı ve seçilmiş bölüm izninin kesişimidir. Destek temsilcisinin şirket onayını aşmasına izin verilmez. Bazı hassas yeni Business bölümleri yalnız firma yöneticisine açıktır.

## 15 günlük deneme

Toplam 5 cari ve 5 belge; kontör 0. Elektronik demo ve ön muhasebe belgeleri ortak belge sınırındadır. Bir elektronik demo ön muhasebe taslağına bağlanınca ikinci kez sayılmaz. 3.3.1 itibarıyla ilk kayıtta paket seçilmez; tüm deneme hesapları gelişmiş panel özelliklerini açar. Ücretli servis ek hizmetleri, OCR / AI hazırlıkları ve harici API denemede kapalıdır. Paket seçimi satın alma aşamasındadır. Destek, dosyadan veri aktarımı ve gerçek API erişimi aktif ücretli üyelik gerektirir. Süresi biten firma yeni mali işlem yapamaz; mevcut kayıtları okuyabilir, yenileme ve firma inceleme işlemlerini kullanabilir.

## Para birimi ve vergiler

Belge fiyatı seçilen para birimindedir. Ürün kartı fiyatı TL'dir; yabancı para seçilince fiyatı ayrıca girin. Kur 1 birim dövizin TL değeridir, manuel girilir. Vergi, kategori ve çıktı seçenekleri açılır alandadır. Stopaj net tutardan, KDV tevkifatı KDV tutarından düşülür; diğer vergi tutarı toplamına eklenir. Uygulanacak oranlar otomatik mevzuat kararı değildir; belgeye göre kontrol edilmelidir.

Belge özgün tutarı ve kayıt kuru ile TL karşılığını birlikte saklar. Raporlar TL kayıt değeridir. Döviz hesabında özgün bakiye ayrıca görünür; güncel piyasa değerlemesi yapılmaz. Belgeye bağlı tahsilat aynı para biriminde girilir, hesap aynı dövizde veya TL olabilir. Gerçek kasa tutarı ve kapatılan belge tutarı ayrıdır; gerçekleşen fark döviz raporunda gösterilir. Otomatik resmî kur farkı faturası üretilmez. Hesaplar arası farklı para biriminde aktarımda çıkan / giren tutar ve her iki kurun TL karşılığı eşleşmelidir.

## Çekler ve çalışanlar

Çek kaydı bakiyeyi değiştirmez. Gerçekleşen tahsil / ödeme banka hesabı ve tarih ile kaydedilir; gerekli onaylar tamamlanana kadar para hareketi oluşmaz. Aynı çek ikinci kez kapatılamaz. Para hareketi geri alınırsa çek yeniden beklemeye geçer. İade / karşılıksız ve iptal gerekçeyle kaydedilir.

Çalışan kendi gider / avans / geri ödeme talebini açabilir. Tüm talepler mevcut yönetici onay sırasına girer; Business eşiği varsa ön kontrol de uygulanır. Çalışanın kendi ödediği gider onaylanınca tek gider belgesi oluşur. Avans / geri ödeme yalnız para hareketi oluşturur. Avanslar ve geri ödemeler eski çalışan giderlerine tarih sırasıyla dağıtılır; aynı gider yeniden ödenecek borç olarak kalmaz. Fazla geri ödeme engellenir. Onaylanan çalışan kaydı gerekçeyle kendi bölümünden geri alınabilir; geçmişi korunur.

## Ürün miktarları

Açılışı veya düzeltmeyi ürün hareketlerinden girin. Yalnız bu sürümden sonra kesinleşen yeni alış / satış belgeleri otomatik hareket oluşturur; geçmiş belgeler geriye dönük sayılmaz. Onay bekleyen belge miktarı etkilemez, iptal belge hareketleri bakiyeye katılmaz. Hizmetlerde miktar bakiyesi tutulmaz. Barkod firma içinde benzersizdir. Negatif bakiye, eksik açılış veya kayıt sırasını gösterebilir; satışa blokaj uygulanmaz.

## Müşteri paylaşımı

Onaylanmış teklif / proforma / sipariş veya kesinleşmiş satış için Paylaşımlar alanından bağlantı oluşturun. Bağlantı yalnız alıcının belgesini gösterir; 30 gün geçerlidir ve kapatılabilir. Belge içeriği değişirse bağlantı kapanır. Teklif / proforma / sipariş için müşteri ticari kabul, ret veya değişiklik isteği verebilir. Bu yanıt resmî e-Fatura yanıtı değildir. Kişisel bağlantı yalnız ilgili alıcıyla paylaşılmalıdır; yeni oluşturulan adres bir kez gösterilir.

## Tekrarlar ve takip

Mevcut satırlı satış / alış / gider belgesinden haftalık, aylık veya yıllık tekrar oluşturun. Çıktı daima taslaktır; kesinleştirme ve onay ayrıdır. Ay sonları için başlangıç gününün taşması düzeltilir. Aynı kural / tarih ikinci kez belge oluşturmaz. Firma yöneticisinin panel kullanımında kontrol 5 dakikada bir yapılır. Panel kapalıyken çalışma için Sistem → Servis bağlantıları alanındaki SchedulerCli.php komutunu sunucunuzun PHP CLI yoluyla 5 dakikada bir zamanlayın. Aynı komut gelecek güncel sürümü işaretçiden bulur. Bakımda ve süresi bitmiş / askıdaki firmada işlem çalışmaz.

Business takip kuralları geciken açık belgeler, yanıtsız paylaşımlar veya görüşmesi gelen fırsatlar için panel bildirimi üretir. Bir olay / gün için tek bildirim oluşturulur. E-posta / SMS gönderilmez. Standart vade ekranları Plus'ta kalır. Business bildirim sayısı ana sayfanın Sıradaki Adım alanına da bağlanır.

## Business rapor ve şablonlar

CRM beklenen satışları gerçek gelir gibi saymaz; görüşme notları ayrı geçmişte korunur. Nakit öngörüsü mevcut hesapların TL kayıt değeri + kesinleşmiş açık belge vadeleridir. Gecikmiş belgeler ilk güne alınır. CRM fırsatları veya çekler tahmine tekrar eklenmez. Öngörü tahsilat garantisi değildir.

Toplu merkez en fazla 50 belgenin kategori ve etiketini değiştirir. Tutar ve durum değiştirmez. Ayrıntılı rapor kesinleşmiş belgeleri tarih / kategori / etiketle filtreler. Çıktı şablonu başlık, banka görünümü, koşul ve dipnotu düzenler; temel PDF yerleşimi sabittir. Belge şablonun kayıt anındaki kopyasını saklar, sonradan değişen metin eski çıktıya uygulanmaz.

## Servis merkezi · şu anda neler gerçek?

Platform ve firma servis hesapları ayrıdır. Anahtarlar şifreli saklanır; kayıtlı sırlar tekrar ekrana yazılmaz. Platform hesabı üyelik tahsilatı hazırlığı, firma hesabı kendi müşterisinden tahsilat hazırlığı içindir. PayTR / iyzico için bu sürüm gerçek ödeme sayfası oluşturmaz, başarı bildirimi kabul etmez ve üyeliği otomatik açmaz. Havale / yönetici onayı mevcut akışta devam eder.

Elektronik belge merkezi e-Fatura, e-Arşiv, e-SMM, e-İrsaliye ve e-İhracat alanları ile DEMO taslağı hazırlar. İç numara resmî numara değildir. Gelen demo kabul / retleri ayrı tutulur; kabul edilen demo ancak ön muhasebe TASLAĞI olur, kendiliğinden kesinleşmez. Resmî gelen belgeler mevcut entegratör kutusunda ayrı kalır.

Fiş fotoğrafı inceleme kuyruğu fotoğrafı saklar ve yöneticiye inceletir; otomatik okuma yapmaz, gider üretmez. Rapor özeti mevcut rakamların kurallı özetidir; yapay zekâ sonucu değildir. Business demo kotası OCR 50 / ay, özet 100 / ay; Plus ek hizmette 20 / ay. İptal etmek kullanılan hazırlık kotasını geri vermez.

Gerçek özel entegratör, PayTR / iyzico, banka, pazaryeri / CRM, OCR ve AI adaptörleri; test ve gerçek ortam bağlantıları; dış gönderim / uzlaştırma / webhook doğrulamaları son entegrasyon aşamasında tamamlanacaktır. Anahtar girilmesi bunları otomatik etkinleştirmez. E-posta / Netgsm ayarları mevcut Sistem → E-posta / SMS gönderimleri alanındadır; canlı gönderim denemeleri burada yapılmadı. İki aşamalı kimlik doğrulama ve ayrı Android / iOS uygulamaları sonraki aşamadadır.

## Çalışan salt okunur API

Firma yöneticisi servis merkezinden API anahtarı oluşturabilir; anahtar yalnız bir kez gösterilir, tekrar gösterilemez ve iptal edilebilir. Veritabanında yalnız özeti saklanır. Authorization: Bearer ANAHTAR başlığıyla ?page=public_data&resource=contacts veya resource=documents çağrılır. Yalnız GET. after / limit ile sayfalama, en fazla 50 satır. Anahtar yalnız kendi firmasını okur; ödeme, silme veya güncelleme uç noktası yoktur. Business firma başına 1000 istek / ay, Plus ek hizmette 200. Birden fazla anahtar aynı firma kotasını paylaşır. Abonelik, firma durumu veya paket / ek hizmet yetkisi biterse erişim kapanır. total_try / subtotal_try / tax_try TL kuruş; native_total özgün para biriminde kuruştur. fx_rate bir birim dövizin TL karşılığıdır.
