# Kobivira 3.5.6

3.5.5 üzerine yönetim panelinden yüklenebilen imzalı güncelleme. Yeni kurulum değildir. Önceki sürümler sırasıyla yüklenmiş olmalıdır.

## Tasarım
Mevcut CSS, logo, renk, menü, sayfa yerleşimi ve tanıtım sayfaları değiştirilmedi. Yeni iade işlemleri ödeme ayrıntısındaki katlanabilir bölümde, mevcut form bileşenleriyle bulunur. Paket fiyatları, indirimler ve kullanıcı kotaları değişmez.

## Veri taşıma
SATIS, ISTISNA ve ayrışmış vergi kalemleri olan TEVKIFAT / OZELMATRAH UBL Invoice dosyaları işlenir. KDV ile diğer vergiler ayrı tutulur; ödenecek tutardan KDV tevkifatı düşülür. Tahsilat bilinmediği için normal XML faturası taslak gelir.

KDV tevkifatının belge toplamıyla tam uyumlu tek bir mevcut oranı olmalıdır. Birden fazla farklı oran / desteklenmeyen kesinti, ön ödeme, yuvarlama farkı veya satırlara dağıtılmamış belge indirimi / masrafı otomatik muhasebeleştirilmez.

IADE XML için önce kaynak fatura aktarılmış ve kesinleşmiş olmalıdır. Aktarımda Kesinleşmiş seçeneğiyle açık onay gerekir. Yön ters çevrilerek kaynak faturanın düzeltme kaydı oluşturulur; kısmi / tam miktar, matrah ve KDV kaynakla doğrulanır. Belirsiz satır eşleşmesi, tevkifatlı / ek vergili iade ve farklı kur otomatik aktarılmaz.

Dosyadan aktarım gerçek e-Fatura gönderimi veya resmî yanıt işlemi yapmaz. CSV / XLSX sütun eşleştirme desteği korunur. Kaynak uygulamanın listelenmesi o sağlayıcının bütün özel dışa aktarma biçimlerinin sınandığı anlamına gelmez. Gerçek sağlayıcı örneği olmadan genel uyumluluk sözü verilmez.

## Abonelik ödeme iadesi
Firma: Üyelik paketim → Ödeme ve etkinleştirme → ödeme kaydını incele → İade talepleri ve üyelik iptali.
Yönetici: Ödemeler ve paket satışları → ilgili ödeme → İade talepleri ve üyelik iptali.

Firma yöneticisi tutar ve gerekçeyle talep açar. Aynı ödemede tek bekleyen talep bulunur. Yönetici şifresini doğrulayarak reddeder veya banka iadesi gerçekten gerçekleştikten sonra tarih, benzersiz banka referansı, tutar ve açıklamayla kaydeder. Bu form bankadan para göndermez. Karar ve gerekçe firmaya bildirilir.

Kısmi iadede üyelik korunur. Tam iadede iki seçenek vardır:
- Üyeliği koru: yalnız para iadesini kaydeder; süre ve kontörler değişmez. Özel müşteri anlaşmaları için açık yönetici kararıdır.
- Bu ödemenin üyelik etkisini geri al: 3.5.6 sonrası onaylanmış ödemenin önceki üyelik durumunu geri yükler. Önceki süre geçmişteki bitiş tarihiyle geri gelir, kullanılmış süre yeniden verilmez. Paket kontörleri ve kullanılmamış yıllık Plus hediyesi geri alınır. Hediye tekrar kazanılmaz.

Sonradan değişen üyelik, bekleyen diğer ödeme, yetersiz kontör, önceki pakete sığmayan kullanıcılar veya üyeliğe eklenmiş referans süresi varsa otomatik geri alma engellenir. Yönetici üyeliği koruyarak iadeyi kaydedip hakları ayrıca inceleyebilir. Davet eden firmanın kazandığı süreyi korumak ayrıca açıkça onaylanır. Eski ödemeler için geçmiş üyelik bilgisi uydurulmaz; yalnız üyeliği koruyan iade kaydı yapılabilir.

Ödeme aslı ve banka tahsilat kaydı denetim için korunur; iadeler ayrı hareketlerdir. Yönetici aylık iadeleri ayrıca görür. Toplam iadeler ilk ödeme tutarını geçemez.

## Güncelleme
029_refunds356 migration'ı iki tablo ekler. Önceki 28 migration korunur. Yeni tablolar firma silme ve uygulama yedeği temizliğine dahildir. Canlı kabul adımları OPERATIONS_356.md dosyasındadır. Dış servis aktivasyonu bu sürümde yapılmaz.
