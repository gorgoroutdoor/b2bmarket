# Kobivira 3.5.9

3.5.8 üzerine admin panelinden yüklenen imzalı güncelleme. Yeni kurulum değildir. Mevcut tasarım, 11 CSS dosyası, görsel dosya paketi ve PDF yerleşimi korunur. Fiyatlar, indirimler ve kullanıcı kotaları değiştirilmez.

## İptali geri alma
Firma yöneticisi iptal edilmiş teklif, proforma veya siparişi açıp İptali geri al düğmesine basar. Aynı kayıt ve numara korunur; belge düzenleme için Taslak olur. Düzenle → Kaydet → Kesinleştir adımlarından sonra yeni müşteri paylaşımı oluşturulur. Eski paylaşım bağlantıları yeniden açılmaz; geçmiş müşteri yanıtları saklanır.

Kapalı eski revizyon, aktif bağlı kayıt, yetkisiz kullanıcı, farklı firma veya üyeliği bitmiş hesap için işlem engellenir. İptal edilmiş satış / alış faturası bu işlemle açılmaz. İptal geri alınmadan doğrudan düzenleme isteği de reddedilir.

## Eski teklif neden açık görünüyordu?
3.5.8 önceki müşteri bağlantısını kapatıyor, belgenin kendisini Onaylandı durumunda tutuyordu. Bu sürüm yeni revizyon onaylandığında önceki belgeyi Revize edildi · kapalı durumuna alır. Orijinal tutar / kalem / belge numarası ve PDF korunur. Eski sürüm düzenlenemez, yeniden paylaşılamaz, dönüştürülemez ve iptali geri al ile açılamaz. Güncel revizyon bağlantısı belge ekranında yer alır.

031_close_revised_documents migration'ı 3.5.8'de onaylanmış açık revizyon ilişkilerine de bu durumu uygular ve önceki müşteri bağlantılarının kapalı olmasını sağlar. Yalnız açıkça kayıtlı revizyon ilişkileri kullanılır; birbirinden bağımsız oluşturulmuş benzer belgeler tahminle kapatılmaz. Eski iptal edilmiş kayıtlar kendiliğinden açılmaz.

## Teklif kabulü muhasebe kaydı değildir
- Müşterinin teklif / proforma / siparişi kabul etmesi ticari yanıttır. Tek başına satış, gelir, cari alacak, KDV veya kasa / banka hareketi oluşturmaz.
- Belge açık bir işlemle satış faturasına dönüştürülüp kesinleştirildiğinde satış ve cari alacak kayıtlarına yansır. Satış taslağı bu etkiyi oluşturmaz.
- Tahsilat ayrıca kaydedildiğinde kasa / banka tutarı artar ve ilgili alacak azalır. Satış veya KDV ikinci kez yazılmaz.
- Satış tutarı doğrudan kâr anlamına gelmez; kâr maliyet ve giderlerle ayrıca değerlendirilir. Bu kayıtlar resmî e-Belge gönderimi değildir.

## Teknik
Önceki 30 migration ve sürüm geçmişi korunur. 031 yalnız durum ve paylaşım kayıtlarını mevcut tablolarda günceller; yeni tablo eklemez. İptal geri alma işlem geçmişine yazılır. Dış servis / API aktivasyonu yapılmaz. Testler yereldir; canlı sistem bu çalışmada değiştirilmedi.
