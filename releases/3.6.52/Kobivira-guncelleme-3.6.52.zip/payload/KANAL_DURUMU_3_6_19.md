# 3.6.19 sonrası kalan entegrasyon işleri

- EDM: yeni izlenen belgelerle ticari ret, irsaliye kabul/ret/kısmi kabul, e-Arşiv/e-SMM raporları ve ihracat hata çözümü; her firmanın kendi canlı hesabıyla doğrulama. Önceki ortak test hesabında başkasının yanıtı kendi ret akışımızın başarı kanıtı değildir.
- EDM ticari süreç: gelir paylaşımında müşteri adına aktivasyon, tahsilat, kontör yükletme, faturalandırma ve müşteri ilişkisinin korunması için yazılı yanıt bekleniyor. Müşteri/ kontör satın alma API'si verilmedi.
- PayTR: gerçek ödeme başlatma, imzalı bildirim, tekrar bildirim koruması, üyelik eşleştirme ve başarısız/iade senaryoları.
- Otomatik banka / pazaryeri / e-ticaret / harici CRM: sağlayıcı seçimi ve gerçek adaptörler. Banka CSV/XLSX eşleştirmesi ve dahili CRM mevcut işlevlerdir.
- OCR / AI ve Meta / Google: uygulama içinde canlı sağlayıcı adaptörleri tamamlanmadı; müşteri kullanımına ve paket tanıtımına kapalıdır.
- E-posta / SMS: yapılandırılmış sağlayıcıyla gerçek teslim ve hata/yeniden deneme kontrolleri.
- Turkcell: yeni API/test/ticari belgeleri paylaşılınca değerlendirilecek; adaptör eklenmedi.
- Yedekleme: kullanıcının ertelediği hosting zamanlayıcısı ve geri yükleme provası tamamlanmalı.

Salt okunur firma API'si 3.6.19'da gerçek HTTP ile kontrol edildi. Bu işlem belge oluşturmaz ve ödeme almaz. Bu sürüm arayüz/paket/kütüphane düzenlemesidir; tüm dış entegrasyonların satışa hazır olduğuna dair onay değildir.
