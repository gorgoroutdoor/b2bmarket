# Kobivira 3.6.19 — Paket, panel ve kütüphane düzenlemesi

3.6.18 üzerine imzalı güncelleme paketidir. Yönetim → Sistem → Sürüm güncellemeleri alanından ZIP dosyası yüklenir. Kurulumdan sonra tarayıcıyı Ctrl+F5 ile yenileyin. Geri dönüş için güncellemenin oluşturduğu yedek ve mevcut kurtarma akışı kullanılır.

## Talep edilen düzenlemeler

| Madde | Sonuç |
| --- | --- |
| 1–3 | Üç paketin menüsü, özellik listesi, site karşılaştırması ve kütüphane paket bilgisi ortak özellik ayarını kullanır. Makbuz kaydı ile e-SMM ayrı yetkilerdir. |
| 4 | Müşteri ekranlarındaki eski geliştirme/demo/servis hazırlığı açıklamaları temizlendi. Gerçek servis durumları değiştirilmedi; ücretsiz deneme koşulları korunur. |
| 5, 12 | 87 rehber kaydı gözden geçirilip güncellendi/eklendi. Menü yolları, kategoriler ve elektronik belge adımları güncellendi; kullanılamayan bağlantı rehberleri müşteriye sunulmaz. |
| 6 | Tanıtım sitesinin paket kartları en fazla altı özellik gösterir; her kart tam karşılaştırmaya gider. Panelde ayrıntılı özellik listesi açılır bölümde bulunur. |
| 7 | Yönetim → Paketler → Paket ve fiyat yönetimi → Paket özellikleri alanında her paket için özellik ekleme/çıkarma yapılır. Fiyatlar, kullanıcı sınırları ve mevcut seçimler otomatik değiştirilmez. |
| 8–9 | Tekrarlanan karşılama/çalışma alanı metinleri kaldırıldı. Sekmeler, tablo satırı vurgusu ve yönetici menüsü lacivert/turkuaz temaya uyarlandı. |
| 10 | Masaüstünün sağ kenarında yardım bağlantısı kendi firma numarasındaki destek taleplerini açar. İstenen ücretli destek uyarısı yalnız ücretsiz deneme hesabında gösterilir. |
| 11 | Sayfa başlığında ana işlem düğmesinin yanında Nasıl Yapılır? bağlantısı bulunur. İşleme uygun yayımlanmış rehberi açar; izin kapsamı korunur. |
| 13 | Daraltılmış menüde ikonlar kalır. Fareyle veya klavyeyle kategori alt bağlantılarına erişilir. Üstte Tavsiye et, kazan ve üç bağlantılı Destek merkezi yer alır. |

Firma numarası ve /firma-numarası/ adresleri 3.6.18 ile aynı kalır. Başka firmanın adresi erişim yetkisi sağlamaz. Yönetim hesapları kök adreste çalışır.

## Çalışmayan bir hizmet çalışıyor gibi gösterilmez

Kartla tahsilat/PayTR, otomatik banka, pazaryeri/harici CRM, OCR/AI ve reklam sağlayıcı adaptörleri tamamlanmadığından müşteri menüsünde ve satış kapsamı listelerinde gösterilmez. Yönetici bu özellikleri paketlere seçebilir; ancak sağlayıcı adaptörü tamamlanmadan bu seçim hizmeti açmaz. Yönetim formunda bu koşul açıkça belirtilir. Firma bazında salt okunur veri API erişimi mevcut gerçek uç noktayı kullanır ve paket yetkisine göre denetlenir.

EDM doğrulama araçları yönetimde kalır; test/canlı adres ayrımı, sağlayıcı yanıtları ve gerçek hata mesajları güvenlik ve izlenebilirlik için değiştirilmez. Bu sürüm e-belge gönderme testlerinin geçtiğini veya PayTR'nin bağlandığını iddia etmez.

## Veri koruması ve denetim

İlk 41 geçiş dosyası değiştirilmedi. 42. geçiş yalnız Kobivira tanıtım sitesi ve kütüphane içeriklerini günceller; önceki içerikler CMS geçmişine yazılır. Başka firmaların web siteleri, faturaları, ödemeleri, fiyatları, kontörleri, servis şifreleri ve mevcut paket özellik seçimleri korunur. Hukuki metinler bu değişiklikle yeniden yazılmaz.

## Doğrulama

624 uygulama/veritabanı kontrolü; 62 gerçek HTTP akış kontrolü; 25 menü ve 8 kütüphane DOM etkileşimi kontrolü başarılı. Üç ücretli paket, yetki ekleme/çıkarma, firma izolasyonu, API erişimi, CSRF, rehber bağlantıları, kısa paket kartları, kamuya açık sayfalar ve ücretsiz deneme destek uyarısı kontrol edildi. Sağlayıcılara belge/ödeme gönderilmedi. Gerçek tarayıcı yerleşim kontrolü bu ortamda yapılamadı; kurulum sonrası masaüstü ve mobil görünüm ayrıca görülmelidir.

## Mevcut varsayılan paket kapsamları

Aşağıdaki listeler izole doğrulamadaki etkin özelliklerden çıkarılmıştır. Canlı yönetimde yaptığınız özel paket seçimleri korunur ve görünüm o seçimlerden üretilir. Kullanıcı sınırları yönetimdeki güncel plan kaydından okunur.

### KOBİ

- Müşteriye güvenli belge bağlantısı ve yanıt takibi
- Çalışan işlemlerinde yönetici onayı
- Bölüm bazında çalışan yetkileri
- İşlem geçmişi
- Satış, alış, gider, borç ve alacak takibi
- Standart teklif ve proforma · PDF
- Dosyaya aktarım

### KOBİ Plus

- Müşteriye güvenli belge bağlantısı ve yanıt takibi
- Çalışan işlemlerinde yönetici onayı
- Bölüm bazında çalışan yetkileri
- İşlem geçmişi
- Tarih / döviz filtreli cari ekstre · PDF ve Excel
- Kaynak faturaya bağlı kısmi / tam iade
- Serbest meslek makbuzu kayıt ve tahsilat takibi
- Alacak / borç yaşlandırma raporu
- Satış, alış, gider, borç ve alacak takibi
- Standart teklif ve proforma · PDF
- Sipariş yönetimi ve belge dönüşümleri
- Dövizli hesaplar, belgeler ve kur farkları
- Çek ve vade takibi
- Çalışan giderleri, avans ve geri ödeme
- Ürün miktar hareketleri ve barkod
- Haftalık, aylık ve yıllık tekrarlayan taslaklar
- Standart vade hatırlatmaları
- Dosyaya aktarım
- Standart kârlılık raporu
- İş takibi
- e-Fatura
- e-Arşiv
- Gelen e-Faturalar

### KOBİ Business

- Müşteriye güvenli belge bağlantısı ve yanıt takibi
- Çalışan işlemlerinde yönetici onayı
- Bölüm bazında çalışan yetkileri
- İşlem geçmişi
- Tarih / döviz filtreli cari ekstre · PDF ve Excel
- Kaynak faturaya bağlı kısmi / tam iade
- Serbest meslek makbuzu kayıt ve tahsilat takibi
- Alacak / borç yaşlandırma raporu
- Güvenli bağlantıyla cari mutabakat ve yanıt takibi
- Satış, alış, gider, borç ve alacak takibi
- Standart teklif ve proforma · PDF
- Sipariş yönetimi ve belge dönüşümleri
- Dövizli hesaplar, belgeler ve kur farkları
- Çek ve vade takibi
- Çalışan giderleri, avans ve geri ödeme
- Ürün miktar hareketleri ve barkod
- Haftalık, aylık ve yıllık tekrarlayan taslaklar
- Standart vade hatırlatmaları
- Dosyaya aktarım
- Standart kârlılık raporu
- İş takibi
- İş / proje kârlılığı
- Satış fırsatları ve müşteri etkileşimleri
- 30 / 60 / 90 günlük nakit öngörüsü
- Tutar eşiği ve iki aşamalı onay
- Özelleştirilebilir takip kuralları
- Banka CSV / XLSX dosyası eşleştirme
- Seçili belgelerde toplu kategori / etiket işlemi
- Kategori, etiket ve tarih filtreli raporlar
- Düzenlenebilir belge başlığı, koşullar ve dipnot
- Salt okunur veri API erişimi
- e-Fatura
- e-Arşiv
- Gelen e-Faturalar
- e-İrsaliye
- Gelen e-İrsaliyeler
- e-SMM
- e-İhracat

SMMM/YMM erişimi çalışan kotası dışındadır. Ücretli destek, üyelik süresine bağlıdır. Servis kullanımı için firmanın kendi aktivasyonu ve servis hesabı gerekir. Paket kontör kaydı ile EDM hesabının servis bakiyesi farklıdır.
