# EDM 3.6.4 – Kabul/ret alanları için açıklama

Bu güncelleme, belge detayında kabul/ret formunun neden görünmediğini açıklar. Belge yönünü ve yerel yanıt denemesini gösterir. Giden kayıttan aynı firmaya ve UUID bilgisine ait gelen kayda bağlantı verir.

Önceki sürümde yanıt denemesi kayıtlıysa form açıklamasız kapanıyordu. Yerel testte bu davranış yeniden üretildi. Mevcut canlı firma veritabanına erişim olmadığı için KVT2026000000003 kaydındaki yerel yanıt denemesinin değeri doğrulanmış değildir.

22.10.2026 tarihinde EDM test servisinden UUID bb4b9625-cead-493d-aaea-81f3bf9b212e salt okunur sorgulandı. IN: RECEIVE - WAIT_APPLICATION_RESPONSE; OUT: SEND - WAIT_APPLICATION_RESPONSE. RESPONSE_CODE ve RESPONSE_DESCRIPTION boş döndü. Bu belge için ret tamamlanmış sayılmaz. Bu kontrol sırasında gönderim, kabul veya ret isteği yapılmadı.

Belirsiz sonucu olan önceki istek otomatik yinelenmez ve yanıt denemesi kaydı silinmez. Eski bir deneme varsa yeni ekran bunun adını gösterir; durum hâlâ beklemedeyse servis tarafında inceleme gerekir. Bu sürüm o kayıt için yeniden yanıt gönderme yetkisi açmaz.

## Kurulum ve sonraki kontrol

3.6.3 sürümünün sistem güncelleme ekranından imzalı 3.6.4 ZIP paketini yükleyin. EDM test alanında KVT2026000000003 faturanın IN kaydını açın. Belge yönü ve Kayıtlı yanıt denemesi alanlarını kontrol edin. Deneme yoksa gelen ticari faturanın kabul/ret formları görünür. Deneme RED/KABUL ise ekrandaki açıklamayı izleyin; aynı faturayı yeniden yüklemeyin.

## Doğrulama

11 yeni görünüm kontrolü: yanıtlanmamış IN ticari belge, ret gerekçesi, kabul/ret kontrolleri, önceki RED/KABUL denemeleri, tamamlanmış yanıt, OUT–IN bağlantısı, senaryo uyumsuzluğu ve eksik gelen kayıt. PHP/JavaScript sözdizimi, önceki 33 migration ve sürüm geçmişinin korunması kontrol edildi. İmzalı paket kurulum testi ayrıca yürütülür.

Bu sürüm satışa hazır olunduğunu veya kalan e-belge testlerinin geçtiğini ifade etmez.
