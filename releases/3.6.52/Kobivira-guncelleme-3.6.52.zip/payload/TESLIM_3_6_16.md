# 3.6.16 — Firma menüsü ve paket özellikleri

Bu dosyayla birlikte verilen imzalı güncelleme ZIP'i **3.6.15 üzerine** yönetimin sürüm güncelleme alanından yüklenir. Kaynak arşivi veya anahtar dosyası yüklenmez. Sunucuda elle dosya değiştirilmesi gerekmez. Mevcut güvenilir imzalama anahtarı kullanılmıştır; güncelleyicinin doğrulaması değiştirilmemiştir.

## Firma panelinde değişenler

Elektronik Belgeler artık Satışlar'dan ayrı ana kategoridir. Paket ve kullanıcı yetkisi kapsamındaki e-Fatura, e-Arşiv, e-İrsaliye, e-SMM ve e-İhracat bağlantıları doğrudan kendi belge listelerini açar. Gelen e-Faturalar ve Gelen e-İrsaliyeler de bu kategoridedir. Her türün ekranında yeni belge düğmesi bulunur. Paket yükseltme/üst paket etiketleri menüden kaldırılmıştır; yetki dışındaki bağlantılar gösterilmez.

Firma menüsündeki sıralama ve adlar tek tanımdan gelir. Kategoriler: Satışlar; Elektronik Belgeler; Alışlar ve Giderler; Müşteri ve Tedarikçiler; Ürün ve Hizmetler; Kasa ve Banka; İş ve Müşteri Takibi; Raporlar; Web ve Reklam; Firma ve Ayarlar; Destek ve Rehberler. Boş veya yetki dışındaki kategoriler gösterilmez. Yönetimin kendi menüsü ayrıdır.

Belge hazırlarken mevcut onaylı satış/makbuz seçilir. Kayıt yoksa aynı ekrandaki Satış kaydı oluştur veya Makbuz kaydı oluştur düğmesiyle mevcut kayıt işleyişine gidilir. Kayıt onaylandıktan sonra ayrıntısındaki Elektronik belge hazırla düğmesiyle devam edilir. Muhasebe kaydı oluşturma veya onaylama kuralları bu arayüz düzenlemesi için atlanmaz.

Firma bağlantı formunda ortam seçimi ve test hesabını devralma kutusu bulunmaz; yalnız firmanın kendi canlı servis hesabı tanımlanır. Önceki sandbox kayıtları silinmez, normal firma listelerine veya indirme ekranına karıştırılmaz. Eski sandbox hesap yerine canlı hesap tanımlanabilir; önceki canlı belgeleri bulunan hesabın kimliğini değiştirmeye ilişkin koruma devam eder. Test araçları yönetimde kalır.

## Yönetim ve kütüphane

Yönetim → Paketler → Paket ve fiyat yönetimi alanında paket başına özellikler kategori bazında seçilebilir. Tümünü seç/seçimi temizle desteklenir; mevcut yönetici şifresi gerekir. Eski açılmış formun daha yeni ayarı ezmesi engellenir. Yeni yetkiler o paketteki mevcut firmalara da yansır. Özellik kapatılması kayıt silmez.

Kullanım kütüphanesi, rehberdeki Panelde nerede alanı ve paket özellik listeleri aynı kapsamı izler. 84 rehber kaydı menü yollarıyla ilişkilidir. Eski rehber içerikleri güncellenirken CMS geçmişine alınır.

## Doğrulama

Bu teslimde 150 PHP dosyası sözdizimi kontrolünden geçti. İzole MariaDB/PHP ortamında 211 kontrol başarılı: gerçek imza denetimi ve 3.6.15 → 3.6.16 güncellemesi, 40 geçiş, önceki 39 geçişin korunması, geçişi tekrar çalıştırma, firma/abonelik/fiyat/kayıtların korunması, üç paketin gerçek menüleri, yönetim araçlarının ayrılığı, test ibaresi bulunmayan beş belge ekranı, canlı bağlantı formu, beş hazırlama ekranı, yönetimden paket yetkisi ekleme ve eski form çakışma koruması. Mevcut müşteri/satış/satır ve test hesap/belge örnekleri veri koruma kontrolünde kullanıldı.

Hosting üzerinde kurulum ve gerçek firma canlı gönderimi bu teslimde yapılmamıştır. Yeni EDM gönderimi yapılmamıştır. Önceki irsaliye nihai yanıtı, ihracat başarısızlık incelemesi ve PayTR işi tamamlanmış sayılmaz. Paket yetkisi açmak, sağlayıcı canlı hizmet izni yerine geçmez. Firma kendi canlı hesabını doğrulamalı; yönetim yalnız doğruladığı hizmet türlerini açmalıdır. Gerçek sağlayıcı hataları ve bekleyen durumlar başarılı gösterilmez.
