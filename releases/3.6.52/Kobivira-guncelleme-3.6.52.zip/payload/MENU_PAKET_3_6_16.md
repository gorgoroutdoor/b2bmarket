# 3.6.16 — Paket özellikleri ve firma menüsü

- Yönetim → Paketler → Paket ve fiyat yönetimi: her paket için özellik seçimleri. Fiyat, kullanıcı ve kontör alanları mevcut işlevini korur. Kaydetmek için mevcut yönetici şifresi gerekir.
- Özellik seçimi tüm pakete uygulanır; yeni firmalarla sınırlı değildir. Form sürümü değişmişse eski formun kaydı reddedilir.
- e-Fatura, e-Arşiv, gelen e-Fatura, e-İrsaliye, gelen e-İrsaliye, e-SMM ve e-İhracat bağımsız seçilir. Kaynak satış/makbuz özelliği gerektiğinde birlikte eklenir.
- Firma menüsü yalnız paket ve rolün kapsadığı bağlantıları gösterir. Elektronik belge türleri doğrudan kendi listelerini açar. Yandaki kayan menü kaldırılır.
- Site ve panel paket listeleri aynı seçimleri okur. Web/reklam modüllerinin genel açma/kapama ayarı ayrıca geçerlidir. Mevcut süreli firma hizmet yetkileri korunur.
- 040 geçişi ayarları önceki paket kapsamından başlatır. Önceki 39 geçiş değiştirilmez. Firma verisi, belge, fiyat ve kota silinmez. Rehber güncellemesinden önce eski içerik CMS geçmişine alınır; URL, yayın durumu ve SEO makalesi korunur.
- Rehberlerde menü yolu, güncel paket kapsamı ve ilgili panel ekranına bağlantı bulunur. Eski rehber adresleri korunur; yedi e-belge rehberi eklenir.
- Paket seçimi canlı servis aktivasyonu yerine geçmez. e-belge gönderim, rapor, iptal ve gümrük doğrulama sınırları 3.6.15 ile aynıdır.

## Doğrulama sınırı

Bu teslimin güncel doğrulama sonuçları ve kurulum sınırları TESLIM_3_6_16.md dosyasındadır.
