# Kobivira 3.5.2

Bu tam kurulum değildir. 3.5.1 üzerine yönetim panelinin Sürüm güncellemeleri bölümünden ZIP olarak yüklenir; ZIP açılmaz. Eski 25 migration dosyası ve mevcut temel CSS dosyaları değiştirilmemiştir. Eklenen migration: 026_public_library_leads.php.

## Değişiklikler

- Yönetim ve sürüm yönetimi rehberleri halka açık kütüphaneden, kategori listesinden ve rehber JSON dosyasından çıkarıldı; doğrudan bağlantıları 404 verir. Yönetici içerik yönetimi erişimi korunur.
- Yeni veri taşıma, ekstre, iade, yaşlandırma, mutabakat, makbuz, üyelik ve elektronik belge rehberleri mevcut kütüphane makale düzeniyle, kategori menüsü ve kütüphaneye dönüş bağlantısıyla gösterilir.
- Eski Business Plus tanıtım duyurusu ve istenmeyen iki servis uyarısı kaldırıldı. Sağlayıcı bağlantıları bu sürümle etkinleştirilmez.
- Yeni standart kayıtlar 14 gün denemedir. Güncel site metinleri, SEO açıklamaları ve rehber metinleri güncellendi. Var olan firmaların kazanılmış bitiş tarihleri değiştirilmez; üç aylık veri taşıma kampanyası ayrı kalır.
- Marka renklerinde, kaydırmada görünen, ziyaret boyunca kapatılabilen 14 GÜN / ÜCRETSİZ / DENEYİN balonu eklendi. Azaltılmış hareket tercihi desteklenir.
- Tanıtım penceresi: ziyaret başına bir kez kaydırmada açılır; mobilde tek sütuna geçer. Formda kişi, şirket, telefon, e-posta ve boş başlayan zorunlu onay kutusu bulunur. Metin bağlantısı ayrı sekmede açılır. CSRF, alan doğrulama, istek tekrarı koruması, hız sınırı ve bot alanı kullanılır.
- Site yönetimi → Tanıtım penceresi ve başvurular: başlık, açıklama, görsel, bilgilendirme bağlantısı ve aktif/pasif ayarı. Görsel önce Tanıtım sitesi → Görseller bölümüne yüklenir. Pencere varsayılan olarak kapalıdır; içerik ve bilgi bağlantısı kontrol edilip etkinleştirilmelidir.
- Başvurular yönetim ekranında Yeni / İletişime geçildi / Tamamlandı durumlarıyla takip edilir. Yeni başvuru sayısı menüde görünür. Onay metni, bağlantısı ve zamanı kaydedilir. Bu özellik otomatik telefon araması, e-posta veya SMS göndermez.
- Web modülü yönetici tarafından seçilen paketlerde, geçerli deneme hesaplarında da açılır. Modülün etkin olması ve firmaya site tanımlanması gerekir. Süresi bitmiş / askıdaki deneme hesabına yazma veya yayın yetkisi verilmez.
- Üyeliği düzenle ekranında kontör bakiyesi ve ekleme / düşme formu bulunur. Ayrı Kontör yönetimi sekmesi korunur. Mevcut parola doğrulaması ve tek işlem koruması kullanılır.
- Firma doğrulamasında güncel firma kararı ve son başvuru bağlantısı gösterilir. Son Eksik bilgi başvurusu, bütün evraklar ayrı ayrı onaylanmış ve başvurunun firma bilgileri / evrak sürümleri güncel ise sonuçlandırılabilir. Eski başvuruların kararı otomatik değiştirilmez.
- Hukuki metinlerde yeni sayfa ekleme, HTML editörü, sürüm yayınlama ve sayfa silme eklendi. Silme sayfayı yayından kaldırır; kabul edilmiş eski metin sürümleri ve üyelik onay kayıtları korunur. Silinen sayfa aynı kodla geri açılabilir. Zorunlu üç üyelik metninden biri silinirse yeniden yayımlanana kadar yeni kayıt engellenir; mevcut hesap girişi etkilenmez.

## Yerel doğrulama

- 174 mevcut paket / uygulama HTTP kontrolü ve 21 veri / yetki kontrolü.
- 61 yeni gerçek HTTP kontrolü: tanıtım sitesi giriş dosyasının yönlendirmesi, gerçek form kaydı ve tekrar koruması, izin zorunluluğu, şirketlerin yönetici başvurularına erişememesi, görselin ana alan adından sunulması, başka firmaya ait görselin reddi, kontör ekleme, firma onayı, hukuki sayfa yaşam döngüsü ve rehber erişimi.
- 15 yeni veri / güvenlik kontrolü: 14 günlük gerçek süre, tek kontör artışı, tek başvuru kaydı, onay geçmişinin korunması, eski başvuru veya onaysız evrakla firma onayının engellenmesi, süresi biten / askıya alınan denemenin web yetkisinin kapanması.
- 14 JavaScript / CSS kontrolü: kaydırma, ziyaret içinde tekrar açılmama, balon kapatma, Escape, metin girerken kesintiye uğratmama, form sonucu / hata ve tekrar deneme, mobil tek sütun kuralları, azaltılmış hareket.
- 108 muhasebe / veri taşıma regresyon kontrolü: cari ekstre, iadeler, yaşlandırma, mutabakat, makbuz, dosya aktarımı, dosya şifreleme ve diğer mevcut işlevler.

Testler yerel PHP 8.3 / MariaDB ortamındadır. Gerçek hosting üzerinde uygulama ve tarayıcıda görsel masaüstü / mobil kontrol yapılmamıştır. CSS / DOM kontrolü, gerçek tarayıcı görüntü kontrolü yerine sunulmamaktadır. Mevcut firma verileriyle ilk yüklemede hosting yedeği de tutulmalıdır.

- 110 PHP uzantılı dosyanın sözdizimi kontrolü tamamlandı.
- Gerçek 3.5.1 güncelleyicisinde 13 paket / kurulum kontrolü geçti: mevcut güven anahtarıyla imza doğrulama, değiştirilmiş içeriğin reddi, 3.5.2 etkinleştirme, bütün dosya özetleri, 26 migration, önceki firma ve deneme tarihinin korunması, sürüm notları ve güncelleme kaydı.
- Toplam 406 yerel işlev / yetki / veri / istemci / güncelleyici kontrolü geçti; buna ek olarak 110 dosyanın sözdizimi kontrolü yapıldı. Kontrol sayısı gerçek tarayıcı görsel testini ifade etmez.
