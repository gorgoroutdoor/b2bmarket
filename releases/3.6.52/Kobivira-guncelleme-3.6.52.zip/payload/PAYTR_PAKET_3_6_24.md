# Kobivira 3.6.24 — Firma paket satın alma

3.6.23 üzerine imzalı güncellemedir. Firma panelinin menü ve tasarım düzeni korunur. Bu sürümde PayTR kart ödemesi KOBİ, KOBİ Plus ve KOBİ Business satın alma/yenileme akışına bağlanır. Havale/EFT yönetici onayında kalır. Kontör satın alma kapalıdır.

## Kurulum ve ilk test

1. Yönetimde Güncellemeler bölümüne ZIP dosyasını yükleyin. Kurulu sürüm 3.6.23 olmalıdır.
2. Yönetim → Sistem → PayTR ödeme ayarları bölümündeki mevcut mağaza numarası, anahtar ve salt korunur. Bunları firmalar girmez veya görmez. Sunucunun PHP cURL eklentisi ve PayTR'ye doğrulanmış HTTPS dış bağlantısı bulunmalıdır.
3. PayTR Mağaza Paneli → Destek & Kurulum → Ayarlar → Bildirim URL alanında `https://app.kobivira.com.tr/?page=paytr_callback` adresi kayıtlı olmalıdır. GET ile açılınca METHOD görülmesi normaldir.
4. Kobivira PayTR ayar sayfasındaki **Firma paket ödemeleri** kartını açın. **Test · yalnız seçilen firma** modunu ve test edeceğiniz firmayı seçin. Kobivira yönetici şifrenizle kaydedin. İlk kurulumda kart ödemeleri kapalıdır; güncelleme kendiliğinden gerçek tahsilat başlatmaz.
5. Seçtiğiniz firma hesabında **Üyelik paketim → Paketler** bölümüne girin. Paket, ödeme dönemi ve **Kredi / banka kartı** seçin. Koşulları onaylayıp satın alma düğmesine basın. Ödeme kaydında ödeyen bilgilerini tamamlayın, **Kartla öde** düğmesine basın. PayTR'nin test kartı ve doğrulama adımlarıyla ilerleyin.
6. PayTR ekranından firma panelindeki ödeme kaydına dönülür. PayTR bildirimi ulaştığında test sonucu görünür. Test ortamı gerçek ücret çekmez, gerçek üyeliği veya kontörü değiştirmez. Test firması ekranında bu bilgi açıkça belirtilir; diğer firmalar yalnız Havale/EFT görür.
7. Başarılı testin ardından yeni talep ile başarısız ödeme senaryosunu da deneyin. Aynı referansı tekrar ödemeyin. Bildirim bekleniyorsa **Sonucu yenile** yalnız kayıtlı durumu okur; yeni ödeme oluşturmaz.
8. Havale için sonuçlanmamış test taleplerini sonuçlandırdıktan sonra yeni paket seçerken **Havale / EFT** seçin. Banka bilgileri ve talep referansı gösterilir. Havale bildirimini gönderdiğinizde **Yönetici onayı bekleniyor** olmalıdır; paket açılmamalıdır. Yönetim → Ödemeler ve paket satışları bölümünde banka hesabınızdan doğruladığınız havaleyi onaylayınca paket açılır.

## Canlı kullanım

PayTR mağazasının canlı ödeme yetkisi ve testleri doğrulandıktan sonra yönetimde **Canlı · firmalar kartla paket alabilir** seçilir. Gerçek tahsilatı açma onayı ve yönetici şifresi gerekir. Kobivira ayarını değiştirmek PayTR'nin kendi mağaza onayını sağlamaz.

- Firma paketini ve dönemini seçer; Kredi/banka kartı veya Havale/EFT kullanır.
- Tutar, KDV ve varsa indirim kayıtlı paket fiyatından sunucuda hesaplanır; tarayıcıdan gönderilen tutar kullanılmaz.
- Kart bilgileri PayTR ekranına girilir; Kobivira kart bilgisi saklamaz.
- Ödeme dönüşü firmayı kendi `app.kobivira.com.tr/FIRMANUMARASI/` alanındaki ödeme kaydına götürür. Dönüş köprüsü çerçeveden üst pencereye geçer; dış adrese yönlendirme kabul etmez ve kendi başına paketi açmaz. Oturum sona ermişse yeniden giriş gerekir.
- PayTR'nin imzalı başarılı bildirimi doğrulanınca ödeme ve paket aynı veritabanı işlemi içinde sonuçlanır. Aynı pakette yenileme mevcut ücretli bitişe eklenir; paket değişikliğinde mevcut kalan süre politikası uygulanır.
- Tekrarlanan form ve bildirimler ikinci süre veya hediye kazandırmaz. Başarısız kart ödemesi paketi değiştirmez.
- Aktif bir belirsiz kart ödemesi varken ikinci talep oluşturulmaz. Önceki talebin yöntemi/paketi/dönemi farklıysa yeni seçime sessizce geçirilmez; firma mevcut talebi kontrol eder.
- Ödeme alınmışken firma kısıtlanmış veya üyelik/kullanıcı koşulları değişmişse tahsilat bilgisi korunur, paket otomatik değiştirilmez. Firma “Ödeme alındı · etkinleştirme kontrol ediliyor” görür; yönetimde Kart incelemesi alanına düşer. Koşullar düzeltildiyse yetkili yönetici doğrulanmış ödemeyi yeniden değerlendirebilir. Uyuşmayan üyelik süreleri gibi durumlar ayrıca incelenmelidir; tekrar tahsilat yapılmaz.
- Havale onayı kart ödemesine uygulanamaz. Havale bildirimi tek başına üyeliği etkinleştirmez.
- PayTR bildirimi bakım sırasında gelirse 503 yanıtıyla tekrar istenir. Canlı ayarı sonradan kapansa da önceden oluşturulmuş geçerli ödemelerin bildirimi kaybolmaz. Yeni token isteği mod değişiminde durdurulur.

## Kontör ve e-belge sağlayıcısı

Firma panelindeki satın alma bağlantısı **Kontörlerim** olarak değiştirilmiştir. Bakiye/hareketler görülebilir; yeni kontör siparişi, havale bildirimi ve kart ödemesi firma tarafından başlatılamaz. Eski kayıtlar silinmez. Yönetici mevcut kontör kayıtlarını yönetebilir.

Ödeme kayıtlarında sağlayıcı, sipariş türü, üyelik/kontör sipariş bağlantıları, tutar, ortam ve imzalı sonuç alanları ayrıdır. Kontör siparişleri için bağlantı alanı bulunur; ancak kontör için ödeme veya bakiye yükleme yolu çalıştırılamaz. EDM veya Turkcell servisine başvuru, satın alma, bakiye yükleme isteği gönderilmez. İleride anlaşılacak sağlayıcı bu katmana bağlanabilir; ilgili sağlayıcının API yetenekleri ayrıca doğrulanmalıdır.

Paketin mevcut kapsamındaki dönem kontörü ve yıllık Plus hediyesi politikası korunur. Bunlar Kobivira'nın kayıtlı bakiyesidir; bir e-belge sağlayıcısına otomatik yükleme değildir. Kontör satın alma ödemesinden ayrıdır.

## Sınırlar

Bu sürüm tek seferlik paket satın alma ve yenileme ödemesidir; kart saklama veya otomatik düzenli çekim eklenmemiştir. PayTR otomatik iade API'si eklenmemiştir. Mevcut iade talep/kayıt akışı para göndermez; gerçek kart iadesi PayTR'den ayrıca gerçekleştirilip referansıyla kayda alınmalıdır. Firmaların kendi satış faturalarından müşterilerine kartla tahsilat bağlantısı bu sürümün kapsamına dahil değildir.

111 yerel kontrol (59 PHP/veritabanı, 52 gerçek yerel HTTP) ve 162 PHP dosyasının sözdizimi kontrolü geçti. 3.6.23 → 3.6.24 imzalı güncellemesi ayrı veritabanında kuruldu; eski 43 migration dosyası değiştirilmedi. Önceki kayıtların korunması, her üç paketin imzalı ödemeyle etkinleşmesi, fiyat manipülasyonu, tekrar bildirim, başarısız ödeme, firma ayrımı, test/canlı ayrımı ve havale yönetici onayı doğrulandı. PayTR token yanıtı kontrollü taklitle üretildi; PayTR hesabınızla gerçek servis isteği yapılmadı. Bu sonuçlar sağlayıcının canlıya geçiş onayı değildir. Görsel tarayıcı ve gerçek 3D Secure dönüş testi sunucuya kurulum sonrasında yapılmalıdır.

Resmî teknik kaynaklar: https://dev.paytr.com/iframe-api/iframe-api-1-adim ve https://dev.paytr.com/iframe-api/iframe-api-2-adim
