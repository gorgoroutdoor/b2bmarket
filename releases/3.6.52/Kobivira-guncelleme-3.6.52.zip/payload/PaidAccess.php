<?php
declare(strict_types=1);
function paid_member(): bool {return paid_support(company_id());}
function require_paid(string $feature='Bu işlem'): void {if(!paid_member()){http_response_code(403);$GLOBALS['paid_required']=true;throw new DomainException($feature.' yalnız kullanım süresi devam eden ücretli üyeliklerde kullanılabilir. Paket seçip ödemenizi tamamlayabilirsiniz.');}}
function paid_notice(string $feature): void {echo '<div class="info-note"><strong>'.esc($feature).' ücretli üyeliklerde kullanılabilir.</strong><p>Ücretsiz deneme hesabınızda bu alanı inceleyebilirsiniz. İşlem yapmak için paketinizi etkinleştirin.</p>'.a('membership','Paketleri incele',['view'=>'plans'],'button primary').'</div>';}
function contact_creation_notice(string $kind): void {
 $supplier=in_array($kind,['purchase','expense'],true);echo '<div class="info-note no-print" id="contact-start-note"><strong>Önce '.($supplier?'tedarikçiyi':'müşteriyi').' seçin</strong><p>Kayıtlı '.($supplier?'tedarikçinizi':'müşterinizi').' aşağıdaki arama alanından bulun. Listede yoksa yeni cari kart ekleyebilirsiniz. Ürün kartı açmadan belge satırına ürün veya hizmet adını yazabilirsiniz.</p>';
 if((paid_member()||trial_contact_available())&&(!support_context()||support_allowed('contacts',true))&&(!team_member()||employee_allowed('quick_contact',[],true)))echo '<button class="button quiet" type="button" id="quick-contact-open">Yeni '.($supplier?'tedarikçi':'müşteri').' ekle</button>';
 elseif(!paid_member())echo '<p>Denemede toplam 5 cari kart sınırına ulaştınız. Yeni kayıt için ücretli üyeliğinizi etkinleştirin.</p>'.a('membership','Paketleri incele',['view'=>'plans'],'button');echo '</div>';
}
