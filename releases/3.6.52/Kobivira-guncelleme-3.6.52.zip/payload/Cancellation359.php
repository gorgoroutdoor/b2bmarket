<?php
declare(strict_types=1);
function cancel359_restorable(array $d): bool {
 return in_array($d['kind'],['quote','proforma','order'],true)&&$d['status']==='cancelled'&&!revision358_child((int)$d['id']);
}
function cancel359_restore(int $id): void {
 firm_manager();require_write();if(!db()->inTransaction())throw new LogicException('İptal geri alma işlem kilidi gerektirir.');$d=tenant_row('documents',$id,true);need_feature($d['kind']==='order'?'orders':'quotes');
 if(!cancel359_restorable($d))throw new DomainException('Yalnız iptal edilmiş güncel teklif, proforma veya siparişin iptali geri alınabilir. Revizyonla kapanmış eski belge tekrar açılamaz.');
 if(query("SELECT id FROM documents WHERE company_id=? AND source_id=? AND status<>'cancelled' LIMIT 1",[company_id(),$id])->fetchColumn())throw new DomainException('Bu belgenin aktif bağlı kaydı var. Önce bağlı belgeleri inceleyin.');
 if(query('SELECT id FROM payments WHERE company_id=? AND document_id=? AND reversed_at IS NULL LIMIT 1',[company_id(),$id])->fetchColumn())throw new DomainException('Bağlı tahsilat / ödeme varken bu işlem yapılamaz.');
 // Never revive old customer tokens when the document is approved again.
 query('UPDATE record_shares SET revoked_at=COALESCE(revoked_at,UTC_TIMESTAMP()) WHERE company_id=? AND document_id=?',[company_id(),$id]);query("UPDATE documents SET status='draft' WHERE company_id=? AND id=?",[company_id(),$id]);audit('document.cancel_reversed',['id'=>$id,'status'=>'draft','reason'=>'İptal geri alındı. Düzenleme için taslağa dönüldü; eski paylaşım bağlantıları kapalı kalır.']);
}
function cancel359_panel(array $d): void {
 if(!in_array($d['kind'],['quote','proforma','order'],true))return;
 if($d['status']==='superseded')echo '<div class="info-note no-print">Bu belge yeni revizyonla kapatıldı. Geçmiş ve PDF korunur; işlem yapmak için güncel revizyonu açın.</div>';
 elseif($d['status']==='cancelled')echo '<div class="info-note no-print">İptal edilmiş belge düzenlenemez. Uygunsa İptali geri al düğmesiyle taslağa dönün; düzenleyip yeniden onaylayın. Eski müşteri bağlantıları açılmaz.</div>';
 elseif($d['status']==='draft'&&query("SELECT id FROM audit_logs WHERE company_id=? AND action='document.cancel_reversed' AND JSON_UNQUOTE(JSON_EXTRACT(metadata,'$.id'))=? LIMIT 1",[company_id(),(string)$d['id']])->fetchColumn())echo '<div class="info-note no-print">İptal geri alındı. Düzenle düğmesiyle değişiklikleri kaydedip yeniden kesinleştirin. Sonrasında yeni müşteri paylaşım bağlantısı oluşturun.</div>';
}

function revision359_latest(array $child): array {
 $seen=[];while(!isset($seen[(int)$child['document_id']])){$seen[(int)$child['document_id']]=true;$next=revision358_child((int)$child['document_id']);if(!$next)break;$child=$next;}return $child;
}
