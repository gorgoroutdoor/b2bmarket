<?php
declare(strict_types=1);
function public_site(): never {
 if($_SERVER['REQUEST_METHOD']!=='GET'){http_response_code(405);exit;}
 $files=json_decode(file_get_contents(__DIR__.'/PublicSite.json'),true,32,JSON_THROW_ON_ERROR);$path=is_string($_GET['path']??null)?$_GET['path']:'index.html';
 if($path==='download.zip'){
  if(!is_file(APP_ROOT.'/config/installed.lock')||!current_user()||!owner()||support_context()){http_response_code(403);exit('Yönetici erişimi gerekir.');}
  $tmp=tempnam(APP_ROOT.'/storage','site-export-');$z=new ZipArchive();if($z->open($tmp,ZipArchive::OVERWRITE)!==true)throw new RuntimeException('Dışa aktarım hazırlanamadı.');foreach($files as $name=>$file)$z->addFromString($name,base64_decode($file['data'],true));$z->close();header('Content-Type: application/zip');header('Content-Disposition: attachment; filename="Kobivira-tanitim-sitesi-3.3.3.zip"');header('Content-Length: '.filesize($tmp));readfile($tmp);unlink($tmp);exit;
 }
 if(!isset($files[$path])){http_response_code(404);header('Content-Type: text/plain; charset=utf-8');exit('Sayfa bulunamadı.');}
 if(preg_match('~rehber-(yonetim|surumler)\.html$~D',$path)){http_response_code(404);exit('Sayfa bulunamadı.');}$file=$files[$path];$content=base64_decode($file['data'],true);if(str_starts_with($file['type'],'text/html'))$content=public352_copy($content);
 header('Content-Type: '.$file['type']);header("Content-Security-Policy: default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' https://app.kobivira.com.tr; media-src https:; frame-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'self'");
 if($file['type']==='text/html; charset=utf-8'){
  $content=str_replace('https://app.kobivira.com.tr/?page=marketing_data','?page=marketing_data',$content);$content=preg_replace_callback('/\b(href|src)="([^"#?][^"]*)"/',function($m)use($files){$target=html_entity_decode($m[2],ENT_QUOTES|ENT_HTML5,'UTF-8');if(preg_match('~^[a-z][a-z0-9+.-]*:|^//~i',$target))return $m[0];$name=preg_split('/[?#]/',$target,2)[0];if(!isset($files[$name]))return $m[0];$hash=str_contains($target,'#')?'#'.explode('#',$target,2)[1]:'';return $m[1].'="?page=showcase&amp;path='.rawurlencode($name).esc($hash).'"';},$content);
 }
 echo $content;exit;
}
