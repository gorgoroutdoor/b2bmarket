(() => {
 const body=document.body;
 document.querySelectorAll('[data-print]').forEach(el=>{el.addEventListener('click',e=>{e.stopImmediatePropagation();const id=new URLSearchParams(location.search).get('id');if(id){const u=new URL(location.href);u.searchParams.set('page','print_document');u.searchParams.set('id',id);window.open(u.href,'_blank','noopener,noreferrer');}},true);});
 let seen=0;document.addEventListener('kobivira:poll-data',e=>{const n=e.detail.company_notices;if(n){const badge=document.getElementById('firm-notice-count');if(badge){badge.hidden=!n.unread;badge.textContent=n.unread||'';}const last=n.items?.[0],alert=document.getElementById('firm-notice-alert');if(last&&alert&&last.id>seen){seen=last.id;alert.hidden=false;alert.querySelector('strong').textContent=last.title;alert.querySelector('p').textContent=last.body;if(last.open_url)alert.querySelector('a').href=last.open_url;}}
 const t=e.detail.task_reminder;if(t){document.querySelectorAll('[data-task-count]').forEach(el=>{el.textContent=t.count||'';el.hidden=!t.count;});}});
 document.querySelector('[data-close-firm-notice]')?.addEventListener('click',()=>document.getElementById('firm-notice-alert').hidden=true);
 const method=document.querySelector('[name=method]'),acc=document.querySelector('select[name=account_id]');method?.addEventListener('change',()=>{const kind=method.value==='cash'?'cash':['bank_transfer','card'].includes(method.value)?'bank':null;if(!kind||!acc)return;const option=[...acc.options].find(o=>o.dataset.kind===kind);if(option)acc.value=option.value;});
})();
