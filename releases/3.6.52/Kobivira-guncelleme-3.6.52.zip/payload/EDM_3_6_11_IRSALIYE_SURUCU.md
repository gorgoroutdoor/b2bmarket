# 3.6.11 — mükerrer sürücü ve ayrıntılı zarf geçmişi

KVI2026000000002, UUID 83fd6cf1-6e1b-4709-8195-ba92a82f03f0, SEND - FAILED oldu. Salt okunur GetDespatch/GetDespatchStatus yanıtları sebebi açıklamadı; GetEnvelope belge UUID'si ile sorgulandığında 1164 ve MUKERRER KAYIT(IRSALIYE BELGESINDE MUKERRER SURUCU NationalityID BILGISI) döndü. Zarf UUID: 179635ac-14e0-4eca-a293-9380d98417e9. Örnekte iki sürücüye aynı test NationalityID atanması bu hataya neden oldu.

Örnek tek test sürücüsüyle güncellendi. Gönderilecek ve yeni yüklenecek XML için sürücü kimliğinin tekrarı yerel olarak engellenir. Eski kayıtları incelemek ve EDM'den alınan geçmiş belgeleri okumak bu yeni doğrulamayla engellenmez. Aynı eski UUID için gönderim kilidi açılmaz.

Durum sorgusuna GetEnvelope eklendi. Gelen kayıtların DespatchUUID değeri istenen belgeyle eşleştirilir; en yeni geçmişin durum kodu, açıklaması ve zamanı gösterilir. Opsiyonel geçmiş servisi hata verirse asıl belge durumu kaybedilmez; geçmişin alınamaması başarı kabul edilmez. Geçmişteki açıklama hata metni olarak kaçışlanarak gösterilir. Durum sorgusu hiçbir yeni belge göndermez.

3.6.10 üzerine kurun. Bağlantı/etiket kontrolünden sonra bir kez yeni örnek hazırlayın. Sadece bu yeni örneği, varsayılan EDM GB/PK etiketleri ve açık onayla bir kez gönderin. Yerel sayaçta başka örnek oluşturulmadıysa yeni numara KVI2026000000003 olur; numara ve UUID panelden kontrol edilmelidir. Önceki KVI2026000000002 korunur ve yeniden gönderilmez. Yeni örneğin GİB gönderiminin geçtiği henüz doğrulanmış değildir; panelden durum ve gelen belge testi tamamlanmalıdır.

35 migration, mevcut firma hesapları, test belgeleri, üyelikler, yerel kontörler ve tasarım korunur. Bu sürüm e-İrsaliye kabul/ret/kısmi kabul yanıtlarını veya canlı gönderimi eklemez.
