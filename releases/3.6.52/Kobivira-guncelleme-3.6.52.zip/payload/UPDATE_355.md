# Kobivira 3.5.5

3.5.4 üzerine yönetim panelinden yüklenebilen imzalı güncellemedir.

Yalnızca menüdeki **Üst paket** rozeti düzenlendi: belirgin koyu turkuaz yazı, açık turkuaz zemin, ince çerçeve, yuvarlatılmış köşeler ve kategori adıyla arasında 8 piksel boşluk. Aktif satırda rozet beyaz zeminle ayrışır. Aynı stil dar menünün açılır alanında ve mobil menüde de kullanılır; uzun adlarda satır kayması korunur.

İşlevler, paket yetkileri, veritabanı şeması, fiyatlar, kullanıcı kotaları ve diğer tasarım kuralları değiştirilmez. Önceki migration dosyaları ve sürüm açıklamaları korunur. Yeni migration bulunmaz.
