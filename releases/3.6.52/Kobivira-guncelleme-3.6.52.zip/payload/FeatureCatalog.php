<?php
declare(strict_types=1);
/** The plan catalogue is also the server-side entitlement source. Levels are cumulative. */
function feature_catalog_base(): array {return [
 'edocs'=>[2,'e-Fatura / e-Arşiv',true],
 'advanced_edocs'=>[3,'e-SMM / e-İrsaliye / e-İhracat',true],
 'sharing'=>[1,'Müşteriye güvenli belge bağlantısı ve yanıt takibi'],
 'payment_links'=>[2,'Kartla tahsilat bağlantısı',true],
 'approvals'=>[1,'Çalışan işlemlerinde yönetici onayı'],'roles'=>[1,'Bölüm bazında çalışan yetkileri'],'audit'=>[1,'İşlem geçmişi'],
 'statements'=>[2,'Tarih / döviz filtreli cari ekstre · PDF ve Excel'],'returns'=>[2,'Kaynak faturaya bağlı kısmi / tam iade'],'smm'=>[2,'Serbest meslek makbuzu kayıt ve tahsilat takibi'],'aging'=>[2,'Alacak / borç yaşlandırma raporu'],'reconciliation'=>[3,'Güvenli bağlantıyla cari mutabakat ve yanıt takibi'],
 'bookkeeping'=>[1,'Satış, alış, gider, borç ve alacak takibi'],'quotes'=>[1,'Standart teklif ve proforma · PDF'],'orders'=>[2,'Sipariş yönetimi ve belge dönüşümleri'],
 'currency'=>[2,'Dövizli hesaplar, belgeler ve kur farkları'],'cheques'=>[2,'Çek ve vade takibi'],
 'staff_money'=>[2,'Çalışan giderleri, avans ve geri ödeme'],'quantity'=>[2,'Ürün miktar hareketleri ve barkod'],
 'recurring'=>[2,'Haftalık, aylık ve yıllık tekrarlayan taslaklar'],'reminders'=>[2,'Standart vade hatırlatmaları'],
 'export'=>[1,'Dosyaya aktarım'],'profit'=>[2,'Standart kârlılık raporu'],'tasks'=>[2,'İş takibi'],
 'projects'=>[3,'İş / proje kârlılığı'],'crm'=>[3,'Satış fırsatları ve müşteri etkileşimleri'],
 'forecast'=>[3,'30 / 60 / 90 günlük nakit öngörüsü'],'approval_rules'=>[3,'Tutar eşiği ve iki aşamalı onay'],
 'automation'=>[3,'Özelleştirilebilir takip kuralları'],'bank_match'=>[3,'Banka CSV / XLSX dosyası eşleştirme'],
 'bulk'=>[3,'Seçili belgelerde toplu kategori / etiket işlemi'],'advanced_reports'=>[3,'Kategori, etiket ve tarih filtreli raporlar'],
 'templates'=>[3,'Düzenlenebilir belge başlığı, koşullar ve dipnot'],
 'ocr'=>[3,'Fiş okuma',true], 'ai'=>[3,'Akıllı rapor',true],
 'bank_feed'=>[3,'Otomatik banka bağlantısı',true],
 'commerce'=>[3,'Pazaryeri / CRM bağlantıları',true],
 'website'=>[3,'Kurumsal web sitesi ve içerik yönetimi'],
 'public_api'=>[3,'Salt okunur veri API erişimi',true]
 ];}
function plan_level(?string $code=null): int {return ['kobi'=>1,'plus'=>2,'business'=>3,'business_plus'=>3][$code??subscription()['plan_code']]??1;}
function feature_catalog(): array {return plan3616_catalog();}
function feature_allowed(string $key): bool {
 $catalog=feature_catalog();if(!isset($catalog[$key])||!launch3619_available($key))return false;
 if($key==='edocs')return edoc3616_any();
 if($key==='advanced_edocs')return has_feature('edoc_smm')||has_feature('edoc_despatch')||has_feature('edoc_export')||has_feature('edoc_incoming_despatch');
 if(in_array($key,['website','meta_ads','google_ads'],true))return module351_allowed($key);
 if(subscription()['status']==='trial'){if(!empty($catalog[$key][2]))return false;return plan3616_has('business',$key);}
 if(plan3616_has(subscription()['plan_code'],$key))return true;
 // Existing time-limited service grants remain effective, including legacy e-document grants.
 if(plan_level()!==2||empty($catalog[$key][2])||!paid_member())return false;
 $grant=match($key){'edoc_invoice','edoc_archive','edoc_incoming'=>'edocs','edoc_smm','edoc_despatch','edoc_export','edoc_incoming_despatch'=>'advanced_edocs',default=>$key};
 return (bool)query('SELECT 1 FROM feature_grants WHERE company_id=? AND feature IN (?,?) AND expires_at>UTC_TIMESTAMP()',[company_id(),$key,$grant])->fetchColumn();
}
function package_rows(): array {return package_catalog_rows([['Kullanım odağı','Günlük ön muhasebe','Satış ve finans yönetimi','Tüm gelişmiş iş araçları'],['Kapsam özeti',package3627_intro('kobi'),package3627_intro('plus'),package3627_intro('business')]]);}
function package_catalog_rows(array $r): array {
 foreach(plan3616_selectable() as $key=>$f){if(!launch3619_available($key))continue;$row=[$f[1]];foreach(['kobi','plus','business'] as $code){$allowed=in_array($key,['website','meta_ads','google_ads'],true)?in_array($code,array_keys(access354_plans($key)),true):plan3616_has($code,$key);$row[]=$allowed?'Dahil':'—';}$r[]=$row;}
 $cfg=migration_config();$row=['Veri taşıma alanı · yönetici ayarı'];foreach(['kobi','plus','business'] as $code)$row[]=migration_bytes((int)$cfg['quotas'][$code]*1048576);$r[]=$row;
 $r[]=['Yıllık Plus · firma başına bir kez hediye kontör','—','1.000 kontör','—'];$r[]=['SMMM / YMM salt okunur fatura erişimi','Dahil · kota dışı','Dahil · kota dışı','Dahil · kota dışı'];$r[]=['Ücretli üyelikte yazılı / canlı destek','Dahil','Dahil','Dahil'];return $r;
}
function demo_document_count(): int {return (int)query('SELECT (SELECT COUNT(*) FROM documents WHERE company_id=?)+(SELECT COUNT(*) FROM electronic_drafts WHERE company_id=? AND source_id IS NULL)',[company_id(),company_id()])->fetchColumn();}
function extension_routes(): array {return ['edoc_center'=>'edocs','shares'=>'sharing','cheques'=>'cheques','staff_money'=>'staff_money','quantity'=>'quantity','currency_report'=>'currency','repeat_rules'=>'recurring','crm'=>'crm','forecast'=>'forecast','automation'=>'automation','bulk_center'=>'bulk','advanced_reports'=>'advanced_reports','templates'=>'templates','service_center'=>null,'service_admin'=>null];}
function extension_route(string $page): bool {return array_key_exists($page,extension_routes());}
function extension_authorize(string $page): bool {if(!extension_route($page))return false;if($page==='service_admin'){if((base_user()['role']??'')!=='platform_admin'||support_context()){http_response_code(403);throw new DomainException('Yalnız platform yöneticisi servis ayarlarını yönetebilir.');}return true;}if(owner()){http_response_code(403);throw new DomainException('Firma hesabı gerekir.');}if(!in_array($page,['edoc_center','shares','quantity','staff_money','cheques','currency_report'],true))business_manager();if($page==='service_center')business_manager();if($_SERVER['REQUEST_METHOD']==='POST'){$f=extension_routes()[$page];if($f)need_feature($f);require_write();}return true;}
function extension_post(string $page,string $action): void {match($page){'service_admin','service_center'=>service_post($page,$action),'edoc_center'=>edoc_post($action),'shares'=>share_post($action),'repeat_rules','automation'=>automation_post($page,$action),default=>operations_post($page,$action)};}
function extension_view(string $page): void {$f=extension_routes()[$page];if($f&&!has_feature($f)){heading(feature_catalog()[$f][1],'Bu özellik için uygun paketi seçebilirsiniz.');upgrade_cta();return;}match($page){'service_admin','service_center'=>service_view($page),'edoc_center'=>edoc_view(),'shares'=>shares_view(),'repeat_rules','automation'=>automation_view($page),default=>operations_view($page)};}
function module_row(string $table,int $id,bool $lock=false): array {if(!in_array($table,['cheques','staff_money','stock_moves','repeat_rules','crm_deals','automation_rules','automation_events','document_templates','record_shares','electronic_drafts','service_jobs'],true))throw new LogicException('Geçersiz tablo.');$r=query("SELECT * FROM $table WHERE company_id=? AND id=?".($lock?' FOR UPDATE':''),[company_id(),$id])->fetch();if(!$r){http_response_code(404);throw new DomainException('Kayıt bulunamadı.');}return $r;}
function contact_options(): array {return array_column(query('SELECT id,name FROM contacts WHERE company_id=? ORDER BY name LIMIT 1000',[company_id()])->fetchAll(),'name','id');}
function account_options(): array {$a=[];foreach(query('SELECT id,name,currency FROM accounts WHERE company_id=? ORDER BY name',[company_id()]) as $r)$a[$r['id']]=$r['name'].' · '.$r['currency'];return $a;}

function subscription_title(array $s): string {return $s['status']==='trial'?(migration_campaign_active()?'3 aylık veri taşıma kampanyası':'Ücretsiz demo'):$s['plan_name'];}
function public_demo_plan(): int {$id=query("SELECT id FROM plans WHERE code='kobi' LIMIT 1")->fetchColumn();if(!$id)throw new DomainException('Demo hesabı hazırlanamadı. Kobivira ile iletişime geçin.');return (int)$id;}
