(() => {
 document.querySelectorAll('.team-permissions').forEach(root=>root.addEventListener('change',e=>{const row=e.target.closest('.permission-row');if(!row)return;if(e.target.name==='allow_write[]'&&e.target.checked)row.querySelector('[name="allow_read[]"]').checked=true;if(e.target.name==='allow_read[]'&&!e.target.checked)row.querySelector('[name="allow_write[]"]').checked=false}));
 const b=document.body;let signature='';
 document.querySelector('[data-close-service]')?.addEventListener('click',()=>document.getElementById('service-live-alert').hidden=true);
 document.addEventListener('kobivira:poll-data',e=>{
  const s=e.detail.service;if(!s)return;
  for(const [key,value] of Object.entries({live:s.live_waiting,help:s.help_unread,approvals:s.approvals})){document.querySelectorAll('[data-service-count="'+key+'"]').forEach(el=>{el.textContent=value?String(value):'';el.hidden=!value;});}
  const counts={live:s.live_waiting||0,help:s.help_unread||0,approvals:s.approvals||0};document.querySelectorAll('[data-service-group]').forEach(el=>{const n=el.dataset.serviceGroup.split(',').reduce((n,k)=>n+(counts[k]||0),0);el.textContent=n?String(n):'';el.hidden=!n;});
  const alert=document.getElementById('service-live-alert');const sig=(s.live_waiting||0)+':'+(s.help_unread||0)+':'+(s.approvals||0)+':'+(s.help_revision||'');
  if(alert&&sig!==signature){signature=sig;let title='',text='',page='';if(s.live_waiting){title='Yeni canlı destek bekleyen firma var';text=s.live_waiting+' firma canlı destek sırasında bekliyor.';page='support_desk';}else if(s.help_unread){title='Destek talebinde yeni mesaj var';text=s.help_unread+' destek talebi / cevap okunmayı bekliyor.';page='help';}else if(s.approvals){title='Çalışan işlemi onayınızı bekliyor';text=s.approvals+' finansal işlem henüz uygulanmadı.';page='approvals';}if(page){alert.hidden=false;alert.querySelector('strong').textContent=title;alert.querySelector('p').textContent=text;alert.querySelector('[data-service-link]').href='?page='+page;}else alert.hidden=true;}
  const due=s.due?.[0],dueAlert=document.getElementById('service-due-alert');if(dueAlert){dueAlert.hidden=!due;if(due){dueAlert.querySelector('strong').textContent=due.company_name+' destek için hazır bekliyor';dueAlert.querySelector('[data-service-due-link]').href='?page=support_desk#queue-'+due.id;}}
 });
})();
