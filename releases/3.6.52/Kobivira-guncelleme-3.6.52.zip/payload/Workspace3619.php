<?php
declare(strict_types=1);
/** Customer availability is independent of the administrator's package selections. */
function launch3619_available(string $key): bool {
 return !in_array($key,['payment_links','ocr','ai','bank_feed','commerce','meta_ads','google_ads'],true);
}
function launch3619_plan_has(string $code,string $key): bool {
 if(!launch3619_available($key))return false;
 if(in_array($key,['website','meta_ads','google_ads'],true)&&empty(module351_config()[$key]['enabled']))return false;
 return plan3616_has($code,$key);
}
function launch3619_guide_visible(string $slug,array $g): bool {
 $feature=$g['feature']??'';
 if($feature!==''&&!launch3619_available($feature))return false;
 if($feature!==''&&!access354_plans($feature))return false;
 return (bool)query("SELECT 1 FROM cms_pages WHERE site_id=1 AND slug=? AND kind='guide' AND status='published' AND category<>'Yönetim'",[$slug])->fetchColumn();
}
function launch3619_guide_plan_codes(array $page): string {
 $feature=guide354_features()[$page['slug']]??'';
 return implode(' ',$feature===''?['kobi','plus','business']:array_keys(access354_plans($feature)));
}
function launch3619_guide_slug(string $page,array $params): string {
 if($page==='statement')return 'rehber-cari-ekstre';
 if($page==='contact'){$page='contacts';if(!empty($params['id']))$params['kind']=tenant_row('contacts',(int)$params['id'])['kind'];}
 if(in_array($page,['newdocument','document','print_document'],true)){
  if(!empty($params['id'])){$d=tenant_row('documents',(int)$params['id']);if(($d['record_type']??'')==='smm')return 'rehber-smm';$params['kind']=$d['kind'];}
  $page='documents';
 }
 $best='';$score=-1;
 if($page==='service_center'&&launch3619_guide_visible('rehber-veri-api',guide3616_catalog()['rehber-veri-api']))return 'rehber-veri-api';
 foreach(guide3616_catalog() as $slug=>$g){
  if($g['page']!==$page||!launch3619_guide_visible($slug,$g))continue;
  $match=true;foreach($g['params'] as $k=>$v)if(($params[$k]??null)!==$v)$match=false;
  if($match&&count($g['params'])>$score){$best=$slug;$score=count($g['params']);}
 }
 return $best;
}
function launch3619_guide_button(): string {
 if(!current_user()||owner()||support_context())return '';
 $page=is_string($_GET['page']??null)?$_GET['page']:'dashboard';
 $params=$_GET;if($page==='documents'&&!isset($params['kind']))$params['kind']='sale';
 if(in_array($page,['edoc_center','incoming_invoices'],true)&&!isset($params['kind'])&&!isset($params['tab']))$params['kind']='invoice';
 $slug=launch3619_guide_slug($page,$params);
 if($slug==='')return '<a class="button guide-button3619" href="'.esc(url('library3616')).'" target="_blank" rel="noopener">Nasıl Yapılır?</a>';
 return '<a class="button guide-button3619" href="https://kobivira.com.tr/'.esc($slug).'.html" target="_blank" rel="noopener">Nasıl Yapılır?</a>';
}
function launch3619_library(): void {
 heading('Kullanım kütüphanesi');
 echo '<div class="library-search3619"><label>Rehber ara<input type="search" data-guide-search placeholder="İşlem veya bölüm adı" aria-label="Rehber ara"></label></div><div class="guide-directory3619">';
 $groups=[];
 foreach(guide3616_catalog() as $slug=>$g){
  if(!launch3619_guide_visible($slug,$g)||!nav354_visible($g['page'],$g['params'])||($g['feature']!==''&&!has_feature($g['feature'])&&!demo3627_preview($g['page'],$g['params'])))continue;
  $row=query("SELECT title,description,category FROM cms_pages WHERE site_id=1 AND slug=?",[$slug])->fetch();
  $groups[$row['category']][]=[$slug,$g,$row];
 }
 foreach($groups as $category=>$items){echo '<section class="panel guide-category3619"><h2>'.esc($category).'</h2>';foreach($items as [$slug,$g,$r])echo '<article class="guide-entry3619" data-guide-entry><a href="https://kobivira.com.tr/'.esc($slug).'.html" target="_blank" rel="noopener"><strong>'.esc($r['title']).'</strong><span>'.esc($g['path']).'</span></a>'.a($g['page'],'Panelde aç',$g['params'],'button quiet').'</article>';echo '</section>';}
 echo '</div><p data-guide-empty hidden>Aramanıza uygun rehber bulunamadı.</p>';
}
function launch3619_top_actions(): string {
 if(owner()||support_context()||!firm_manager_visible3616()||suspended_firm())return '';
 return '<div class="workspace-tools3619">'.a('referrals',icon('spark').' Tavsiye et, kazan',[],'button referral3619').'<details class="support-menu3619"><summary class="button">'.icon('people').' Destek merkezi</summary><div>'.a('library3616','Kullanım kütüphanesi').a('help','Destek taleplerim').a('support_center','Kobivira canlı destek').'</div></details></div>';
}
function launch3619_help_label(): string {
 if(owner()||support_context()||!firm_manager_visible3616()||suspended_firm())return '';
 return a('help',icon('people').'<span>Yardıma mı ihtiyacınız var?</span>',[],'help-label3619 no-print');
}
function launch3619_rail(): string {
 $s='<aside class="menu-rail3619 no-print" id="menu-rail3619" aria-label="Daraltılmış ana menü" aria-hidden="true" inert><a class="rail-home3619" title="Genel Bakış" aria-label="Genel Bakış" href="'.esc(url(support_context()?'support_workspace':'dashboard')).'">'.icon('grid').'</a><nav aria-label="Menü kategorileri">';
 foreach(nav_groups() as [$id,$ico,$label,$links]){
  $s.='<div class="rail-group3619"><button type="button" title="'.esc($label).'" aria-label="'.esc($label).'" aria-expanded="false" aria-controls="rail-'.esc($id).'">'.icon($ico).'</button><div class="rail-flyout3619" id="rail-'.esc($id).'" role="group" aria-label="'.esc($label).'"><strong>'.esc($label).'</strong>';
  foreach($links as [$p,$l,$params])$s.='<a href="'.esc(url($p,$params)).'" '.(nav_active($p,$params)?'aria-current="page"':'').'>'.esc($l).'</a>';
  $s.='</div></div>';
 }
 return $s.'</nav><button class="rail-expand3619" type="button" data-toggle-sidebar title="Menüyü genişlet" aria-label="Menüyü genişlet">'.icon('menu').'</button></aside>';
}
function launch3619_plan_summary(string $code): array {return package3627_summary($code);}
/** Exact obsolete product copy only; never alters customer records, status responses or legal documents. */
function launch3619_public_copy(string $body): string {
 $body=strtr($body,[
  'Elektronik belge demo hazırlığı'=>'Günlük ön muhasebe',
  'Elektronik belge hazırlığı · gönderim henüz açık değil'=>'Günlük ön muhasebe',
  'Belge hazırlığı ve paylaşım düzeni.'=>'Günlük ön muhasebe ve güvenli belge paylaşımı.',
  'e-Fatura / e-Arşiv hazırlığı'=>'e-Fatura / e-Arşiv',
  'e-SMM / e-İrsaliye / e-İhracat hazırlığı'=>'e-SMM / e-İrsaliye / e-İhracat',
  'Elektronik belge hazırlığı nasıl kullanılır?'=>'Elektronik belgeler nereden düzenlenir?',
  'Elektronik belge hazırlığı'=>'Elektronik belge yönetimi',
  'Servis merkezi ve hazırlık işlemleri nasıl okunur?'=>'Servis merkezi ve veri API erişimi',
  'KOBİ Business Plus test aşamasında olduğu için satışa kapalıdır.'=>'',
  'KOBİ Business Plus test aşamasındadır; testler tamamlanmadığı için satışa açık değildir.'=>'',
  'KOBİ Business Plus test aşamasındadır; testler tamamlanmadığı için satışa açık değildir. Kurumsal web sitesi hizmetinin genel kullanıma açılışı ayrıca duyurulacaktır.'=>'',
  'Business Plus · Test / satışa kapalı'=>'',
  ' · servis hazırlığı'=>'',
  'Servis hazırlığı'=>'',
  'Ücretsiz demo'=>'Ücretsiz deneme',
  'ücretsiz demo'=>'ücretsiz deneme',
  'Test kullanım koşulları'=>'Kullanım koşulları',
  'Fiyat hazırlanıyor'=>'Bilgi alın'
 ]);
 $body=strtr($body,[
  'Business test aşamasında ve satışa kapalıdır.'=>'',
  'Demo kaydı, reddedilen ödeme ve yenileme ödül oluşturmaz.'=>'Ücretsiz hesap açılışı, reddedilen ödeme ve yenileme ödül oluşturmaz.',
  'Gerçek ödeme alımı bu test aşamasında henüz açılmamıştır.'=>'Üyelik ödemeleri doğrulanıp onaylandıktan sonra ödül koşulları değerlendirilir.',
  'KOBİ Business test aşamasındadır; testler tamamlanmadığı için satışa açık değildir. Kurumsal web sitesi hizmetinin genel kullanıma açılışı ayrıca duyurulacaktır.'=>'',
  'Belge hazırlık ekranlarını inceleyin. Resmî gönderim hizmeti kullanıma açıldığında panelinizde bilgilendirileceksiniz.'=>'Paketinizdeki elektronik belgeleri, firmanıza ait doğrulanmış servis hesabıyla düzenleyin; gelen belgeleri ve gönderim sonuçlarını izleyin.',
  'Elektronik belge hazırlık ekranları kullanılabilir; resmî gönderim henüz kullanıma açık değildir. Resmî gönderim ve gelen belge bağlantısı özel entegratör geliştirmesi tamamlandığında açılacaktır.'=>'Resmî belge işlemleri için paketinizin ilgili belge türünü kapsaması ve firmanıza ait servis hesabının etkin olması gerekir. Gönderim ve alım sonuçları Elektronik Belgeler bölümünden takip edilir.',
  'Plus günlük ön muhasebe içindir. Business; proje kârlılığı, CRM, nakit öngörüsü, gelişmiş onay, ayrıntılı rapor, toplu işlem ve takip kuralları ekler.'=>'KOBİ günlük ön muhasebeyi, Plus satış ve finans yönetimiyle e-Fatura ve e-Arşiv işlemlerini kapsar. Business gelişmiş iş araçlarını ve ek elektronik belge türlerini içerir. Güncel kapsamı paket karşılaştırmasında inceleyebilirsiniz.'
 ]);
 return $body;
}
function launch3619_feature_directory(string $body): string {
 $groups=[];
 foreach(guide3616_catalog() as $slug=>$g){
  if($slug==='rehber-menu'||!launch3619_guide_visible($slug,$g))continue;
  $r=query('SELECT * FROM cms_pages WHERE site_id=1 AND slug=?',[$slug])->fetch();$groups[$r['category']][]=$r;
 }
 $directory='';foreach($groups as $category=>$rows){$directory.='<section class="wrap section"><div class="section-title"><span class="eyebrow">'.esc($category).'</span><h2>'.esc($category).' özellikleri ve kullanım rehberleri</h2></div><div class="guide-grid">';foreach($rows as $r)$directory.='<a class="guide-card" href="'.esc($r['slug']).'.html"><h3>'.esc($r['title']).'</h3><p>'.esc($r['description']).'</p>'.guide354_badge($r).'<b>Nasıl Yapılır? →</b></a>';$directory.='</div></section>';}
 $inserted=false;
 return preg_replace_callback('~<section class="wrap section">(?:(?!</section>).)*?<div class="guide-grid">.*?</section>~s',function()use(&$inserted,$directory){if($inserted)return '';$inserted=true;return $directory;},$body);
}
function launch3619_connections(): string {
 $body='<section class="wrap page-head"><span class="eyebrow">KOBİVİRA HİZMETLERİ</span><h1>İşinizi tamamlayan bağlantılar.</h1><p>Firmanıza ait hesaplarla belge ve veri işlemlerinizi yönetin.</p></section><section class="wrap section"><div class="guide-grid">';
 if(access354_plans('edocs'))$body.='<article class="guide-card"><span>ELEKTRONİK BELGELER</span><h2>Elektronik belge bağlantısı</h2><p>Paketinizin kapsadığı e-Fatura, e-Arşiv, e-SMM, e-İrsaliye ve e-İhracat işlemlerini firmanıza ait doğrulanmış servis hesabıyla yürütün.</p><a href="rehber-elektronik-belge.html">Belge rehberini incele →</a></article>';
 if(access354_plans('public_api'))$body.='<article class="guide-card"><span>VERİ ERİŞİMİ</span><h2>Salt okunur firma API erişimi</h2><p>Yetkili uygulamanızla firmanızın cari ve belge kayıtlarını güvenli API anahtarı üzerinden okuyun.</p><a href="rehber-veri-api.html">API rehberini incele →</a></article>';
 return $body.'</div><p class="caption">Servis kullanımı paket kapsamına, firma aktivasyonuna ve bağlantı yetkilerine bağlıdır.</p></section>';
}
