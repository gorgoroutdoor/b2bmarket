# 3.6.49 — Sabit cron ve son 10 güncelleme yedeği

KobiviraCron.php sürüm numarası içermeyen giriş dosyası oluşturulur. Son 10 kayıtlı başarılı güncelleme yedeği ve geri dönüş için gerekli sürümler korunur. Cron geçişi onaylanınca gereksiz eski sürüm klasörleri temizlenir. Disk tablosu yönetimde görünür. Ayrıntılar SAKLAMA_ZAMANLAYICI_3_6_49.md dosyasında.

# 3.6.48 — SSH gerektirmeyen adımlı firma silme

Eski güncelleme yedekleri her istekte bir dosya olarak temizlenir, ilerleme kaydedilir. Tüm yedekler tamamlanmadan canlı firma silinmez. Ayrıntılar FIRMA_SILME_3_6_48.md dosyasında.

# 3.6.47 — Firma silmede doğrudan gönderim

Firma silme formu standart POST kullanır. İşlem sırasında bekleme durumu görünür; doğrulama hatası aynı firma sayfasında gösterilir. Ayrıntılar FIRMA_SILME_3_6_47.md dosyasında.

# 3.6.46 — Sürüm geçmişi ve firma kayıt temizliği

Yönetim geçmişine eksik 3.6.45 açıklaması eklendi. Firma silmede doğrulama kayıtlarının canlı veritabanından ve eski JSONL güncelleme yedeklerinden temizliği düzenlendi. Kullanıcıdaki silme hatasının kesin nedeni henüz doğrulanmadı. Ayrıntılar SURUM_3_6_46.md dosyasında.

# 3.6.45 — Kurumsal doğrulama e-postası

Lacivert/turkuaz, mobil uyumlu HTML e-posta, onay düğmesi ve düz metin alternatifi. Gönderen adresi mevcut SMTP yönetiminden değiştirilebilir. Doğrulama süreleri, bağlantı güvenliği, SMS ve PayTR akışı korunur. Ayrıntılar EPOSTA_TASARIM_3_6_45.md dosyasında.

# 3.6.44 — Mobil doğrulama ve şifre yenileme

Yeni kayıtlarda zorunlu cep telefonu, mobil doğrulama, SMS ile şifre yenileme, kod geçerlilik ve yeniden gönderim sayaçları. Netgsm için ayrılmış hesapla test modu ve canlı ayarı. SMTP hatalarının yönetimde güvenli özeti. Veri taşıma kampanyasında kontörün dahil olmadığının açıklaması. Ayrıntılar MOBIL_DOGRULAMA_3_6_44.md dosyasında.

Netgsm kapalıyken yeni kayıtlar mobil doğrulamayı tamamlayamaz. Gerçek SMTP teslimi ve Netgsm gönderimi henüz doğrulanmadı.

# 3.4.9 — Tanıtım istatistiklerinde elle giriş

Admin → Sistem → Tanıtım ve referanslar → Kartların veri kaynağı: Elle giriş · gerçek istatistikler. Firma sayısı, belge sayısı ve KDV dahil hacim değerlerini girip Toplu istatistikleri yayınla seçeneğini açın; mevcut yönetici şifrenizle kaydedin.

Gerçek istatistiklerinizi siz güncellersiniz. Muhasebe ve firma kayıtları değiştirilmez. Otomatik moda dönülebilir. Yeni migration yoktur; 3.4.8 üzerine yüklenir.

# 3.4.8 — Güvenlik ve doğruluk düzeltmeleri

Bu sürüm 3.4.7 üzerine uygulanır. Tasarım değişikliği veya yeni migration içermez.

Firma silme / yedek temizliği, halka açık iletişim formu, ön izleme yönlendirmesi, kontör bildirimleri, sunucu tarafında içerik politikası, görsel kotası ve sayfalama düzeltildi. Veritabanı geri yüklemesi geçici tablolarda hazırlanıp doğrulandıktan sonra tek RENAME TABLE işlemiyle etkinleşir.

Büyük veritabanlarında web işlemi limitleri korunur. 3.4.8 kurulduktan sonraki imzalı sürümler için UpdateCli.php terminal aracı vardır; otomatik dış yedek servisi kurulmaz. Yedek DB içindir; dosyalar ve yapılandırma ayrıca yedeklenmelidir.

Detaylar sürüm geçmişine eklendi. Önceki notlar:

# 3.4.7

Yönetimden başlık, tarih ve paket bazında kampanya / yıllık indirim ayarı.
Başlık alanında kampanya geri sayacı; kaydırılabilir onaylı yorumlar, toplu veriler, kontör ve SSS alanları.
Firma panelinde kontör satın alma ve havale onayından sonra bir kez bakiye ekleme.
İndirimler birleştirilmez; yüksek olan oran uygulanır.
E-Fatura, SMS ve çevrimiçi ödeme entegrasyonları hazırlık durumunda kalır.
Kontör fiyatları yönetici tarafından tanımlanana kadar satış kapalıdır. Mevcut firma verileri ve önceki ödeme talepleri korunur. Özgün imza doğrulaması korunur.
