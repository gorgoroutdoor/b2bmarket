# Kobivira 3.6.28

3.6.27 üzerine imzalı güncellemedir. Paket kapsamı, fiyat, menü yapısı ve servis gönderim kuralları değişmez. Eski 46 veritabanı migration dosyası aynıdır.

## Tamamlanan düzenlemeler

- Paket kısa özetindeki birleşik açıklama yerine e-Fatura ve e-Arşiv ayrı özellik olarak gösterilir.
- Paket karşılaştırmasındaki alıcı kayıt durumu açıklaması ve belge sayfalarındaki uzun e-Fatura/e-Arşiv notu kaldırılır. Firma kimlik alanında yalnız TCKN/VKN uzunluk açıklaması kalır.
- Satış/alış belge düzenleyicisindeki alıcı TCKN/VKN alanına 10 veya 11 rakam girilince sadece aynı firmanın kayıtlı cari kartları tam numara eşleşmesiyle aranır. Tek eşleşmede kart seçilir ve unvan/ad soyad, vergi dairesi, adres, ilgili kişi, telefon ve e-posta aktarılır. Birden fazla eşleşmede kullanıcı seçim yapar. Kayıt bulunamazsa girilmiş diğer alanlar silinmez.
- Eski arama yanıtının yeni yazılmış kimliği ezmesi önlenir. Müşteri bilgileri yüklenirken taslak kaydı bekletilir. Belgedeki cari anlık görüntüsü korunur; kalıcı cari kart değişmez.

## İlk kez fatura kesilecek müşterinin GİB üzerinden sorgulanması — TAMAMLANMADI

Bu sürümdeki otomatik doldurma GİB veya harici mükellef bilgisi API bağlantısı değildir. Önceden kaydedilmemiş bir alıcının adres/iletişim bilgileri dış servisten alınmaz. Yeni alıcı için mevcut yeni cari kart formu kullanılır.

EDM CheckUser / GIBUSER teknik tanımı e-Fatura kaydı, unvan, kimlik ve etiket alanları içerir; tam adres, telefon ve e-posta alanları bu tipte bulunmaz. Doküman kaynağı: EDM_E-Fatura_Web_API_v4.2.1.docx, CHECK USER bölümü; https://docs.edmbilisim.com.tr/api/api-documentation/einvoice/referenced/EFaturaEDMConnectorService.GIBUSER.html . CRM GetCustomer metodu müşteri GİB statüsü/etiketleri ve interaktif fatura durumunu sorgular; bunu genel adres sorgusu yerine kullanmıyoruz.

Kullanıcının ilettiği fiyat listesinde GİB VKN Sorgulama Servisi bulunuyor. Bu ayrı servis için endpoint, kimlik doğrulama/yetki, örnek istek/yanıt, dönen alanlar ve ücretlendirme davranışı sağlayıcıdan alınarak doğrulanmalıdır. Aynı şekilde TCKN sorgusunun kapsamı ayrıca doğrulanmalıdır. Henüz doğrulanmamış bir endpoint eklenmedi ve yeni dış servis ücreti doğuracak sorgu yapılmadı.

## Doğrulama

- Önceki sürümden gerçek imzalı yerel güncelleme, 78 PHP/veritabanı kontrolü.
- Oturum açılarak 52 yerel HTTP kontrolü: tam numara, iki kayıt, TCKN, başka firmada kayıt, hatalı uzunluk ve oturumsuz erişim dahil.
- 9 alıcı otomatik doldurma DOM kontrolü ve mevcut 3 firma kimliği DOM kontrolü.
- 152 PHP kaynak sözdizimi kontrolü; 46 migration değişmedi.
- Gerçek GİB/EDM/PayTR çağrısı, hosting kurulumu veya canlı fatura testi yapılmadı.
