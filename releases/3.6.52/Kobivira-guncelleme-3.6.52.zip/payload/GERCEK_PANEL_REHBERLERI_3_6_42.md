# Kobivira 3.6.42 — Gerçek panel görüntüleriyle kullanım rehberleri

3.6.41 üzerine **Sistem → Sürüm güncellemeleri** bölümünden ZIP olarak yükleyin. Kurulumdan sonra kütüphane sayfasını yenileyin. Görselleri tek tek yüklemeniz gerekmez.

## Eklenenler

- Kullanıcının izin verdiği gerçek Business demo firma hesabının mevcut 3.6.41 ekranlarından alınan 80 özgün JPEG, 84 kullanım rehberine konusuna göre hazır bağlandı. Görseller tasarlanmış veya üretilmiş panel maketleri değildir. Kaynak JPEG dosyalarının özetleri Guide3642Provenance.json içindedir.
- İlk görüntü ilgili bölümün yerini gösterir. Uygun ekranlarda gerçek menü ve yeni kayıt düğmesi, konumlarına göre HTML katmanında numaralandırılır. JPEG pikselleri değiştirilmez.
- Erişilebilen boş yeni kayıt formları ikinci, açılabilir görüntü olarak sunulur. Böylece rehber gereksiz uzamaz. Her görselde tam boy açma bağlantısı vardır; ayrı sekmede açılır.
- Alış faturası rehberinde gerçek Alışlar ve Giderler → Alış faturaları listesi, Yeni alış faturası düğmesi ve tedarikçi seçimiyle başlayan mevcut form kullanılır.
- Eski Alışlar, Giderler, Para ve Ayarlar yollarının bilinen karşılıkları rehber metinlerinde ve açıklamalarında mevcut panel adlarıyla eşleştirilir. Kayıtlı rehber metinleri topluca silinmez veya yeniden yazılmaz; düzeltme gösterim sırasında yapılır.
- Rehberlerin altına ortak banner eklendi: “İşinizin hesabını Kobivira ile kolaylaştırın.” / “14 günlük ücretsiz deneme. Kontör ve ücretli servisler dahil değildir.” / Ücretsiz deneyin. Banner yönetici oturumunda da Düzenle düğmesi içermez. Önceki sayfa düzeyindeki yönetici düzenleme bağlantısı kendi yetki kontrolüyle devam eder.
- Yeni galeri ve banner yalnız Kobivira'nın kütüphane rehberlerine uygulanır. Firma panelinin tasarımı, menüleri, paketleri, ödeme ve belge işlevleri değiştirilmez.

## İleride bir görseli değiştirmek

**Site ve İçerikler → Kullanım kütüphanesi → İlgili rehberi düzenle → Gerçek panel ekran görüntüleri.**

Bu alanda hazır görüntü yerine site görsellerinden seçim yapabilir veya doğrudan yükleyebilirsiniz; görsel açıklaması değiştirilebilir. Hazır gerçek panel görüntüsünü kullan seçeneği varsayılanı geri getirir. Kendi görselinizde eski koordinat işaretleri gösterilmez. Rehber bazında galeriyi gizlemek de mümkündür. Yetki, form güvenliği, içerik sürümü, site kapsamı ve yüklenen dosya doğrulamaları mevcut CMS işlemi içinde korunur.

## Görüntülerin kapsamı

Görüntüler 24.10.2026 tarihinde gerçek firma hesabındaki erişilebilir ekranlardan alınmıştır. Demo firma ve ödeme testi uyarıları gerçekten panelde bulunduğu için fotoğraflardan silinmemiştir. Menü konumlarını gösteren bazı ayar ekranları kişisel alanlar görünmeden kırpılmıştır. Hesap ayrıntıları, gerçek ödeme kayıtları ve işlem geçmişi kayıt satırları rehber görseli olarak kullanılmamıştır. İşlem geçmişi tarih filtresi kayıt bulunmayan aralıkta görüntülenmiştir. Ödeme takibi ve iade rehberleri, özel ödeme kayıtları yerine Ödeme ve etkinleştirme sekmesinin yerini işaretler.

Bu firmada e-Belge bağlantısı tanımlı olmadığından gerçek e-Belge ekranları Bağlantı gerekli uyarısı göstermektedir. Bu durum gizlenmez; erişilemeyen gönderim formu için maket oluşturulmaz veya başka ekran form diye sunulmaz. Firma hesabında belge gönderimi, ödeme, cari kart, fatura veya destek kaydı oluşturulmamıştır. Görüntü almak için yalnız sayfalar, boş formlar ve kayıt yazmayan liste filtreleri açılmıştır.

Güncel KOBİ / Plus / Business hizmet kapsamı dışında kalan web sitesi ve Meta / Google reklam rehberlerinin mevcut yayın kısıtları korunur; bu üç rehbere başka modülün görüntüsü bağlanmaz. Yeni veritabanı göçü yoktur. Görseller paket içindeki güvenli varlık dosyalarıyla gelir; harici resim hizmetine bağlı değildir.

## Kontroller

İmzalı 3.6.41 → 3.6.42 kurulum, PHP sözdizimi, mevcut kayıt ve göçlerin korunması, rehberlerin HTTP yanıtları, özgün JPEG özetleri, tek galeri / tek banner, görüntü bağlantıları, yönetici görsel değiştirme, yabancı site medyasının reddi, ziyaretçiye düzenleme alanı gösterilmemesi ve eski menü adı düzeltmeleri kontrol edilir. Sayısal sonuçlar Guide3642TestResults.json içindedir.

Kaynak ekranlar canlı tarayıcıdan alınarak kontrol edilmiştir. Güncellenen rehberlerin yerel ön izlemesi bu tarayıcıdan açılamadığı için yeni rehber yerleşiminin masaüstü / mobil görsel tarayıcı kontrolü tamamlanamamıştır. HTTP ve DOM kontrolleri bu görsel kontrolün yerine sunulmaz.
