# 3.6.48 — Paylaşımlı hostingde adımlı firma silme

3.6.47 üzerine imzalı güncellemedir. SSH, Terminal, VDS ve yeni cron kaydı gerektirmez. Yeni migration yoktur.

## Kullanım

Yönetim → Firmalar → Firma listesi → ilgili firmada Üyeliği düzenle → Firma üyeliğini ve tüm verileri kalıcı olarak sil.

Firma unvanını aynen, SİL ifadesini ve mevcut yönetici şifrenizi girip kalıcı silme onayını işaretleyin. Bir kez gönderin. Eski JSONL güncelleme yedekleri her istekte bir dosya olacak şekilde temizlenir; ilerleme X / Y olarak gösterilir ve açık sayfada sonraki adım otomatik gönderilir. Sayfa kapatılırsa aynı yöneticiyle firma ekranına dönüp “Silme işlemini sürdür” seçeneğiyle devam edilebilir. Bir hata olursa otomatik tekrar durur; hata aynı sayfada görünür.

Tüm güncel yedekler temizlenmeden canlı firma silinmez. Yeni eklenen veya değişen yedekler temizlenmemiş kabul edilir. Son adımda mevcut firma silme işlemi, firma ve bağlı canlı kayıtlarını temizler. Onay bir saat geçerlidir; aynı kullanıcı ve oturum sürümüne bağlıdır. Şifre/oturum sürümü değişirse veya süre dolarsa yeniden şifreyle silme onayı gerekir. Başka yönetici mevcut onayı kullanamaz.

## Kapsam

Bu işlem eski güncelleme yedeklerini topluca silmez; yalnız seçilen firmanın verilerini bunlardan çıkarır. Temizlenmiş bir eski yedeğin firma kayıtları sonradan geri gelmez. İşlem yarıda kesilirse canlı firma durur; tamamlanan yedek temizliği geri alınmaz. Her adımda uygulamanın mevcut kilit kontrolü korunur. CSRF, yönetici yetkisi, firma unvanı, SİL ve şifre kontrolleri kaldırılmaz.

Hosting sağlayıcısının yedekleri, dışa indirilmiş kopyalar ve şifreli tam sistem yedekleri bu JSONL temizliğinin kapsamı dışındadır. Bunlar otomatik silinmez. Çalışan sürüm klasörlerini veya tüm eski yedekleri Dosya Yöneticisi'nden elle silmek gerekmez.

Önceki sorun çok sayıda yedeğin aynı 25 saniyelik istekte taranmasıydı. Sınır artık her dosya adımına ayrı uygulanır. Tek bir yedek tek başına bu sınırı aşarsa işlem güvenli biçimde durur; ekran sonucu incelenmelidir. Sunucu verileri burada doğrudan incelenmediği için gerçek hostingde tamamlanma henüz doğrulanmadı.

PayTR, e-posta ve DNS ayarları değiştirilmez. Gerçek firma bu geliştirme sırasında silinmedi.
