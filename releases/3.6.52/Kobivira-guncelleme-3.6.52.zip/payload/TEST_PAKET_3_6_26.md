# Kobivira 3.6.26 — Test ödemesi sonrası paket ve süre

3.6.25 üzerine yüklenir. Seçilen ayrı test firmasında KOBİ, KOBİ Plus ve KOBİ Business paketinin ödeme sonrası açılması, süresi ve menü erişimleri test edilebilir. Havale ve canlı kart ödeme akışları korunur.

## Kullanım

1. Farklı e-posta ile oluşturduğunuz yeni firma hesabını kullanın. Mevcut veya geçmiş ücretli üyeliği bulunan firma test hesabına çevrilemez. Gorgor gibi ücretli hesabınızı seçmeyin.
2. Yönetim → Sistem → PayTR ödeme ayarları → Firma paket ödemeleri bölümünü açın.
3. Kart ödemeleri alanında **Test · yalnız seçilen firma** seçin. Test firması alanından yeni hesabı seçin.
4. **Başarılı test ödemesinde yalnız seçilen yeni test firmasının paketini ve süresini güncelle** kutusunu işaretleyin. Kobivira yönetici şifrenizle **Paket ödeme ayarlarını kaydet** düğmesine basın.
5. Test firmasına giriş yapın. Üyelik paketim → Paketler bölümünden paket, dönem ve Kredi/banka kartı seçin. Koşulları onaylayarak yeni ödeme talebi oluşturun.
6. Ödeyen bilgilerini tamamlayın; Kartla öde düğmesiyle PayTR ekranını açıp PayTR test adımlarını tamamlayın.
7. Firma paneline dönüşte Sonucu yenile düğmesiyle imzalı bildirim sonucunu kontrol edin. Başarılı bildirimde bu hesabın paketi ve süresi güncellenir. Üyelik bilgilerim bölümünde yeni paket/süre, menüde o paketin özellikleri görünmelidir. Menü gerekirse sayfa yenilenerek kontrol edilir.
8. Diğer paketler için farklı yeni test ödemeleri yapabilirsiniz. Aynı paket yenilemesi süreye eklenir; paket değişikliğinde mevcut kalan süre politikası uygulanır. Her testte aynı referansı tekrar ödemeyin. Başarısız ödeme paketi değiştirmez; tekrarlanan bildirim süreyi tekrar eklemez.

**İzin, ödeme ekranı ilk açılırken işlem kaydına sabitlenir.** Daha önceden başlatılmış veya sonuçlanmış test ödemesi sonradan bu kutuyu işaretlemekle paket açmaz. Yeni hesapta, izni kaydettikten sonra yeni ödeme talebiyle başlayın.

PayTR Bildirim URL değişmez: `https://app.kobivira.com.tr/?page=paytr_callback`. Adresi tarayıcıda açınca METHOD görülmesi normaldir. Bu sürüm test ortamından canlı moda geçmeyi gerektirmez; gerçek kartla tahsilat yapmayın.

## Test hesabının sınırları

- Paket/süre değişikliği yalnız yönetici tarafından ayrılmış ve ödeme başlatılırken izin verilmiş test hesabına uygulanır. Gerçek firma hesabına test ödemesiyle ücretli üyelik verilmez.
- Test ödeme durumu ayrı tutulur. Gelir/tahsilat makbuzu, kontör, hediye kontör, referans ödülü veya gerçek ödeme iade etkisi oluşturmaz. Test firması ödeme testi için ayrıldığını belirten bir uyarı görür.
- Test hesabı iş araçlarını paket yetkilerine göre kullanabilir; ancak canlı kart ödemesi ve canlı e-Belge servisi bu hesapta kapalıdır. E-belge menüsünün görünmesi gerçek servis bağlantısının etkinleştiği anlamına gelmez.
- Firma kısıtlanmışsa, kullanıcı sınırı aşılmışsa veya üyelik test dışında değiştirilmişse test ödemesi doğrulanır; paket değişikliği uygulanmaz ve yönetici kontrolü istenir.
- Mevcut firma kayıtları, paket fiyatları ve normal havale onayları değiştirilmez. Ayrılmış test hesabına gerçek havale onayı verilmesi engellenir.

## Test öncesi üyeliğe dönüş

Yönetimde aynı PayTR ayar sayfasının **Ayrılmış test hesapları** kartından firmayı seçip yönetici şifrenizle **Test öncesi üyeliği geri getir** düğmesine basabilirsiniz. Başlangıçtaki paket, deneme/üyelik durumu ve süreler geri getirilir; oluşturduğunuz muhasebe kayıtları silinmez. Test ödeme kayıtları da tutulur.

Sonuçlanmamış PayTR isteği varsa dönüş engellenir. Test dışında üyelik değişmişse bu değişikliği ezmemek için dönüş reddedilir ve inceleme gerekir. Henüz PayTR isteği başlamamış kart talepleri dönüşte iptal edilir. Dönüşten sonra eski bir başarılı bildirimin tekrarı test paketini yeniden açmaz.

## Doğrulama

3.6.25 → 3.6.26 imzalı kurulum izole veritabanında çalıştırıldı. Eski 45 migration değişmedi; 046 test hesabı kaydını ve işlem iznini ekler. 53 PHP/veritabanı ve 33 yerel HTTP kontrolü geçti; 164 PHP dosyası sözdizimi kontrolünden geçti. Üç paketin testte açılması ve gerçek menü farkları; yanlış imza/tutar, başarısız ödeme, tekrar bildirim, hesap ayrımı, ücretli firma koruması, normal canlı akışın korunması ve güvenli geri dönüş denendi.

PayTR token isteği testlerde kontrollü yanıtla karşılandı; gerçek PayTR ağına veya hesabınıza bağlanılmadı. Sunucudaki gerçek PayTR test ödemesi ve tarayıcı/3D Secure akışı kurulumdan sonra doğrulanmalıdır.
