# Kobivira 3.6.43 — Yeni üyeliklerde e-posta doğrulaması

3.6.42 üzerine **Sistem → Sürüm güncellemeleri** alanından ZIP olarak yükleyin.

## Bir defalık e-posta ayarı

**Destek ve İletişim → E-posta ve SMS gönderimleri** bölümünü açın.

| Alan | Değer |
|---|---|
| SMTP sunucusu | mail.kobivira.com.tr |
| SMTP portu | 465 |
| SMTP bağlantısı | TLS / SSL |
| SMTP kullanıcısı | info@kobivira.com.tr |
| Gönderen e-posta | info@kobivira.com.tr |

SMTP sunucusu daha önce yapılandırılmamışsa bu değerler hazır gelir. Önceden yapılandırılmış SMTP hesabı otomatik değiştirilmez; varsa tablodaki değerlerle kontrol edin.

SMTP şifresi alanına info@kobivira.com.tr posta hesabının şifresini girin. Mevcut platform yöneticisi şifresi alanı, Kobivira yönetici hesabınızın şifresidir. E-posta gönderimini Açık seçin ve yeni firma kayıtlarında e-posta doğrulamasını zorunlu tutma kutusunu seçili bırakıp kaydedin.

Aynı sayfadan Deneme e-postası gönder işlemini yapın. Mesajın gelen kutusuna veya istenmeyen e-posta klasörüne ulaştığını kontrol edin. Yeni müşteri kaydı almadan önce bu testi tamamlayın. Posta şifresi ZIP içine eklenmemiştir; yönetimden girildiğinde mevcut şifreleme altyapısıyla saklanır.

## Yeni müşteri akışı

1. Firma kayıt formunu doldurur, mevcut üyelik metinlerini onaylar.
2. Hesap oluşturulur ve giriş e-postasına otomatik doğrulama bağlantısı gönderilir.
3. Müşteri doğrulama ekranında bekler. Doğrulamadan firma işlemleri veya paket satın alma ekranına geçemez.
4. E-postadaki bağlantıyı açıp E-posta adresimi doğrula düğmesine basar. Bir e-posta tarayıcısının bağlantıyı GET isteğiyle açması hesabı doğrulamaz.
5. Oturumu aynı tarayıcıda açıksa paneline, varsa seçtiği paket akışına döner. Farklı tarayıcıda doğrulamışsa hesabına giriş yaparak devam eder.

Bağlantı 30 dakika geçerli ve tek kullanımlıktır. Yeniden gönderimler arasında en az bir dakika olmalıdır; hesap başına günlük en fazla sekiz doğrulama e-postası istenebilir. Yeni bağlantı eskisini geçersiz kılar. Veritabanında bağlantı anahtarının yalnız özeti tutulur. Doğrulama sayfası önbelleğe alınmaz; referer üzerinden bağlantı taşınmaz. Gönderim başarısız olursa firma kaydı korunur ve müşteri yeniden gönderim isteyebilir. Yeni kayıtta SMTP etkinleştirilmeden doğrulamayı zorunlu bırakmak müşterinin panel girişini bekletir; bu nedenle posta ayarlarını önce tamamlayın.

## Mevcut firmalar ve diğer servisler

- Önceden kayıtlı firmaların erişimi korunur; e-postaları doğrulanmış gibi işaretlenmez.
- Yeni müşterinin kendi kayıt formundan açtığı hesaplar bu akışa alınır. Yönetici tarafından oluşturulan firmalara otomatik e-posta gönderilmez.
- Giriş e-postası doğrulandığında firma iletişim e-postası aynıysa o adresin doğrulama durumu da güncellenir. Farklı bir iletişim adresi doğrulanmış sayılmaz.
- Hesabın e-posta adresi değişirse önceki adrese gönderilmiş bağlantı kullanılamaz.
- Mevcut firma iletişim kodu ve telefon doğrulama alanları korunur. Bu onay, vergi/evrak veya e-Belge sağlayıcı aktivasyonu onayı değildir.
- Yönetimde doğrulama/gönderim durumu, yeni doğrulanmış üyenin hesap ekranında da doğrulama durumu görünür.
- PayTR canlı modu ve ödeme modülleri değiştirilmez; ödeme dosyaları önceki sürümle aynıdır.

## Kontroller ve sınır

İmzalı 3.6.42 → 3.6.43 güncellemesi izole veritabanında sınanmıştır. Mevcut kullanıcı ve PayTR canlı modunun korunması, yeni üyelikte otomatik SMTP gönderimi ve kimlik doğrulama, Türkçe e-posta konusu, süre sınırı, yeniden gönderim, eski bağlantının iptali, tek kullanım, adres değişikliği, oturumsuz onay, CSRF ve doğrulanmadan doğrudan yazma engeli denetlenmiştir. Posta hatasında firma kaydının korunması da kontrol edilmiştir.

Gerçek mail.kobivira.com.tr hesabının şifresi girilmediğinden bu oturumda gerçek posta teslimatı doğrulanmamıştır. Posta aktarımı kontrollü yerel SMTP sunucusuyla test edilmiştir. Yeni doğrulama sayfasının masaüstü ve mobil görsel tarayıcı kontrolü tamamlanmamıştır. Sayısal sonuçlar Email3643TestResults.json dosyasındadır.
