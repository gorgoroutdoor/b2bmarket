# Kobivira 3.5.0 test raporu

Tarih: 21 Ekim 2026. Yerel PHP 8.3.6, MariaDB 10.11.14, gerçek HTTP istekleri ve Node.js ile 128 kontrol başarılıdır. Canlı sunucuda işlem yapılmamıştır.

## Muhasebe, iade, ekstre ve temel aktarım · 32 kontrol

- 23 migrations rerun without changes
- Detailed invoice writes correct total
- Detailed invoice preserves quantity
- Partial return proportional net and VAT
- Original outstanding reduced by partial return
- Return request key is idempotent
- Final partial return consumes rounding remainder exactly
- Full return closes original invoice
- Cannot return more than original quantity
- Statement includes full return corrections
- Dashboard sales net of returns
- Period opening carried into closing
- Unknown document rejected
- Mapped invoice row validated
- Validated row imported
- Repeated invoice import skipped
- Business quota default and reserved bytes correct
- Quota overflow rejected
- Traversal storage key rejected
- Statement Excel link and separate PDF tab
- returns UI renders
- aging UI renders
- reconciliations UI renders
- smm UI renders
- Migration upload UI renders
- Admin quotas render
- Paid historical invoice creates linked receipt
- Refund limited to genuinely collected amount
- Refund cannot be paid twice
- Refund and signed credit preserve contact net balance
- Other tenant cannot access migration job
- Other tenant cannot read contact statement

## XML güvenliği, paketler, kampanya ve döviz · 30 kontrol

- Standard UBL XML parsed with exact tax and quantities, unknown settlement
- Wrong XML direction rejected by company VKN
- Foreign-company XML rejected
- Unsupported official return XML not silently imported
- Mixed XML currencies rejected
- XXE rejected before parsing
- Valid XML and PDF archive accepted
- ZIP traversal rejected
- Ambiguous archive basenames rejected
- Original XML encrypted at rest
- Extracted attachment bytes charged to quota
- Campaign registration grants import access
- Campaign uses three calendar months
- Campaign does not masquerade as paid service
- Eligible campaign import guard permits access
- Ordinary trial cannot import
- Ordinary registration remains 15 days
- kobi entitlement statements
- kobi entitlement aging
- plus entitlement statements
- plus entitlement aging
- business entitlement statements
- business entitlement aging
- Staff cannot bypass new manager-only routes
- Promotion links to separate campaign
- Six admin-editable library guides installed
- FX full returns close native and TRY balances without rounding leakage
- Fully returned FX invoice absent from aging
- Negative opening payable imported in cents
- Imported opening visible in statement period carry

## Gerçek HTTP form ve uçtan uca ZIP aktarımı · 39 kontrol

- HTTP login ledger350@example.invalid
- HTTP page migration
- HTTP page returns
- HTTP page aging
- HTTP page reconciliations
- HTTP page smm
- HTTP page contact&id=1
- HTTP page document&id=1
- HTTP page reports&view=balances
- HTTP page membership&view=plans
- SMM form renders
- SMM creates actual draft via POST
- SMM draft reflects withholding calculations
- SMM draft posts through own route
- Chunk upload reserves job
- Multipart chunk stored at correct offset
- Repeated chunk offset rejected
- Uploaded file final hash created
- CSV mapping prepares preview
- Prepared preview renders
- Commit requires explicit consent
- Preview approved and product actually imported
- Finished result renders
- Statement is actual XLSX package
- Reconciliation created via POST
- Anonymous recipient with token can view fixed snapshot
- Recipient can submit dispute
- Repeat reply does not cause server failure
- Submitted reconciliation response immutable
- Upload initialization rejects CSRF
- Unknown public token rejected
- ZIP job initialized
- ZIP chunk uploaded
- ZIP finalized
- ZIP scanned into ready preview
- ZIP invoice committed while preserving unknown payment state as draft
- Invoice list renders after XML import
- Files above 1 GiB cap rejected
- Oversize spreadsheet rejected before upload

## İçe alınan dosyaların ve şifreli kaynakların kontrolü · 7 kontrol

- Untagged XML payment remains draft after full HTTP import
- Original XML and same-basename PDF linked to imported invoice
- Completed products.csv source archive encrypted
- Encrypted products.csv source round-trips exactly
- Completed archive.zip source archive encrypted
- Encrypted archive.zip source round-trips exactly
- Large-value return allocation avoids integer overflow

## Firma silme ve yedek temizliği · 3 kontrol

- Company deletion clears new accounting and import tables
- Company deletion removes private uploaded files
- Application backup sanitized for new tenant tables

## JavaScript yükleme etkileşimleri · 5 kontrol

- Source filter selects matching programs
- Upload splits file into 1 MiB chunks
- Chunk offsets progress without overlap
- CSRF sent with upload requests
- Successful upload redirects to preview

## Tasarım ve eski migration bütünlüğü · 3 kontrol

- All existing root and nested CSS files byte-identical
- Embedded marketing assets, scripts, fonts and logo pack byte-identical
- All 21 previous migration files byte-identical

## Mevcut 3.4.9 güncelleyicisiyle gerçek paket kurulumu · 9 kontrol

- Existing installation public key verifies package signature
- Modified payload rejected before installation
- Actual 3.4.9 updater installs and activates 3.5.0
- All installed payload file hashes match
- Upgrade applies two new migrations while preserving all 21 old checksums
- Existing company and subscription retained
- New release history appears without altering previous notes
- Migration guide installed by old updater
- Update completion recorded

## Sınırlar

- 102 PHP uzantılı kaynak dosyasında PHP sözdizimi kontrolü yapıldı. Yeni yükleme JavaScript’i ayrıca etkileşim testiyle doğrulandı; adımlı devam betiği Node sözdizimi denetiminden geçti.
- Ana paket için mevcut açık anahtar kullanıldı; imza kontrolü kaldırılmadı. Eski 21 migration ve önceki sürüm kayıtları korundu. Yerel 3.4.9 güncelleyicisiyle gerçek kurulum ve dosya özetleri sınandı.
- Gerçek sağlayıcı dışa aktarım dosyaları verilmediğinden program bazında tam uyumluluk testi yapılmadı. Sentetik CSV, XLSX çıktısı ve standart UBL XML örnekleri kullanıldı. Kaynak program seçimi API bağlantısı değildir.
- 1 GiB üst sınır ve büyük dosya ret koşulları sınandı; tam 1 GiB dosyanın canlı hosting üzerindeki yük / hız testi yapılmadı. CSV / XLSX için 5 MiB ve 2000 satır sınırı geçerlidir.
- Mobil / masaüstü görsel tarayıcı ekran testi yapılmadı. Mevcut CSS, gömülü görseller / fontlar ve marka paketi aynı baytlarla korunmuştur. HTTP ekranları başarıyla oluşturuldu.
- PDF çıktı tarayıcıdaki PDF olarak kaydet / yazdır akışıdır; sunucuda bağımsız PDF dosyası üreten yeni kütüphane eklenmemiştir. XLSX gerçek Excel dosyasıdır.
- Resmî belge gönderimi, sağlayıcı API’leri, SMS, POS ve ayrı mobil uygulama bu testin ve sürümün kapsamı dışındadır.
