<?php
declare(strict_types=1);
function mail3645_message(string $from,string $to,string $subject,string $plain,?string $html=null):string {
 if(!str_contains($plain,'Kobivira · İşinizin hesabı'))$plain.="\n\nKobivira · İşinizin hesabı";
 $head='From: Kobivira <'.$from.">\r\nTo: <".$to.">\r\nSubject: =?UTF-8?B?".base64_encode($subject)."?=\r\nDate: ".gmdate('D, d M Y H:i:s')." +0000\r\nMessage-ID: <".bin2hex(random_bytes(16)).'@'.substr(strrchr($from,'@'),1).">\r\nMIME-Version: 1.0\r\n";
 if($html===null)return $head."Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($plain),76,"\r\n").".\r\n";
 $boundary='kv_'.bin2hex(random_bytes(18));$wire=$head.'Content-Type: multipart/alternative; boundary="'.$boundary."\"\r\n\r\n";
 foreach(['text/plain'=>$plain,'text/html'=>$html] as $type=>$body)$wire.='--'.$boundary."\r\nContent-Type: ".$type."; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($body),76,"\r\n");
 return $wire.'--'.$boundary."--\r\n.\r\n";
}
function mail3645_verification(string $name,string $link):string {
 return mail3651_layout('E-posta adresinizi doğrulayın',"Merhaba ".$name.",\n\nHesabınızla devam etmek için e-posta adresinizi doğrulayın.",['E-posta adresimi doğrula'=>$link],"Bağlantı 30 dakika geçerlidir ve bir kez kullanılabilir. Açılan sayfada doğrulama işlemini onaylayın.\nBu hesabı siz oluşturmadıysanız işlem yapmanız gerekmez. Yeni bağlantı istediğinizde önceki bağlantı geçersiz olur.");
}
