# 3.6.12 — e-İrsaliye kabul, ret ve kısmi kabul test alanı

Bu sürüm 3.6.11 üzerine kurulur. Mevcut gönderim/alım/PDF/XML işlevleri korunur. İrsaliye yanıtı yalnız gelen (IN), TEMELIRSALIYE, ücretli advanced_edocs yetkili firmada veya platform yöneticisi tarafından gönderilebilir. Firma hesabı ve belge VKN/UUID/numara eşleşmeleri mevcut yöntemlerle yeniden kontrol edilir.

EDM API v4.1.1 ve ayrı Kısmı Kabul İrsaliye Request.xml örneğine göre SendDespatchResponseWithServerSign kullanılır. KABUL satır yanıtı olmadan gönderilir. RED tüm satır kimlikleri, miktarları ve ret gerekçesiyle gönderilir. KISMI KABUL tüm satırların gönderilen/kabul edilen/reddedilen miktarları ve kısmi ret gerekçesiyle gider. Eksik/fazla teslimat miktarları bu testte 0'dır. Kısmi kabulün miktar hesabı altı ondalık basamakta tamsayıyla yapılır. Negatif, taşan, eksik, tümü kabul veya tümü ret olan kısmi yanıtlar gönderilmez. İstekler güncel EDM test WSDL şemasına karşı kontrol edildi.

EDM durum tablosu RECEIVE - WAIT_SYSTEM_RESPONSE için sorgulamaya devam edilmesini, RECEIVE - WAIT_APPLICATION_RESPONSE için yanıt verilmesini bildirir. Panel ve sunucu yalnız ikincisinde yanıt açar. Gönderimden hemen önce taze durum sorgulanır. 1300 zarf sonucu tek başına bu ön koşulun yerine geçmez.

036 migration mevcut irsaliye test tablosuna yanıt deneme zamanı, karar, şifreli yanıt içeriği ve istek onay zamanı ekler. Deneme işareti servisten önce, mevcut belge kilidi altında kaydedilir. Ağ hatası veya belirsiz sonuçta aynı belgeye ikinci yanıt gönderilmez. RETURN_CODE=0 yalnız isteğin kabulünü gösterir; başarıyla tamamlanmış yanıt için ayrıca ACCEPT/REJECT/PARTIALACCEPT - SUCCEED ve seçilen yanıt türünün eşleşmesi gerekir. Mevcut durum sorgusu, ikinci kez yanıt göndermeden sonucu takip eder.

## Mevcut testin devamı

KVI2026000000003, UUID 673c5d68-60e9-43f8-a4ab-33106ee91e60 için kullanıcının ekranında OUT SEND - WAIT_APPLICATION_RESPONSE ve zarf geçmişi 1300 doğrulandı. IN kaydı sisteme geldi; kullanıcı PDF/XML'in indiğini bildirdi. Son salt okunur servis sorgusunda IN hâlâ RECEIVE - WAIT_SYSTEM_RESPONSE idi. Kabul/ret/kısmi kabul servis gönderimi yapılmadı; bu üç test henüz tamamlanmış sayılmaz.

Kurulumdan sonra EDM test alanı → e-İrsaliye → KVI2026000000003 IN → İrsaliye durumunu sorgula. RECEIVE - WAIT_APPLICATION_RESPONSE olduğunda kabul onayı işaretlenip Test irsaliyesini kabul et düğmesine bir kez basılabilir. WAIT_SYSTEM_RESPONSE devam ederse yanıt zorlanmaz, yeni irsaliye gönderilmez. Süreç uzarsa EDM teknik destekten aynı UUID için sistem yanıtı kuyruğunun incelenmesi istenir.

Tam kabul tamamlandıktan sonra ret ve kısmi kabul için ayrı yeni test irsaliyeleri hazırlanmalıdır. Aynı irsaliyede üç farklı yanıt denemesi yapılmaz. Kısmi kabul örneğinde birinci satırın 20 adet miktarı için 19 kabul/1 ret, diğer satırların tamamı kabul şeklinde denenebilir.

35 mevcut migration, firma bilgileri, geçmiş test belgeleri, yerel kontör, planlar ve tasarım değiştirilmez. Canlıya hazır olunduğu iddia edilmez. Normal firma panelinden üretim e-belgesi oluşturma ve diğer belge türlerinin tamamlanması ayrıca gerekir.
