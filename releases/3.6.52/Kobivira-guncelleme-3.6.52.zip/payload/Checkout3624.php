<?php
declare(strict_types=1);
function checkout3624_config():array {
 $v=json_decode(setting('paytr_checkout3624','{}'),true,16,JSON_THROW_ON_ERROR);return is_array($v)?$v+['mode'=>'off','test_company'=>0,'test_activation'=>0]:['mode'=>'off','test_company'=>0,'test_activation'=>0];
}
function checkout3624_available(?int $cid=null):bool {
 $c=checkout3624_config();if(checkout3626_marked($cid??0)&&$c['mode']==='live')return false;return $c['mode']==='live'||($c['mode']==='sandbox'&&$cid!==null&&(int)$c['test_company']===$cid);
}
function checkout3624_options():array {return (checkout3624_available(company_id())?['card'=>'Kredi / banka kartı']:[])+['transfer'=>'Havale / EFT'];}
function checkout3624_admin_post():never {
 admin351_guard();reauthenticate(base_user());$mode=choice('checkout_mode',['off','sandbox','live']);$cid=int_field('test_company',0,PHP_INT_MAX);
 if($mode!=='off')Paytr3623::credentials(profile_values(service_profile(0,'paytr')));
 if($mode==='sandbox'&&!query("SELECT id FROM companies WHERE id=? AND status='active'",[$cid])->fetchColumn())throw new DomainException('Test için aktif bir firma seçin.');
 if($mode==='live'&&($_POST['live_confirm']??'')!=='1')throw new DomainException('PayTR canlı hesap onayını işaretleyin.');
 $activate=$mode==='sandbox'&&($_POST['test_activation']??'')==='1';transaction(function()use($mode,$cid,$activate){if($activate)checkout3626_designate($cid);query("INSERT INTO settings(name,value) VALUES ('paytr_checkout3624',?) ON DUPLICATE KEY UPDATE value=VALUES(value)",[json_encode(['mode'=>$mode,'test_company'=>$cid,'test_activation'=>(int)$activate],JSON_THROW_ON_ERROR)]);audit('integration.configured',['reason'=>'PayTR paket ödemeleri · '.$mode]);});flash('Paket ödeme ayarları kaydedildi.');redirect('service_admin',['provider'=>'paytr']);
}
function checkout3624_admin_view():void {
 admin351_guard();$c=checkout3624_config();panel('Firma paket ödemeleri','Kart ödemesi imzalı bildirimle otomatik; havale/EFT yönetici onayıyla etkinleşir. Kontör satışı kapalıdır.');
 form_start('service_admin','checkout_settings',['provider'=>'paytr']);select_field('checkout_mode','Kart ödemeleri',['off'=>'Kapalı','sandbox'=>'Test · yalnız seçilen firma','live'=>'Canlı · firmalar kartla paket alabilir'],$c['mode']);select_field('test_company','Test firması',[0=>'Seçin']+array_column(query("SELECT id,CONCAT(name,' · ',account_number) label FROM companies WHERE status='active' ORDER BY name LIMIT 2000")->fetchAll(),'label','id'),$c['test_company']);
 echo '<label class="wide"><input type="checkbox" name="test_activation" value="1" '.(!empty($c['test_activation'])?'checked':'').'> Başarılı test ödemesinde yalnız seçilen yeni test firmasının paketini ve süresini güncelle.</label><p class="field-hint wide">Ücretli üyeliği bulunan firma bu seçenekle test hesabı yapılamaz. Test hesabında canlı ödeme ve canlı e-Belge işlemi kapalıdır.</p>';echo '<label class="wide"><input type="checkbox" name="live_confirm" value="1"> PayTR mağazamın canlı ödeme onayı bulunduğunu ve gerçek tahsilatı açtığımı onaylıyorum.</label><p class="field-hint wide">Testte paket değişimi yalnız yukarıdaki izinle ayrılmış test hesabında uygulanır. Canlı modda PayTR hesabının da canlı olması gerekir. Bildirim URL: <code>'.esc(Paytr3623::ORIGIN.'/?page=paytr_callback').'</code></p>';input('current_password','Kobivira yönetici şifreniz','','password','required');form_end('Paket ödeme ayarlarını kaydet');echo '</section>';checkout3626_reset_view();
}
function checkout3624_guard():void {firm_manager();if(suspended_firm())throw new DomainException('Firma hesabı kısıtlı. Ödeme öncesinde destekle görüşün.');}
function checkout3624_prepare(int $id,array $buyer,string $ip):array {
 checkout3624_guard();return transaction(function()use($id,$buyer,$ip){
  $cid=company_id();query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$cid]);
  $o=query('SELECT o.*,p.name plan_name FROM payment_orders o JOIN plans p ON p.id=o.plan_id WHERE o.id=? AND o.company_id=? FOR UPDATE',[$id,$cid])->fetch();if(!$o||$o['payment_method']!=='card')throw new DomainException('Kart ödeme talebi bulunamadı.');
  $old=query('SELECT * FROM gateway_payments WHERE membership_order_id=?',[$id])->fetch();if($old)return $old;
  if($o['status']!=='awaiting_card')throw new DomainException('Bu ödeme talebi kartla ödenemez.');
  if(!checkout3624_available($cid))throw new DomainException('Kart ödemeleri şu anda kullanılamıyor.');
  if((int)query('SELECT COUNT(*) FROM gateway_payments WHERE company_id=? AND created_at>DATE_SUB(UTC_TIMESTAMP(),INTERVAL 1 HOUR)',[$cid])->fetchColumn()>=10)throw new DomainException('Çok fazla ödeme denemesi var. Mevcut ödeme durumunu kontrol edin.');
  $c=Paytr3623::credentials(profile_values(service_profile(0,'paytr')));$cfg=checkout3624_config();$mode=$cfg['mode'];$testActivate=$mode==='sandbox'&&!empty($cfg['test_activation'])&&(int)$cfg['test_company']===$cid&&checkout3626_marked($cid);
  $r=['id'=>0,'company_id'=>$cid,'membership_order_id'=>$id,'order_kind'=>'membership','mode'=>$mode,'amount'=>$o['total'],'merchant_oid'=>'KVP'.strtoupper(bin2hex(random_bytes(16)))];
  checkout3624_payload($r,$o,$c,$buyer,$ip);
  query("INSERT INTO gateway_payments(company_id,membership_order_id,order_kind,mode,amount,merchant_oid,credential_cipher,test_activation,created_at,updated_at) VALUES (?,?,'membership',?,?,?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())",[$cid,$id,$mode,$o['total'],$r['merchant_oid'],seal_code(json_encode($c,JSON_THROW_ON_ERROR)),(int)$testActivate]);return query('SELECT * FROM gateway_payments WHERE id=?',[(int)db()->lastInsertId()])->fetch();
 });
}
function checkout3624_payload(array $r,array $o,array $c,array $buyer,string $ip):array {
 if($r['order_kind']!=='membership'||!empty($r['credit_order_id']))throw new DomainException('Kontör kart ödemesi kapalı.');
 $p=Paytr3623::payload(['id'=>$o['id'],'plan_name'=>$o['plan_name'],'months'=>$o['months'],'amount'=>$r['amount'],'merchant_oid'=>$r['merchant_oid']],$c,$buyer,$ip);
 $number=(string)query('SELECT account_number FROM companies WHERE id=?',[$r['company_id']])->fetchColumn();if(!preg_match('/^[1-9][0-9]{7}$/D',$number))throw new DomainException('Firma hesap numarası bulunamadı.');
 $back=Paytr3623::ORIGIN.'/?page=payment_return&company='.$number.'&id='.(int)$o['id'];$p['merchant_ok_url']=$back.'&returned=success';$p['merchant_fail_url']=$back.'&returned=failed';
 $p['test_mode']=$r['mode']==='live'?'0':'1';$p['paytr_token']=Paytr3623::tokenHash($p,$c);return $p;
}
function checkout3624_start(array $r,array $buyer,string $ip,?callable $transport=null):void {
 $o=query('SELECT o.*,p.name plan_name FROM payment_orders o JOIN plans p ON p.id=o.plan_id WHERE o.id=?',[$r['membership_order_id']])->fetch();$c=Paytr3623::credentials(json_decode(open_code($r['credential_cipher']),true,16,JSON_THROW_ON_ERROR));$p=checkout3624_payload($r,$o,$c,$buyer,$ip);
 // Claim under company/order lock before I/O; cancellation cannot race token issuance.
 $claimed=transaction(function()use($r){if(!checkout3624_available((int)$r['company_id'])||checkout3624_config()['mode']!==$r['mode'])throw new DomainException('Kart ödeme ayarı değişti. Ödeme talebini yeniden açın.');query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$r['company_id']]);$o=query('SELECT * FROM payment_orders WHERE id=? FOR UPDATE',[$r['membership_order_id']])->fetch();if($o['status']!=='awaiting_card')return false;query("UPDATE gateway_payments SET status='requesting',updated_at=UTC_TIMESTAMP() WHERE id=? AND status='created'",[$r['id']]);return (bool)query('SELECT ROW_COUNT()')->fetchColumn();});if(!$claimed)return;
 try{$v=$transport?$transport($p):Paytr3623::request($p);
  if(($v['status']??'')==='success'&&is_string($v['token']??null)&&preg_match('/^[A-Za-z0-9_-]{10,200}$/D',$v['token']))query("UPDATE gateway_payments SET status='ready',token_cipher=?,detail='Ödeme sonucu bekleniyor.',updated_at=UTC_TIMESTAMP() WHERE id=? AND status='requesting'",[seal_code($v['token']),$r['id']]);
  elseif(($v['status']??'')==='failed')transaction(function()use($r){query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$r['company_id']]);query('SELECT id FROM payment_orders WHERE id=? FOR UPDATE',[$r['membership_order_id']]);query("UPDATE gateway_payments SET status='api_error',detail='Ödeme ekranı açılamadı. Bilgilerinizi kontrol edin veya destekle görüşün.',updated_at=UTC_TIMESTAMP() WHERE id=? AND status='requesting'",[$r['id']]);if(query('SELECT ROW_COUNT()')->fetchColumn())query("UPDATE payment_orders SET status='card_failed' WHERE id=? AND status='awaiting_card'",[$r['membership_order_id']]);});else throw new RuntimeException('Geçersiz PayTR yanıtı.');
 }catch(Throwable){query("UPDATE gateway_payments SET status='unknown',detail='Ödeme sonucu henüz kesinleşmedi. Yeniden ödeme yapmadan destekle görüşün.',updated_at=UTC_TIMESTAMP() WHERE id=? AND status='requesting'",[$r['id']]);}
}
/** Runs inside a transaction with company + order + gateway locked. No session or POST dependency. */
function checkout3624_activate(array $o):void {
 $cid=(int)$o['company_id'];$id=(int)$o['id'];$s=query('SELECT * FROM subscriptions WHERE company_id=? FOR UPDATE',[$cid])->fetch();$p=query('SELECT * FROM plans WHERE id=? FOR UPDATE',[$o['plan_id']])->fetch();
 if(checkout3626_marked($cid))throw new DomainException('Ayrılmış test hesabına gerçek üyelik uygulanamaz.');if(!in_array($p['code']??'',['kobi','plus','business'],true)||!$s)throw new DomainException('Paket veya üyelik bulunamadı.');
 if(query('SELECT status FROM companies WHERE id=?',[$cid])->fetchColumn()!=='active')throw new DomainException('Firma incelemesi gerekli.');
 $count=(int)query("SELECT COUNT(*) FROM users WHERE company_id=? AND is_active=1 AND is_deleted=0 AND role<>'accountant'",[$cid])->fetchColumn();if($count>(int)$p['user_limit'])throw new DomainException('Kullanıcı sınırı kontrol edilmeli.');
 $bonus=terms354_bonus($o,$s);$before=refund356_state($cid);$now=new DateTimeImmutable('now',new DateTimeZone('UTC'));$start=$now;
 if((int)$s['plan_id']===(int)$o['plan_id']&&$s['status']==='active'&&$s['paid_until']&&strtotime($s['paid_until'].' UTC')>time())$start=new DateTimeImmutable($s['paid_until'],new DateTimeZone('UTC'));
 $end=add_months_utc($start,(int)$o['months'])->modify('+'.$bonus.' seconds')->format('Y-m-d H:i:s');query('UPDATE membership_terms354 SET applied_bonus_seconds=? WHERE payment_order_id=?',[$bonus,$id]);
 $reference='PAYTR:'.query('SELECT merchant_oid FROM gateway_payments WHERE membership_order_id=?',[$id])->fetchColumn();commerce_receipt($reference,'membership',$id);
 query("UPDATE payment_orders SET status='approved',bank_reference=?,admin_note='Kart ödemesi PayTR bildirimiyle doğrulandı.',approved_by=NULL,approved_at=UTC_TIMESTAMP() WHERE id=?",[$reference,$id]);query("UPDATE subscriptions SET plan_id=?,status='active',has_paid_membership=1,paid_until=?,period_started_at=? WHERE company_id=?",[$o['plan_id'],$end,$start>$now?$s['period_started_at']:$now->format('Y-m-d H:i:s'),$cid]);
 referral_on_payment($o);referral_apply_bank($cid);$credits=(int)$p['credits_per_period']*(int)$o['months'];if($credits)credit_change($cid,$credits,'Paket dönemi kontörü','payment:'.$id,0);gift354_award($o,0);refund356_snapshot($id,$cid,$before);
 company_notice($cid,'payment:'.$id.':approved','Ödemeniz alındı',$o['reference'].' · Paketiniz etkinleştirildi.','billing',$id);billing_notice($o,'approved');mail3650_payment($id,'activated');
 query("INSERT INTO audit_logs(company_id,actor_name,action,metadata,created_at) VALUES (?,'PayTR','billing.approved',?,UTC_TIMESTAMP())",[$cid,json_encode(['order'=>$id,'total'=>(int)$o['total'],'paid_until'=>$end,'method'=>'card'],JSON_THROW_ON_ERROR)]);
}
function checkout3624_receive(array $p):void {
 foreach(['merchant_oid','status','total_amount','hash'] as $k)if(!is_string($p[$k]??null))throw new DomainException('Geçersiz bildirim.');
 if(!preg_match('/^KVP[A-F0-9]{32}$/D',$p['merchant_oid'])||!in_array($p['status'],['success','failed'],true)||!preg_match('/^[0-9]{1,12}$/D',$p['total_amount'])||strlen($p['hash'])!==44)throw new DomainException('Geçersiz bildirim.');
 $ref=query('SELECT company_id,membership_order_id FROM gateway_payments WHERE merchant_oid=?',[$p['merchant_oid']])->fetch();if(!$ref)throw new DomainException('Bilinmeyen ödeme.');
 transaction(function()use($p,$ref){
  query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$ref['company_id']]);$o=query('SELECT * FROM payment_orders WHERE id=? FOR UPDATE',[$ref['membership_order_id']])->fetch();$r=query('SELECT * FROM gateway_payments WHERE merchant_oid=? FOR UPDATE',[$p['merchant_oid']])->fetch();
  if(!$o||$r['order_kind']!=='membership'||$o['payment_method']!=='card'||(int)$o['company_id']!==(int)$r['company_id'])throw new DomainException('Ödeme eşleşmedi.');
  $c=Paytr3623::credentials(json_decode(open_code($r['credential_cipher']),true,16,JSON_THROW_ON_ERROR));if(!hash_equals(Paytr3623::callbackHash($p['merchant_oid'],$p['status'],$p['total_amount'],$c),$p['hash']))throw new DomainException('İmza geçersiz.');
  if($p['status']==='success'&&((int)$p['total_amount']!==(int)$r['amount']||(int)$o['total']!==(int)$r['amount']))throw new DomainException('Tutar eşleşmedi.');
  if($r['callback_status']!==null){$conflict=$r['callback_status']!==$p['status']||(int)$r['callback_amount']!==(int)$p['total_amount'];query('UPDATE gateway_payments SET callback_count=callback_count+1,callback_conflict=GREATEST(callback_conflict,?),updated_at=UTC_TIMESTAMP() WHERE id=?',[(int)$conflict,$r['id']]);if($conflict)admin_notification((int)$r['company_id'],'paytr:conflict:'.$r['id'],'payment_review','Kart ödemesi incelemesi',$r['merchant_oid'].' · Farklı sonuç bildirimleri alındı.',(int)$o['id']);return;}
  $status=$p['status'];$detail='';
  if($status==='failed'){query("UPDATE payment_orders SET status='card_failed' WHERE id=? AND status='awaiting_card'",[$o['id']]);$detail='Ödeme tamamlanamadı. Paketiniz değiştirilmedi.';}
  elseif($r['mode']!=='live'||($p['test_mode']??null)==='1'){$detail=checkout3626_test_result($o,$r);query("UPDATE payment_orders SET status='card_test_success' WHERE id=? AND status='awaiting_card'",[$o['id']]);}
  else{
   // Savepoint retains a proven payment while rolling back all partial entitlement effects.
   db()->exec('SAVEPOINT paytr_activation');
   try{if($o['status']!=='awaiting_card')throw new DomainException('Ödeme talebinin durumu değişmiş.');checkout3624_activate($o);$detail='Ödemeniz alındı. Paketiniz etkinleştirildi.';}
   catch(DomainException $e){db()->exec('ROLLBACK TO SAVEPOINT paytr_activation');$status='review';$detail='Ödemeniz alındı. Paketinizin etkinleştirilmesi için destek ekibimiz kontrol sağlıyor.';query("UPDATE payment_orders SET status='card_review' WHERE id=?",[$o['id']]);admin_notification((int)$o['company_id'],'paytr:review:'.$r['id'],'payment_review','Tahsil edilen kart ödemesi inceleme bekliyor',$r['merchant_oid'].' · Üyelik veya kullanıcı koşulları değişti.',(int)$o['id']);}
   db()->exec('RELEASE SAVEPOINT paytr_activation');
  }
  query('UPDATE gateway_payments SET status=?,detail=?,callback_status=?,callback_amount=?,callback_count=1,callback_at=UTC_TIMESTAMP(),token_cipher=NULL,updated_at=UTC_TIMESTAMP() WHERE id=?',[$status,$detail,$p['status'],(int)$p['total_amount'],$r['id']]);
 });
}
function checkout3624_post(string $action):never {
 checkout3624_guard();if(!in_array($action,['card_start','card_cancel'],true))throw new DomainException('Geçersiz ödeme işlemi.');$id=int_field('id',1,PHP_INT_MAX);
 if($action==='card_cancel'){transaction(function()use($id){query('SELECT id FROM companies WHERE id=? FOR UPDATE',[company_id()]);$o=query("SELECT * FROM payment_orders WHERE id=? AND company_id=? AND payment_method='card' FOR UPDATE",[$id,company_id()])->fetch();if(!$o||$o['status']!=='awaiting_card')throw new DomainException('Ödeme iptal edilemez.');$g=query('SELECT * FROM gateway_payments WHERE membership_order_id=? FOR UPDATE',[$id])->fetch();if($g&&$g['status']!=='created')throw new DomainException('Ödeme başlatılmış; sonuç kesinleşmeden iptal edilemez.');query("UPDATE payment_orders SET status='cancelled' WHERE id=?",[$id]);if($g)query("UPDATE gateway_payments SET status='cancelled' WHERE id=?",[$g['id']]);});redirect('billing',['id'=>$id]);}
 if(!function_exists('curl_init'))throw new DomainException('Kart ödeme bağlantısı kullanılamıyor. Destek ekibimizle görüşün.');
 $buyer=['email'=>required_field('email',100),'user_name'=>required_field('user_name',60),'user_phone'=>required_field('user_phone',20),'user_address'=>required_field('user_address',400)];$ip=(string)($_SERVER['REMOTE_ADDR']??'');$r=checkout3624_prepare($id,$buyer,$ip);checkout3624_start($r,$buyer,$ip);redirect('billing',['id'=>$id]);
}
function checkout3624_view(array $o):void {
 $g=query('SELECT * FROM gateway_payments WHERE membership_order_id=?',[$o['id']])->fetch();
 echo '<p>Ödeme yöntemi: <strong>Kredi / banka kartı</strong></p>';
 if($g){echo '<p>'.esc($g['detail']).'</p>';if($g['callback_conflict']&&owner())echo '<p>Farklı sonuç bildirimleri var; PayTR işlem kaydı incelenmeli.</p>';if($g['mode']!=='live')echo '<p class="info-note">Bu işlem PayTR test ortamındadır; gerçek ücret tahsil edilmez. Paket değişimi yalnız izin verilen test hesabında uygulanır.</p>';}
 if(owner()){echo '<p>Referans: '.esc($g['merchant_oid']??'Henüz başlatılmadı').'</p>';if($g&&$o['status']==='card_review'){form_start('billing','card_resolve');hidden('id',$o['id']);input('current_password','Kobivira yönetici şifreniz','','password','required');form_end('Koşulları tekrar kontrol et ve paketi etkinleştir');}return;}
 if($o['status']==='awaiting_card'&&(!$g||$g['status']==='created')){
  if(!checkout3624_available((int)$o['company_id']))echo '<p>Kart ödemesi şu anda kullanılamıyor. Bu talebi iptal edip Havale/EFT seçebilirsiniz.</p>';
  else{$company=query('SELECT * FROM companies WHERE id=?',[$o['company_id']])->fetch();if(checkout3624_config()['mode']==='sandbox'&&!$g)echo '<p class="info-note">Bu firma için test ödeme ortamı açıktır; gerçek tahsilat yapılmaz. Paket değişimi yalnız yönetimden test izni verildiyse uygulanır.</p>';form_start('billing','card_start');hidden('id',$o['id']);input('user_name','Ad soyad',mb_substr(base_user()['name']??'',0,60),'text','required maxlength="60"');input('email','E-posta',base_user()['email']??'','email','required maxlength="100"');input('user_phone','Telefon',mb_substr($company['phone'],0,20),'tel','required maxlength="20"');input('user_address','Adres',mb_substr($company['address']??'',0,400),'text','required maxlength="400"');form_end('Kartla öde');}
  small_action('billing','card_cancel','Ödeme talebini iptal et',['id'=>$o['id']]);
 }
 if($g&&$o['status']==='awaiting_card'&&$g['status']==='ready'&&$g['token_cipher']&&strtotime($g['created_at'].' UTC')>time()-1800){$token=open_code($g['token_cipher']);if(preg_match('/^[A-Za-z0-9_-]{10,200}$/D',$token))echo '<iframe class="paytr3623-frame" src="https://www.paytr.com/odeme/guvenli/'.esc($token).'" title="Güvenli kart ödeme ekranı" referrerpolicy="no-referrer"></iframe>';}
 if($o['status']==='awaiting_card'&&$g)echo '<p>Ödeme sonucunuz bekleniyor. Yeniden ödeme yapmadan sonucu kontrol edin.</p><p>'.a('billing','Sonucu yenile',['id'=>$o['id']],'button').'</p>';
 if(in_array($o['status'],['card_failed','card_test_success'],true))echo a('membership','Paketlere dön',['view'=>'plans'],'button');
 if($o['status']==='approved')echo '<p>'.a('dashboard','Panelime dön',[],'button primary').'</p>';
}
function checkout3624_resolve():never {
 admin351_guard();reauthenticate(base_user());$id=int_field('id',1,PHP_INT_MAX);
 transaction(function()use($id){$cid=(int)query('SELECT company_id FROM payment_orders WHERE id=?',[$id])->fetchColumn();query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$cid]);$o=query('SELECT * FROM payment_orders WHERE id=? FOR UPDATE',[$id])->fetch();$g=query('SELECT * FROM gateway_payments WHERE membership_order_id=? FOR UPDATE',[$id])->fetch();if(!$o||$o['status']!=='card_review'||!$g||$g['mode']!=='live'||$g['callback_status']!=='success'||(int)$g['callback_amount']!==(int)$o['total']||$g['callback_conflict'])throw new DomainException('Doğrulanmış ve incelemeye uygun ödeme bulunamadı.');checkout3624_activate($o);query("UPDATE gateway_payments SET status='success',detail='Ödemeniz alındı. Paketiniz etkinleştirildi.',updated_at=UTC_TIMESTAMP() WHERE id=?",[$g['id']]);});flash('Paket etkinleştirildi.');redirect('billing',['id'=>$id]);
}
function checkout3624_credit_view():void {
 commerce_guard();heading('Kontörlerim');$cid=company_id();panel('Kontör bakiyesi · '.(int)query('SELECT credits_balance FROM companies WHERE id=?',[$cid])->fetchColumn());echo '<p>Bu alan kayıtlı kontör hareketlerinizi gösterir.</p></section>';panel('Kontör hareketleri');$rows=query('SELECT * FROM credit_ledger WHERE company_id=? ORDER BY id DESC LIMIT 100',[$cid])->fetchAll();table_start(['Zaman','Açıklama','Değişim','Bakiye']);foreach($rows as $r)echo '<tr><td>'.esc(desk_time($r['created_at'])).'</td><td>'.esc($r['reason']).'</td><td>'.(int)$r['delta'].'</td><td>'.(int)$r['balance_after'].'</td></tr>';table_end(count($rows),4);echo '</section>';
}
/** Public, display-only bridge: leave the payment iframe and return to the company panel. */
function checkout3624_return():never {
 $number=$_GET['company']??null;$id=$_GET['id']??null;$result=$_GET['returned']??'';
 if(($_SERVER['REQUEST_METHOD']??'')!=='GET'||!is_string($number)||!preg_match('/^[1-9][0-9]{7}$/D',$number)||!is_string($id)||!preg_match('/^[1-9][0-9]{0,17}$/D',$id)||!is_string($result)||!in_array($result,['success','failed'],true)){http_response_code(400);exit('Geçersiz dönüş adresi.');}
 $target=Paytr3623::ORIGIN.'/'.$number.'/?page=billing&id='.$id.'&returned='.$result;$nonce=base64_encode(random_bytes(18));
 header('Content-Type: text/html; charset=utf-8');header('Cache-Control: no-store');header('Referrer-Policy: no-referrer');header("Content-Security-Policy: default-src 'none'; script-src 'nonce-$nonce'; base-uri 'none'; frame-ancestors 'self'");header('X-Content-Type-Options: nosniff');
 echo '<!doctype html><html lang="tr"><meta charset="utf-8"><title>Ödeme sonucuna dön</title><p><a target="_top" href="'.esc($target).'">Firma panelimde ödeme sonucunu aç</a></p><script nonce="'.esc($nonce).'">window.top.location.replace('.json_encode($target,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_THROW_ON_ERROR).');</script></html>';exit;
}
