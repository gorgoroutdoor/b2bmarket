# EDM 3.6.5

EDM teknik temsilcisinin yazılı açıklaması doğrultusunda tüm SOAP isteklerinde APPLICATION_NAME değeri tam olarak Kobivira olacak şekilde sabitlendi. Önceki sürümdeki sürüm numarası kaldırıldı. Login, firma doğrulama, kontör sorgusu, alıcı sorgusu, gelen belge, durum, gönderim ve kabul/ret aynı istek oluşturucuyu kullanır. Önceki ret ekranı açıklamaları korunur.

Bu güncelleme test ortamında kalır. Canlı bağlantı açmaz ve EDM tarafındaki hak ediş kaydının yapıldığını kanıtlamaz. EDM'den Kobivira adının tanımlandığı ve hesaplama/ödeme koşulları ayrıca teyit edilmelidir. Geçmiş istekler yeniden gönderilmez.

Paket 3.6.4 üzerine kurulur. Kurulu sürüm 3.6.3 ise önce 3.6.4 yüklenmelidir.
