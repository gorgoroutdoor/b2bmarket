<?php
declare(strict_types=1);
// Local hosting terminal only. Uses the same signature and migration checks as the panel.
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
if(count($argv)!==4||$argv[1]!=='--confirm'||!ctype_digit($argv[3]))exit("Kullanım: php UpdateCli.php --confirm /tam/yol/imzali-surum.zip YONETICI_ID\n");
define('APP_ROOT',dirname(__DIR__,2));
$gate=fopen(APP_ROOT.'/storage/request.lock','c');if(!$gate||!flock($gate,LOCK_EX|LOCK_NB))exit("Sistem meşgul.\n");
try{
 $pointer=json_decode((string)file_get_contents(APP_ROOT.'/storage/current.json'),true,16,JSON_THROW_ON_ERROR);$version=$pointer['version']??'';
 if(!is_string($version)||!preg_match('/^\d+\.\d+\.\d+$/D',$version))throw new RuntimeException('Kurulu sürüm geçersiz.');
 define('APP_VERSION',$version);define('RELEASE_ROOT',APP_ROOT.'/releases/'.$version);
 foreach(['Core','Migrator','ReleaseHistory','Backup','Updater'] as $module)require RELEASE_ROOT.'/'.$module.'.php';
 $actor=(int)$argv[3];if(!query("SELECT id FROM users WHERE id=? AND role='platform_admin' AND is_active=1 AND is_deleted=0",[$actor])->fetchColumn())throw new DomainException('Etkin platform yöneticisi gerekir.');
 if(!is_file($argv[2]))throw new DomainException('Güncelleme dosyası bulunamadı.');
 set_time_limit(0);(new Updater(db()))->install($argv[2],$actor);echo "İmzalı güncelleme tamamlandı.\n";
}catch(Throwable $e){fwrite(STDERR,$e->getMessage()."\n");exit(1);}finally{flock($gate,LOCK_UN);fclose($gate);}
