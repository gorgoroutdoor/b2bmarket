<?php
declare(strict_types=1);
function purge_row(array $row): array {$out=[];foreach($row as $k=>$v){if($v===null){$out[$k]=null;continue;}$d=base64_decode($v,true);if($d===false)throw new DomainException('Uygulama yedeği doğrulanamadı. Firma silinmedi.');$out[$k]=$d;}return $out;}
function purge_matches(string $table,array $r,int $cid,array $notificationIds,array $commerce=[],array $siteIds=[],array $userIds=[]): bool {
    if(in_array($table,['registration_email_checks','account_mobile_codes'],true)&&isset($userIds[(int)($r['user_id']??0)]))return true;
    if(in_array($table,['referral_links','referral_rewards'],true)&&((int)($r['referrer_company_id']??0)===$cid||(int)($r['referred_company_id']??0)===$cid))return true;
    if(str_starts_with($table,'cms_')&&isset($r['site_id'])&&isset($siteIds[(int)$r['site_id']]))return true;
    if(in_array($table,['payment_pricing','membership_terms354'],true)&&isset($commerce['membership'][(int)($r['payment_order_id']??0)]))return true;
    if($table==='commerce_receipts'&&isset($commerce[$r['order_kind']??''][(int)($r['order_id']??0)]))return true;
    if(isset($r['company_id'])&&(int)$r['company_id']===$cid)return true;
    if($table==='companies'&&(int)($r['id']??0)===$cid)return true;
    if($table==='admin_notification_reads'&&isset($notificationIds[(int)($r['notification_id']??0)]))return true;
    if($table==='audit_logs'&&($r['company_id']??null)===null){$m=json_decode($r['metadata']??'{}',true);if(is_array($m)&&(int)($m['company']??0)===$cid)return true;}
    return false;
}
function purge_prepare_backups(int $cid,?string $only=null): array {
    $staged=[];$deadline=microtime(true)+25;
    try{foreach(glob(APP_ROOT.'/storage/backups/backup-*.jsonl.gz')?:[] as $source){
        if($only!==null&&$source!==$only)continue;
        if(is_link($source))throw new DomainException('Yedek yolu doğrulanamadı. Firma silinmedi.');
        $f=gzopen($source,'rb');if(!$f)throw new DomainException('Yedek okunamadı. Firma silinmedi.');$table='';$ids=[];$commerce=['membership'=>[],'credits'=>[]];$siteIds=[];$userIds=[];
        try{while(($line=gzgets($f))!==false){if(microtime(true)>$deadline)throw new DomainException('Yedek temizliği web işlem süresini aşıyor. Firma silinmedi; yönetici teknik bakım üzerinden temizliği tamamlamalıdır.');$item=json_decode($line,true,512,JSON_THROW_ON_ERROR);if(isset($item['table']))$table=$item['table'];elseif(isset($item['row'])&&in_array($table,['admin_notifications','payment_orders','credit_orders','cms_sites','users'],true)){$r=purge_row($item['row']);if((int)$r['company_id']===$cid){if($table==='users')$userIds[(int)$r['id']]=true;elseif($table==='cms_sites')$siteIds[(int)$r['id']]=true;elseif($table==='admin_notifications')$ids[(int)$r['id']]=true;else $commerce[$table==='payment_orders'?'membership':'credits'][(int)$r['id']]=true;}}}}finally{gzclose($f);}
        $temporary=APP_ROOT.'/storage/backups/purge-'.bin2hex(random_bytes(12)).'.tmp';$staged[]=['source'=>$source,'temporary'=>$temporary];$f=gzopen($source,'rb');$out=gzopen($temporary,'wb6');if(!$f||!$out)throw new DomainException('Yedek temizliği hazırlanamadı. Firma silinmedi.');chmod($temporary,0600);$table='';$count=0;$originalRows=0;$ended=false;
        try{while(($line=gzgets($f))!==false){if(microtime(true)>$deadline)throw new DomainException('Yedek temizliği süre sınırını aşıyor. Firma silinmedi.');$item=json_decode($line,true,512,JSON_THROW_ON_ERROR);if(isset($item['table']))$table=$item['table'];elseif(isset($item['row'])){$originalRows++;if(purge_matches($table,purge_row($item['row']),$cid,$ids,$commerce,$siteIds,$userIds))continue;$count++;}elseif(isset($item['end'])){if($item['end']!==true||(int)$item['rows']!==$originalRows)throw new DomainException('Eksik uygulama yedeği bulundu. Firma silinmedi.');$ended=true;$item['rows']=$count;}if($ended&&isset($item['row']))throw new DomainException('Yedek sırası geçersiz.');$bytes=json_encode($item,JSON_THROW_ON_ERROR)."\n";if(gzwrite($out,$bytes)!==strlen($bytes))throw new DomainException('Temiz yedek yazılamadı. Firma silinmedi.');}if(!$ended)throw new DomainException('Eksik uygulama yedeği bulundu. Firma silinmedi.');}finally{gzclose($f);gzclose($out);}
    }return $staged;}catch(Throwable $e){foreach($staged as $s)if(is_file($s['temporary']))unlink($s['temporary']);throw $e;}
}
function permanently_delete_company(): never {
    $u=base_user();if(!$u||support_context()||isset($_GET['support'])){http_response_code(403);throw new DomainException('Canlı destek üzerinden firma silinemez.');}
    $isAdmin=$u['role']==='platform_admin';if(!$isAdmin&&$u['role']!=='company_admin'){http_response_code(403);throw new DomainException('Firma silmek için firma veya platform yöneticisi yetkisi gerekir.');}
    $cid=$isAdmin?int_field('company_id',1,PHP_INT_MAX):(int)$u['company_id'];if(!purge3648_approved($cid,$u))reauthenticate($u);
    if(required_field('confirm_delete',10)!=='SİL'||!isset($_POST['acknowledge_delete']))throw new DomainException('Geri alınamaz silmeyi onaylayın ve SİL yazın.');
    $gate=$GLOBALS['gate']??null;if(!is_resource($gate)||!flock($gate,LOCK_EX|LOCK_NB)){http_response_code(423);throw new DomainException('Sistem işlem yapıyor. Firma silinmedi; kısa süre sonra tekrar deneyin.');}
    $staged=[];$evidenceFiles=[];
    try{transaction(function()use($cid,&$staged,&$evidenceFiles){$c=query('SELECT * FROM companies WHERE id=? FOR UPDATE',[$cid])->fetch();if(!$c)throw new DomainException('Firma bulunamadı.');if(required_field('confirm_company',160)!==$c['name'])throw new DomainException('Firma unvanını ekranda yazdığı gibi tekrar girin.');if(is_file(APP_ROOT.'/storage/maintenance.json'))throw new DomainException('Güncelleme veya kurtarma sırasında firma silinemez.');
        // Prepare every sanitized snapshot before changing either live data or any stored backup.
        $GLOBALS['purge_cms_sites']=array_fill_keys(array_column(query('SELECT id FROM cms_sites WHERE company_id=?',[$cid])->fetchAll(),'id'),true);$staged=purge3648_final_backups($cid);$evidenceFiles=array_merge($evidenceFiles,migration_company_paths($cid));$websites=query('SELECT id FROM cms_sites WHERE company_id=?',[$cid])->fetchAll();foreach($websites as $w){foreach(query('SELECT filename FROM cms_media WHERE site_id=?',[$w['id']]) as $m)$evidenceFiles[]=APP_ROOT.'/storage/site-media/'.$m['filename'];foreach(['cms_history','cms_media','cms_nav','cms_features','cms_plans','cms_blocks','cms_pages','cms_settings'] as $t)query('DELETE FROM '.$t.' WHERE site_id=?',[$w['id']]);}query('DELETE FROM cms_sites WHERE company_id=?',[$cid]);foreach(query('SELECT * FROM verification_documents WHERE company_id=?',[$cid]) as $e)$evidenceFiles[]=evidence_path($e);
        query('DELETE FROM referral_rewards WHERE company_id=? OR referred_company_id=?',[$cid,$cid]);query('DELETE FROM referral_links WHERE company_id=? OR referrer_company_id=?',[$cid,$cid]);query('DELETE FROM referral_codes WHERE company_id=?',[$cid]);
        query('DELETE r FROM admin_notification_reads r JOIN admin_notifications n ON n.id=r.notification_id WHERE n.company_id=?',[$cid]);
        query("DELETE r FROM commerce_receipts r JOIN payment_orders o ON r.order_kind='membership' AND r.order_id=o.id WHERE o.company_id=?",[$cid]);
        query("DELETE r FROM commerce_receipts r JOIN credit_orders o ON r.order_kind='credits' AND r.order_id=o.id WHERE o.company_id=?",[$cid]);
        query('DELETE FROM annual_credit_awards WHERE company_id=?',[$cid]);query('DELETE p FROM membership_terms354 p JOIN payment_orders o ON o.id=p.payment_order_id WHERE o.company_id=?',[$cid]);query('DELETE p FROM payment_pricing p JOIN payment_orders o ON o.id=p.payment_order_id WHERE o.company_id=?',[$cid]);
        query('DELETE FROM credit_orders WHERE company_id=?',[$cid]);
        foreach(['automatic_emails3650','automatic_email_state3650','checkout_test_accounts','gateway_payments','paytr_test_attempts','edoc_documents','edoc_sequences','edoc_accounts','edm_export_test_documents','edm_smm_test_documents','edm_despatch_test_documents','edm_test_documents','edm_test_accounts','document_revisions','membership_refunds356','membership_effects356','registration_consents','migration_files','migration_items','migration_jobs','migration_campaigns','ledger_reconciliations','ledger_openings','api_usage','api_keys','feature_grants','record_shares','invoice_paylinks','service_jobs','electronic_drafts','integration_profiles','document_templates','stock_moves','staff_money','cheques','repeat_runs','repeat_rules','crm_notes','crm_deals','automation_events','automation_rules','bank_rows','bank_batches','business_approval_rules','user_avatars','import_batches','incoming_invoices','notice_deliveries','company_notices','contact_codes','verification_requests','verification_documents','help_messages','help_tickets','approval_requests','admin_notifications','company_logos','company_presence','document_lines','payments','recurring','tasks','support_requests','support_queue','payment_orders','credit_ledger'] as $table)query('DELETE FROM '.$table.' WHERE company_id=?',[$cid]);
        query('DELETE FROM scheduler_state WHERE name IN (?,?)',['company_cycle_'.$cid,'automation_rule_cursor_'.$cid]);query('UPDATE documents SET source_id=NULL,return_of_id=NULL WHERE company_id=?',[$cid]);query('DELETE FROM documents WHERE company_id=?',[$cid]);query('DELETE FROM business_projects WHERE company_id=?',[$cid]);
        purge3646_user_checks($cid);
        foreach(['products','contacts','accounts','subscriptions','users'] as $table)query('DELETE FROM '.$table.' WHERE company_id=?',[$cid]);
        query("DELETE FROM audit_logs WHERE company_id=? OR (company_id IS NULL AND JSON_UNQUOTE(JSON_EXTRACT(metadata,'$.company'))=?)",[$cid,(string)$cid]);query('DELETE FROM companies WHERE id=?',[$cid]);
        // The transaction is still uncommitted; a failure leaves the live company intact.
        foreach($staged as $s)if(!rename($s['temporary'],$s['source']))throw new DomainException('Yedek temizliği tamamlanamadı. Canlı firma verileri silinmedi.');
    });}finally{foreach($staged as $s)if(is_file($s['temporary']))unlink($s['temporary']);}
    foreach($evidenceFiles as $path)if(is_file($path))unlink($path);if(is_dir(evidence_dir($cid)))rmdir(evidence_dir($cid));
    purge3648_clear($cid);
    if(!$isAdmin){$_SESSION=[];session_regenerate_id(true);flash('Firma üyeliğiniz ve uygulamadaki verileriniz kalıcı olarak silindi.');redirect('login');}
    audit('company.permanently_deleted');flash('Firma, kullanıcıları ve uygulamadaki verileri kalıcı olarak silindi. Uygulama yedeklerinden de temizlendi.');redirect('companies');
}
function delete_company_form(array $c,bool $admin): void {
    if(support_context()||(! $admin&&(base_user()['role']??'')!=='company_admin'))return;
    if(purge3648_progress($c,$admin))return;
    echo '<details class="panel deletion-panel"><summary>Firma üyeliğini ve tüm verileri kalıcı olarak sil</summary><p class="text-red">Bu işlem geri alınamaz. Firmanın tüm kullanıcıları, belgeleri, ödemeleri, firma bilgileri ve logosu silinir. Uygulamanın kendi güncelleme yedeklerinden de temizlenir.</p>';
    form_start($admin?'companies':'account','delete_company',$admin?['edit'=>$c['id'],'view'=>'membership']:[],'form-stack');hidden('company_id',$c['id']);echo '<p>Silinecek firma: <strong>'.esc($c['name']).'</strong></p>';input('confirm_company','Firma unvanını aynen tekrar yazın','','text','required autocomplete="off" maxlength="160"');input('confirm_delete','Onaylamak için SİL yazın','','text','required autocomplete="off"');input('current_password',$admin?'Mevcut platform yöneticisi şifreniz':'Kendi firma yöneticisi şifreniz','','password','required autocomplete="current-password"');echo '<label><input type="checkbox" name="acknowledge_delete" value="1" required> Tüm firma verilerinin kalıcı silineceğini ve geri alınamayacağını anladım.</label>';submit('Firmayı ve tüm verilerini kalıcı sil','danger');echo '</form></details>';
}

function purge3646_user_checks(int $cid):void {foreach(['registration_email_checks','account_mobile_codes'] as $table)query('DELETE checks FROM '.$table.' checks JOIN users u ON u.id=checks.user_id WHERE u.company_id=?',[$cid]);}
