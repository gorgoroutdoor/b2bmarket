<?php
declare(strict_types=1);
function auth3644_clock(int $expires,int $retry,string $label):void {echo '<div class="mail43-small" data-auth-clock data-server-now="'.time().'" data-expires="'.$expires.'" data-retry="'.$retry.'"><p>'.esc($label).': <strong data-auth-expiry>'.($expires?gmdate('i:s',max(0,$expires-time())):'—').'</strong></p><p data-auth-retry-label aria-live="polite"></p></div>';}
function auth3644_retry_html(string $label,int $retry):string {return '<button type="submit" data-auth-retry-button '.($retry>time()?'disabled':'').'>'.esc($label).'</button>';}
function auth3644_retry_button(string $label,int $retry):void {echo auth3644_retry_html($label,$retry);}
function auth3644_script():string {return '<script nonce="'.esc($GLOBALS['nonce']).'">'.file_get_contents(__DIR__.'/AuthClock3644Browser.php').'</script>';}
