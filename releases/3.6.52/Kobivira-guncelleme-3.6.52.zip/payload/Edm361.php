<?php
declare(strict_types=1);

/** SOAP 1.1 sandbox adapter. Never routes a test document to production. */
final class Edm361Client {
    public const ENDPOINT='https://test.edmbilisim.com.tr/EFaturaEDM21ea/EFaturaEDM.svc';
    private string $session='0';
    public function __construct(private string $username, private string $password, private string $company, private ?Closure $transport=null,private string $environment='sandbox') {
        $this->endpoint();
        if(!class_exists('DOMDocument'))throw new DomainException('EDM test alanı için PHP DOM eklentisi gerekir.');
        if($username===''||$password===''||!preg_match('/^\d{10,11}$/D',$company))throw new DomainException('EDM kullanıcı adı, şifre ve test firmasının VKN/TCKN bilgisi gerekir.');
    }
    public static function xml(string $bytes): DOMDocument {
        if(strlen($bytes)>12582912||preg_match('/<!DOCTYPE|<!ENTITY/i',$bytes))throw new DomainException('XML boyutu veya güvenlik kontrolü geçersiz.');
        $d=new DOMDocument();$old=libxml_use_internal_errors(true);try{$ok=$d->loadXML($bytes,LIBXML_NONET|LIBXML_NOBLANKS);}finally{libxml_clear_errors();libxml_use_internal_errors($old);}
        if(!$ok)throw new DomainException('Servisten veya belgeden gelen XML okunamadı.');return $d;
    }
    public static function text(DOMNode $node,string $path): string {$x=new DOMXPath($node instanceof DOMDocument?$node:$node->ownerDocument);return trim((string)$x->evaluate('string('.$path.')',$node instanceof DOMDocument?null:$node));}
    public static function add(DOMNode $parent,string $name,string $value='',array $attrs=[]): DOMElement {
        $d=$parent instanceof DOMDocument?$parent:$parent->ownerDocument;$e=$d->createElement($name);$e->appendChild($d->createTextNode($value));foreach($attrs as $k=>$v)$e->setAttribute($k,(string)$v);$parent->appendChild($e);return $e;
    }
    public function endpoint():string{if(!in_array($this->environment,['sandbox','live'],true))throw new DomainException('e-Belge ortamı geçersiz.');return $this->environment==='sandbox'?self::ENDPOINT:'https://portal2.edmbilisim.com.tr/EFaturaEDM/EFaturaEDM.svc';}
    public function call(string $method,Closure $body): DOMDocument {
        $allowed=['Login','Logout','GetCompany','CheckCounter','CheckUser','GetInvoice','SendInvoice','GetInvoiceStatus','SendInvoiceResponseWithServerSign','CancelInvoice'];
        if(!in_array($method,$allowed,true))throw new DomainException('EDM işlemi desteklenmiyor.');
        $d=new DOMDocument('1.0','UTF-8');$env=$d->createElementNS('http://schemas.xmlsoap.org/soap/envelope/','s:Envelope');$d->appendChild($env);$b=$d->createElementNS('http://schemas.xmlsoap.org/soap/envelope/','s:Body');$env->appendChild($b);$r=$d->createElementNS('http://tempuri.org/',$method.'Request');$b->appendChild($r);
        $h=$d->createElementNS('','REQUEST_HEADER');$r->appendChild($h);
        foreach(['SESSION_ID'=>$this->session,'CLIENT_TXN_ID'=>self::uuid(),'ACTION_DATE'=>gmdate('c'),'REASON'=>'Kobivira firma bazlı EDM test işlemi','APPLICATION_NAME'=>'Kobivira','HOSTNAME'=>'kobivira','CHANNEL_NAME'=>$this->company,'COMPRESSED'=>'N'] as $k=>$v)self::add($h,$k,$v);
        $body($r);$bytes=$d->saveXML();
        if($this->transport)$response=($this->transport)($this->endpoint(),$method.'Request',$bytes);
        else {
            $ctx=stream_context_create(['http'=>['method'=>'POST','header'=>"Content-Type: text/xml; charset=utf-8\r\nSOAPAction: \"".$method."Request\"\r\nConnection: close\r\n",'content'=>$bytes,'timeout'=>25,'ignore_errors'=>true,'follow_location'=>0,'max_redirects'=>0],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'allow_self_signed'=>false]]);
            $stream=@fopen($this->endpoint(),'rb',false,$ctx);if(!$stream)throw new DomainException('EDM test servisine ulaşılamadı. İşlem sonucu bilinmiyor; belgeyi yeniden göndermeden durumunu sorgulayın.');
            try{$response=stream_get_contents($stream,12582913);$meta=stream_get_meta_data($stream);}finally{fclose($stream);}
            if($response===false||!empty($meta['timed_out']))throw new DomainException('EDM yanıt süresi aşıldı. İşlem sonucu bilinmiyor; önce durum sorgulayın.');
            $http=$meta['wrapper_data'][0]??'';if(!preg_match('~^HTTP/\S+ (200|500)\b~',$http))throw new DomainException('EDM HTTP yanıtı uygun değil; yönlendirme izlenmedi.');
        }
        $result=self::xml($response);$xp=new DOMXPath($result);
        if($xp->query('/*[local-name()="Envelope"]/*[local-name()="Body"]')->length!==1)throw new DomainException('EDM SOAP yanıtı bekleniyor.');
        if($xp->query('//*[local-name()="Fault"]')->length){$fault=self::text($result,'//*[local-name()="faultcode"]');if(preg_match('/(?:^|:)InvalidSecurity$/D',$fault))throw new DomainException('EDM oturumu doğrulanamadı. Bağlantı kontrolünü yeniden çalıştırın.');$code=self::text($result,'//*[local-name()="ERROR_CODE"]');$safe=preg_match('/^\d{1,6}$/D',$code)?' ('.$code.')':'';throw new DomainException('EDM servis işlemini reddetti'.$safe.'. Hesap yetkisi ve belge bilgilerini kontrol edin.');}
        if($xp->query('//*[local-name()="'.$method.'Response"]')->length!==1)throw new DomainException('EDM beklenen işlem yanıtını dönmedi.');
        $return=self::text($result,'//*[local-name()="RETURN_CODE"]');if($return!==''&&$return!=='0')throw new DomainException('EDM başarısız işlem kodu döndürdü.');
        return $result;
    }
    public static function uuid(): string {$v=random_bytes(16);$v[6]=chr((ord($v[6])&15)|64);$v[8]=chr((ord($v[8])&63)|128);$h=bin2hex($v);return substr($h,0,8).'-'.substr($h,8,4).'-'.substr($h,12,4).'-'.substr($h,16,4).'-'.substr($h,20);}
    public function connect(): void {
        $this->login();
        $this->verifyCompany();
        // GetCompany reauthenticates the account and invalidates its earlier session.
        // Renew only here, before any invoice or counter operation; never retry a send.
        $this->login();
    }
    public function login(): void {
        $r=$this->call('Login',function($e){foreach(['USER_NAME'=>$this->username,'PASSWORD'=>$this->password] as $k=>$v){$n=$e->ownerDocument->createElementNS('',$k);$n->appendChild($e->ownerDocument->createTextNode($v));$e->appendChild($n);}});
        $s=self::text($r,'//*[local-name()="SESSION_ID"]');if(!preg_match('/^[a-f0-9-]{36}$/iD',$s))throw new DomainException('EDM geçerli oturum vermedi.');$this->session=$s;
    }
    public function verifyCompany(): void {
        $r=$this->call('GetCompany',function($e){foreach(['USER_NAME'=>$this->username,'PASSWORD'=>$this->password,'TAXNUMBER'=>$this->company,'SETCOMPANYMM'=>'false','DELETECOMPANYMM'=>'false','ISHASH'=>'false'] as $k=>$v){$n=$e->ownerDocument->createElementNS('',$k);$n->appendChild($e->ownerDocument->createTextNode($v));$e->appendChild($n);}});$x=new DOMXPath($r);$found=false;
        foreach($x->query('//*[local-name()="GetCompanyResponse"]//*[local-name()="VKN" or local-name()="TCKN" or local-name()="IDENTIFIER" or local-name()="TAX_NUMBER" or local-name()="TaxNumber"]') as $n)if(trim($n->textContent)===$this->company)$found=true;
        $taxes=[];foreach($x->query('//*[local-name()="GetCompanyResponse"]//*[local-name()="VKN"]') as $n)if(trim($n->textContent)!=='')$taxes[]=trim($n->textContent);if(count(array_unique($taxes))!==1)$found=false;
        if(!$found)throw new DomainException('EDM hesabı ile seçilen test firmasının VKN/TCKN eşleşmesi doğrulanamadı.');
    }
    public function balance(): string {$r=$this->call('CheckCounter',static function($e){});$v=self::text($r,'//*[local-name()="COUNTER_LEFT"]');if(!preg_match('/^-?\d+(?:\.\d+)?$/D',$v))throw new DomainException('EDM kontör bakiyesi doğrulanamadı.');return $v;}
    public function inbox(string $start,string $end): DOMDocument {
        return $this->call('GetInvoice',static function($e)use($start,$end){$s=$e->ownerDocument->createElementNS('','INVOICE_SEARCH_KEY');$e->appendChild($s);foreach(['LIMIT'=>'100','START_DATE'=>$start,'END_DATE'=>$end,'READ_INCLUDED'=>'true','DIRECTION'=>'IN'] as $k=>$v)self::add($s,$k,$v);foreach(['HEADER_ONLY'=>'N','INVOICE_CONTENT_TYPE'=>'XML'] as $k=>$v){$n=$e->ownerDocument->createElementNS('',$k);$n->appendChild($e->ownerDocument->createTextNode($v));$e->appendChild($n);}});
    }
    public function document(array $expected,string $direction,string $format): string {
        $uuid=$expected['uuid'];self::validUuid($uuid);
        if(!in_array($direction,['IN','OUT'],true)||!in_array($format,['XML','PDF'],true))throw new DomainException('Belge yönü veya indirme biçimi geçersiz.');
        if(($expected[$direction==='IN'?'recipient':'sender']??'')!==$this->company)throw new DomainException('İndirilecek belge test firmasına ait değil.');
        $searchDirection=$direction==='OUT'&&$expected['profile']==='EARSIVFATURA'?'OUT-EARCHIVE':$direction;
        $d=$this->call('GetInvoice',static function($e)use($uuid,$searchDirection,$format){$key=$e->ownerDocument->createElementNS('','INVOICE_SEARCH_KEY');$e->appendChild($key);foreach(['LIMIT'=>'1','UUID'=>$uuid,'READ_INCLUDED'=>'true','DIRECTION'=>$searchDirection] as $k=>$v)self::add($key,$k,$v);foreach(['HEADER_ONLY'=>'N','INVOICE_CONTENT_TYPE'=>$format] as $k=>$v){$n=$e->ownerDocument->createElementNS('',$k);$n->appendChild($e->ownerDocument->createTextNode($v));$e->appendChild($n);}});
        $nodes=(new DOMXPath($d))->query('//*[local-name()="GetInvoiceResponse"]/*[local-name()="INVOICE"]');
        if($nodes->length!==1)throw new DomainException('EDM bu UUID için tek bir belge döndürmedi. Belge henüz hazır olmayabilir.');$n=$nodes->item(0);
        if(strtolower($n->getAttribute('UUID'))!==strtolower($uuid)||$n->getAttribute('ID')!==$expected['number'])throw new DomainException('EDM indirme yanıtının UUID veya fatura numarası eşleşmiyor.');
        foreach(['SENDER'=>'sender','RECEIVER'=>'recipient','PROFILEID'=>'profile'] as $remote=>$local)if(self::text($n,'./*[local-name()="HEADER"]/*[local-name()="'.$remote.'"]')!==$expected[$local])throw new DomainException('EDM indirme yanıtının firma veya senaryo bilgisi eşleşmiyor.');
        $bytes=base64_decode(self::text($n,'./*[local-name()="CONTENT"]'),true);
        if($bytes===false||$bytes===''||strlen($bytes)>8388608)throw new DomainException('EDM belge içeriği boş, geçersiz veya 8 MB sınırının üzerinde.');
        if($format==='PDF'){if(!str_starts_with($bytes,'%PDF-'))throw new DomainException('EDM geçerli PDF içeriği dönmedi.');}
        else {$actual=self::invoiceInfo($bytes);foreach(['uuid','number','profile','sender','recipient'] as $k)if(($k==='uuid'?strtolower($actual[$k]):$actual[$k])!==($k==='uuid'?strtolower($expected[$k]):$expected[$k]))throw new DomainException('İndirilen XML seçilen test belgesiyle eşleşmiyor.');}
        return $bytes;
    }
    public function status(string $uuid,string $direction): DOMDocument {
        self::validUuid($uuid);if(!in_array($direction,['IN','OUT'],true))throw new DomainException('Belge yönü geçersiz.');
        $result=$this->call('GetInvoiceStatus',static function($e)use($uuid,$direction){$n=$e->ownerDocument->createElementNS('','INVOICE');$n->setAttribute('UUID',$uuid);$n->setAttribute('TRXID','0');$e->appendChild($n);$h=self::add($n,'HEADER');self::headerDefaults($h,false);$dir=$h->ownerDocument->createElement('DIRECTION',$direction);$h->insertBefore($dir,$h->lastChild);});
        $actual=self::text($result,'//*[local-name()="INVOICE_STATUS"]/@UUID');if(strtolower($actual)!==strtolower($uuid))throw new DomainException('EDM durum yanıtı istenen belge UUID bilgisiyle eşleşmiyor.');return $result;
    }
    private static function headerDefaults(DOMElement $h,bool $archive): void {
        foreach(['INTERNETSALES'=>'false','EARCHIVE'=>$archive?'true':'false','EARCHIVE_REPORT_SENDDATE'=>'0001-01-01','CANCEL_EARCHIVE_REPORT_SENDDATE'=>'0001-01-01'] as $k=>$v)self::add($h,$k,$v);
        $n=$h->ownerDocument->createElement('OTHER_ENTEGRATION');$n->setAttributeNS('http://www.w3.org/2001/XMLSchema-instance','i:nil','true');$h->appendChild($n);
    }
    public static function validUuid(string $v): void {if(!preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iD',$v))throw new DomainException('Geçerli belge UUID bilgisi gerekir.');}
    public static function invoiceInfo(string $xml): array {
        $d=self::xml($xml);if($d->documentElement->localName!=='Invoice'||$d->documentElement->namespaceURI!=='urn:oasis:names:specification:ubl:schema:xsd:Invoice-2')throw new DomainException('UBL Invoice XML belgesi gerekir.');
        $get=static fn($p)=>self::text($d,$p);$root='/*[local-name()="Invoice"]';$party=static fn($role)=>$get($root.'/*[local-name()="'.$role.'"]/*[local-name()="Party"]/*[local-name()="PartyIdentification"]/*[local-name()="ID"][@schemeID="VKN" or @schemeID="TCKN"]');
        $a=['uuid'=>$get($root.'/*[local-name()="UUID"]'),'number'=>$get($root.'/*[local-name()="ID"]'),'profile'=>$get($root.'/*[local-name()="ProfileID"]'),'type'=>$get($root.'/*[local-name()="InvoiceTypeCode"]'),'sender'=>$party('AccountingSupplierParty'),'recipient'=>$party('AccountingCustomerParty'),'currency'=>$get($root.'/*[local-name()="DocumentCurrencyCode"]'),'date'=>$get($root.'/*[local-name()="IssueDate"]'),'total'=>$get($root.'/*[local-name()="LegalMonetaryTotal"]/*[local-name()="PayableAmount"]')];self::validUuid($a['uuid']);
        if(!preg_match('/^\d{10,11}$/D',$a['sender'])||!preg_match('/^\d{10,11}$/D',$a['recipient'])||!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$a['date'])||!preg_match('/^\d+(?:\.\d+)?$/D',$a['total']))throw new DomainException('UBL taraf, tarih veya toplam bilgileri eksik.');return $a;
    }
    public function send(string $xml,string $alias): DOMDocument {
        $a=self::invoiceInfo($xml);if($a['sender']!==$this->company)throw new DomainException('XML gönderici VKN/TCKN bilgisi test firmasıyla uyuşmuyor.');
        if(!in_array($a['profile'],['TEMELFATURA','TICARIFATURA','EARSIVFATURA'],true))throw new DomainException('İlk test alanı temel, ticari ve e-Arşiv fatura içindir. Özel senaryolar ayrıca doğrulanmalıdır.');
        if($a['profile']!=='EARSIVFATURA'&&($alias===''||strlen($alias)>250||!str_starts_with($alias,'urn:mail:')))throw new DomainException('Alıcının CheckUser ile doğrulanan posta kutusu etiketi gerekir.');
        return $this->call('SendInvoice',static function($e)use($xml,$a,$alias){
            $n=$e->ownerDocument->createElementNS('','RECEIVER');$n->setAttribute('vkn',$a['recipient']);if($alias!=='')$n->setAttribute('alias',$alias);$e->appendChild($n);
            $i=$e->ownerDocument->createElementNS('','INVOICE');$i->setAttribute('UUID',$a['uuid']);$i->setAttribute('TRXID','0');$i->setAttribute('ID',$a['number']);$e->appendChild($i);$h=self::add($i,'HEADER');self::headerDefaults($h,$a['profile']==='EARSIVFATURA');self::add($i,'CONTENT',base64_encode($xml));
        });
    }
    public function cancelArchive(array $expected): void {
        if(($expected['sender']??'')!==$this->company||($expected['profile']??'')!=='EARSIVFATURA')throw new DomainException('Yalnız firmaya ait e-Arşiv test faturası iptal edilebilir.');
        self::validUuid($expected['uuid']);
        // Retrieve the actual provider document before attempting the irreversible operation.
        $this->document($expected,'OUT','XML');
        $status=edm361_status($this->status($expected['uuid'],'OUT'));
        if($status!=='SEND - SUCCEED')throw new DomainException('İptal testi için EDM gönderimin tamamlandığını doğrulamalıdır. Son durum: '.$status);
        $response=$this->call('CancelInvoice',static function($e)use($expected){$n=$e->ownerDocument->createElementNS('','INVOICE');$n->setAttribute('UUID',$expected['uuid']);$n->setAttribute('TRXID','0');$e->appendChild($n);});
        if(self::text($response,'//*[local-name()="RETURN_CODE"]')!=='0')throw new DomainException('EDM iptal isteği sonucunu doğrulamadı. Yeniden göndermeden durum sorgulayın.');
    }
    public function checkUser(string $vkn): DOMDocument {if(!preg_match('/^\d{10,11}$/D',$vkn))throw new DomainException('Alıcı VKN/TCKN bilgisi geçersiz.');return $this->call('CheckUser',static function($e)use($vkn){$u=$e->ownerDocument->createElementNS('','USER');$e->appendChild($u);self::add($u,'IDENTIFIER',$vkn);});}
    public static function recipientAliases(DOMDocument $d,string $tax): array {
        $xp=new DOMXPath($d);$aliases=[];foreach($xp->query('//*[local-name()="CheckUserResponse"]/*[local-name()="USER"]') as $u){if(self::text($u,'./*[local-name()="IDENTIFIER"]')!==$tax)throw new DomainException('EDM mükellef yanıtı istenen alıcıyla eşleşmiyor.');$alias=self::text($u,'./*[local-name()="ALIAS"]');if($alias!=='')$aliases[]=$alias;}return array_values(array_unique($aliases));
    }
    public function respond(string $uuid,string $decision,string $reason): DOMDocument {
        self::validUuid($uuid);if(!in_array($decision,['KABUL','RED'],true)||($decision==='RED'&&trim($reason)===''))throw new DomainException('Kabul/ret ve ret gerekçesi kontrol edilmeli.');
        return $this->call('SendInvoiceResponseWithServerSign',static function($e)use($uuid,$decision,$reason){foreach(['STATUS'=>$decision] as $k=>$v){$n=$e->ownerDocument->createElementNS('',$k);$n->appendChild($e->ownerDocument->createTextNode($v));$e->appendChild($n);}$n=$e->ownerDocument->createElementNS('','INVOICE');$n->setAttribute('UUID',$uuid);$n->setAttribute('TRXID','0');$e->appendChild($n);if($reason!==''){$n=$e->ownerDocument->createElementNS('','DESCRIPTION');$e->appendChild($n);$n->appendChild($e->ownerDocument->createTextNode($reason));}});
    }
}

function edm361_guard(): void {
    if(support_context()||isset($_GET['support'])||!empty($GLOBALS['follow_mode'])||(base_user()['role']??'')==='support_agent')throw new DomainException('EDM hesabı destek oturumundan kullanılamaz.');
    if(owner())return;firm_manager();require_paid('EDM test işlemleri');need_feature('edocs');require_write();
}
function edm361_company(): int {edm361_guard();$cid=owner()?(int)($_GET['company_id']??$_POST['company_id']??0):company_id();if($cid<1||!query("SELECT id FROM companies WHERE id=? AND status='active'",[$cid])->fetchColumn())throw new DomainException('Aktif bir firma seçin.');return $cid;}
function edm361_account(int $cid): array {$r=query('SELECT * FROM edm_test_accounts WHERE company_id=?',[$cid])->fetch();return $r?:[];}
function edm361_client(int $cid): Edm361Client {
    $r=edm361_account($cid);if(!$r||!$r['enabled'])throw new DomainException('Bu firma için EDM test bağlantısı yönetici tarafından açılmalıdır.');
    $v=json_decode(open_code($r['credentials']),true,16,JSON_THROW_ON_ERROR);$client=new Edm361Client($v['username'],$v['password'],$r['tax_number']);$client->connect();return $client;
}
function edm361_row(int $cid,int $id): array {$r=query('SELECT * FROM edm_test_documents WHERE company_id=? AND id=?',[$cid,$id])->fetch();if(!$r)throw new DomainException('Test belgesi bu firmada bulunamadı.');return $r;}
function edm361_status(DOMDocument $d): string {$v=Edm361Client::text($d,'//*[local-name()="INVOICE_STATUS"]/*[local-name()="STATUS"]');if($v==='')$v=Edm361Client::text($d,'//*[local-name()="INVOICE"]/*[local-name()="HEADER"]/*[local-name()="STATUS"]');return mb_substr($v?:'Yanıt alındı; son durum sorgulanmalı',0,100);}
/** Separate read polling from state-changing operations and authentication limits. */
function edm363_rate(int $cid,string $action): void {
    $rules=['status'=>['status',120,'Durum sorgusu'],'check'=>['connection',12,'Bağlantı kontrolü'],'recipient'=>['recipient',60,'Alıcı sorgusu'],'sync'=>['inbox',20,'Gelen belge sorgusu'],'stage'=>['upload',30,'XML yükleme'],'send'=>['write',20,'Belge işlemi'],'accept'=>['write',20,'Belge işlemi'],'reject'=>['write',20,'Belge işlemi'],'cancel_archive'=>['write',20,'Belge işlemi']];
    if(!isset($rules[$action]))throw new DomainException('EDM test işlemi geçersiz.');
    [$scope,$limit,$label]=$rules[$action];try{throttle('edm363-'.$scope.'-'.$cid,$limit);}catch(DomainException $e){if(http_response_code()!==429)throw $e;throw new DomainException($label.' sınırına ulaşıldı. Bu işlem için 15 dakika sonra yeniden deneyin.');}
}
function edm363_status_due(int $cid,int $id): bool {
    $key=throttle_key('edm363-status-document-'.$cid.'-'.$id);
    // One atomic claim prevents simultaneous clicks from starting duplicate refreshes.
    $q=query('INSERT INTO login_attempts(bucket,attempts,last_attempt) VALUES (?,1,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE attempts=IF(last_attempt<=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 30 SECOND),attempts+1,attempts),last_attempt=IF(last_attempt<=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 30 SECOND),UTC_TIMESTAMP(),last_attempt)',[$key]);return $q->rowCount()>0;
}
function edm361_post(string $action): never {
    if(str_starts_with($action,'export_'))export3614_post(substr($action,7));
    if(str_starts_with($action,'smm_'))smm3613_post(substr($action,4));
    if(str_starts_with($action,'despatch_'))despatch369_post(substr($action,9));
    $cid=edm361_company();$params=['company_id'=>$cid];$a=edm361_account($cid);
    if(!in_array($action,['configure','check','recipient','sync','stage','status','send','accept','reject','cancel_archive'],true))throw new DomainException('EDM test işlemi geçersiz.');
    if($action==='configure'){
        admin351_guard();reauthenticate(base_user());$tax=required_field('tax_number',11);if(!preg_match('/^\d{10,11}$/D',$tax))throw new DomainException('Test firmasının VKN/TCKN bilgisini girin.');
        $old=$a?json_decode(open_code($a['credentials']),true):[];$user=field('edm_username',150);$pass=field('edm_password',250);$v=['username'=>$user?:($old['username']??''),'password'=>$pass?:($old['password']??'')];if(!$v['username']||!$v['password'])throw new DomainException('EDM test hesabı kullanıcı adı ve şifresi gerekir.');
        if(query('SELECT company_id FROM edm_test_accounts WHERE tax_number=? AND company_id<>?',[$tax,$cid])->fetchColumn())throw new DomainException('Bu EDM test firması başka bir Kobivira firmasına bağlı.');
        if($a&&$a['tax_number']!==$tax&&(query('SELECT id FROM edm_test_documents WHERE company_id=? LIMIT 1',[$cid])->fetchColumn()||query('SELECT id FROM edm_despatch_test_documents WHERE company_id=? LIMIT 1',[$cid])->fetchColumn()||query('SELECT id FROM edm_smm_test_documents WHERE company_id=? LIMIT 1',[$cid])->fetchColumn()||query('SELECT id FROM edm_export_test_documents WHERE company_id=? LIMIT 1',[$cid])->fetchColumn()))throw new DomainException('Test belgeleri bulunan hesabın VKN/TCKN bilgisi değiştirilemez.');
        $values=[$tax,seal_code(json_encode($v,JSON_THROW_ON_ERROR)),isset($_POST['enabled'])?1:0,'Ayar kaydedildi; dış servis doğrulaması yapılmadı.'];
        if($a)query('UPDATE edm_test_accounts SET tax_number=?,credentials=?,enabled=?,checked_at=NULL,provider_balance=NULL,last_result=? WHERE company_id=?',[...$values,$cid]);
        else query('INSERT INTO edm_test_accounts(tax_number,credentials,enabled,last_result,company_id) VALUES (?,?,?,?,?)',[...$values,$cid]);flash('Firma test bağlantısı kaydedildi.');redirect('edm_test',$params);
    }
    if($action==='status'){$statusId=int_field('id',1,PHP_INT_MAX);edm361_row($cid,$statusId);if(!edm363_status_due($cid,$statusId)){flash('Aynı belge için 30 saniye dolmadı. Son kaydedilen durum gösteriliyor; EDM’ye yeni istek gönderilmedi.');redirect('edm_test',$params+['id'=>$statusId]);}}
    edm363_rate($cid,$action);if($action==='check')query('UPDATE edm_test_accounts SET checked_at=NULL,provider_balance=NULL,last_result=? WHERE company_id=?',['Bağlantı kontrolü başlatıldı; sonuç henüz doğrulanmadı.',$cid]);audit('edm.test_action',['company'=>$cid,'reason'=>$action.' · yalnız test ortamı']);$client=$action==='stage'?null:edm361_client($cid);
    if($action==='stage'&&(!$a||!$a['enabled']))throw new DomainException('Bu firma için EDM test bağlantısı yönetici tarafından açılmalıdır.');
    if($action==='check'){$balance=$client->balance();query('UPDATE edm_test_accounts SET checked_at=UTC_TIMESTAMP(),last_result=?,provider_balance=? WHERE company_id=?',['EDM Login ve firma VKN/TCKN eşleşmesi başarılı. Test bakiyesi sorgulandı.',$balance,$cid]);flash('EDM hesabı ve firma eşleşmesi doğrulandı.');redirect('edm_test',$params);}
    if($action==='recipient'){$tax=required_field('recipient_tax',11);$r=$client->checkUser($tax);$aliases=Edm361Client::recipientAliases($r,$tax);$_SESSION['edm361_recipient']=['company'=>$cid,'text'=>$aliases?implode(' · ',$aliases):'Alıcı için etiket dönmedi. e-Fatura gönderimi başlatılmadı.'];redirect('edm_test',$params);}
    if($action==='sync'){
        $start=date_field('start');$end=date_field('end');$days=(strtotime($end)-strtotime($start))/86400;if($days<0||$days>7)throw new DomainException('En fazla 7 günlük, sıralı tarih aralığı seçin.');$r=$client->inbox($start,$end);$xp=new DOMXPath($r);$count=0;
        foreach($xp->query('//*[local-name()="GetInvoiceResponse"]/*[local-name()="INVOICE"]') as $node){$content=Edm361Client::text($node,'./*[local-name()="CONTENT"]');$xml=base64_decode($content,true);if(!$xml)throw new DomainException('EDM fatura içeriği XML olarak alınamadı.');$info=Edm361Client::invoiceInfo($xml);if($info['recipient']!==$a['tax_number'])throw new DomainException('Başka firmaya ait belge döndü; kayıt durduruldu.');$status=Edm361Client::text($node,'./*[local-name()="HEADER"]/*[local-name()="STATUS"]')?:'Alındı';$existing=query("SELECT * FROM edm_test_documents WHERE company_id=? AND direction='IN' AND uuid=?",[$cid,$info['uuid']])->fetch();$hash=hash('sha256',$xml);
            if($existing){if(!hash_equals($existing['payload_hash'],$hash))throw new DomainException('Aynı UUID ile farklı XML döndü; mevcut belge değiştirilmedi.');query('UPDATE edm_test_documents SET provider_status=?,updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?',[mb_substr($status,0,100),$cid,$existing['id']]);}
            else query("INSERT INTO edm_test_documents(company_id,direction,uuid,number,profile,payload,payload_hash,provider_status,created_at,updated_at) VALUES (?,'IN',?,?,?,?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())",[$cid,$info['uuid'],$info['number'],$info['profile'],seal_code($xml),$hash,mb_substr($status,0,100)]);$count++;
        }
        flash($count.' test faturası sorgulandı. Muhasebe veya ödeme kaydı oluşturulmadı. 100 sonuç varsa tarih aralığını daraltın.');redirect('edm_test',$params);
    }
    if($action==='stage'){
        $f=$_FILES['ubl']??null;if(!$f||$f['error']!==UPLOAD_ERR_OK||$f['size']>2097152||!is_uploaded_file($f['tmp_name']))throw new DomainException('En fazla 2 MB UBL XML yükleyin.');$xml=file_get_contents($f['tmp_name']);$info=Edm361Client::invoiceInfo($xml);if($info['sender']!==$a['tax_number'])throw new DomainException('Belge göndericisi test firmasının VKN/TCKN bilgisiyle uyuşmuyor.');
        if(!in_array($info['profile'],['TEMELFATURA','TICARIFATURA','EARSIVFATURA'],true))throw new DomainException('Bu test alanında temel, ticari ve e-Arşiv fatura kullanılabilir.');
        if(query("SELECT id FROM edm_test_documents WHERE company_id=? AND direction='OUT' AND uuid=?",[$cid,$info['uuid']])->fetchColumn())throw new DomainException('Bu UUID zaten kayıtlı; mevcut belgeden devam edin.');
        query("INSERT INTO edm_test_documents(company_id,direction,uuid,number,profile,payload,payload_hash,provider_status,created_at,updated_at) VALUES (?,'OUT',?,?,?,?,?,'Yüklenen test XML — gönderilmedi',UTC_TIMESTAMP(),UTC_TIMESTAMP())",[$cid,$info['uuid'],$info['number'],$info['profile'],seal_code($xml),hash('sha256',$xml)]);flash('Test XML kaydedildi. Göndermek için belgeyi açın.');redirect('edm_test',$params);
    }
    $id=int_field('id',1,PHP_INT_MAX);$r=edm361_row($cid,$id);$params['id']=$id;
    $lock='edm361:'.$cid.':'.$id;if((int)query('SELECT GET_LOCK(?,0)',[$lock])->fetchColumn()!==1)throw new DomainException('Belge üzerinde başka işlem var.');
    try {
        $r=edm361_row($cid,$id);
        if($action==='status'){$result=$client->status($r['uuid'],$r['direction']);query('UPDATE edm_test_documents SET provider_status=?,updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?',[edm361_status($result),$cid,$id]);}
        elseif($action==='send'){
            if($r['direction']!=='OUT'||$r['attempted_at'])throw new DomainException('Bu belge zaten gönderim denemesi içeriyor. Tekrar göndermek yerine durum sorgulayın.');if(!isset($_POST['confirm_test']))throw new DomainException('EDM test ortamına gönderimi onaylayın.');
            $alias=field('alias',250);$info=Edm361Client::invoiceInfo(open_code($r['payload']));$check=$client->checkUser($info['recipient']);$allowed=Edm361Client::recipientAliases($check,$info['recipient']);if($info['profile']==='EARSIVFATURA'){if($allowed)throw new DomainException('Alıcı e-Fatura mükellefi görünüyor; e-Arşiv yerine uygun e-Fatura senaryosu gerekir.');$alias='';}elseif(!in_array($alias,$allowed,true))throw new DomainException('Posta kutusu etiketi alıcının EDM CheckUser sonucuyla eşleşmiyor.');
            query("UPDATE edm_test_documents SET attempted_at=UTC_TIMESTAMP(),provider_status='Gönderim denendi; sonuç henüz doğrulanmadı' WHERE company_id=? AND id=?",[$cid,$id]);
            $result=$client->send(open_code($r['payload']),$alias);query('UPDATE edm_test_documents SET provider_status=?,updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?',[edm361_status($result),$cid,$id]);
        }
        elseif($action==='cancel_archive'){
            if($r['direction']!=='OUT'||$r['profile']!=='EARSIVFATURA'||!$r['attempted_at']||!empty($r['cancel_attempted_at']))throw new DomainException('Yalnız iptal denemesi bulunmayan giden e-Arşiv test faturası iptal edilebilir.');
            if(!isset($_POST['confirm_test']))throw new DomainException('e-Arşiv test faturası iptalini onaylayın.');
            $info=Edm361Client::invoiceInfo(open_code($r['payload']));
            // Persist before provider calls: a lost response must never enable a second cancellation.
            query("UPDATE edm_test_documents SET cancel_attempted_at=UTC_TIMESTAMP(),provider_status='İptal denemesi başlatıldı; sonuç henüz doğrulanmadı',updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?",[$cid,$id]);
            $client->cancelArchive($info);
            query("UPDATE edm_test_documents SET provider_status='İptal isteğine RETURN_CODE=0 alındı; son durum sorgulanmalı',updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?",[$cid,$id]);
            $result=$client->status($r['uuid'],'OUT');query('UPDATE edm_test_documents SET provider_status=?,updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?',[edm361_status($result),$cid,$id]);
        }
        elseif(in_array($action,['accept','reject'],true)){
            if($r['direction']!=='IN'||$r['profile']!=='TICARIFATURA'||$r['response_decision'])throw new DomainException('Yalnız yanıtlanmamış gelen ticari test faturasına yanıt verilebilir.');if(!isset($_POST['confirm_test']))throw new DomainException('Test faturası yanıtını onaylayın.');
            $status=edm361_status($client->status($r['uuid'],'IN'));if($status!=='RECEIVE - WAIT_APPLICATION_RESPONSE')throw new DomainException('EDM bu belge için yanıt bekleniyor durumunu doğrulamadı.');$reason=$action==='reject'?required_field('reason',1000):'';$decision=$action==='accept'?'KABUL':'RED';
            query("UPDATE edm_test_documents SET response_decision=?,provider_status='Yanıt denendi; son durum sorgulanmalı' WHERE company_id=? AND id=?",[$decision,$cid,$id]);$client->respond($r['uuid'],$decision,$reason);query('UPDATE edm_test_documents SET provider_status=?,updated_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?',[edm361_status($client->status($r['uuid'],'IN')),$cid,$id]);
        }else throw new DomainException('EDM test işlemi geçersiz.');
    }finally{query('SELECT RELEASE_LOCK(?)',[$lock]);}
    flash('Servis yanıtı kaydedildi. Son durum belgenin üzerinde gösteriliyor.');redirect('edm_test',$params);
}

/** Read-only download; tenant authorization happens before any provider connection. */
function edm366_download(): void {
    if(($_GET['kind']??'')==='export'){export3614_download();return;}
    if(($_GET['kind']??'')==='smm'){smm3613_download();return;}
    if(($_GET['kind']??'')==='despatch'){despatch369_download();return;}
    if(!isset($_GET['download']))return;
    $cid=edm361_company();$format=$_GET['download'];
    if(!is_string($format)||!in_array($format,['XML','PDF'],true))throw new DomainException('İndirme biçimi XML veya PDF olmalı.');
    $id=filter_var($_GET['id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);if($id===false||$id===null)throw new DomainException('Geçerli bir test belgesi seçin.');
    $row=edm361_row($cid,$id);if($row['direction']==='OUT'&&!$row['attempted_at'])throw new DomainException('Bu test XML henüz EDM’ye gönderilmedi.');
    $info=Edm361Client::invoiceInfo(open_code($row['payload']));$account=edm361_account($cid);
    if(!$account||!$account['enabled'])throw new DomainException('Bu firma için EDM test bağlantısı açık değil.');
    if(strtolower($row['uuid'])!==strtolower($info['uuid'])||$row['number']!==$info['number']||$row['profile']!==$info['profile'])throw new DomainException('Yerel test belgesinin kimlik bilgileri uyuşmuyor.');
    if(($info[$row['direction']==='IN'?'recipient':'sender']??'')!==$account['tax_number'])throw new DomainException('Test belgesi firma hesabıyla eşleşmiyor.');
    throttle('edm366-download-'.$cid,60);$bytes=edm361_client($cid)->document($info,$row['direction'],$format);
    audit('edm.test_download',['company'=>$cid,'reason'=>$format.' · yalnız test ortamı']);
    header('Content-Type: '.($format==='PDF'?'application/pdf':'application/xml; charset=UTF-8'));
    header('Content-Disposition: attachment; filename="kobivira-test-'.$info['uuid'].'.'.strtolower($format).'"');
    header('X-Content-Type-Options: nosniff');header('Cache-Control: private, no-store, max-age=0');header('Content-Length: '.strlen($bytes));echo $bytes;exit;
}

function edm361_view(): void {
    edm361_guard();if(($_GET['kind']??'')==='export'){heading('EDM e-İhracat test alanı','Yalnız test ortamı; gönderim başarısı gümrük onayı değildir.');export3614_view();return;}if(($_GET['kind']??'')==='smm'){heading('EDM e-SMM test alanı','Yalnız EDM test ortamı; canlı makbuz gönderilmez.');smm3613_view();return;}if(($_GET['kind']??'')==='despatch'){heading('EDM e-İrsaliye test alanı','Yalnız test ortamı; resmî canlı gönderim yapılmaz.');despatch369_view();return;}heading('EDM test alanı','Yalnız EDM test ortamı. Test belgeleri firma muhasebesine, yerel kontöre ve tahsilatlara işlenmez.');
    if(owner()||has_feature('advanced_edocs'))echo '<p>'.a('edm_test','e-İhracat test alanını aç',['kind'=>'export','company_id'=>(int)($_GET['company_id']??0)],'button').'</p>';
    if(owner()||has_feature('advanced_edocs'))echo '<p>'.a('edm_test','e-SMM test alanını aç',['kind'=>'smm','company_id'=>(int)($_GET['company_id']??0)],'button').'</p>';
    if(owner()||has_feature('advanced_edocs'))echo '<p>'.a('edm_test','e-İrsaliye test alanını aç',['kind'=>'despatch','company_id'=>(int)($_GET['company_id']??0)],'button').'</p>';
    if(owner()){panel('Firma seçimi');echo '<form method="get" class="form-grid">';hidden('page','edm_test');select_field('company_id','Firma',[0=>'Firma seçin']+query("SELECT id,name FROM companies WHERE status='active' ORDER BY name LIMIT 2000")->fetchAll(PDO::FETCH_KEY_PAIR),(int)($_GET['company_id']??0));submit('Test hesabını aç');echo '</form></section>';if(empty($_GET['company_id']))return;}
    $cid=edm361_company();$a=edm361_account($cid);$params=['company_id'=>$cid];
    if(owner()){panel('Firmaya özel EDM test hesabı','Dokümandaki örnek hesap yerine firmanıza tahsis edilen test hesabını girin. Şifre şifrelenerek saklanır; boş bırakmak mevcut değeri korur.');form_start('edm_test','configure',$params);hidden('company_id',$cid);input('tax_number','EDM test firmasının VKN/TCKN bilgisi',$a['tax_number']??'','text','required inputmode="numeric" maxlength="11"');input('edm_username','EDM test kullanıcı adı','','password','autocomplete="new-password" maxlength="150"');input('edm_password','EDM test şifresi','','password','autocomplete="new-password" maxlength="250"');echo '<label><input name="enabled" type="checkbox" value="1" '.(!empty($a['enabled'])?'checked':'').'> Firma test erişimini aç</label>';input('current_password','Kobivira yönetici şifreniz','','password','required autocomplete="current-password"');form_end('Test ayarlarını kaydet');echo '</section>';}
    if(!$a||!$a['enabled']){echo '<p>EDM test bağlantısı henüz açılmadı.</p>';return;}
    panel('Bağlantı durumu',$a['last_result']);echo '<p>Adres: <code>'.esc(Edm361Client::ENDPOINT).'</code></p><p>EDM test bakiyesi: '.esc($a['provider_balance']??'Sorgulanmadı').'</p>';form_start('edm_test','check',$params);hidden('company_id',$cid);form_end('Hesabı, firma eşleşmesini ve bakiyeyi test et');echo '</section>';
    $id=(int)($_GET['id']??0);if($id){$r=edm361_row($cid,$id);$info=Edm361Client::invoiceInfo(open_code($r['payload']));panel($r['number'],$r['provider_status']);foreach(['uuid'=>'UUID','profile'=>'Senaryo','sender'=>'Gönderici VKN/TCKN','recipient'=>'Alıcı VKN/TCKN','date'=>'Tarih','total'=>'Toplam','currency'=>'Para birimi'] as $k=>$label)echo '<p>'.esc($label).': '.esc($info[$k]).'</p>';echo '<p>'.a('edm_test','Test listesine dön',$params,'button').'</p>';foreach(['status'=>'Durumu sorgula'] as $action=>$label){form_start('edm_test',$action,$params+['id'=>$id]);hidden('company_id',$cid);hidden('id',$id);form_end($label);}echo '<p class="field-hint">Aynı belgenin durumu en az 30 saniye arayla yenilenir. Daha erken tıklarsanız son kaydedilen durum gösterilir.</p>';
        echo '<p>Belge yönü: <strong>'.esc($r['direction']==='IN'?'Gelen (IN)':($r['direction']==='OUT'?'Giden (OUT)':$r['direction'])).'</strong></p>';
        if($r['direction']==='IN'||$r['attempted_at']){
            echo '<p>'.a('edm_test','EDM’den PDF indir',$params+['id'=>$id,'download'=>'PDF'],'button').' '.a('edm_test','EDM’den XML indir',$params+['id'=>$id,'download'=>'XML'],'button').'</p>';
            echo '<p class="field-hint">Dosya EDM test servisinden alınır. Yeni fatura veya kabul/ret isteği gönderilmez.</p>';
        }
        $decision=trim((string)($r['response_decision']??''));
        echo '<p>Kayıtlı yanıt denemesi: <strong>'.esc($decision!==''?$decision:'Yok').'</strong></p>';
        if($r['direction']==='OUT'&&$r['profile']!=='EARSIVFATURA'){
            echo '<p>Kabul ve ret işlemleri gelen (IN) kaydından yapılır.</p>';
            $incoming=query("SELECT id FROM edm_test_documents WHERE company_id=? AND direction='IN' AND uuid=?",[$cid,$r['uuid']])->fetchColumn();
            if($incoming)echo '<p>'.a('edm_test','Bu faturanın gelen kaydını aç',$params+['id'=>(int)$incoming],'button').'</p>';
            else echo '<p>Gelen kayıt henüz yok. Test listesine dönerek gelen test faturalarını sorgulayın.</p>';
        }elseif($r['direction']==='IN'&&$r['profile']!=='TICARIFATURA'){
            echo '<p>Bu kaydın senaryosu kabul/ret formuna uygun değil. Kayıtlı senaryo: <strong>'.esc($r['profile']).'</strong>.</p>';
        }elseif($r['direction']==='IN'&&$decision!==''){
            $final=in_array($r['provider_status'],['ACCEPT - SUCCEED','REJECT - SUCCEED'],true);
            echo '<p role="status">'.($final?'EDM yanıt işlemi tamamlanmış görünüyor. Aynı fatura için tekrar kabul/ret gönderilmez.':'Bu fatura için daha önce '.esc($decision).' yanıtı denenmiş. Sonuç belirsiz olabileceği için kabul/ret formu kapalı. Bu kayıt, yanıtın EDM tarafından tamamlandığını tek başına kanıtlamaz.').'</p>';
            if(!$final)echo '<p>Önce Durumu sorgula düğmesiyle sonucu yenileyin. Durum hâlâ yanıt bekleniyor ise kayıt silmeyin veya aynı yanıtı tekrar göndermeyin. Yönetici kontrolü için belge yönü, UUID, EDM durumu ve kayıtlı yanıt denemesi bilgilerini iletin.</p>';
        }
        if($r['direction']==='OUT'&&$r['profile']==='EARSIVFATURA'&&$r['attempted_at']){
            echo '<p>e-Arşiv iptal denemesi: <strong>'.esc(!empty($r['cancel_attempted_at'])?$r['cancel_attempted_at'].' UTC':'Yok').'</strong></p>';
            echo '<p>İptal sonucu ile GİB iptal raporunun tamamlanması ayrı kontrollerdir. Bu ekran EDM belge durumunu gösterir; GİB raporunun tamamlandığını tek başına kanıtlamaz.</p>';
            if(!empty($r['cancel_attempted_at']))echo '<p>İptal daha önce denendi. Aynı istek tekrar gönderilmez; Durumu sorgula ile sonucu kontrol edin. Sonuç belirsiz kalırsa EDM teknik desteğine UUID ile başvurun.</p>';
            elseif($r['provider_status']==='SEND - SUCCEED'){
                form_start('edm_test','cancel_archive',$params+['id'=>$id]);hidden('company_id',$cid);hidden('id',$id);
                echo '<label class="wide"><input type="checkbox" name="confirm_test" value="1" required> Bu e-Arşiv faturasını yalnız EDM test ortamında iptal etmek istiyorum.</label>';
                form_end('Test e-Arşiv faturasını iptal et');
            }else echo '<p>İptal düğmesi için önce Durumu sorgula ile SEND - SUCCEED sonucu doğrulanmalıdır.</p>';
        }
        $actions=$r['direction']==='OUT'&&!$r['attempted_at']?['send'=>'EDM test ortamına gönder']:($r['direction']==='IN'&&$r['profile']==='TICARIFATURA'&&!$r['response_decision']?['accept'=>'Test faturasını kabul et','reject'=>'Test faturasını reddet']:[]);
        foreach($actions as $action=>$label){form_start('edm_test',$action,$params+['id'=>$id]);hidden('company_id',$cid);hidden('id',$id);if($action==='send'&&$r['profile']!=='EARSIVFATURA')input('alias','Alıcının posta kutusu etiketi','','text','required maxlength="250"');if($action==='reject')textarea('reason','Ret gerekçesi','','required maxlength="1000"');echo '<label class="wide"><input type="checkbox" name="confirm_test" value="1" required> EDM test ortamında bu işlemi yapmak istiyorum.</label>';form_end($label);}echo '</section>';return;}
    panel('Alıcı mükellef ve etiket sorgusu');form_start('edm_test','recipient',$params);hidden('company_id',$cid);input('recipient_tax','Alıcı VKN/TCKN','','text','required maxlength="11"');form_end('Alıcıyı sorgula');$last=$_SESSION['edm361_recipient']??[];if(($last['company']??0)===$cid)echo '<p>'.esc($last['text']).'</p>';echo '</section>';
    panel('Gelen test faturaları','Okunmuş belgeler de sorgulanır; aynı UUID ikinci kez kaydedilmez.');form_start('edm_test','sync',$params);hidden('company_id',$cid);input('start','Başlangıç',date('Y-m-d',time()-86400*7),'date','required');input('end','Bitiş',today(),'date','required');form_end('EDM’den test faturalarını getir');echo '</section>';
    panel('Giden test faturası','Firmanın VKN/TCKN bilgisini taşıyan UBL Invoice XML yükleyin. Bu aşama XSD/Schematron onayı değildir; EDM gönderimde kontrol eder.');form_start('edm_test','stage',$params);hidden('company_id',$cid);input('ubl','UBL XML dosyası','','file','required accept=".xml"');form_end('XML’i test listesine ekle');echo '</section>';
    panel('Firma test belgeleri');table_start(['Belge','Yön','Senaryo','EDM durumu','']);$rows=query('SELECT id,number,direction,profile,provider_status FROM edm_test_documents WHERE company_id=? ORDER BY id DESC LIMIT 100',[$cid])->fetchAll();foreach($rows as $r)echo '<tr><td>'.esc($r['number']).'</td><td>'.esc($r['direction']).'</td><td>'.esc($r['profile']).'</td><td>'.esc($r['provider_status']).'</td><td>'.a('edm_test','İncele',$params+['id'=>$r['id']]).'</td></tr>';table_end(count($rows),5);echo '</section>';
}
