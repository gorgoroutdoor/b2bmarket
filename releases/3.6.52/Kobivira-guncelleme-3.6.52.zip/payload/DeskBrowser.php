(() => {
  const body=document.body;
  if(body.dataset.pollEnabled!=='1'||body.dataset.followMode==='1')return;
  const qDialog=document.getElementById('desk-queue-dialog'),qBanner=document.getElementById('desk-queue-banner'),follow=document.getElementById('support-follow-dialog'),frame=document.getElementById('support-follow-frame');
  const names=new Set(['recipient[name]','recipient[tax_number]','recipient[tax_office]','recipient[address]','recipient[contact_person]','recipient[phone]','recipient[email]','contact_person','tax_office','contact_id','issue_date','due_date','description','name','kind','email','phone','tax_number','address','note','code','unit','price','cost','vat','type','opening_balance','account_id','document_id','direction','amount','paid_date','title','due_at','status']);
  let queue=null,monitor=null,revision='',loadedRevision='',noticeSeen=new Set(),queueRevision=null,offset=0;
  const noticeKey='kobivira-queue-notices-'+(document.getElementById('sidebar')?.dataset.navKey||'');try{const previous=JSON.parse(sessionStorage.getItem(noticeKey)||'[]');if(Array.isArray(previous))noticeSeen=new Set(previous.slice(-100))}catch{}
  const modal=d=>{if(d&&!d.open){const current=document.querySelector('dialog[open]');if(current&&current!==d)current.close();d.showModal();}};
  document.querySelectorAll('[data-open-queue]').forEach(b=>b.addEventListener('click',()=>{if(queue)modal(qDialog)}));
  document.querySelector('[data-close-queue]')?.addEventListener('click',()=>qDialog.close());
  document.querySelectorAll('[data-close-follow]').forEach(b=>b.addEventListener('click',()=>follow.close()));
  document.querySelectorAll('[data-open-follow]').forEach(b=>b.addEventListener('click',()=>{if(monitor){modal(follow);refreshFrame();}else{b.textContent='İzleme, bağlantı onaylandıktan sonra açılır';setTimeout(()=>b.textContent='Yöneticinin ekranını izle',3500)}}));
  document.addEventListener('kobivira:poll-send',e=>{
    if(body.dataset.isSupport!=='1')return;
    const data=e.detail,params=new URLSearchParams(location.search);
    for(const k of ['edit','q','p'])if(params.has(k))data.set('location_'+k,params.get(k));
    const quick=document.getElementById('quick-contact-dialog');data.set('dialog',quick?.open?'quick-contact-dialog':document.querySelector('.quick-add[open]')?'quick-add':'');
    const fields=[];
    for(const el of document.querySelectorAll('#main form input,#main form select,#main form textarea')){
      if(['password','hidden','file','submit','button','checkbox','radio'].includes(el.type)||!el.name||!el.getClientRects().length)continue;
      if(!names.has(el.name)&&!/^lines\[\d{1,3}\]\[(product_id|label|quantity|price|vat)\]$/.test(el.name))continue;
      fields.push({name:el.name,value:el.value.slice(0,1000),zone:el.closest('#quick-contact-dialog')?'quick-contact-dialog':'main'});if(fields.length>=200)break;
    }
    const serialized=JSON.stringify(fields);data.set('form_state',serialized.length<=32000?serialized:'[]');
  });
  function updateCountdown(){
    if(!queue)return;
    const countdown=document.getElementById('desk-countdown'),remaining=queue.scheduled_at?queue.scheduled_at-Math.floor(Date.now()/1000+offset):null;
    if(countdown)countdown.textContent=remaining===null?'Temsilci henüz saat atamadı.':remaining>0?'Destek saatine '+Math.floor(remaining/60)+' dakika '+String(remaining%60).padStart(2,'0')+' saniye kaldı.':'Destek saatiniz geldi. Temsilcinin bağlantı talebini bekleyin.';
    const assigned=queue.agent&&queue.status==='scheduled',soon=assigned&&remaining!==null&&remaining<=300,first=queue.status!=='connecting'&&queue.position===1;
    const notification=soon?'soon':first?'first':null;
    if(notification){const key=queue.id+':'+queue.scheduled_at+':'+notification;if(!noticeSeen.has(key)&&!document.hidden&&!document.querySelector('dialog[open]')){noticeSeen.add(key);try{sessionStorage.setItem(noticeKey,JSON.stringify([...noticeSeen].slice(-100)))}catch{}modal(qDialog)}}
  }
  function refreshFrame(){
    if(!monitor||!follow?.open)return;
    if(loadedRevision!==revision){loadedRevision=revision;frame.src=monitor.follow_url+'&revision='+encodeURIComponent(revision);}
    else applyMirror();
  }
  function applyMirror(){
    if(!monitor)return;let doc;try{doc=frame.contentDocument;if(!doc?.body||doc.body.dataset.followMode!=='1')return;}catch{return;}
    // The embedded page has no scripts, no form submission and no navigation permission.
    // Only allowlisted business-field values are applied; HTML is never accepted from telemetry.
    const all=monitor.fields||[],lineIndexes=[...new Set(all.map(f=>f.name.match(/^lines\[(\d+)\]/)?.[1]).filter(Boolean))];
    const tbody=doc.getElementById('document-lines'),template=doc.getElementById('line-template');
    if(tbody&&template){tbody.replaceChildren();for(const i of lineIndexes.slice(0,30)){const temp=doc.createElement('tbody');temp.innerHTML=template.innerHTML.replaceAll('__INDEX__',i);tbody.append(...temp.children);}}
    for(const f of all){if(!names.has(f.name)&&!/^lines\[\d{1,3}\]\[(product_id|label|quantity|price|vat)\]$/.test(f.name))continue;const scope=f.zone==='quick-contact-dialog'?doc.getElementById('quick-contact-dialog'):doc.getElementById('main');if(!scope)continue;for(const el of scope.querySelectorAll('input,select,textarea'))if(el.name===f.name&&!['password','hidden','file','submit','button'].includes(el.type)&&((f.zone==='quick-contact-dialog')===!!el.closest('#quick-contact-dialog')))el.value=f.value;}
    doc.querySelectorAll('input,select,textarea,button').forEach(el=>el.disabled=true);
    doc.querySelectorAll('a').forEach(el=>{el.removeAttribute('href');el.tabIndex=-1});
    doc.querySelectorAll('dialog[open]').forEach(el=>{if(el.id!==monitor.dialog)el.close()});
    const popup=monitor.dialog==='quick-contact-dialog'?doc.getElementById('quick-contact-dialog'):null;if(popup&&!popup.open)popup.showModal();
    // Recalculate the same visible document estimate without enabling any embedded scripts.
    const n=(v,scale=2)=>{let s=String(v).replace(/[\s\u00a0]+/g,'').replace(/(?:TL|TRY|₺)$/i,'');if(s.includes(','))s=s.replaceAll('.','').replace(',','.');else if(scale===2&&/^\d{1,3}(?:\.\d{3})+$/.test(s))s=s.replaceAll('.','');return Number(s)||0};
    let total=0;const fmt=v=>new Intl.NumberFormat('tr-TR',{style:'currency',currency:'TRY'}).format(v);for(const row of doc.querySelectorAll('.document-line')){const net=Math.round(n(row.querySelector('[data-line-qty]').value,3)*n(row.querySelector('[data-line-price]').value)*100)/100;const amount=net+Math.round(net*n(row.querySelector('[data-line-vat]').value)/100)/100;total+=amount;row.querySelector('.line-preview').textContent=fmt(amount)}const estimate=doc.getElementById('document-preview');if(estimate)estimate.textContent=fmt(total);
  }
  frame?.addEventListener('load',applyMirror);
  document.addEventListener('kobivira:poll-data',e=>{
    const d=e.detail,count=document.getElementById('desk-count');if(count&&typeof d.queue_count==='number')count.textContent=d.queue_count?'('+d.queue_count+')':'';
    if(d.queue_revision!==undefined){if(queueRevision!==null&&queueRevision!==d.queue_revision&&body.dataset.page==='support_desk'){const alert=document.getElementById('desk-list-update');if(alert)alert.hidden=false;}queueRevision=d.queue_revision;}
    if(qDialog){queue=d.queue||null;if(qBanner)qBanner.hidden=!queue;
      if(queue){offset=queue.server_time-Date.now()/1000;const state=queue.status==='connecting'?'Bağlantı hazırlanıyor':queue.scheduled_at?'Destek: '+queue.scheduled_label+' · Sıranız: '+queue.position:'Talebiniz sırada · Sıranız: '+queue.position;document.getElementById('desk-queue-text').textContent=state;document.getElementById('desk-queue-detail').textContent=queue.subject+' · '+(queue.agent||'Temsilci atanması bekleniyor')+' · '+state;qDialog.querySelector('[name=id]').value=queue.id;updateCountdown();}
      else if(qDialog.open)qDialog.close();
    }
    if(follow){monitor=d.monitor||null;
      if(!monitor){if(follow.open)follow.close();frame.removeAttribute('src');loadedRevision='';document.getElementById('support-follow-events').replaceChildren();return;}
      revision=monitor.request_id+':'+monitor.revision;
      follow.querySelector('[name=id]').value=monitor.request_id;
      const age=monitor.seen?Math.max(0,Math.floor(Date.now()/1000-monitor.seen)):null;
      document.getElementById('support-follow-page').textContent='Açık sayfa: '+monitor.caption+(monitor.dialog==='quick-contact-dialog'?' · Yeni müşteri / tedarikçi penceresi açık':'')+(age===null?' · Yönetici sayfası bekleniyor':age>15?' · Bağlantı bilgisi '+age+' saniye önce güncellendi':' · Canlı');
      const events=document.getElementById('support-follow-events');events.replaceChildren();for(const event of monitor.events||[]){const p=document.createElement('p');p.textContent=event.time+' · '+event.label;events.append(p)}refreshFrame();
    }
  });
  const tick=setInterval(updateCountdown,1000);window.addEventListener('pagehide',()=>clearInterval(tick));
})();
