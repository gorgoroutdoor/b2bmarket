<?php
declare(strict_types=1);
/** Package policy shared by navigation, server gates and public library. */
function nav354_visible(string $page,array $params=[]): bool {
 if(demo3627_preview($page,$params))return true;
 $f=plan351_feature($page,$params);if(in_array($f,['website','meta_ads','google_ads'],true))return module351_allowed($f);
 return plan3616_nav_allowed($page,$params);
}
function access354_plans(?string $feature): array {
 $names=['kobi'=>'KOBİ','plus'=>'KOBİ Plus','business'=>'KOBİ Business'];
 if(in_array($feature,['website','meta_ads','google_ads'],true)){ $m=module351_config()[$feature];return $m['enabled']?array_filter($names,fn($name,$code)=>plan3616_has($code,$feature),ARRAY_FILTER_USE_BOTH):[]; }
 if($feature!==null&&!launch3619_available($feature))return [];
 $key=$feature;if($key==='edocs')return array_filter($names,fn($name,$code)=>count(array_intersect(plan3616_config()['plans'][$code],['edoc_invoice','edoc_archive','edoc_incoming','edoc_smm','edoc_despatch','edoc_incoming_despatch','edoc_export']))>0,ARRAY_FILTER_USE_BOTH);if($key==='advanced_edocs')return array_filter($names,fn($name,$code)=>count(array_intersect(plan3616_config()['plans'][$code],['edoc_smm','edoc_despatch','edoc_export','edoc_incoming_despatch']))>0,ARRAY_FILTER_USE_BOTH);return array_filter($names,fn($name,$code)=>plan3616_has($code,$key),ARRAY_FILTER_USE_BOTH);
}
function access354_card(): void {if(owner())return;heading('Bu bölüm kullanılamıyor','Hesabınızın erişim ve çalışma durumunu kontrol edin.',a('dashboard','Genel bakış',[],'button'));}
function guide354_features(): array {return array_replace([
 'rehber-teklif'=>'quotes','rehber-proforma'=>'quotes','rehber-siparis'=>'orders','rehber-cari-ekstre'=>'statements','rehber-iade'=>'returns','rehber-smm'=>'smm','rehber-yaslandirma'=>'aging','rehber-mutabakat'=>'reconciliation',
 'rehber-aktarim'=>'bookkeeping','rehber-alis-faturasi'=>'bookkeeping','rehber-giderler'=>'bookkeeping','rehber-hesaplar'=>'bookkeeping','rehber-nakit-takvimi'=>'bookkeeping','rehber-raporlar'=>'bookkeeping','rehber-satis-faturasi'=>'bookkeeping','rehber-tahsilat'=>'bookkeeping','rehber-urunler'=>'bookkeeping','rehber-veri-aktarimi'=>'bookkeeping','rehber-veri-tasima'=>'bookkeeping',
 'rehber-elektronik-belge'=>'edocs','rehber-gelen-efatura'=>'edocs','rehber-ebelge-turleri'=>'advanced_edocs','rehber-onaylar'=>'approvals','rehber-onay-kurallari'=>'approval_rules','rehber-web-sitesi'=>'website',
 'rehber-calisan-gideri'=>'staff_money','rehber-cek'=>'cheques','rehber-crm'=>'crm','rehber-doviz'=>'currency','rehber-hatirlatma'=>'reminders','rehber-is-takibi'=>'tasks','rehber-kar'=>'profit','rehber-miktar'=>'quantity','rehber-ongoru'=>'forecast','rehber-otomasyon'=>'automation','rehber-paylasim'=>'sharing','rehber-proje'=>'projects','rehber-sablon'=>'templates','rehber-tekrar-kurallari'=>'recurring','rehber-tekrarlayan-satis'=>'recurring','rehber-toplu-islem'=>'bulk','rehber-ayrintili-rapor'=>'advanced_reports','rehber-banka-eslestirme'=>'bank_match'
 ],guide360_features(),array_map(fn($r)=>$r['feature'],guide3616_catalog()));}
function guide354_level(array $p): int {$f=guide354_features()[$p['slug']]??null;$plans=$f?access354_plans($f):[];return $plans?min(array_map(fn($code)=>plan_level($code),array_keys($plans))):1;}
function guide354_badge(array $p): string {
 $f=guide354_features()[$p['slug']]??null;$plans=$f?access354_plans($f):array_filter(['kobi'=>'KOBİ','plus'=>'KOBİ Plus','business'=>'KOBİ Business'],fn($name,$code)=>plan_level($code)>=guide354_level($p),ARRAY_FILTER_USE_BOTH);
 $s='<div class="guide354-plans" data-package-feature="'.esc($f??'general').'"><strong>Kullanılabilen paketler</strong><span>'.esc($plans?implode(' · ',$plans):'Şu anda bir pakete tanımlı değil').'</span></div>';
 $note='Paket kapsamı yönetimdeki güncel özellik seçimlerine göre gösterilir. Dış servis işlemleri için etkin bağlantı ve gerekli aktivasyonlar ayrıca tamamlanmalıdır.';
 return $s.($note?'<p class="guide354-note">'.esc($note).'</p>':'');
}
function guide354_badges(array $p,string $body): string {
 $body=preg_replace('~<div class="article-meta">.*?</div>~s','',$body);
 $badge=guide354_badge($p).guide3616_navigation($p);if(preg_match('~<h1\b[^>]*>.*?</h1>~s',$body))return preg_replace_callback('~<h1\b[^>]*>.*?</h1>~s',fn($m)=>$m[0].$badge,$body,1);return $badge.$body;
}
function edoc354_require(string $kind): void {require_paid('Elektronik belge işlemleri');need_feature(plan3616_edoc_feature($kind));}
/** Award is earned at approved annual payment, once for the lifetime campaign. Never sends a document. */
function gift354_snapshot(array $plan,int $months): array {return ['campaign'=>'plus-annual-1000-v1','units'=>$plan['code']==='plus'&&$months===12?1000:0];}
function gift354_award(array $order,?int $actor=null): void {
 $terms=query('SELECT gift_units,gift_campaign FROM membership_terms354 WHERE payment_order_id=?',[$order['id']])->fetch();if(!$terms||(int)$terms['gift_units']!==1000)return;
 $cid=(int)$order['company_id'];$campaign=$terms['gift_campaign'];
 if(query('SELECT 1 FROM annual_credit_awards WHERE company_id=? AND campaign=?',[$cid,$campaign])->fetchColumn())return;
 query("INSERT INTO annual_credit_awards(company_id,campaign,payment_order_id,units,status,created_at) VALUES (?,?,?,?, 'granted',UTC_TIMESTAMP())",[$cid,$campaign,$order['id'],1000]);
 credit_change($cid,1000,'Yıllık KOBİ Plus · bir defalık hediye kontör','gift:'.$campaign.':'.$cid,$actor??(int)current_user()['id']);
 company_notice($cid,'gift:'.$campaign,'1.000 hediye kontör hesabınıza tanımlandı','Yıllık KOBİ Plus ödemeniz onaylandı. Bu hediye firma başına bir defadır. Kontör kullanımı, paket yetkisi ve etkin sağlayıcı bağlantısına bağlıdır.','membership',null);
 audit('credits.annual_gift',['company'=>$cid,'order'=>$order['id'],'units'=>1000]);
}
function gift354_revoke(int $cid,string $reason): void {
 $r=query("SELECT * FROM annual_credit_awards WHERE company_id=? AND campaign='plus-annual-1000-v1' FOR UPDATE",[$cid])->fetch();if(!$r||$r['status']!=='granted')throw new DomainException('Geri alınabilecek bir yıllık Plus hediyesi bulunamadı.');
 // Refuse a negative balance: spent credits need a separate refund agreement, not silent debt.
 if((int)query('SELECT credits_balance FROM companies WHERE id=? FOR UPDATE',[$cid])->fetchColumn()<(int)$r['units'])throw new DomainException('Kontör bakiyesi hediyeyi geri almaya yetmiyor. Kullanılmış kontörler için iade değerlendirmesini ayrı sonuçlandırın.');
 credit_change($cid,-(int)$r['units'],'Yıllık Plus hediyesi geri alındı · '.$reason,'gift-revoke:'.$r['payment_order_id'],(int)current_user()['id']);
 query("UPDATE annual_credit_awards SET status='revoked',revoked_at=UTC_TIMESTAMP(),revoke_reason=? WHERE company_id=? AND campaign=?",[$reason,$cid,$r['campaign']]);
 company_notice($cid,'gift-revoke:'.$r['payment_order_id'],'Hediye kontör kaydınız güncellendi',$reason,'membership',null);audit('credits.gift_revoked',['company'=>$cid,'order'=>$r['payment_order_id'],'reason'=>$reason]);
}
function gift354_copy(): string {return 'Yıllık KOBİ Plus satın alımında firma başına bir kez 1.000 hediye kontör. Hediye ödeme onayında tanımlanır; gerçek kullanım etkin sağlayıcı bağlantısına bağlıdır. Aylık ödemelerde ve yenilemelerde yeniden verilmez. Nakde çevrilemez; ödeme iptali / iadesinde hediye ayrıca değerlendirilir.';}
/** Proration is a non-cash time conversion, list prices fixed at order creation. Discounts never overwritten. */
function terms354_create(int $id,array $target,int $months): void {
 $s=query('SELECT s.*,p.monthly_price FROM subscriptions s JOIN plans p ON p.id=s.plan_id WHERE s.company_id=? FOR UPDATE',[company_id()])->fetch();$gift=gift354_snapshot($target,$months);
 query('INSERT INTO membership_terms354(payment_order_id,source_plan_id,source_status,source_paid_until,old_monthly,new_monthly,gift_campaign,gift_units,created_at) VALUES (?,?,?,?,?,?,?,?,UTC_TIMESTAMP())',[$id,$s['plan_id'],$s['status'],$s['paid_until'],$s['monthly_price']===null?0:scaled((string)$s['monthly_price']),scaled((string)$target['monthly_price']),$gift['campaign'],$gift['units']]);
}
function terms354_bonus(array $r,array $s): int {
 $t=query('SELECT * FROM membership_terms354 WHERE payment_order_id=?',[$r['id']])->fetch();if(!$t)return 0;
 if((int)$s['plan_id']!==(int)$t['source_plan_id']||$s['status']!==$t['source_status']||($s['paid_until']??null)!==($t['source_paid_until']??null))throw new DomainException('Üyelik bu talep oluşturulduktan sonra değişti. Güncel üyeliğe göre yeni ödeme talebi oluşturulmalıdır. Bu talebi reddederek firmaya açıklayın.');
 if((int)$r['plan_id']===(int)$s['plan_id']||$s['status']!=='active'||!$s['paid_until'])return 0;
 $seconds=max(0,strtotime($s['paid_until'].' UTC')-time());if(!$seconds)return 0;
 if((int)$t['old_monthly']<=0||(int)$t['new_monthly']<=0)throw new DomainException('Kalan üyelik süresi için paket fiyatları tanımlanmalı; bu talebi yeniden oluşturun.');
 // PHP floats avoid intermediate integer overflow; result is bounded by old right and price ratio.
 $bonus=floor($seconds*((int)$t['old_monthly']/(int)$t['new_monthly']));if(!is_finite($bonus)||$bonus>315576000)throw new DomainException('Aktarılacak süre 10 yılı aşıyor. Yönetici incelemesi gerekir.');return (int)$bonus;
}
function terms354_copy(): string {return 'Aynı pakette yenileme, mevcut ücretli bitişinize eklenir. Paket değişikliği ödeme onayında başlar. Kalan ücretli süreniz, talep tarihindeki eski / yeni paket net aylık liste fiyatı oranıyla yeni pakete ek süre olarak aktarılır. Deneme süresi aktarılmaz; bu işlem nakit iade veya ödeme indirimi oluşturmaz. İndirimler satın alma bedeline uygulanır.';}
function terms354_summary(array $r): string {
 $t=query('SELECT * FROM membership_terms354 WHERE payment_order_id=?',[$r['id']])->fetch();if(!$t)return '<div class="info-note">'.esc(terms354_copy()).'</div>';
 $text=terms354_copy();if((int)$t['source_plan_id']!==(int)$r['plan_id']&&$t['source_status']==='active')$text.=' Süre hesabında sabitlenen net liste fiyatları: '.money((int)$t['old_monthly']).' / '.money((int)$t['new_monthly']).'.';
 if($t['applied_bonus_seconds']!==null)$text.=' Onayda eklenen süre: '.number_format((int)$t['applied_bonus_seconds']/86400,2,',','.').' gün.';
 return '<div class="info-note"><strong>Paket değişikliği ve kalan kullanım hakkı</strong><p>'.esc($text).'</p>'.((int)$t['gift_units']?'<p>'.esc(gift354_copy()).'</p>':'').'</div>';
}
function gift354_admin(array $c): void {
 $r=query("SELECT * FROM annual_credit_awards WHERE company_id=? AND campaign='plus-annual-1000-v1'",[$c['id']])->fetch();if(!$r)return;
 panel('Yıllık Plus · bir defalık kontör hediyesi');echo '<p>Ödeme kaydı: #'.(int)$r['payment_order_id'].' · '.(int)$r['units'].' kontör · '.($r['status']==='granted'?'Tanımlandı':'Geri alındı').'</p><p class="field-hint">'.esc(gift354_copy()).'</p>';
 if($r['status']==='granted'){form_start('billing','revoke_gift');hidden('company_id',$c['id']);input('reason','Ödeme iptali / iadesi değerlendirme gerekçesi','','text','required maxlength="500"');input('current_password','Mevcut yönetici şifreniz','','password','required');form_end('Hediye kontörü geri al');}else echo '<p>'.esc($r['revoke_reason']).'</p>';echo '</section>';
}
