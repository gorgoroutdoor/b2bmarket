<?php
declare(strict_types=1);
function authorize_page(string $page): void {
    email3643_guard($page);phone3644_guard($page);
    if(in_array($page,['admin_menu','admin_search','admin_pending','admin_favorites','admin_credits','admin_plan_features'],true)){admin3641_guard();return;}
    if($page==='paytr_test'){admin351_guard();return;}
    if($page==='backups'){backup367_guard();return;}
    if($page==='edm_test'){edm361_guard();return;}
    if(in_array($page,['login','register'],true))return;
    if($page==='support_poll')return;if(in_array($page,['module_admin','launch_admin','legal_admin','promotion_admin'],true)){admin351_guard();return;}
    if(suspended_firm()&&!in_array($page,['settings','account','logout','company_notices','verification_download'],true)){if($_SERVER['REQUEST_METHOD']==='GET')redirect('settings');http_response_code(403);throw new DomainException('Firma erişimi askıda. Yalnız firma bilgileri ve inceleme işlemleri açıktır.');}
    if(demo3627_preview($page,$_GET)){demo3627_guard($page);return;}
    if($page==='credits'){commerce_guard();return;}
    if(in_array($page,['site_admin','website','digital_ads','web_preview'],true)){if(cms_platform())return;if($page==='site_admin'){http_response_code(403);throw new DomainException('Kobivira yönetici yetkisi gerekir.');}firm_manager();plan351_guard($page);return;}
    if(in_array($page,['verification','delivery','marketing_admin'],true)){if(isset($_GET['support'])){http_response_code(403);throw new DomainException('Canlı destekten bu alana erişilemez.');}if((base_user()['role']??'')!=='platform_admin'||support_context()){http_response_code(403);throw new DomainException('Platform yöneticisi yetkisi gerekir.');}return;}
    if(in_array($page,['company_notices','verification_download'],true)){if(isset($_GET['support'])){http_response_code(403);throw new DomainException('Canlı destekten özel firma evraklarına erişilemez.');}if($page==='verification_download'&&(base_user()['role']??'')==='platform_admin'&&!support_context())return;firm_manager();return;}
    if($page==='referrals'){firm_manager();return;}support_guard($_SERVER['REQUEST_METHOD']==='POST');team_guard($page);if($page==='library3616'){if(!current_user()||owner())throw new DomainException('Firma hesabı gerekir.');if($_SERVER['REQUEST_METHOD']!=='GET')throw new DomainException('Bu bölüm yalnız görüntülenebilir.');return;}if(!owner())plan351_guard($page);if(ledger_route($page)){ledger_guard($page);return;}if($page==='migration'){firm_manager();return;}if($page==='migration_admin'){require_owner();if((base_user()['role']??'')!=='platform_admin'||support_context())throw new DomainException('Platform yöneticisi gerekir.');return;}if(extension_authorize($page))return;
    if(in_array($page,['member_edit','data_import','projects','bank_match','approval_rules'],true)){firm_manager();return;}
    if($_SERVER['REQUEST_METHOD']==='GET'&&!support_context()&&!suspended_firm()&&(base_user()['role']??'')==='company_admin'){if($page==='settings'&&isset($_GET['accountant_edit']))redirect('member_edit',['id'=>(int)$_GET['accountant_edit'],'type'=>'accountant']);if($page==='users'&&isset($_GET['edit']))redirect('member_edit',['id'=>(int)$_GET['edit'],'type'=>'employee']);}
    if($page==='help'){help_authorize();return;}
    if($page==='approvals'&&!support_context()&&!owner())return;
    if($page==='audit'&&(current_user()['role']??'')==='company_admin')return;
    if(support_context()&&in_array($page,['support_workspace','support_end'],true))return;
    if((base_user()['role']??'')==='support_agent'&&!support_context()){if($page==='dashboard')redirect('support_desk');if(!in_array($page,['support_desk','support','help','account','logout'],true)){http_response_code(403);throw new DomainException('Bu bölüm destek temsilcisine açık değildir.');}}
    $ownerPages=['help','notifications','support_desk','dashboard','companies','plans','updates','audit','platform','account','logout','billing','support'];
    $companyPages=['incoming_invoices','contact_lookup','print_document','invoice_download','help','support_follow','dashboard','documents','document','newdocument','contacts','contact','products','accounts','payments','cashflow','reports','settings','users','membership','recurring','reminders','tasks','approvals','search','account','logout','export','audit','billing','support_center','quick_contact'];
    if(!in_array($page,owner()?$ownerPages:$companyPages,true)){http_response_code(404);throw new DomainException('Sayfa bulunamadı.');}
    if(owner())return;
    if($page==='support_follow'){if($_SERVER['REQUEST_METHOD']!=='GET'){http_response_code(405);throw new DomainException('Canlı izleme yalnızca görüntüleme içindir.');}desk_company_admin();return;}
    if(in_array($page,['settings','users'],true)&&!support_context())require_manager();
    if(in_array($page,['export'],true))need_feature($page==='export'?'export':($page==='audit'?'audit':$page));
    if($page==='newdocument'&&!bookkeeping_available())need_feature('bookkeeping');
    
    if(in_array($page,['document','print_document'],true)&&isset($_GET['id'])){$d=tenant_row('documents',(int)$_GET['id']);}
}
function dispatch_post(string $page): void {
    $action=required_field('action',40);if($page==='admin_menu'){admin3641_post($action);return;}if($page==='admin_plan_features'){admin3641_features_post($action);return;}if($page==='paytr_test')paytr3623_post($action);if($page==='document'&&in_array($action,['cancel','revise','restore_cancel'],true))firm3615_protect_source(int_field('id',1,PHP_INT_MAX));if($page==='backups')backup367_post($action);if($page==='edm_test')edm361_post($action);if(owner()&&in_array($page,['companies','plans'],true))plan351_validate_assignment();if($page==='promotion_admin'){promotion352_post($action);return;}if($page==='module_admin'){module351_post($action);return;}if($page==='launch_admin'){launch351_post($action);return;}if($page==='legal_admin'){legal_admin_post($action);return;}if(!owner()&&!in_array($page,['login','register'],true))plan351_guard($page);if(ledger_route($page)){ledger_post($page,$action);return;}if(in_array($page,['migration','migration_admin'],true)){migration_post($page,$action);return;}if($page==='credits')credits_post($action);if($page==='plans'&&$action==='commerce_save')commerce_save();
    if($page==='login'&&$action==='login'){
        throttle('login');$email=email_field();$pass=is_string($_POST['password']??null)?$_POST['password']:'';
        $u=query('SELECT * FROM users WHERE email=? AND is_active=1 AND is_deleted=0',[$email])->fetch();
        $hash=$u['password_hash']??'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi';
        if(!password_verify($pass,$hash)||!$u)throw new DomainException('E-posta veya şifre hatalı.');
        if($u['company_id']){$firm=query('SELECT status,restriction_reason,restriction_code FROM companies WHERE id=?',[$u['company_id']])->fetch();if(!$firm||($firm['status']!=='active'&&$u['role']!=='company_admin'))throw new DomainException(restriction_message(company_restriction($firm?:[])));}
        query('DELETE FROM login_attempts WHERE bucket=?',[throttle_key('login')]);login($u);
    }
    if($page==='register'&&$action==='register'){
        if(setting('registration_open','1')!=='1')throw new DomainException('Yeni üyelikler şu anda kapalı.');throttle('register',5);
        mobile_number(required_field('mobile_phone',24));$consent=legal_validate_registration();$GLOBALS['registration_consent']=$consent;try{$cid=create_company(required_field('company',160),email_field(),password_field(),required_field('name',100),public_demo_plan(),referral_input());}finally{unset($GLOBALS['registration_consent']);}
        email3643_after_registration($cid);login(query('SELECT * FROM users WHERE email=?',[email_field()])->fetch());
    }
    if(!current_user())throw new DomainException('Oturum açın.');if(in_array($page,['site_admin','website'],true))cms_save(cms_post('view',30)?:($_GET['view']??'dashboard'),$action);if($page==='marketing_admin')marketing_admin_post($action);if(extension_route($page)){extension_post($page,$action);return;}
    if(in_array($action,['delete_company','delete_company_continue'],true)&&in_array($page,['companies','account'],true)){if(!owner()&&(!can_write()||suspended_firm())){http_response_code(403);throw new DomainException('Kısıtlı hesap firma verilerini silemez.');}purge3648_dispatch($action);}
    if($page==='projects'){project_post($action);return;}if($page==='bank_match'){bank_post($action);return;}if($page==='approval_rules'){approval_rules_post($action);return;}if($page==='member_edit'){team_post($action,($_GET['type']??'employee')==='accountant');return;}if($page==='company_notices'){firm_notice_post($action);return;}if($page==='verification'){review_post();return;}if($page==='delivery'){delivery_post($action);return;}if($page==='settings'&&in_array($action,['request_code','confirm_code'],true)){contact_code_post($action);return;}if($page==='settings'&&$action==='upload_evidence')upload_evidence();if($page==='settings'&&in_array($action,['submit_review','reconsider'],true))review_submit($action==='reconsider'?'reconsider':'verification');
    if(!owner()&&(!can_write()||suspended_firm())&&$action==='delete_company'){http_response_code(403);throw new DomainException('Kısıtlı hesap yalnız görüntüleme ve firma inceleme işlemleri yapabilir.');}
    if($page==='notifications'){notification_post($action);return;}
    if($page==='settings'&&$action==='set_business_type')save_verification_type();
    if($page==='settings'&&$action==='save_bank')save_bank_profile();
    if($page==='settings'&&$action==='save'){save_company_profile();return;}
    if($page==='users'&&in_array($action,['save','toggle','reset_password'],true)){team_post(['save'=>'save_member','toggle'=>'toggle_member','reset_password'=>'reset_member'][$action]);return;}
    if($page==='help'){help_post($action);return;}
    if($page==='approvals'){approval_post($action);return;}
    if(in_array($page,['users','settings'],true)&&in_array($action,['save_member','delete_member','toggle_member','reset_member'],true)){team_post($action,$page==='settings');return;}
    if($page==='support_poll')support_poll();
    if($page==='support_desk'||($page==='support_center'&&in_array($action,['join','cancel_queue'],true))){desk_post($action);return;}
    if(in_array($page,['support','support_center','support_end'],true)){support_post($action);return;}
    if($page==='billing'){billing_post($action);return;}
    if($page==='newdocument'&&$action==='save_imported')imported_summary_save();if($page==='account'&&in_array($action,['save_avatar','remove_avatar'],true))avatar_post($action);if($page==='data_import')import_post($action);if($page==='incoming_invoices')incoming_post($action);if($page==='quick_contact')quick_contact();
    if($action==='logout'&&$page==='logout'){$_SESSION=[];session_regenerate_id(true);redirect('login');}
    if($page==='account'&&$action==='save_profile'){studio3634_profile_save();return;}
    if($page==='account'&&$action==='password'){
        reauthenticate(current_user());query('UPDATE users SET password_hash=?,session_version=session_version+1 WHERE id=?',[password_hash(password_field(),PASSWORD_DEFAULT),current_user()['id']]);audit('user.own_password_changed');$_SESSION=[];session_regenerate_id(true);flash('Şifreniz değişti. Yeniden giriş yapın.');redirect('login');
    }
    if(owner()){owner_post($page,$action);return;}
    require_write();
    if(in_array($page,['newdocument','document','accounts','payments','recurring','tasks'],true))need_feature('bookkeeping');
    if($page==='payments'&&in_array($action,['save','transfer'],true)){ $queued=company_transaction(function()use($action){$key=request_key();if(query('SELECT id FROM payments WHERE company_id=? AND '.($action==='save'?'request_key':'transfer_key').'=?',[company_id(),$key])->fetchColumn())return false;if(query('SELECT id FROM approval_requests WHERE company_id=? AND request_key=?',[company_id(),$key])->fetchColumn())return true;$data=$action==='save'?payment_input():transfer_input();if(needs_financial_approval(scaled($data['amount']))){enqueue_approval($action==='save'?'payment':'transfer',$data);return true;}if($action==='save')apply_payment($data,(int)current_user()['id']);else apply_transfer($data,(int)current_user()['id']);return false;});flash($queued?'İşlem onay sırasına gönderildi. Para hareketi henüz kayıtlara uygulanmadı.':'İşlem kaydedildi.');redirect($queued?'approvals':'payments');}
    if($page==='document'&&$action==='post'&&tenant_row('documents',int_field('id',1,PHP_INT_MAX))['record_type']==='smm')throw new DomainException('Makbuz taslağını makbuz ekranından kesinleştirin.');if($page==='document'&&$action==='post'&&in_array(($approvalDoc=tenant_row('documents',int_field('id',1,PHP_INT_MAX)))['kind'],['sale','purchase','expense'],true)&&needs_financial_approval((int)$approvalDoc['total'])){company_transaction(fn()=>enqueue_document(int_field('id',1,PHP_INT_MAX)));flash('Belge yönetici onayına gönderildi.');redirect('approvals');}
    switch($page.':'.$action){
        case 'contacts:save':
            company_transaction(function(){
                $kind=choice('kind',['customer','supplier','both']);$email=field('email');if($email&&!filter_var($email,FILTER_VALIDATE_EMAIL))throw new DomainException('E-posta hatalı.');
                $args=[required_field('name',160),$kind,$email,field('phone',30),field('tax_number',16),field('address',1000),field('note',1000),field('contact_person',100),field('tax_office',100)];$id=(int)field('id',20);
                if($id){tenant_row('contacts',$id,true);query('UPDATE contacts SET name=?,kind=?,email=?,phone=?,tax_number=?,address=?,note=?,contact_person=?,tax_office=? WHERE company_id=? AND id=?',[...$args,company_id(),$id]);}
                else {require_contact_capacity();query('INSERT INTO contacts(name,kind,email,phone,tax_number,address,note,contact_person,tax_office,company_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP())',[...$args,company_id()]);}
                audit('contact.saved',['id'=>$id?:db()->lastInsertId()]);
            });flash('Cari kartı kaydedildi.');redirect('contacts',in_array($_POST['kind']??'', ['customer','supplier'],true)?['kind'=>$_POST['kind']]:[]);
        case 'products:save':
            company_transaction(function(){
                $args=[required_field('name',160),choice('kind',['product','service']),required_field('code',64),required_field('unit',24),amount('price',999999999),amount('cost',999999999),int_field('vat',0,10000)];$id=(int)field('id',20);
                if($id){tenant_row('products',$id,true);query('UPDATE products SET name=?,kind=?,code=?,unit=?,price=?,cost=?,vat=? WHERE company_id=? AND id=?',[...$args,company_id(),$id]);}
                else query('INSERT INTO products(name,kind,code,unit,price,cost,vat,company_id,created_at) VALUES (?,?,?,?,?,?,?,?,UTC_TIMESTAMP())',[...$args,company_id()]);audit('product.saved',['id'=>$id?:db()->lastInsertId()]);
            });flash('Ürün / hizmet kaydedildi.');redirect('products',['kind'=>$_POST['kind']]);
        case 'newdocument:save':
            $id=company_transaction(function(){$id=save_document();if(team_member()&&in_array($_POST['kind']??'', ['sale','purchase','expense'],true))enqueue_document($id);return $id;});flash(team_member()&&in_array($_POST['kind']??'', ['sale','purchase','expense'],true)?'Belge yönetici onayına gönderildi. Onaylanana kadar finansal kayıtlara uygulanmaz.':'Taslak kaydedildi. Kontrol edip kesinleştirebilirsiniz.');redirect('document',['id'=>$id]);
        case 'document:restore_cancel':
            $id=int_field('id',1,PHP_INT_MAX);company_transaction(fn()=>cancel359_restore($id));flash('İptal geri alındı. Belge taslak olarak düzenlenebilir; eski bağlantılar kapalı kalır.');redirect('document',['id'=>$id]);
        case 'document:revise':
            $id=company_transaction(fn()=>revision358_create(int_field('id',1,PHP_INT_MAX),request_key()));flash('Revizyon taslağı oluşturuldu. Bilgileri düzenleyip yeniden onaylayın.');redirect('document',['id'=>$id]);
        case 'document:post':
            $id=int_field('id',1,PHP_INT_MAX);company_transaction(function()use($id){
                $d=tenant_row('documents',$id,true);if(!empty($d['return_of_id'])||$d['record_type']==='smm')throw new DomainException('Bu kaydı kendi işlem ekranından yönetin.');if($d['kind']==='order')need_feature('orders');if($d['status']!=='draft')throw new DomainException('Yalnızca taslak kesinleştirilebilir.');require_issuer($d['kind']);
                $pending=has_feature('approvals')&&!can_approve()&&in_array($d['kind'],['sale','purchase','expense'],true);
                $status=$pending?'pending':(in_array($d['kind'],['quote','proforma','order'],true)?'approved':'posted');
                query('UPDATE documents SET status=? WHERE company_id=? AND id=?',[$status,company_id(),$id]);revision358_publish($id);stock_document($id);audit('document.'.$status,['id'=>$id]);
            });flash('Belge durumu güncellendi.');redirect('document',['id'=>$id]);
        case 'document:approve':
            $request=query('SELECT id FROM approval_requests WHERE company_id=? AND document_id=?',[company_id(),int_field('id',1,PHP_INT_MAX)])->fetchColumn();if($request){$_POST['id']=$request;approval_post('approve');return;}
            need_feature('approvals');if(!can_approve()){http_response_code(403);throw new DomainException('Onay yetkisi gerekir.');}
            $id=int_field('id',1,PHP_INT_MAX);company_transaction(function()use($id){$d=tenant_row('documents',$id,true);if($d['status']!=='pending'||((int)$d['created_by']===(int)current_user()['id']&&current_user()['role']!=='company_admin'))throw new DomainException('Bu belgeyi onaylayamazsınız.');require_issuer($d['kind']);query("UPDATE documents SET status=? WHERE company_id=? AND id=?",[in_array($d['kind'],['quote','proforma','order'],true)?'approved':'posted',company_id(),$id]);revision358_publish($id);audit('document.approved',['id'=>$id]);});flash('Belge onaylandı.');redirect('document',['id'=>$id]);
        case 'document:cancel':
            $id=int_field('id',1,PHP_INT_MAX);company_transaction(function()use($id){$d=tenant_row('documents',$id,true);if(query("SELECT id FROM staff_money WHERE company_id=? AND expense_id=? AND status='approved'",[company_id(),$id])->fetchColumn())throw new DomainException('Çalışan giderini Çalışan giderleri / avanslar bölümünden gerekçeyle geri alın.');if($d['status']==='cancelled')throw new DomainException('Belge zaten iptal.');if($d['status']==='superseded')throw new DomainException('Bu belge revizyonla kapatılmış. Güncel revizyonu kullanın.');
                if(in_array($d['status'],['posted','pending'],true)&&!can_approve()){http_response_code(403);throw new DomainException('Kesinleşmiş belgeyi yönetici iptal edebilir.');}
                if(query("SELECT id FROM documents WHERE company_id=? AND source_id=? AND status<>'cancelled'",[company_id(),$id])->fetchColumn())throw new DomainException('Bu belgeden türetilen kayıtları önce iptal edin.');
                if(query("SELECT id FROM documents WHERE company_id=? AND return_of_id=? AND status='posted'",[company_id(),$id])->fetchColumn())throw new DomainException('Önce bağlı iade kayıtlarını geri alın.');if(!empty($d['return_of_id']))throw new DomainException('İade kaydını İade kayıtları bölümünden geri alın.');if(query('SELECT id FROM payments WHERE company_id=? AND document_id=? AND reversed_at IS NULL',[company_id(),$id])->fetchColumn())throw new DomainException('Önce bağlı tahsilat / ödemeyi geri alın.');
                if(query('SELECT id FROM recurring WHERE company_id=? AND document_id=? AND is_active=1',[company_id(),$id])->fetchColumn())throw new DomainException('Önce bu belgenin tekrarını durdurun.');
                query("UPDATE documents SET status='cancelled' WHERE company_id=? AND id=?",[company_id(),$id]);audit('document.cancelled',['id'=>$id]);});flash('Belge iptal edildi.');redirect('document',['id'=>$id]);
        case 'document:convert':
            $id=int_field('id',1,PHP_INT_MAX);$new=company_transaction(function()use($id){$d=tenant_row('documents',$id,true);$target=choice('target',['order','sale']);need_feature('orders');if(!in_array($d['kind'],['quote','proforma','order'],true)||$d['status']!=='approved'||($d['kind']==='order'&&$target!=='sale'))throw new DomainException('Bu dönüşüm kullanılamaz.');return clone_document($d,$target,today(),$id);});flash('Yeni taslak oluşturuldu.');redirect('document',['id'=>$new]);
        case 'accounts:save':
            company_transaction(function(){require_manager();$opening=field('opening_balance',30);$negative=str_starts_with($opening,'-');$n=scaled(ltrim($opening,'-'));if($negative)$n=-$n;
                query('INSERT INTO accounts(company_id,name,kind,opening_balance,created_at) VALUES (?,?,?,?,UTC_TIMESTAMP())',[company_id(),required_field('name',100),choice('kind',['cash','bank']),$n]);$id=(int)db()->lastInsertId();account_currency_create($id,$n);audit('account.created',['id'=>$id]);});flash('Hesap eklendi.');redirect('accounts');
        case 'payments:save':
            company_transaction(fn()=>save_payment());flash('İşlem kaydedildi.');redirect('payments');
        case 'payments:transfer':
            company_transaction(function(){
                $key=request_key();if(query('SELECT id FROM payments WHERE company_id=? AND transfer_key=?',[company_id(),$key])->fetchColumn())return;
                $from=tenant_row('accounts',int_field('from_account',1,PHP_INT_MAX),true);$to=tenant_row('accounts',int_field('to_account',1,PHP_INT_MAX),true);if($from['id']===$to['id'])throw new DomainException('İki farklı hesap seçin.');$n=amount('amount');if($n<=0)throw new DomainException('Pozitif tutar girin.');$day=date_field('paid_date');
                foreach([[$from['id'],'out'],[$to['id'],'in']] as [$account,$direction])query('INSERT INTO payments(company_id,account_id,direction,amount,paid_date,note,request_key,transfer_key,created_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP())',[company_id(),$account,$direction,$n,$day,'Hesaplar arası aktarım',form_key(),$key,current_user()['id']]);audit('accounts.transferred');
            });flash('Hesaplar arası aktarım kaydedildi.');redirect('payments');
        case 'payments:reverse':
            require_manager();$id=int_field('id',1,PHP_INT_MAX);company_transaction(function()use($id){$p=query('SELECT * FROM payments WHERE company_id=? AND id=? FOR UPDATE',[company_id(),$id])->fetch();if(!$p||$p['reversed_at'])throw new DomainException('İşlem bulunamadı veya geri alınmış.');if($p['transfer_key'])query('UPDATE payments SET reversed_at=UTC_TIMESTAMP() WHERE company_id=? AND transfer_key=? AND reversed_at IS NULL',[company_id(),$p['transfer_key']]);else query('UPDATE payments SET reversed_at=UTC_TIMESTAMP() WHERE company_id=? AND id=?',[company_id(),$id]);if(query("SELECT id FROM staff_money WHERE company_id=? AND payment_id=? AND status='approved'",[company_id(),$id])->fetchColumn())throw new DomainException('Onaylı çalışan ödemesi doğrudan geri alınamaz. Önce çalışan kayıtlarını inceleyin.');query("UPDATE cheques SET status='waiting' WHERE company_id=? AND payment_id=?",[company_id(),$id]);audit('payment.reversed',['id'=>$id]);});flash('İşlem geri alındı; geçmiş kaydı korundu.');redirect('payments');
        case 'settings:save':
            require_manager();company_transaction(function(){query('UPDATE companies SET name=?,tax_number=?,tax_office=?,phone=?,address=? WHERE id=?',[required_field('name',160),field('tax_number',16),field('tax_office',100),field('phone',30),field('address',1000),company_id()]);audit('company.settings');});flash('Firma bilgileri kaydedildi.');redirect('settings');
        case 'users:save':save_user();flash('Kullanıcı kaydedildi.');redirect('users');
        case 'users:reset_password':
            require_manager();reauthenticate(current_user());company_transaction(function(){
                $u=tenant_row('users',int_field('id',1,PHP_INT_MAX),true);if($u['role']==='support')throw new DomainException('Geçici destek hesabı buradan değiştirilemez.');if($u['role']==='company_admin')throw new DomainException('Yönetici şifresi için Şifre ve güvenlik ekranını kullanın.');
                query('UPDATE users SET password_hash=?,session_version=session_version+1 WHERE company_id=? AND id=?',[password_hash(password_field(),PASSWORD_DEFAULT),company_id(),$u['id']]);audit('user.password_reset',['id'=>$u['id']]);
            });flash('Ekip üyesinin şifresi yenilendi; açık oturumları kapatıldı.');redirect('users');
        case 'users:toggle':
            require_manager();company_transaction(function(){$u=tenant_row('users',int_field('id',1,PHP_INT_MAX),true);if($u['role']==='support')throw new DomainException('Geçici destek hesabı etkinleştirilemez.');if($u['role']==='company_admin'||(int)$u['id']===(int)current_user()['id'])throw new DomainException('Yönetici hesabı buradan kapatılamaz.');
                if(!$u['is_active'])check_user_quota();query('UPDATE users SET is_active=1-is_active,session_version=session_version+1 WHERE company_id=? AND id=?',[company_id(),$u['id']]);audit('user.toggled',['id'=>$u['id']]);});redirect('users');
        case 'recurring:add':
            need_feature('recurring');company_transaction(function(){$d=tenant_row('documents',int_field('id',1,PHP_INT_MAX),true);if($d['kind']!=='sale'||$d['status']!=='posted')throw new DomainException('Kesinleşmiş satış seçin.');$next=date_field('next_date');query('INSERT INTO recurring(company_id,document_id,next_date,anchor_day) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE next_date=VALUES(next_date),anchor_day=VALUES(anchor_day),is_active=1',[company_id(),$d['id'],$next,(int)substr($next,8,2)]);audit('recurring.created');});flash('Aylık tekrar eklendi.');redirect('recurring');
        case 'recurring:generate':
            need_feature('recurring');$count=company_transaction(function(){$rs=query('SELECT * FROM recurring WHERE company_id=? AND is_active=1 AND next_date<=? ORDER BY id LIMIT 50 FOR UPDATE',[company_id(),today()])->fetchAll();foreach($rs as $r){$d=tenant_row('documents',(int)$r['document_id']);if($d['status']!=='posted')throw new DomainException('Tekrarın kaynak satışı kesinleşmiş olmalıdır.');clone_document($d,'sale',$r['next_date'],null,(int)$r['id']);query('UPDATE recurring SET next_date=? WHERE company_id=? AND id=?',[next_month($r['next_date'],(int)$r['anchor_day']),company_id(),$r['id']]);}audit('recurring.generated',['count'=>count($rs)]);return count($rs);});flash($count.' satış taslağı oluşturuldu.');redirect('recurring');
        case 'recurring:stop':need_feature('recurring');company_transaction(function(){$r=tenant_row('recurring',int_field('id',1,PHP_INT_MAX),true);query('UPDATE recurring SET is_active=0 WHERE company_id=? AND id=?',[company_id(),$r['id']]);audit('recurring.stopped');});redirect('recurring');
        case 'tasks:add':case 'tasks:save':case 'tasks:toggle':case 'tasks:close':case 'tasks:reopen':case 'tasks:complete':work_task_post($action);break;
        default:throw new DomainException('İşlem tanınmadı.');
    }
}
function form_key(): string {return bin2hex(random_bytes(16));}
function request_key(): string {$s=required_field('request_key',32);if(!preg_match('/^[a-f0-9]{32}$/D',$s))throw new DomainException('İşlem anahtarı geçersiz.');return $s;}
function save_document(): int {if(!empty($_POST['id'])){ $prior=tenant_row('documents',(int)$_POST['id']);if(!empty($prior['return_of_id'])||$prior['record_type']==='smm')throw new DomainException('İade ve makbuz kayıtları kendi ekranından yönetilir.');}
    $kind=choice('kind',array_keys(doc_kinds()));need_feature(in_array($kind,['quote','proforma'],true)?'quotes':($kind==='order'?'orders':'bookkeeping'));$id=(int)field('id',20);$key=request_key();
    if(!$id){$existing=query('SELECT id FROM documents WHERE company_id=? AND request_key=?',[company_id(),$key])->fetchColumn();if($existing)return (int)$existing;require_document_capacity();}
    else{$old=tenant_row('documents',$id,true);if(imported_summary($old))throw new DomainException('Aktarılan fatura için özet düzenleme formunu kullanın.');if($old['status']!=='draft'||$old['kind']!==$kind)throw new DomainException('Yalnızca aynı türdeki taslak düzenlenebilir.');}
    require_issuer($kind);$contact=(int)field('contact_id',20);if($contact)tenant_row('contacts',$contact);elseif($kind!=='expense'){$GLOBALS['contact_required']=true;throw new DomainException('Bu belgeyi kime hazırladığınızı seçin. Müşteri kaydınız yoksa Yeni müşteri ekle düğmesiyle önce bir cari kartı oluşturun.');}
    $issue=date_field('issue_date');$due=date_field('due_date');if($due<$issue)throw new DomainException('Vade, belge tarihinden önce olamaz.');
    $raw=$_POST['lines']??null;if(!is_array($raw)||count($raw)>30)throw new DomainException('En fazla 30 belge satırı ekleyin.');
    $lines=[];$net=0;$tax=0;$cost=0;$discountTotal=0;
    $rowNumber=0;foreach($raw as $r){$rowNumber++;if(!is_array($r))throw new DomainException('Belge satırı hatalı.');
        $label=trim(is_string($r['label']??null)?$r['label']:'');$pid=filter_var($r['product_id']??0,FILTER_VALIDATE_INT);if($label===''&&!$pid){$rawPrice=is_string($r['price']??null)?trim($r['price']):'';if($rawPrice!=='')throw new DomainException($rowNumber.'. satırda ürün / hizmet adını yazın. Örnek: Rulman. Kayıtlı ürün seçmeniz gerekmez.');continue;}
        $p=$pid?tenant_row('products',(int)$pid):null;if(!$label)$label=$p['name'];if(mb_strlen($label)>160)throw new DomainException('Satır açıklaması uzun.');
        $qty=scaled(is_string($r['quantity']??null)?$r['quantity']:'',3,1000000000);if($qty<=0)throw new DomainException('Miktar sıfırdan büyük olmalı.');
        if(currency_code()!=='TRY'&&(!is_string($r['price']??null)||trim($r['price'])===''))throw new DomainException('Dövizli belgede her satırın fiyatını seçili para biriminde girin.');$price=($r['price']??'')===''&&$p?(int)$p['price']:scaled(is_string($r['price']??null)?$r['price']:'',2,999999999);
        $vat=($r['vat']??'')===''&&$p?(int)$p['vat']:filter_var($r['vat']??'',FILTER_VALIDATE_INT);if($vat===false||$vat<0||$vat>10000)throw new DomainException('KDV oranı hatalı.');
        $n=intdiv($qty*$price+500,1000);if($n>99999999999)throw new DomainException('Satır tutarı sınırı aşıldı.');$rawDiscount=$r['discount']??'0';if(!is_string($rawDiscount))throw new DomainException('İndirim oranını sayı olarak yazın.');$rate=scaled(trim($rawDiscount)===''?'0':$rawDiscount,2,10000);if($rate>10000)throw new DomainException('İndirim oranı %100 sınırını aşamaz.');$discount=intdiv($n*$rate+5000,10000);$discountTotal+=$discount;$n-=$discount;$t=intdiv($n*$vat+5000,10000);
        $c=intdiv($qty*(int)($p['cost']??0)+500,1000);$lines[]=[$pid?:null,$label,$qty,$price,(int)($p['cost']??0),$vat,$n,$t,$n+$t,$rate,$discount];$net+=$n;$tax+=$t;$cost+=$c;
    }
    if(!$lines)throw new DomainException('En az bir satır ekleyin: ürün / hizmet adını ve birim fiyatını yazın. Örnek: Rulman, 1 adet, 7.500 TL.');
    if($net+$tax<=0)throw new DomainException('Belge toplamı sıfır. Satırlardaki miktar ve birim fiyatı kontrol edin.');
    if($net+$tax>99999999999)throw new DomainException('Belge toplamı 999.999.999,99 TL sınırını aşıyor.');
    $args=[$contact?:null,$issue,$due,field('description',500),$net,$tax,$net+$tax,$cost];
    if($id){query('UPDATE documents SET contact_id=?,issue_date=?,due_date=?,description=?,subtotal=?,tax=?,total=?,cost_total=? WHERE company_id=? AND id=?',[...$args,company_id(),$id]);query('DELETE FROM document_lines WHERE company_id=? AND document_id=?',[company_id(),$id]);}
    else{$prefix=['quote'=>'TEK','proforma'=>'PRO','order'=>'SIP','sale'=>'SAT','purchase'=>'ALS','expense'=>'GDR'][$kind];$num=$prefix.'-'.substr($issue,0,4).'-'.strtoupper(bin2hex(random_bytes(4)));query('INSERT INTO documents(company_id,number,request_key,kind,contact_id,issue_date,due_date,description,subtotal,tax,total,cost_total,created_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP())',[company_id(),$num,$key,$kind,...$args,current_user()['id']]);$id=(int)db()->lastInsertId();}
    query('UPDATE documents SET electronic_type=? WHERE company_id=? AND id=?',[$kind==='purchase'?(isset($_POST['electronic_type'])?choice('electronic_type',['e_archive','paper','unspecified']):'e_archive'):'unspecified',company_id(),$id]);query('UPDATE documents SET contact_snapshot=?,discount_total=?,bank_snapshot=? WHERE company_id=? AND id=?',[json_encode(recipient_input($contact),JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE),$discountTotal,bank_snapshot(),company_id(),$id]);
    foreach($lines as $l)query('INSERT INTO document_lines(company_id,document_id,product_id,label,quantity,price,cost,vat,net,tax,total,discount_rate,discount_amount) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',[company_id(),$id,...$l]);document_currency_save($id,$net,$tax,$discountTotal);audit('document.saved',['id'=>$id]);return $id;
}
function clone_document(array $d,string $kind,string $issue,?int $source=null,?int $recurring=null): int {if(!empty($d['return_of_id'])||$d['record_type']==='smm')throw new DomainException('İade ve makbuz kaydı tekrarlanamaz veya dönüştürülemez.');
    if($source){revision358_current($source);need_feature('orders');}need_feature(in_array($kind,['quote','proforma'],true)?'quotes':($kind==='order'?'orders':'bookkeeping'));require_document_capacity();require_issuer($kind);
    if($source&&in_array($d['kind'],['quote','proforma'],true)&&query("SELECT id FROM documents WHERE company_id=? AND source_id=? AND kind<>? AND status<>'cancelled'",[company_id(),$source,$kind])->fetchColumn())throw new DomainException('Bu teklif farklı bir belgeye dönüştürülmüş. Satışı mevcut sipariş üzerinden oluşturun.');
    if($source&&query("SELECT id FROM documents WHERE company_id=? AND source_id=? AND kind=?",[company_id(),$source,$kind])->fetchColumn())throw new DomainException('Bu dönüşüm daha önce yapıldı.');
    $days=max(0,(int)(new DateTimeImmutable($d['issue_date']))->diff(new DateTimeImmutable($d['due_date']))->days);$due=(new DateTimeImmutable($issue))->modify('+'.$days.' days')->format('Y-m-d');date_value($due);
    $num=($kind==='sale'?'SAT':'SIP').'-'.substr($issue,0,4).'-'.strtoupper(bin2hex(random_bytes(4)));
    query('INSERT INTO documents(company_id,number,request_key,kind,contact_id,issue_date,due_date,description,subtotal,tax,total,cost_total,created_by,source_id,recurring_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP())',[company_id(),$num,form_key(),$kind,$d['contact_id'],$issue,$due,$d['description'],$d['subtotal'],$d['tax'],$d['total'],$d['cost_total'],current_user()['id'],$source,$recurring]);$id=(int)db()->lastInsertId();
    query('UPDATE documents SET contact_snapshot=?,discount_total=?,bank_snapshot=? WHERE company_id=? AND id=?',[$d['contact_snapshot']??json_encode(document_recipient($d),JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE),(int)$d['discount_total'],$d['bank_snapshot']??bank_snapshot(),company_id(),$id]);if(!empty($d['project_id'])&&project_row((int)$d['project_id'])['status']==='open')query('UPDATE documents SET project_id=? WHERE company_id=? AND id=?',[$d['project_id'],company_id(),$id]);
    query('INSERT INTO document_lines(company_id,document_id,product_id,label,quantity,price,cost,vat,net,tax,total,discount_rate,discount_amount,vat_total_only) SELECT company_id,?,product_id,label,quantity,price,cost,vat,net,tax,total,discount_rate,discount_amount,vat_total_only FROM document_lines WHERE company_id=? AND document_id=?',[$id,company_id(),$d['id']]);clone_currency($d,$id);audit('document.derived',['id'=>$id,'source'=>$d['id']]);return $id;
}
function save_payment(): void {$key=request_key();if(query('SELECT id FROM payments WHERE company_id=? AND request_key=?',[company_id(),$key])->fetchColumn())return;apply_payment(payment_input(),(int)current_user()['id']);}
function check_user_quota(): void {$s=query('SELECT p.user_limit FROM subscriptions s JOIN plans p ON p.id=s.plan_id WHERE s.company_id=? FOR UPDATE',[company_id()])->fetch();if((int)query('SELECT COUNT(*) FROM users WHERE company_id=? AND is_active=1 AND role<>\'accountant\'',[company_id()])->fetchColumn()>=(int)$s['user_limit'])throw new DomainException('Paketinizin aktif kullanıcı sınırına ulaştınız.');}
function save_user(): void {
    require_manager();company_transaction(function(){check_user_quota();$role=choice('role',['staff','approver']);if($role==='approver')need_feature('roles');query('INSERT INTO users(company_id,name,email,password_hash,role,created_at) VALUES (?,?,?,?,?,UTC_TIMESTAMP())',[company_id(),required_field('name',100),email_field(),password_hash(password_field(),PASSWORD_DEFAULT),$role]);audit('user.created');});
}
function owner_post(string $page,string $action): void {
    require_owner();
    if($page==='companies'&&$action==='create'){$cid=create_company(required_field('company',160),email_field(),password_field(),required_field('name',100),int_field('plan_id',1,1000));audit('company.created');flash('Firma ve yönetici hesabı oluşturuldu.');redirect('companies',['edit'=>$cid]);}
    if($page==='companies'&&$action==='reset_password'){
        reauthenticate(current_user());transaction(function(){
            $cid=int_field('company_id',1,PHP_INT_MAX);if(!query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$cid])->fetchColumn())throw new DomainException('Firma bulunamadı.');
            query("UPDATE users SET password_hash=?,session_version=session_version+1 WHERE company_id=? AND role='company_admin'",[password_hash(password_field(),PASSWORD_DEFAULT),$cid]);audit('company_admin.password_reset',['company'=>$cid]);
        });flash('Firma yöneticisinin şifresi yenilendi. Açık oturumları kapatıldı.');redirect('companies',['edit'=>(int)$_POST['company_id'],'view'=>'security']);
    }
    if($page==='companies'&&$action==='subscription'){
        transaction(function(){$cid=int_field('company_id',1,PHP_INT_MAX);$plan=int_field('plan_id',1,1000);$p=query('SELECT * FROM plans WHERE id=? FOR UPDATE',[$plan])->fetch();if(!$p)throw new DomainException('Paket bulunamadı.');if(!query('SELECT id FROM companies WHERE id=? FOR UPDATE',[$cid])->fetchColumn())throw new DomainException('Firma bulunamadı.');
            $s=query('SELECT * FROM subscriptions WHERE company_id=? FOR UPDATE',[$cid])->fetch();$u=query('SELECT COUNT(*) FROM users WHERE company_id=? AND is_active=1 AND role<>\'accountant\'',[$cid])->fetchColumn();if($u>$p['user_limit'])throw new DomainException('Aktif kullanıcı sayısı yeni paket sınırını aşıyor.');
            $status=choice('status',['trial','active','expired']);$until=date_field('until').' 20:59:59';
            $periodStart=$s['period_started_at'];if($status==='trial')$periodStart=null;elseif($status==='active'&&($s['status']!=='active'||(int)$s['plan_id']!==$plan||!$s['paid_until']||strtotime($s['paid_until'].' UTC')<=time()))$periodStart=gmdate('Y-m-d H:i:s');query('UPDATE subscriptions SET plan_id=?,status=?,trial_ends_at=?,paid_until=?,period_started_at=?,has_paid_membership=IF(?=\'active\',1,has_paid_membership) WHERE company_id=?',[$plan,$status,$status==='trial'?$until:$s['trial_ends_at'],$status==='active'?$until:null,$periodStart,$status,$cid]);if($status==='active')referral_apply_bank($cid);
            $reason=field('restriction_code',40);if($reason==='')$reason='custom';if(!isset(restriction_catalog()[$reason]))throw new DomainException('Geçerli bir erişim mesajı seçin.');query('UPDATE companies SET status=?,restriction_reason=?,restriction_code=? WHERE id=?',[choice('company_status',['active','suspended']),field('restriction_reason',300),$reason,$cid]);audit('subscription.changed',['company'=>$cid,'status'=>$status]);
        });flash('Üyelik güncellendi.');redirect('companies',['edit'=>(int)$_POST['company_id']]);
    }
    if($page==='plans'&&$action==='save'){
        admin351_guard();reauthenticate(base_user());transaction(function(){$id=int_field('id',1,1000);$p=query('SELECT * FROM plans WHERE id=? FOR UPDATE',[$id])->fetch();if(!$p)throw new DomainException('Paket bulunamadı.');$limit=int_field('user_limit',1,1000);$max=(int)query('SELECT COALESCE(MAX(x.n),0) FROM (SELECT COUNT(*) n FROM users u JOIN subscriptions s ON s.company_id=u.company_id WHERE s.plan_id=? AND u.is_active=1 AND u.role<>\'accountant\' GROUP BY u.company_id) x',[$id])->fetchColumn();if($limit<$max)throw new DomainException('Bu pakette mevcut kullanıcı sayısından düşük sınır verilemez.');
            plan3616_save($p['code']);query('UPDATE plans SET monthly_price=?,user_limit=?,is_active=?,credits_per_period=?,vat_rate=? WHERE id=?',[field('monthly_price',30)===''?null:decimal(amount('monthly_price')),$limit,int_field('is_active',0,1),int_field('credits_per_period',0,1000000),int_field('vat_rate',0,10000),$id]);audit('plan.changed',['id'=>$id]);});flash('Paket kaydedildi.');redirect('plans');
    }
    if($page==='platform'&&$action==='save'){reauthenticate(current_user());transaction(function(){foreach(['brand'=>required_field('brand',60),'trial_days'=>(string)int_field('trial_days',1,14),'registration_open'=>(string)int_field('registration_open',0,1),'support_email'=>email_contact_field(),'support_phone'=>field('support_phone',40),'bank_name'=>field('bank_name',100),'bank_recipient'=>field('bank_recipient',160),'bank_iban'=>field('bank_iban',40)] as $k=>$v)query('UPDATE settings SET value=? WHERE name=?',[$v,$k]);audit('platform.settings');});flash('Ayarlar kaydedildi.');redirect('platform');}
    if($page==='updates'&&in_array($action,['stable_cron_confirm','retention_continue'],true))retention3649_post($action);
    if($page==='updates'&&$action==='upload'){reauthenticate(current_user());$f=$_FILES['package']??null;if(!$f||$f['error']!==UPLOAD_ERR_OK||!is_uploaded_file($f['tmp_name']))throw new DomainException('Geçerli bir ZIP dosyası seçin.');(new Updater(db()))->install($f['tmp_name'],(int)current_user()['id']);flash('Yeni sürüm etkinleştirildi.');redirect('updates');}
    if($page==='updates'&&$action==='recover'){reauthenticate(current_user());(new Updater(db()))->recover((int)current_user()['id']);flash('Önceki sürüm ve veritabanı geri alındı.');redirect('updates');}
    throw new DomainException('İşlem tanınmadı.');
}
function export_csv(): void {
    need_feature('export');$cid=company_id();$rows=null;$f=null;
    db()->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY,false);
    try{
        $rows=query("SELECT d.number,d.kind,d.issue_date,d.due_date,c.name,d.status,d.subtotal,d.tax,d.total FROM documents d LEFT JOIN contacts c ON c.company_id=d.company_id AND c.id=d.contact_id WHERE d.company_id=? ORDER BY d.id DESC",[$cid]);
        header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename=kobi-belgeler.csv');$f=fopen('php://output','w');fwrite($f,"\xEF\xBB\xBF");fputcsv($f,['Belge','Tür','Tarih','Vade','Cari','Durum','Net TL','KDV TL','Toplam TL'],';','"','');
        while($r=$rows->fetch()){foreach(['subtotal','tax','total'] as $k)$r[$k]=decimal((int)$r[$k]);foreach($r as &$v)if(preg_match('/^[=+\-@\t\r]/u',(string)$v))$v="'".$v;unset($v);if(fputcsv($f,array_values($r),';','"','')===false)throw new RuntimeException('CSV yazılamadı.');}
    }finally{if($rows)$rows->closeCursor();db()->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY,true);if(is_resource($f))fclose($f);}
}
