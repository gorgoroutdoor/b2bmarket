# Kobivira 3.5.0

3.4.9 üzerine yönetim panelinden yüklenen tam sürüm güncellemesidir. Mevcut tasarım dosyaları ve marka görselleri değişmemiştir. Önceki 21 migration değiştirilmemiş; 022 ve 023 eklenmiştir.

## Yeni işlemler

- Müşteri / tedarikçi kartında tarih ve para birimi filtreli cari ekstre; gerçek XLSX ve ayrı sekmede PDF olarak kaydet / yazdır.
- Satışlar → İade kayıtları: kaynak faturaya bağlı kısmi / tam iade; finans ve KDV düzeltmeleri; gerekçeyle geri alma; ödenmiş fazlalık için para iadesi.
- Raporlar → Borç / alacak yaşlandırma ve Cari mutabakatlar. Mutabakat bağlantısı 14 gün geçerlidir, ilk alıcı yanıtı sabitlenir. Otomatik e-posta / SMS gönderilmez.
- Satışlar → Serbest meslek makbuzları: taslak, düzenle, kesinleştir ve tahsilat. Resmî e-SMM gönderimi değildir.
- Ayarlar → Veri taşıma merkezi: CSV / XLSX fatura kalemleri, cari ve ürün / hizmetler, açılışlar ve geçmiş ödemeler; ZIP içinden standart UBL XML ve orijinal PDF / XML ekleri.
- Sistem → Veri taşıma ve kampanya: toplam paket kotaları ve dosya başı sınır ayarı, kampanya aç / kapat, mevcut deneme firmasını bir kez kampanyaya alma.

## Paketler ve kotalar

| Özellik | KOBİ | KOBİ Plus | KOBİ Business | Business Plus |
|---|---|---|---|---|
| Cari ekstre / iade / yerel SMM kayıtları | — | Dahil | Dahil | Dahil |
| Yaşlandırma / cari mutabakat | — | — | Dahil | Dahil |
| Varsayılan toplam aktarım alanı | 1 GB | 3 GB | 10 GB | 20 GB |

Kotaları yönetici değiştirebilir. Veri türü ayrıca paketin mevcut muhasebe yetkisine bağlıdır; örneğin KOBİ üyeliği ön muhasebe faturası oluşturma hakkı kazanmaz. Yeni mali işlem ekranları firma yöneticisine özeldir. Standart 15 günlük deneme veri taşıyamaz. Kampanya hesapları üç takvim ayı taşıma ve gelişmiş panel kullanımı alır; kontör ve gerçek servisler açılmaz. Kampanya yönetimden kapatılabilir. Business Plus’ın önceki satış durumu değiştirilmez.

## Dosya sınırları ve doğruluk

ZIP dosyası başına varsayılan 1 GiB sınır vardır; 1 MiB parçalarla gönderilir. Açılmış ZIP en fazla 1 GiB / 5000 kayıt, tek ek en fazla 8 MiB. CSV / XLSX dosyası en fazla 5 MiB / 2000 satır. Kotalar ham yükleme ve arşivlenen ekleri kapsar; veritabanının toplam boyutu değildir. Yeterli hosting disk alanı ve PHP DOM gereklidir. Yarım kalan işler aktarım geçmişinden devam ettirilebilir veya dosyaları kaldırılarak alan boşaltılır. Arşiv kaldırma muhasebe kayıtlarını silmez; bağlı XML / PDF eklerini kaldırır.

Kaynaktaki program adının listede bulunması o programın tüm dışa aktarım biçimleri için hazır özel dönüştürücü olduğu anlamına gelmez. Tablo sütunları eşleştirilir; UBL 2 Invoice standardının desteklenen SATIS / ISTISNA belgeleri işlenir. Özel tevkifat, ek vergi ve resmî iade XML türleri sessizce dönüştürülmez. Sağlayıcıya özel dosyalar örnekleriyle ayrıca doğrulanmalıdır.

PDF dosyası arşivdir; otomatik PDF okuma yapılmaz. Ödeme durumu bilinmeyen faturalar taslaktır. Paid için mevcut hesap ve ödeme tarihi gerekir. Aynı eski faturaların üzerine tekrar açılış bakiyesi eklemeyin. Dosya toplamları / yeni kayıt toplamları kontrol ekranında para birimi bazında ayrılır. Taslaklar kesinleşene kadar raporlara dahil değildir.

Stopaj / tevkifat / ek vergi içeren kaynak faturaların iadesi bu akışta desteklenmez. İade tutarı onay kuralı eşiğindeyse işlem engellenir; kural atlanmaz. Mutabakat bağlantısına sahip kişi seçili ekstreyı görür; bağlantıyı yalnız alıcınızla paylaşın.

## Kurulum sonrası

1. Sistem → Sürüm güncellemeleri bölümünden tek ZIP’i yükleyin. cPanel’den kurulum yapılmaz.
2. Sistem → Veri taşıma ve kampanya bölümünde kotaları / kampanyayı kontrol edin.
3. Firma panelinde yeni menüleri ve Üyelik paketim içindeki kullanılan alanı kontrol edin.
4. Hosting yedeğinde veritabanıyla birlikte özel `storage/migration` klasörünü saklayın. Güncelleyicinin veritabanı yedeği tek başına fiziksel belge eklerinin kopyası değildir.

Sürüm testi yerel PHP / MariaDB ve gerçek HTTP istekleriyle yapılmıştır. Canlı hosting, gerçek sağlayıcı dosyaları, tam 1 GiB yük altında hız ve görsel mobil tarayıcı testi ayrıca doğrulanmalıdır. Testte yapılmayan bu kontroller yapılmış olarak sunulmaz.
