# Kobivira 3.6.14 — İhracat e-Faturası test alanı

3.6.13 üzerine imzalı güncellemedir. Ayrı 038 migrasyonu yalnız edm_export_test_documents tablosunu ekler; eski 37 migrasyon ve CSS korunur. Hesaplar, abonelikler, yerel kontörler ve önceki belgeler korunur.

## Kullanım

Yönetim → EDM test alanı → e-İhracat test alanını aç → mevcut test firmasını seç → e-İhracat bağlantısını kontrol et. Bu adım e-Fatura servisiyle hesabın VKN bağını ve test servisinde gümrüğün ihracat posta kutusunu doğrular.

Örnek e-İhracat hazırla yalnız yerel XML üretir. KEX serisi, taze UUID/tarih, 1.000 TRY, iki adet sentetik cam ürün, Almanya adresli sentetik alıcı ve örnek sevkiyat içerir. Bu veriler gerçek ihracat işlemlerinde kullanılmamalıdır. Onay kutusu işaretlenerek Test ihracat faturasını EDM’ye gönder düğmesine bir kez basılır. Gönderim denemesi başlamış belge tekrar gönderilmez; durum sorgulanır. PDF/XML yalnız EDM servisinden indirilir.

## Senaryo

IHRACAT / ISTISNA, TRY, 301 mal ihracı örneği. XML örneği EDM'nin e-Fatura teknik dokümanındaki XML ÖRNEKLERİ.rar / istisna_ihracat.xml temel alınarak hazırlanmıştır. Alıcı kurum VKN 1460415308, ihracat PK urn:mail:ihracatpk@gtb.gov.tr. Yolcu beraber etiketi kabul edilmez. BuyerCustomerParty gerçek yurt dışı alıcı alanıdır. Satırda 12 haneli GTİP, miktar, teslim şekli, taşıma kodu ve paket miktarı kontrol edilir. Dövizli, farklı istisnalı, yolcu beraber veya özel ihracat senaryoları bu sürümde test edilmiş sayılmaz.

EDM testi: https://test.edmbilisim.com.tr/EFaturaEDM21ea/EFaturaEDM.svc . Her istekte APPLICATION_NAME=Kobivira. Canlı endpoint seçimi yoktur.

PACKAGE - PROCESSING / SEND - PROCESSING nihai başarı değildir. SEND - SUCCEED veya zarfın tamamlanması da tek başına gümrük onayı, referans/tescil numarası veya fiili ihracatın gerçekleştiği anlamına gelmez. Servis döndürüyorsa EXPORT_GTB_REF/REFNO, EXPORT_GTB_GCB_TESCILNO ve EXPORT_GTB_FIILI_IHRACAT_TARIHI ayrıca gösterilir. Sahte referans veya tescil üretilmez. Gümrük kabul/ret testi EDM'nin test akışına göre ayrıca doğrulanmalıdır.

## Sınırlar ve güvenilirlik

Normal firma satış ekranının resmî ihracat gönderimine dönüştürülmesi bu sürümün kapsamı değildir; bu modül ayrı test alanıdır. Firma kullanıcısı için ücretli paket ve advanced_edocs yetkisi, yönetici için firma seçimi gerekir. Destek ve takip oturumları engellenir. UBL şifreli ve özetli saklanır. Belge kimliği ve firma bağı indirmede kontrol edilir. Gönderim başlamadan kalıcı deneme işareti konur, belge kilidi tutulur ve belirsiz sonuca otomatik yeniden gönderim yapılmaz. Yeni tablo tam veritabanı yedeğine dahildir; firma silmede temizlenir. Mevcut cron görevi değişmez.

## Kaynaklar

- EDM sağlanan teknik arşivi, e-Fatura Web API v4.2.1 ve istisna_ihracat.xml.
- GİB gümrük işlemleri kılavuzu: https://ebelge.gib.gov.tr/dosyalar/kilavuzlar/e-Fatura_Uygulamasi_gumruk_islemleri_Kilavuzu.pdf
- Ticaret Bakanlığı ihracat e-Fatura kullanım kılavuzu: https://efatura.gtb.gov.tr/files/Kilavuz.pdf

Güncel EDM WSDL tamamında kapsam dışı GiderPusulasi tipinin kalıtımında şema hatası vardır. Bu sürümün beş istek tipinin bağımlılıkları değiştirilmeden ayrıştırılmış alt şema ile doğrulanır; tüm WSDL doğrulandı iddiası yoktur.

EDM'nin ihracat indirme yanıtında HEADER/RECEIVER, XML'deki gümrük VKN'si yerine BuyerCustomerParty/PartyLegalEntity/CompanyID değeridir. Bu davranış gerçek test servisiyle doğrulandı. İndirmede bu yabancı alıcı kimliği, gönderici, UUID, numara ve profil eşleşmesi aranır; XML içinde gümrük VKN'si ayrıca 1460415308 kalmalıdır.

Gerçek teknik test: KXD2026000000001, UUID 9d1e7bc6-1315-450d-9f50-d42ba8b751df. Test gönderimi alındı, EDM PDF ve XML doğrulandı. Son kontrol SEND - PROCESSING: nihai gönderim veya gümrük kabulü doğrulanmış sayılmaz. Panel örnekleri ayrı KEX serisiyle hazırlanır.
