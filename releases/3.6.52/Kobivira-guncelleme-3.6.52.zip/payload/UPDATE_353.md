# Kobivira 3.5.3 · 3.5.2 üzerine güncelleme

ZIP açılmadan Admin → Sürüm güncellemeleri alanından yüklenir. Tam kurulum değildir. Mevcut temel tasarım, logo ve renkler korunur. Eski 26 migration dosyası değiştirilmez; yalnız 027_popup_frequency eklenir.

## Özellikler menüsü ve hizalama

Özellikler başlığıyla aşağıdaki kategori alanı arasındaki fare geçişi için bir bağlantı bölgesi ve iptal edilebilen kapanma gecikmesi eklenmiştir. Menüye geçildiğinde kapanma beklemesi iptal edilir. Üst menü başlıkları dikey olarak hizalanmıştır; mobilde mevcut dokunarak açma ve dikey menü düzeni korunur.

## Firma / yönetici paneli menüsü

Üstteki menü düğmesi masaüstünde paneli daraltır / genişletir. Dar menüde kategori ikonları görünür kalır. Kategoriye tıklanınca sağdaki alanda kendi bağlantıları açılır; bağlantılar mevcut sayfalara gider. Dışarı tıklama veya Escape bu alanı kapatır. Menü tercihi kullanıcı bazında tarayıcıda saklanır. Mobilde ikon şeridi yerine mevcut açılır tam menü kullanılır. Aynı anda tek kategori açılması, genel bakışa dönünce kategorilerin kapanması korunur.

## Popup ayarları

Site yönetimi → Tanıtım penceresi ve başvurular:

- Doğrudan yeni PNG / JPG / WebP görsel yükleme alanı. En fazla 4 MB; yüklenen görsel seçilir. Diğer popup ayarlarında henüz kaydedilmemiş metinler, JavaScript etkin olduğunda görsel yüklemesiyle sıfırlanmaz.
- Görsel listesinden Görselsiz kullan seçilerek görsel kaldırılabilir.
- Kişi başına günlük gösterim sınırı: 1–100; örneğin 5 veya 10.
- Tekrar gösterme aralığı: 1–1440 dakika. Varsayılan 60 dakikadır.
- Sayaç: aynı tarayıcı veya aynı IP. Varsayılan tarayıcıdır. IP seçeneğinde aynı ağdaki kişiler ortak kotaya tabidir.
- Gün Türkiye saatine göre yenilenir. Varsayılan yeni sınır 5/gündür. Önceki metin, görsel ve etkin/pasif ayarları korunur.

Sayaç sunucuda tutulur; sayfa yenilemek sınırı sıfırlamaz. Tarayıcı modunda rastgele bir ziyaretçi çerezi kullanılır. IP modunda IP'nin kendisi kaydedilmez; anahtarlı özet kullanılır. Gösterim kayıtları sekiz günden eski olduğunda temizlenir. Kapatılan pencere, ayarlanan aralık dolduktan sonra yeniden kaydırmada açılabilir. Pencere açıksa veya ziyaretçi bir giriş alanına yazıyorsa ikinci pencere açılmaz.

## Popup formundaki HTML / JSON hatası

Form gönderimi açık /index.php?kv_action=lead adresine alınmıştır. Bu adres tanıtım sitesinin mevcut giriş dosyası üzerinden doğrudan JSON döndürür. Gösterim sayacı aynı giriş dosyasında ayrı bir adres kullanır. İstemci yanıt türünü kontrol eder; yönlendirmeleri sessizce başarılı kabul etmez. HTML veya bağlantı hatasında ham JSON ayrıştırma hatası yerine anlaşılır mesaj gösterilir. Girilen bilgiler yerinde kalır; yalnız doğrulanmış kayıt yanıtında başarı gösterilir. Aynı başvurunun tekrar gönderimi mevcut tek işlem korumasıyla ikinci kayıt oluşturmaz.

Gelen bilgiler aynı yönetim ekranındaki Geri arama başvuruları listesinde görülür. E-posta / SMS gönderimi eklenmemiştir.

## Form bilgilerinin korunması

JavaScript etkin olduğunda paneldeki normal kayıt / düzenleme formları sunucuya gönderilir; doğrulama hatası halinde bütün sayfa değiştirilmez. Seçimler, kutular, açıklamalar ve belge satırları mevcut formda kalır. Hatalı alan sunucu tarafından belirlenebildiğinde işaretlenir ve odaklanır; diğer hatalar aynı formun başında gösterilir. Kapalı detay içindeki zorunlu alanlar açılır. Düzeltilen bilgiler yeniden gönderilebilir. Başarıda mevcut normal yönlendirme yapılır.

Bu davranış, yönetim ayarlarını, paket / firma düzenlemelerini, teklif / proforma / muhasebe belge girişlerini ve güncelleme yükleme formunu kapsar. Mevcut özel dosya aktarımı / hızlı cari gibi kendi istemci akışına sahip formların işleyişine müdahale edilmez. Kurulum ve giriş / kayıt ekranlarının normal doğrulama akışı korunur. JavaScript kapalıysa mevcut sunucu gösterimi kullanılır; köşeli parantezli alan adlarının geri doldurulması da iyileştirilmiştir.

Form metinleri veya şifreler yeni bir tarayıcı taslak deposuna kaydedilmez; hata anında mevcut sayfa korunur. Başarısız veya belirsiz ağ isteği otomatik tekrar edilmez.

## Doğrulama kapsamı

Yerel PHP 8.3 / MariaDB ortamında:

- Mevcut paket / yetki / uygulama HTTP kontrolleri ve veritabanı kontrolleri tekrar çalıştırıldı.
- Yeni gerçek HTTP testlerinde günlük limit, aralık, tarayıcı / IP ayrımı, açık PHP adresinden gerçek başvuru kaydı, tekrarlı gönderim, JSON hata yanıtı, eksik / hatalı şifre, zorunlu alan, görsel yükleme ve görselsiz kullanım sınandı.
- Teklif ve proforma için önce hatalı satır gönderildi, sonra aynı bilgiler düzeltilip iki satırla gerçek kayıt oluşturuldu.
- İstemci model testlerinde formun korunması, alan odağı, hata / HTML yanıtı, görsel seçiminde diğer alanların korunması, popup tekrar açılışı, dar menü ve mobil geçiş kontrol edildi.
- Mevcut 108 muhasebe / veri taşıma regresyon kontrolü geçti.

Gerçek hosting üzerinde uygulama veya gerçek tarayıcıda görsel masaüstü / mobil kontrol yapılmamıştır. DOM / CSS model kontrolleri görsel tarayıcı testi olarak sunulmamaktadır. Canlı sitede görülen HTML yanıtının hosting kaynaklı kesin sebebi yerelden doğrulanmamıştır; açık gönderim adresi, yanıt türü doğrulaması ve hata koruması yerelde sınanmıştır.

Son doğrulama: 396 yerel kontrol (174 mevcut HTTP, 21 veri / yetki, 37 yeni HTTP, 19 form / kaynak / CSS modeli, 13 menü modeli, 9 popup modeli, 108 muhasebe / aktarım ve 15 güncelleyici kontrolü). Ayrıca 114 PHP uzantılı dosya sözdizimi kontrolünden geçmiştir. 3.5.2'nin mevcut güncelleyicisi imzalı paketi kabul etmiş, değiştirilmiş paketi reddetmiş; kurulu firma, deneme tarihi, popup ayarları ve mevcut geri arama başvurusu korunmuştur. Gerçek tarayıcı görsel testi bu sayılara dahil değildir.
