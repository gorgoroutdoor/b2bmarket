(() => {
  document.querySelectorAll('[data-height]').forEach(el=>el.style.height=el.dataset.height+'%');
  document.querySelectorAll('[data-print]').forEach(el=>el.addEventListener('click',()=>window.print()));
  const body=document.getElementById('document-lines'), add=document.getElementById('add-line'), template=document.getElementById('line-template');
  if(body && add && template) {
    let index=body.children.length;
    const fmt=n=>new Intl.NumberFormat('tr-TR',{style:'currency',currency:document.querySelector('form [name=currency]')?.value||'TRY'}).format(n);
    const num=(s,scale=2)=>{let v=String(s).replace(/[\s\u00a0]+/g,'').replace(/(?:TL|TRY|₺)$/i,'');if(v.includes(','))v=v.replaceAll('.','').replace(',','.');else if(scale===2&&/^\d{1,3}(?:\.\d{3})+$/.test(v))v=v.replaceAll('.','');return Number(v)||0;};
    const recalc=()=>{let total=0,netSum=0,taxSum=0;for(const row of body.querySelectorAll('.document-line')){const qty=num(row.querySelector('[data-line-qty]').value,3),price=num(row.querySelector('[data-line-price]').value),vat=num(row.querySelector('[data-line-vat]').value);const gross=Math.round(qty*price*100),discount=Math.min(100,Math.max(0,num(row.querySelector('[data-line-discount]')?.value||'0'))),net=(gross-Math.round(gross*discount/100))/100;const n=net+Math.round(net*vat/10000*100)/100;total+=n;netSum+=net;taxSum+=Math.round(net*vat/10000*100)/100;row.querySelector('.line-preview').textContent=fmt(n);row.querySelector('[data-line-price]').closest('td').dataset.label='Birim fiyat · '+(document.querySelector('form [name=currency]')?.value||'TRY');}const form=body.closest('form');const stop=Math.min(100,Math.max(0,num(form?.querySelector('[name=withholding_rate]')?.value||'0'))),withheld=Math.round(netSum*stop)/100,vatWithheld=Math.round(taxSum*num(form?.querySelector('[name=vat_withholding]')?.value||'0'))/100,extra=num(form?.querySelector('[name=extra_tax]')?.value||'0');document.getElementById('document-preview').textContent=fmt(total+extra-withheld-vatWithheld);};
    add.addEventListener('click',()=>{if(body.children.length>=30)return;const wrapper=document.createElement('tbody');wrapper.innerHTML=template.innerHTML.replaceAll('__INDEX__',String(index++));body.append(...wrapper.children);recalc()});
    body.addEventListener('click',e=>{const b=e.target.closest('[data-remove-line]');if(b){b.closest('tr').remove();recalc()}});
    body.addEventListener('change',e=>{if(e.target.matches('[data-product-select]')){const opt=e.target.selectedOptions[0],row=e.target.closest('tr');if(opt.dataset.price!==undefined){row.querySelector('[data-line-price]').value=(document.querySelector('form [name=currency]')?.value||'TRY')==='TRY'?opt.dataset.price:'';row.querySelector('[data-line-label]').value=opt.dataset.name;row.querySelector('[data-line-vat]').value=opt.dataset.vat;}}recalc()});body.addEventListener('input',recalc);for(const key of ['currency','withholding_rate','vat_withholding','extra_tax'])document.querySelector('form [name='+key+']')?.addEventListener('input',recalc);document.querySelector('form [name=currency]')?.addEventListener('change',recalc);recalc();
  }
  document.querySelectorAll('form[method=post]').forEach(form=>form.addEventListener('submit',()=>{if(form.querySelector('input[name="action"]')?.value==='delete_company')return;const b=form.querySelector('button[type=submit]');if(b){b.disabled=true;setTimeout(()=>b.disabled=false,8000)}}));
})();
(() => {
  document.querySelectorAll('[data-refresh]').forEach(b=>b.addEventListener('click',()=>location.reload()));
  document.querySelectorAll('form[data-read-only]').forEach(form=>form.querySelectorAll('input:not([type=hidden]),select,textarea,button').forEach(el=>el.disabled=true));
  // Keep the authenticated, per-tab support ticket on GET filter forms.
  const support=new URLSearchParams(location.search).get('support');
  if(support)document.querySelectorAll('form[method=get]').forEach(f=>{if(!f.querySelector('[name=support]')){const i=document.createElement('input');i.type='hidden';i.name='support';i.value=support;f.append(i)}});
  const quick=document.getElementById('quick-contact-dialog'),openQuick=document.getElementById('quick-contact-open');
  openQuick?.addEventListener('click',()=>quick.showModal());document.querySelector('[data-close-quick-contact]')?.addEventListener('click',()=>quick.close());
  quick?.querySelector('form')?.addEventListener('submit',async e=>{
    e.preventDefault();const form=e.currentTarget,error=document.getElementById('quick-contact-error');error.textContent='';
    try{const r=await fetch(form.getAttribute('action'),{method:'POST',body:new FormData(form),credentials:'same-origin',headers:{Accept:'application/json'}});if(!r.headers.get('Content-Type')?.includes('application/json'))throw new Error('Oturum süresi dolmuş olabilir. Sayfayı yenileyip tekrar deneyin.');const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||'Kayıt yapılamadı. Bilgileri kontrol edin.');const select=document.querySelector('form [name=contact_id]');select.add(new Option(d.name,String(d.id),true,true));select.dispatchEvent(new Event('change',{bubbles:true}));quick.close();form.reset();}
    catch(err){error.textContent=err.message||'İşlem yapılamadı. Lütfen tekrar deneyin.';}
    finally{const b=form.querySelector('button[type=submit]');if(b)b.disabled=false;}
  });
  const body=document.body;if(body.dataset.pollEnabled!=='1')return;
  const dialog=document.getElementById('support-dialog'),ownerStatus=document.getElementById('support-owner-status'),banner=document.getElementById('support-active-alert');let current=null,signature='',stopped=false,timer;
  const open=()=>{if(dialog&&current&&!dialog.open)dialog.showModal()};
  document.querySelectorAll('[data-open-support]').forEach(b=>b.addEventListener('click',open));document.querySelectorAll('[data-close-support]').forEach(b=>b.addEventListener('click',()=>dialog.close()));
  dialog?.addEventListener('change',e=>{if(e.target.matches('[name="allow_write[]"]')&&e.target.checked)e.target.closest('.permission-row').querySelector('[name="allow_read[]"]').checked=true;if(e.target.matches('[name="allow_read[]"]')&&!e.target.checked)e.target.closest('.permission-row').querySelector('[name="allow_write[]"]').checked=false;});
  const labels={requested:'Firma yöneticisinden kod bekleniyor',awaiting:'Firma onayı bekleniyor',active:'Bağlantı onaylandı',denied:'Firma bağlantıyı reddetti; yönetici bağlanamadı',revoked:'Bağlantı sonlandırıldı',cancelled:'Talep iptal edildi',expired:'Bağlantının süresi doldu'};
  const poll=async()=>{
    if(stopped)return;
    const data=new FormData();data.set('action','poll');data.set('csrf',body.dataset.csrf);data.set('current_page',body.dataset.page);if(ownerStatus)data.set('request_id',ownerStatus.dataset.requestId);
    const params=new URLSearchParams(location.search);for(const key of ['id','kind','view','from','to'])if(params.has(key))data.set('location_'+key,params.get(key));
    document.dispatchEvent(new CustomEvent('kobivira:poll-send',{detail:data}));
    try{
      const response=await fetch(body.dataset.supportPoll,{method:'POST',body:data,credentials:'same-origin',headers:{Accept:'application/json'}});if(!response.ok)throw new Error('Oturum denetlenemedi');const d=await response.json();document.dispatchEvent(new CustomEvent('kobivira:poll-data',{detail:d}));
      if(body.dataset.isSupport==='1'){if(!d.active){stopped=true;location.href='?page=support&id='+encodeURIComponent(body.dataset.supportRequest);return;}}
      else if(ownerStatus){const state=d.request?.status;if(state&&state!==ownerStatus.dataset.status){ownerStatus.dataset.status=state;ownerStatus.textContent=labels[state]||state;location.reload();return;}}
      else if(dialog){current=d.request||null;if(!current){if(banner)banner.hidden=true;if(dialog.open)dialog.close();signature='';return;}
        const sig=current.id+':'+current.status;dialog.querySelectorAll('[name=id]').forEach(i=>i.value=current.id);
        document.getElementById('support-actor').textContent='Kobivira sistem yöneticisi: '+current.actor_name;
        document.getElementById('support-connection-code').textContent=current.code||'';
        document.getElementById('support-requested').hidden=current.status!=='requested';document.getElementById('support-awaiting').hidden=current.status!=='awaiting';document.getElementById('support-connected').hidden=current.status!=='active';document.getElementById('support-deny').hidden=current.status==='active';
        if(current.status==='active'){const permissions=JSON.parse(current.permissions||'{}');const names={sales:'Satışlar',purchases:'Alışlar',expenses:'Giderler',contacts:'Müşteri ve Tedarikçiler',products:'Ürün ve Hizmetler',finance:'Para',reports:'Raporlar',settings:'Firma bilgileri',tasks:'İş takibi'};document.getElementById('support-granted').textContent='Verdiğiniz izinler: '+Object.entries(permissions).map(([k,v])=>(names[k]||k)+' ('+(v==='write'?'görüntüleme ve işlem':'yalnızca görüntüleme')+')').join(', ');}
        if(banner){banner.hidden=false;document.getElementById('support-live-text').textContent=current.status==='active'?'Kobivira yöneticisi izin verdiğiniz bölümlere bağlı.':'Kobivira canlı destek onayınız bekleniyor.';}
        if(sig!==signature){signature=sig;open();}
      }
    }catch{if(body.dataset.isSupport==='1'){stopped=true;document.getElementById('main').inert=true;location.href='?page=support&id='+encodeURIComponent(body.dataset.supportRequest);}}
    finally{if(!stopped)timer=setTimeout(poll,document.hidden?12000:3000);}
  };
  setTimeout(poll,0);window.addEventListener('pagehide',()=>{stopped=true;clearTimeout(timer)});
})();

document.addEventListener('click',e=>{const b=e.target.closest('[data-features-select]');if(!b)return;const form=b.closest('form');form?.querySelectorAll('input[name="features[]"]').forEach(c=>c.checked=b.dataset.featuresSelect==='all');});
