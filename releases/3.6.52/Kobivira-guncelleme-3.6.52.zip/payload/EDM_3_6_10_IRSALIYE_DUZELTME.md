# 3.6.10 — örnek e-İrsaliye XML düzeltmesi

KVI2026000000001, UUID aa586e08-a9b7-4d1c-b6c1-228db0020753 gönderiminde kullanıcı 2005 hatası aldı. Yapılan UUID sorgusunda GetDespatch OUT belge dönmedi, GetDespatchStatus 11017 (belge bulunamadı) döndü. Buna rağmen eski gönderim işareti sıfırlanmadı ve aynı UUID tekrar gönderilmedi.

Ayrı bir teşhis taslağında (LoadDespatch, GİB'e gönderim yapılmadan) hata yeniden üretildi: 2005, Sistem hatasi, StartIndex cannot be less than zero. Örneğin ns0/ns2 biçimindeki ad alanı önekleri yerine EDM örneğindeki varsayılan DespatchAdvice ve cbc/cac önekleri korunduğunda 2005 ortadan kalktı. Sonraki 11047/Schematron yanıtı Shipment/Delivery/DeliveryAddress il, ilçe, ülke ve posta kodu eksiklerini açıkladı. Bu teslim adresi eklendiğinde KVD2026000000003 teşhis taslağı RETURN_CODE=0, LOAD - SUCCEED aldı. Bu teşhis taslağı sonrasında CancelDespatch ile iptal edildi, RETURN_CODE=0 doğrulandı. Bu işlem yeni irsaliye gönderiminin geçtiği anlamına gelmez.

Örnek üreticisi düzeltildi. Teslim adresi eksikleri gönderimden önce yerel XML doğrulamasında yakalanır. e-İrsaliye servis hata mesajı koduyla birlikte sınırlı uzunlukta gösterilir; kullanıcı, şifre, oturum ve UUID bilgileri hata metninden gizlenir. Belge işleme hataları kayıtta saklanır; belirsiz gönderim kilidi açılmaz.

## Devam

3.6.9 üzerine bu güncellemeyi kurun. Eski KVI2026000000001 kaydını silmeyin veya tekrar göndermeyin. EDM test alanı → e-İrsaliye → bağlantı/etiket kontrolü → Örnek e-İrsaliye hazırla düğmesine bir kez basın. Yeni örnek sonraki yerel KVI numarasını ve yeni UUID'yi alır. EDM varsayılan GB/PK etiketleriyle onay verip bir kez gönderin. İşlem sonucunu sorgulayın ve gelen kaydı/PDF/XML'i doğrulayın.

Mevcut 35 migration, firma kayıtları, kontörler, paketler, test belgeleri ve tasarım korunur. Bu sürüm yeni kabul/ret/kısmi kabul veya canlı gönderim özelliği eklemez.
