# 3.6.22 — İşlem geçmişi

3.6.21 üzerine yüklenir. Firma ve platform işlem geçmişi başlangıç/bitiş tarihiyle filtrelenir. Tarihler Türkiye saatine göre günün tamamını kapsar. Her sayfa en fazla 50 kayıt içerir. Önceki/Sonraki düğmeleri tarih aralığını ve firma adresini korur. Tarihleri boş bırakınca tüm kayıtlar sayfalı gösterilir. Son 500 kayıt sınırı kaldırılmıştır; hiçbir işlem kaydı silinmez.

Sistem menüsüne PayTR ödeme ayarları kısayolu eklendi. Bu kısayol mevcut güvenli ayar formunu açar; gerçek ödeme veya bildirim adaptörü eklemez.

İzole MariaDB üzerinde 15 kontrol başarılı: 50/50/kalan kayıt, firma ayrımı, yönetici kapsamı, Türkiye saatiyle tarih sınırları, boş aralık, geçersiz tarih, sayfa sınırı ve çalışan erişim engeli. PHP sözdizimi ve imzalı ZIP doğrulandı. Canlı sunucuya yüklenmedi.
