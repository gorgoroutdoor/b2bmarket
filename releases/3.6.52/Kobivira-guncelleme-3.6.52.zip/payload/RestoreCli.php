<?php
declare(strict_types=1);
// Emergency recovery when a partially restored database cannot serve the panel.
if(PHP_SAPI!=='cli'||($argv[1]??'')!=='--confirm')exit("Kullanım: php RestoreCli.php --confirm\n");
define('APP_ROOT',dirname(__DIR__,2));
$gate=fopen(APP_ROOT.'/storage/request.lock','c');if(!$gate||!flock($gate,LOCK_EX|LOCK_NB))exit("Sistem meşgul.\n");
try {
    $pointer=json_decode((string)file_get_contents(APP_ROOT.'/storage/current.json'),true,16,JSON_THROW_ON_ERROR);$version=$pointer['version']??'';
    if(!preg_match('/^\d+\.\d+\.\d+$/D',$version))throw new RuntimeException('Sürüm geçersiz.');
    define('APP_VERSION',$version);define('RELEASE_ROOT',APP_ROOT.'/releases/'.$version);
    require RELEASE_ROOT.'/Core.php';require RELEASE_ROOT.'/Backup.php';require RELEASE_ROOT.'/Updater.php';
    $path=APP_ROOT.'/storage/maintenance.json';if(!is_file($path))exit("Kurtarılacak güncelleme yok.\n");
    $state=json_decode((string)file_get_contents($path),true,32,JSON_THROW_ON_ERROR);
    if(($state['phase']??'')==='backup'&&!isset($state['backup'])){unlink($path);exit("Şema değişikliği başlamamış. Bakım kaldırıldı.\n");}
    (new Updater(db()))->recover((int)($state['actor']??1));echo "Önceki sürüm ve veritabanı geri alındı.\n";
}finally{flock($gate,LOCK_UN);fclose($gate);}
