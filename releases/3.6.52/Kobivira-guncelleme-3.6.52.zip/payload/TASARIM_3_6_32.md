# Kobivira 3.6.32 — Tanıtım sitesi

3.6.31 üzerine tam, imzalı güncelleme paketidir. Sunucuya otomatik yüklenmemiştir.

## Bu sürüm

- Ana sayfada insan fotoğrafı ve gerçek ürün ekranının birlikte kullanıldığı açık zeminli hero.
- Masaüstünde altı sekmeli; 800 px ve altında açılır başlıklı özellik gezgini. Klavye okları, Home ve End desteği vardır. JavaScript olmadan bütün açıklamalar okunabilir.
- Ön Muhasebe ürün sayfası: /on-muhasebe.html. Fayda kartları, dört adımlı kullanım akışı, paket kapsamı, rehber bağlantıları ve sık sorulanlar içerir. Menüye ve footer'a bağlantı eklenir.
- Diğer özelliklerin mevcut rehberleri korunur. Diğer ürün sayfaları bu sürümde yeniden tasarlanmamıştır.
- Footer: logo/iletişim, ürün, kaynaklar/destek, kurumsal ve yasal grupları. Mobilde gruplar açılıp kapanır. 0850 304 7681 dokunarak aranabilir; Site / SEO ayarlarından değiştirilebilir.
- Ödeme logoları ve küçük PayTR dipnotu korunur.
- Yorumlar yalnız yayımlanmış, müşteri doğrulaması ve yayın onayı bulunan mevcut kayıtları kullanır. Yeni müşteri yorumu veya sahte kişi eklenmez. Ana sayfada ilk dört onaylı kayıt gösterilir.
- Otomatik açılan geri arama penceresi yerine, mevcut geri arama formu etkinse “Beni arayın” düğmesi gösterilir. Etkin değilse telefon bağlantısı gösterilir. Footer görünürken sabit düğme gizlenir.
- Boş istatistik yer tutucuları gösterilmez. Yönetimde yayını etkin istatistikler geçerli değer geldiğinde açılır.
- Kontör paketleri ana sayfada kısa bağlantıyla sunulur; paketler sayfasındaki mevcut kontör bölümü korunur. Abonelik, referans, veri taşıma, blog ve rehber bağlantıları korunur.
- 14 günlük ücretsiz deneme ve kontör/ücretli servis istisnası yeni tanıtım alanlarında ve paket kartlarında yer alır. Ayrı veri taşıma kampanyasının üç aylık süresi değiştirilmez.

## Yönetim

Site yönetimi → Tanıtım sitesi → Ana sayfa blokları: Hero, Özellik gezgini, Başlangıç ve iletişim.

Site yönetimi → Tanıtım sitesi → Sayfalar → Ön Muhasebe Programı: metin alanları ve HTML içerik.

Site yönetimi → Tanıtım sitesi → Site / SEO ayarları: telefon, footer açıklaması ve sütun başlıkları.

Site yönetimi → Tanıtım sitesi → Menüler: mevcut footer bağlantıları, sıraları ve görünürlükleri.

Müşteri yorumları mevcut onaylı yorum yönetiminden gelir. Paket özetleri mevcut yönetici paket seçimlerinden üretilir; bu sürüm paket özelliklerini veya fiyatlarını değiştirmez.

## Korunanlar

Firma ve yönetim paneli tasarımı, hesaplar, üyelik süreleri, ödeme işleyişi, kontör kayıtları, e-Belge servisleri, hukuki metinler ve geçmiş onaylar değiştirilmez. Önceki 47 migration dosyası aynıdır.

048 migration yalnız site_id=1 içindeki belirlenen tanıtım bloklarını revize eder. Önceki blok içerikleri CMS geçmişine kaydedilir. Birleştirilen eski bloklar silinmez, görünmez yapılır. Özel eklenen bloklara ve diğer firmaların web sitelerine dokunulmaz. Aynı adreste önceden eklenmiş Ön Muhasebe sayfası varsa içerik üzerine yazılmaz.

## Görseller

Hero fotoğrafı yerleşik görsel üretimiyle oluşturulmuş temsili ticari görseldir; müşteri veya müşteri yorumu olarak kullanılmaz. Proje asset'i: kobivira-isletme3632.webp (1200×900, yaklaşık 80 KB). Ürün ekranları önceki paketten korunmuştur. Elektronik belge sekmesinde ekran görüntüsü yerine açıkça belirtilmiş belge akışı illüstrasyonu kullanılır.

Üretim özeti: Gün ışığı alan bir işletmede dizüstü bilgisayardan birlikte çalışan kadın işletme sahibi ve erkek meslektaşı; lacivert ve açık mavi giysiler, turkuaz ayrıntılar; doğal fotoğraf, yazısız ve logosuz, kağıt/defter kullanılmadan. Ayrı gerçek ürün görüntüsü kodla yerleştirilir.

## Doğrulama

- Mevcut 3.6.31 imzasıyla gerçek Updater üzerinden 3.6.32 kurulumu.
- 73 PHP/veritabanı kontrolü, 18 yerel HTTP kontrolü, 171 PHP sözdizimi kontrolü.
- Chrome ön izlemesinde 360, 390, 430, 768, 1024 px iframe viewport ve masaüstü: yatay taşma yok; masaüstü sekme, ok tuşu, mobil menü ve mobil footer açılması doğrulandı.
- Ön Muhasebe sayfası masaüstü ve 390 px görünümde incelendi; footer'da sabit yardım düğmesinin gizlendiği doğrulandı.
- Telefon/sanal kart/gerçek e-Belge işlemi yapılmadı. Gerçek iOS/Android cihaz testi yapılmadı.
