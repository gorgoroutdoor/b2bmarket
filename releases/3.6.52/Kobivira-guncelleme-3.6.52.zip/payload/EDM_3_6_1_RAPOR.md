# Kobivira 3.6.1 — EDM inceleme ve test alanı raporu

Tarih: 22 Ekim 2026. İncelenen uygulama kaynağı: 3.6.0; hazırlanan güncelleme: 3.6.1. Kullanıcı mesajında EDS adı geçse de gönderilen servis belgeleri EDM Bilişim’e aittir. Aşağıdaki entegrasyon EDM içindir.

## Sonuç ve satışa hazırlık kararı

**Tüm özellikler için üretim onayı verilemiyor.** Gerçek EDM hesabıyla giriş, firma yetkisi, kontör, gönderim/alım, GİB işlenme durumu ve ticari kabul/ret uçtan uca doğrulanmadı. Kullanıcıya tahsis edilmiş önceki test kullanıcı adı/şifresi erişilebilen bağlamda bulunamadı. Dokümanlardaki örnek hesaplar kullanılmadı. Henüz gerçek test faturası gönderilmedi veya alınmadı.

Bu paket yönetici üzerinden firma bazında gerçek EDM test servisine bağlanabilecek bir alan ekler. Üretim ortamına bağlanmaz. Canlı Kobivira sunucusuna kurulmadı; kurulu sürüm ve sunucu erişimi doğrulanmadı. Yalnız PayTR kalmış değildir: aşağıda belirtilen e-belge ve diğer dış servis geliştirmeleri de vardır.

## Belgelerin kapsamı

Arşivler, iç içe ZIP/RAR/7z dosyaları ve okunabilen metinler tarandı. Son envanter toplam **779 kayıt**: **49 arşiv okuması, 355 metin okuması, 375 yalnız ikili dosya envanteri**. Ayrıştırma hatası kaydı yok. İkili dosya envanteri DLL/EXE/JAR/görsel dosyalarının çalıştırıldığı veya görsel olarak incelendiği anlamına gelmez. PDF metin çıkarımı, taranmış sayfaların tüm görsel içeriğini doğrulamaz. Tam dosya yolları ve özetler Edm361Inventory.json içindedir. Şifre içerebilen ham doküman metni önbelleği pakete konulmadı.

Son CRM arşivi önceki CRM arşiviyle bayt düzeyinde aynıdır. SHA-256: b693f850321d974b03974c28ea17fdcf10b44d08bc54c8c7a4c930be5ac3793e. Ek bir CRM sürümü değildir.

| Gönderilen kök dosya | Okunan metin sayısı |
|---|---:|
| CRM Web Servis (1).zip | 2 |
| CRM Web Servis.zip | 2 |
| E-ADİSYON.zip | 14 |
| E-BİLET.zip | 9 |
| E-DEFTER VE E-DEFTER SAKLAMA.zip | 28 |
| E-DEKONT.zip | 7 |
| E-DÖVİZ.zip | 11 |
| E-FATURA VE E-ARŞİV FATURA.zip | 22 |
| E-GİDER PUSULASI.zip | 10 |
| E-MM.zip | 9 |
| E-MUTABAKAT REST API.zip | 1 |
| E-MUTABAKAT.zip | 67 |
| E-SMM.zip | 6 |
| E-SİGORTA (1).zip | 4 |
| E-SİGORTA.zip | 4 |
| E-İMZA KÜTÜPHANE.zip | 3 |
| E-İRSALİYE.zip | 17 |
| ENGLISH DOCUMENTS.zip | 20 |
| IDIS & İlaç Tıbbi XML Örnekleri.zip | 4 |
| INTERAKTIF E-ARSIV.zip | 4 |
| KEP.zip | 93 |
| PHP.zip | 1 |
| RESTAPI.zip | 1 |
| SSS.zip | 2 |
| WEB SERVİS ENDPOINT URL ADRESLERİ.docx | 0 |
| Web Servis Hata Kodları (1).txt | 0 |
| YTB XML Örnekleri.zip | 12 |

## Özellik ve servis karşılaştırması

| Alan | Kaynakta mevcut durum | Bu sürümde yapılan / kalan iş |
|---|---|---|
| KOBİ temel ön muhasebe | Cari, satış/alış/gider kayıtları, teklif/proforma, PDF, çalışan onayı | Yerel muhasebe regresyonları çalıştırıldı. e-Fatura yetkisi KOBİ’de açılmadı; mevcut paket kataloğu Plus’tan başlatıyor. |
| KOBİ Plus e-Fatura/e-Arşiv | Önceden bağlantı hazırlığı ve elektronik taslaklar | Yeni test paneli, CheckUser, test UBL yükleme, gönderim, gelen belge alma, durum sorgusu. Gerçek hesapla doğrulama ve üretim adaptörü eksik. |
| KOBİ Business ileri e-belge | e-SMM/e-İrsaliye/e-İhracat bağlantı hazırlığı | Bu servisler için çalışan uçtan uca adaptör eklenmedi. Ayrı protokol/veri modeli ve test gerekir. |
| Satış kaydından e-belge | Finansal satış kaydı var | Otomatik eksiksiz UBL üretimi, vergi/istisna/tevkifat kuralları ve satış kaydıyla e-belge durum zinciri eksik. Panel dışarıda hazırlanmış UBL XML ister. |
| Kontör | Yerel bakiye, hediye ve sipariş kayıtları | CheckCounter ile EDM test hesabı bakiyesi okunur. CRM yükleme/iptal/sipariş mutabakatı ve gerçek kullanım kesintisi bağlanmadı. Yerel hediye kontör EDM bakiyesi sayılmaz. |
| EDM CRM Web Servis | CRM iş fırsatları modülü farklı bir işlev | Müşteri açılışı, ürün/servis yetkisi, bayi sözleşmesi/onayı, kontör yükleme/iptal ve ERP mutabakatı entegrasyonu ayrı geliştirme gerektirir. |
| e-İrsaliye | Hazırlık özelliği | XML taşıma, şoför/araç/teslimat alanları, kısmi kabul/ret ve stok hareketi uzlaştırması gerekli. Fatura kabul mantığı burada yeniden kullanılamaz. |
| e-SMM / e-MM | Yerel SMM kayıt/tahsilat takibi mevcut | Resmî e-SMM ve e-MM gönderim adaptörü ayrı; CreditNote, stopaj ve kesinti türleri doğru eşlenmeli. Yerel makbuz resmî e-SMM değildir. |
| e-Defter / saklama | Tam yevmiye/berat entegrasyonu doğrulanmadı | Defter verisi, berat, imza/HSM, GİB gönderimi ve saklama ayrı süreçlerdir. Fatura listesi tam defter oluşturmaz. |
| e-Mutabakat | Yerel cari mutabakat ve güvenli yanıt bağlantısı | EDM SOAP/REST dış aktarımı eklenmedi. REST ve SOAP borç/alacak enumları ile dönem biçimi farklıdır. |
| KEP / e-İmza | Entegrasyon hazırlığı | KEP OAuth istemci bilgileri ve ayrı servis; e-imzada fiziksel kart/sertifika/Java bağımlılıkları doğrulanmalı. |
| İnteraktif e-Arşiv | Ayrı SMS/oturum akışı | Dokümanındaki ortam kısıtı nedeniyle canlı işleme dönüştürülmedi. Test adresi ve güncel yetki EDM’den teyit edilmeden denenmemeli. |
| e-Adisyon, e-Bilet, e-Dekont, e-Döviz, e-Gider Pusulası, e-Sigorta | Yeni üretim adaptörü yok | Her biri kendi sözleşme, belge şeması, imza ve durum yönetimini gerektirir. |
| IDIS / ilaç-tıbbi / YTB / ihracat | Özel XML örnekleri | Özel zorunlu alanlar ve iş kuralları doğrulanmadı; test gönderim panelinde özel senaryolar açılmadı. |
| RESTAPI / PHP | Gönderilen arşivler bağlantı/başvuru içeriği taşıyor | Tam çalışır PHP SDK sağlandığı varsayılmadı. DOM ve HTTPS akışı kullanan sınırlı SOAP adaptörü yazıldı. |
| OCR / yapay zekâ / otomatik banka / pazaryeri / reklam | Çeşitli servis hazırlığı ve yönetici aktivasyonu | EDM dosyaları bu bağımsız servisleri çalışır hâle getirmez; kendi sağlayıcı ayarları/testleri gerekir. |
| PayTR | Bu çalışmada eklenmedi | Ödeme API, doğrulanmış callback, idempotent tahsilat/abonelik/kontör işleme ve iade testleri ayrı aşama. |

22 Ekim 2026 tarihinde kobivira.com.tr ana sayfasının kamuya açık içeriği de kontrol edildi. Sayfa e-Fatura/e-Arşiv ve ileri e-belgeleri “bağlantı hazırlığı” olarak gösteriyor. Kaynak FeatureCatalog.php de bunu doğruluyor. Bu paket üretim tamamlanmadığı için söz konusu satış ifadelerini değiştirmez.

## Eklenen test alanı

Yol: **Yönetici → Sistem → EDM test alanı → firma seçimi**. Yetkili ücretli Plus/Business firma yöneticisi, e-Belge merkezindeki bağlantıdan yalnız kendi firmasının test alanına geçebilir. KOBİ, deneme, destek ve salt okunur izleme oturumları bu servis işlemlerine açılmadı.

1. Yönetici test VKN/TCKN, kullanıcı adı ve şifreyi girer; kendi Kobivira şifresiyle ayarı kaydeder. Hesap bilgileri uygulama anahtarıyla şifrelenir; geri gösterilmez.
2. “Hesabı, firma eşleşmesini ve bakiyeyi test et” Login → GetCompany → CheckCounter çalıştırır. Başarılı sonuç yalnız bu hesabın ve test firma eşleşmesinin doğrulandığını gösterir; GİB/EDM üretim başvuru onayı değildir.
3. Alıcının VKN/TCKN bilgisiyle CheckUser ve posta kutusu etiketi sorgulanır. Alıcı yanıtının kimliği eşleştirilir.
4. Gönderici bilgileri seçilen test firmasına ait UBL Invoice XML yüklenir. Yükleme gönderim yapmaz ve yerel muhasebeye işlemez. Temel/ticari/e-Arşiv profilleriyle sınırlıdır.
5. Test belge detayından açık onayla gönderilir. e-Faturada etiket EDM yanıtıyla eşleştirilir; kayıtlı e-Fatura alıcısına e-Arşiv seçimi engellenir. Gönderim başladıktan sonra aynı kaydın ikinci gönderimi engellenir; belirsiz sonuçta durum sorgulanır.
6. Gelen test faturaları en fazla 7 günlük aralıkla alınır. Sayfa başına en fazla 100 belge vardır; 100 sonuçta aralık daraltılmalıdır. Hedef VKN eşleşmeden kaydedilmez. UUID/yön/firma benzersizliği ve içerik özeti kontrol edilir.
7. Gelen TICARIFATURA için EDM’nin “RECEIVE - WAIT_APPLICATION_RESPONSE” durumu doğrulandıktan sonra kabul veya gerekçeli ret isteği gönderilebilir. Temel faturaya ticari yanıt düğmesi yoktur. İstek gönderildi bilgisi kabul edilmiş veya ödenmiş anlamına gelmez.

Sabit adres: https://test.edmbilisim.com.tr/EFaturaEDM21ea/EFaturaEDM.svc. Kullanıcı tarafından başka uç nokta yazılamaz. Her uzak işlemde oturum ve firma eşleşmesi yeniden doğrulanır. Birden çok VKN dönen ortak hesaplar, güvenli firma seçimi protokolü gerçek hesapla doğrulanana kadar reddedilir; firma başına ayrılmış test hesabı gerekir.

Yeni alan edm_test_accounts ve edm_test_documents tablolarını kullanır. Test XML’leri de şifrelenir. Muhasebe belgeleri, tahsilat ve yerel kontör defteriyle otomatik bağ kurulmaz. Bu nedenle test paneli üzerinden alınan belge, mevcut gelen fatura muhasebeleştirme ekranına otomatik aktarılmaz. Otomatik durum takibi/zamanlanmış arka plan işi, PDF/XSLT görüntüleme ve canlıya geçiş anahtarı yoktur.

## Teknik doğrulama ve kanıt sınırı

Testlerin ayrıntılı adları Edm361TestResults.json içindedir.

- PHP 8.3/MariaDB ile 33 migration uygulanması ve yeniden çalıştırılması başarılı.
- SOAP istemci testleri sahte taşıyıcıyla yapılmıştır: XML kaçışları, DTD/XXE engeli, hatalı XML/UUID, farklı firma, çoklu firma hesabı, mükellef/etiket eşleşmesi, hata mesajlarında sır sızıntısı ve durum UUID eşleşmesi kontrol edildi.
- Veritabanı/HTTP kontrolleri: oturum, CSRF, yönetici tekrar şifresi, paket, firma ayrımı, şifreli saklama, mükerrer VKN/UUID engeli, XML dosya yükleme ve mükerrer yükleme test edildi. HTTP testleri gerçek EDM servisine bağlanmadı.
- Yerel finans regresyonları: belge toplamı, kısmi/tam iade, tekrar iade engeli, tahsilata bağlı iade limiti, cari ekstre, veri aktarımı ve firma ayrımı geçti. Bu testler ürünün bütün ekranlarının veya tüm satış akışlarının sertifikasyonu değildir.
- 117 PHP dosyası, 21 JavaScript içeriği sözdizimi kontrolünden geçti. 11 CSS dosyası ve mevcut görsel varlıklar değişmedi. Önceki 32 migration ve eski sürüm açıklamaları korundu.
- Güncel test WSDL ve bağımlı XSD’ler indirildi. Servis adresi WSDL GET ile XML verdi. Sekiz oluşturulan SOAP istek gövdesi, ilgili istek türlerinin bağımlılıkları kapatılmış XSD alt kümesiyle doğrulandı. Tam servis XSD’sindeki alakasız GiderPusulasi kalıtım tanımı lxml ile bütün olarak derlenmediği için bu sonuç tam WSDL sertifikasyonu değildir. UBL/GİB Schematron onayı da değildir.
- İmzalı paket, mevcut 3.6.0 güncelleyicisiyle gerçek yerel kurulumdan geçti; değiştirilmiş paket reddedildi. Dosya özetleri, yedek kaydı, 33. migration, paket/fiyat/abonelik/kontör ve özelleştirilmiş site içeriğinin korunması kontrol edildi.

**Dış hesap testi: yapılmadı. Gerçek fatura alım/gönderim: yapılmadı. EDM/GİB üretim onayı: doğrulanmadı. Canlı kurulum: yapılmadı.**

## Firmaların kayıt ve fatura kullanma durumu

Yerel testlerde KOBİ/Plus/Business firmaları oluşturulabildi; abonelik ve paket ayrımları çalıştı. Bu durum kamuya açık canlı kayıt, gerçek e-posta/SMS teslimi, firma belge incelemesi ve EDM başvurusunun onaylandığını kanıtlamaz. Firma şu koşullar tamamlanmadan üretim e-belge kullanıcısı sayılmamalıdır: aktif ve uygun abonelik, firma kimlik/iletişim doğrulaması, EDM müşteri/sözleşme/ürün aktivasyonu, geçerli VKN ve gönderici/alıcı etiketi, gerçek sağlayıcı kontörü, başarılı UBL/iş kuralı doğrulaması ve belge durum takibi.

Mevcut kaynakta firma profil incelemesi ile EDM servis yetkisi aynı onay değildir. Yeni bağlantı kontrolü bu iki süreci birleştirmez. KOBİ paketine e-belge eklemek ayrıca paket/satış kapsamı kararı gerektirir; bu çalışmada paket kapsamı sessizce değiştirilmedi.

## Üretim öncesi tamamlanacak somut işler

Öncelik 1: kullanıcıya ait test bilgilerini admin alanına girip iki ayrılmış test firmasıyla gerçek gönderim, karşı tarafta alım, UUID/durum karşılaştırması, ticari kabul ve ret, temel fatura, e-Arşiv rapor durumu, yanlış şifre, bakiyesizlik ve belirsiz ağ sonucu senaryolarını çalıştırmak. Test hesabı yetkisi veya kayıt sözleşmesi eksikse EDM tarafından açılması gerekir.

Öncelik 2: Kobivira satış/alım kayıtlarıyla UBL üretimi ve doğrulaması; değişmez belge numarası/UUID; taslak-gönderim-sonuç zinciri; gelen belgenin tekrar muhasebeleştirilmesini engelleme; iade/iptal; asenkron durum izleme; gerçek kontör kesintisinin CRM ve yerel defterle mutabakatı. Test paneli bu üretim işlerinin yerine geçmez.

Öncelik 3: Business’ta vaat edilecek e-İrsaliye/e-SMM/e-İhracat ve diğer aktif modüller için ayrı adaptör ve kullanıcı kabul testleri. Tamamlanmayan modüller kullanılabilir özellik olarak satışa açılmamalıdır.

Öncelik 4: PayTR ödeme ve callback testleri, ardından gerçek kurulumda yedek/geri dönüş doğrulaması ve yetkili üretim pilotu. Bu maddeler geçmeden satışa hazır onayı yoktur.

## Kurulum ve dosyalar

Kobivira-guncelleme-3.6.1.zip **yalnız 3.6.0 üzerine** imzalı tam sürüm güncellemesidir. Canlı kurulu sürüm bilinmiyor; farklı sürüme zorla dosya kopyalanmamalıdır. Yönetici → Sistem → Sürüm güncellemeleri üzerinden yüklenir. Normal güncelleyici yedek alır; canlı bakım penceresi ve geri dönüş yedeği uygulama yöneticisinin kontrolündedir. Kurulum sonrasında EDM test ayarları boştur, örnek kullanıcı/şifre yoktur.

EDM test alanı için PHP DOM, HTTPS akışları (allow_url_fopen), geçerli CA deposu ve test.edmbilisim.com.tr:443 erişimi gerekir; mevcut uygulama PHP eklentileri de korunur. Bu sunucu gereksinimleri canlı ortamda henüz doğrulanmadı.

Yeni ana dosyalar: Edm361.php; migrations/033_edm_test.php; Edm361Inventory.json; Edm361TestResults.json; bu rapor. Değişen mevcut dosyalar: Modules.php, Controllers.php, Views.php, ServiceHub.php, Purge.php ve release_history.json. Tasarım varlıkları korunur. Pakete kullanıcı sırları, belge örneği şifreleri veya imzalama özel anahtarı dahil edilmez.
