<?php
declare(strict_types=1);
require_once __DIR__.'/Core.php';require_once __DIR__.'/Brand.php';require_once __DIR__.'/Referral.php';require_once __DIR__.'/Marketing.php';require_once __DIR__.'/site/Core.php';require_once __DIR__.'/site/Controllers.php';require_once __DIR__.'/site/Views.php';require_once __DIR__.'/site/Reviews.php';require_once __DIR__.'/site/Public.php';require_once __DIR__.'/site/Corporate.php';require_once __DIR__.'/PublicSite.php';require_once __DIR__.'/Migrator.php';require_once __DIR__.'/Backup.php';require_once __DIR__.'/Updater.php';require_once __DIR__.'/Installer.php';require_once __DIR__.'/Support.php';require_once __DIR__.'/Help.php';require_once __DIR__.'/Team.php';require_once __DIR__.'/Approvals.php';require_once __DIR__.'/EGuide.php';require_once __DIR__.'/Notice.php';require_once __DIR__.'/Delivery.php';require_once __DIR__.'/Review.php';require_once __DIR__.'/ReleaseHistory.php';require_once __DIR__.'/Customers.php';require_once __DIR__.'/ReadableAudit.php';require_once __DIR__.'/MemberEdit.php';require_once __DIR__.'/Product.php';require_once __DIR__.'/Purge.php';require_once __DIR__.'/LiveDesk.php';require_once __DIR__.'/DeskViews.php';require_once __DIR__.'/Billing.php';require_once __DIR__.'/Commerce.php';require_once __DIR__.'/UpdateViews.php';require_once __DIR__.'/Controllers.php';require_once __DIR__.'/Views.php';require_once __DIR__.'/Workspace.php';require_once __DIR__.'/DocumentLayout.php';require_once __DIR__.'/FinanceReport.php';require_once __DIR__.'/VerificationFlow.php';require_once __DIR__.'/ContactFlow.php';foreach(['CompanyAdmin','Packages','Business','ApprovalRules','BankMatch','EvidenceReview','PaidAccess','Avatar','ImportTable','ImportRecords','IncomingInvoices','DataImport','FeatureCatalog','Currency','Operations','Sharing','Automation','ServiceHub'] as $module)require_once __DIR__.'/'.$module.'.php';
require_once __DIR__.'/Patch348.php';require_once __DIR__.'/Ledger350.php';require_once __DIR__.'/Migration350.php';require_once __DIR__.'/Plan351.php';require_once __DIR__.'/Launch351.php';require_once __DIR__.'/Legal351.php';require_once __DIR__.'/Release352.php';require_once __DIR__.'/Release353.php';
require_once __DIR__.'/Release354.php';

require_once __DIR__.'/Import356.php';require_once __DIR__.'/Refund356.php';

require_once __DIR__.'/Revisions358.php';

require_once __DIR__.'/Cancellation359.php';

require_once __DIR__.'/Guide360.php';

require_once __DIR__.'/Edm361.php';

require_once __DIR__.'/FullBackup367.php';

require_once __DIR__.'/Despatch369.php';require_once __DIR__.'/Despatch369Sample.php';

require_once __DIR__.'/Smm3613.php';require_once __DIR__.'/Smm3613Sample.php';

require_once __DIR__.'/Export3614Client.php';require_once __DIR__.'/Export3614.php';require_once __DIR__.'/Export3614Sample.php';

require_once __DIR__.'/FirmEdoc3615.php';require_once __DIR__.'/FirmEdoc3615Ubl.php';require_once __DIR__.'/FirmEdoc3615Worker.php';require_once __DIR__.'/FirmEdoc3615View.php';

firm3615_register_worker();

require_once __DIR__.'/Package3616.php';

require_once __DIR__.'/FirmEdoc3617.php';

require_once __DIR__.'/Company3618.php';
require_once __DIR__.'/Workspace3619.php';

require_once __DIR__.'/Paytr3623.php';

require_once __DIR__.'/Checkout3624.php';

require_once __DIR__.'/Checkout3626.php';

require_once __DIR__.'/Demo3627.php';

require_once __DIR__.'/EdocForms3629.php';

require_once __DIR__.'/Footer3630.php';


require_once __DIR__.'/Marketing3632.php';

require_once __DIR__.'/Product3633.php';

require_once __DIR__.'/Studio3634.php';

require_once __DIR__.'/QuickEdit3636.php';

require_once __DIR__.'/Tools3639.php';

require_once __DIR__.'/Admin3641.php';

require_once __DIR__.'/Guide3642.php';

require_once __DIR__.'/Email3643.php';

require_once __DIR__.'/Phone3644.php';
require_once __DIR__.'/AuthClock3644.php';

require_once __DIR__.'/Mail3644.php';

require_once __DIR__.'/Mail3645.php';

require_once __DIR__.'/Purge3648.php';

require_once __DIR__.'/Retention3649.php';
retention3649_register();
require_once __DIR__.'/Mail3650.php';
require_once __DIR__.'/Mail3650Admin.php';
mail3650_register();
